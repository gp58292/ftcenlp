import { ConfigurationRoutesModule } from './configuration.routing';
import { ConfigurationService } from './configuration.service';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from "@angular/core";

import { BrowserModule } from "@angular/platform-browser";
import { JsonpModule, HttpModule } from "@angular/http";
import { ReactiveFormsModule, FormsModule } from "@angular/forms";
import { DatepickerModule } from "ngx-bootstrap";

import { CommonModule } from "@angular/common";
import { CheckboxModule } from "primeng/components/checkbox/checkbox";
import { GrowlModule } from "primeng/components/growl/growl";
import { TableModule } from "primeng/table";

import { CalendarModule } from "primeng/components/calendar/calendar";
import { routing } from "../app.routing";
import { InputTextModule, DataTableModule, ButtonModule, DialogModule, ListboxModule, SelectItem, FileUploadModule, RadioButtonModule, InputTextareaModule, PasswordModule } from 'primeng/primeng';
import { AccordionModule, PanelMenuModule, OverlayPanelModule, SharedModule, TabViewModule, FieldsetModule, AutoCompleteModule, ContextMenuModule, SelectButtonModule } from 'primeng/primeng';
import { ConfirmDialogModule, ConfirmationService, MultiSelectModule, ToggleButtonModule, DropdownModule, TooltipModule, SliderModule, CodeHighlighterModule } from 'primeng/primeng';
import { ArchiveComponent } from "./archive/archive.component";

@NgModule({
    declarations: [
        ArchiveComponent

    ],
    imports: [
        BrowserModule,
        FormsModule,
        ReactiveFormsModule,
        HttpModule,
        JsonpModule,
        DatepickerModule,
        InputTextModule,
        DataTableModule,
        ButtonModule,
        DialogModule,
        CalendarModule,
        GrowlModule,
        CheckboxModule,
        ConfigurationRoutesModule,
        CommonModule,
        FormsModule,
        SliderModule,
        DialogModule,
        MultiSelectModule,
        ContextMenuModule,
        DropdownModule,
        ButtonModule,
        GrowlModule,
        InputTextModule,
        TabViewModule,
        CodeHighlighterModule,
        TableModule
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA],
    providers: [
        ConfigurationService
    ]

})


export class ConfigurationModule { }