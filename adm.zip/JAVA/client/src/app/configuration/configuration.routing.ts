import { ArchiveComponent } from './archive/archive.component';
import { ConfigurationComponent } from './configuration.component';
import { PrivatePageGuard } from './../services/private-page.guard';
import { RouterModule, Routes } from '@angular/router';
import { NgModule } from '@angular/core';
const alertsRoutes: Routes = [

    {
        path: 'configuration',
        component: ConfigurationComponent,
        canActivate: [PrivatePageGuard],
        children: [
            {
                path: 'archive',
                component: ArchiveComponent,
                canActivate: [PrivatePageGuard]
            },


            {
                path: '',
                redirectTo: 'archive',
                pathMatch: 'full'
            }
        ]
    },




];

@NgModule({
    imports: [
        RouterModule.forChild(alertsRoutes)
    ],
    exports: [
        RouterModule
    ]
})
export class ConfigurationRoutesModule { }
