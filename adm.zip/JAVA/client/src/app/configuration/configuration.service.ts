import { ArchiveDbForm } from './archive/archive.db.model';
import { ArchiveFileForm } from './archive/archive.file.model';
import { Observable } from 'rxjs/Observable';
import { Injectable } from '@angular/core';
import { MyHttp } from './../services/http';
@Injectable()
export class ConfigurationService {

    constructor(private http: MyHttp) { }

    loadFileTableList(): Observable<any> {
        console.debug("ConfigurationService::loadFileTableList");
        return this.http.get('/api/configuration/archive/files')
            .map((res) => res.json())
            .catch(this.handleError);
    }

    loadDbTableList(): Observable<any> {
        console.debug("ConfigurationService::loadDbTableList");
        return this.http.get('/api/configuration/archive/db')
            .map((res) => res.json())
            .catch(this.handleError);
    }

    editFileArchiveInfo(archiveFileForm: ArchiveFileForm): Observable<any> {
        console.debug("ConfigurationService::editFileArchiveInfo");
        return this.http.put('/api/configuration/archive/file', archiveFileForm)
            .map((res) => res.json())
            .catch(this.handleError);
    }


    editDbArchiveInfo(archiveDbForm: ArchiveDbForm): Observable<any> {
        console.debug("ConfigurationService::editFileArchiveInfo"+archiveDbForm);
        return this.http.put('/api/configuration/archive/db', archiveDbForm)
            .map((res) => res.json())
            .catch(this.handleError);
    }


    insertFileArchiveRec(archiveFileForm: ArchiveFileForm): Observable<any> {
        console.debug("ConfigurationService::insertFileArchiveRec");
        return this.http.post('/api/configuration/archive/file', archiveFileForm)
            .map((res) => res.json())
            .catch(this.handleError);
    }


    insertDbArchiveInfo(archiveDbForm: ArchiveDbForm): Observable<any> {
        console.debug("ConfigurationService::insertDbArchiveInfo",archiveDbForm);
        return this.http.post('/api/configuration/archive/db', archiveDbForm)
            .map((res) => res.json())
            .catch(this.handleError);
    }

    handleError(error: any) {
        let errMsg = (error.message) ? error.message :
            error.status ? `${error.status} - ${error.statusText}` : 'Server error';
        console.log(errMsg);
        return Observable.throw(errMsg);
    }

}

