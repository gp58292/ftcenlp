import { Message } from 'primeng/primeng';
import { ArchiveDbForm } from './archive.db.model';
import { ArchiveFileForm } from './archive.file.model';
import { ConfigurationService } from './../configuration.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-archive',
  templateUrl: './archive.component.html',
  styleUrls: ['./archive.component.scss']
})
export class ArchiveComponent implements OnInit {

  public msgs: Message[] = [];
  public tableTypes: string[] = ['File', 'DB'];
  public tableType: string;
  public fileTableType: Boolean;
  public fileCols: any[] = [];
  public dbCols: any[] = [];

  public fileId: number;
  public dateFormat: String;
  public dateSearchParameter: number;
  public fileNamePattern: String;
  public sourcePath: String;
  public archivePath: String;
  public purgePath: String;
  public archiveFlag: number;
  public archiveDays: number;
  public deleteFlag: number;
  public deleteDays: number;
  public archiveExclusionRule: String;
  public purgingExclusionRule: String;
  public readyFilePattern: String;
  public isActive: number;
  public archiveFileForm: ArchiveFileForm = new ArchiveFileForm(0, '', 0, '', '', '', '', 0, 0, 0, 0, '', '', '');
  public archiveFileList: ArchiveFileForm[];

  public dbId: number;
  public sourceDB: string;
  public sourceTable: string;
  public destinationDB: string;
  public destinationTable: string;
  public queryColumn: string;
  public desiredBatchSize: number;
  public exclusionRuleArchiving: string;
  public exclusionRulePurging: string;
  public archiveDbform: ArchiveDbForm = new ArchiveDbForm(0, '', '', '', '', '', 0, 0, 0, 0, 0, '', '');
  public archiveDbList: ArchiveDbForm[];

  public displayDialog: boolean = false;
  public displayDialogAdd: boolean = false;
  public displayDialogEdit: boolean = false;
  public displayDialogDelete: boolean = false;

  public fileArchiveRecordUpdated: ArchiveFileForm[];
  public dbArchiveRecordUpdated: ArchiveDbForm[];

  constructor(private router: Router, private configurationService: ConfigurationService, private route: ActivatedRoute) {

    this.fileCols = [
      { header: 'Id', field: 'id' },
      { header: 'Date Format', field: 'dateFormat' },
      { header: 'Date Search Parameter ', field: 'dateSearchParameter' },
      { header: 'File Name Pattern', field: 'fileNamePattern' },
      { header: 'Source Path', field: 'sourcePath' },
      { header: 'Archive Path', field: 'archivePath' },
      { header: 'Purge Path', field: 'purgePath' },
      { header: 'Archive Flag', field: 'archiveFlag' },
      { header: 'Archive Days', field: 'archiveDays' },
      { header: 'Delete Flag', field: 'deleteFlag' },
      { header: 'Delete Days', field: 'deleteDays' },
      { header: 'Archive Exclusion Rule', field: 'archive_ExclusionRule' },
      { header: 'Purging Exclusion Rule', field: 'purging_ExclusionRule' },
      { header: 'Ready File Pattern', field: 'readyFilePattern' }



    ],
      this.dbCols = [
        { header: 'Id', field: 'id' },
        { header: 'Source DB', field: 'sourceDB' },
        { header: 'Source Table ', field: 'sourceTable' },
        { header: 'Destination DB', field: 'destDB' },
        { header: 'Destination Table', field: 'destTable' },
        { header: 'Query Column', field: 'queryColumn' },
        { header: 'Archive Flag', field: 'archiveFlag' },
        { header: 'Archive Days', field: 'archiveDays' },
        { header: 'Delete Flag', field: 'deleteFlag' },
        { header: 'Delete Days', field: 'deleteDays' },
        { header: 'Desired Batch size', field: 'desiredBatchSize' },
        { header: 'Archive Exclusion Rule ', field: 'exclusionRule_Archiving' },
        { header: 'Purging Exclusion Rule ', field: 'exclusionRule_Purging' }]
  }


  ngOnInit() {
    this.tableType = 'File';
    this.fileTableType = true;
    this.getFilesTableList();
    this.getDbTableList();
  }


  public tableTypeChange(): void {
    console.debug('ArchiveComponent::tableTypeChange');
    if (this.tableType == 'File') {
      this.fileTableType = true;
    }
    else if (this.tableType == 'DB') {
      this.fileTableType = false;
    }
  }

  //To get the list of archive file tables 
  getFilesTableList(): Observable<any[]> {
    console.debug('ArchiveComponent::getFilesTableList');
    this.configurationService.loadFileTableList()
      .subscribe(res => {
        this.archiveFileList = res;
      })
    return;
  }

  //To get the list of archive DB tables
  getDbTableList(): Observable<any[]> {
    console.debug('ArchiveComponent::getDbTableList');
    this.configurationService.loadDbTableList()
      .subscribe(res => {
        this.archiveDbList = res;
      })
    return;
  }

  //Show the dialog for editing on edit button event click
  editDbArchiveRecord(archiveDbForm: ArchiveDbForm): void {
    console.debug('ArchiveComponent::editDbArchiveRecord');
    this.displayDialog = true;
    this.displayDialogDelete = true;
    this.displayDialogAdd = false;
    this.displayDialogEdit = true;
    this.dbId = archiveDbForm.id;
    this.sourceDB = archiveDbForm.sourceDB;
    this.sourceTable = archiveDbForm.sourceTable;
    this.destinationDB = archiveDbForm.destDB;
    this.destinationTable = archiveDbForm.destTable;
    this.queryColumn = archiveDbForm.queryColumn;
    this.archiveFlag = archiveDbForm.archiveFlag;
    this.archiveDays = archiveDbForm.archiveDays;
    this.deleteFlag = archiveDbForm.deleteFlag;
    this.deleteDays = archiveDbForm.deleteDays;
    this.desiredBatchSize = archiveDbForm.desiredBatchSize;
    this.exclusionRuleArchiving = archiveDbForm.exclusionRule_Archiving;;
    this.exclusionRulePurging = archiveDbForm.exclusionRule_Purging;
    return;
  }


  //Show the dialog for editing on edit button event click
  editFileArchiveRecord(archiveFileform: ArchiveFileForm): void {
    console.debug('ArchiveComponent::editDbArchiveRecord', archiveFileform);
    this.displayDialog = true;
    this.displayDialogDelete = true;
    this.displayDialogAdd = false;
    this.displayDialogEdit = true;
    this.fileId = archiveFileform.id;

    this.dateFormat = archiveFileform.dateFormat;
    this.dateSearchParameter = archiveFileform.dateSearchParameter;
    this.fileNamePattern = archiveFileform.fileNamePattern;
    this.sourcePath = archiveFileform.sourcePath;
    this.archivePath = archiveFileform.archivePath;
    this.purgePath = archiveFileform.purgePath;
    this.archiveFlag = archiveFileform.archiveFlag;
    this.archiveDays = archiveFileform.archiveDays;
    this.deleteFlag = archiveFileform.deleteFlag;
    this.deleteDays = archiveFileform.deleteDays;
    this.archiveExclusionRule = archiveFileform.archive_ExclusionRule;
    this.purgingExclusionRule = archiveFileform.purging_ExclusionRule;
    this.readyFilePattern = archiveFileform.readyFilePattern;
    return;
  }

  clear() {
    this.displayDialog = false;
    this.displayDialogAdd = false;
    this.displayDialogEdit = false;
    this.displayDialogDelete = false;
    this.clearDbArchive();
    this.clearFileArchive();
  }

  clearDbArchive() {
    console.debug('ArchiveComponent::clearDbArchive');
    this.dbId = 0;
    this.sourceDB = '';
    this.sourceTable = '';
    this.destinationDB = '';
    this.destinationTable = '';
    this.queryColumn = '';
    this.archiveFlag = 0;
    this.archiveDays = 0;
    this.deleteFlag = 0;
    this.deleteDays = 0;
    this.desiredBatchSize = 0;
    this.exclusionRuleArchiving = '';
    this.exclusionRulePurging = '';
  }


  clearFileArchive() {
    console.debug('ArchiveComponent::clearFileArchive');
    this.fileId = 0;
    this.dateFormat = '';
    this.dateSearchParameter = 0;
    this.fileNamePattern = '';
    this.sourcePath = '';
    this.archivePath = '';
    this.purgePath = '';
    this.archiveFlag = 0;
    this.archiveDays = 0;
    this.deleteFlag = 0;
    this.deleteDays = 0;
    this.archiveExclusionRule = '';
    this.purgingExclusionRule = '';
    this.readyFilePattern = '';
    this.isActive = 0;

  }

  insertRequest(): void { }

  confirmDelete(): void { }

  submitArchiveEdit(): void {
    console.debug('ArchiveComponent::submitArchiveEdit');
    if (this.fileTableType) {
      this.submitFileArchiveForEdit();
    } else {
      this.submitDbArchiveForEdit();
    }

  }

  archiveFileFormEdit: ArchiveFileForm = new ArchiveFileForm(0, '', 0, '', '', '', '', 0, 0, 0, 0, '', '', '')
  submitFileArchiveForEdit(): void {
    console.debug('ArchiveComponent::submitFileArchiveForEdit');

    this.displayDialogAdd = false;
    this.archiveFileFormEdit.id = this.fileId;
    this.archiveFileFormEdit.dateFormat = this.dateFormat;
    this.archiveFileFormEdit.dateSearchParameter = this.dateSearchParameter;
    this.archiveFileFormEdit.fileNamePattern = this.fileNamePattern;
    this.archiveFileFormEdit.sourcePath = this.sourcePath;
    this.archiveFileFormEdit.archivePath = this.archivePath;
    this.archiveFileFormEdit.purgePath = this.purgePath;
    this.archiveFileFormEdit.archiveFlag = this.archiveFlag;
    this.archiveFileFormEdit.archiveDays = this.archiveDays;
    this.archiveFileFormEdit.deleteFlag = this.deleteFlag;
    this.archiveFileFormEdit.deleteDays = this.deleteDays;
    this.archiveFileFormEdit.archive_ExclusionRule = this.archiveExclusionRule;
    this.archiveFileFormEdit.purging_ExclusionRule = this.purgingExclusionRule;
    this.archiveFileFormEdit.readyFilePattern = this.readyFilePattern;

    this.configurationService.editFileArchiveInfo(this.archiveFileFormEdit)
      .subscribe(res => {
        this.fileArchiveRecordUpdated = res;
        this.clear();
        this.msgs.push({ severity: 'Success', summary: 'Edit Request ', detail: 'File Archive Record Modified' });
      
      })
      this.getFilesTableList();
    return;
  }


  archiveDbFormEdit: ArchiveDbForm = new ArchiveDbForm(0, '', '', '', '', '', 0, 0, 0, 0, 0, '', '');

  submitDbArchiveForEdit(): void {
    console.debug('ArchiveComponent::submitDbArchiveForEdit');
    this.displayDialogAdd = false;
    this.archiveDbFormEdit.id = this.dbId,
      this.archiveDbFormEdit.sourceDB = this.sourceDB,
      this.archiveDbFormEdit.sourceTable = this.sourceTable,
      this.archiveDbFormEdit.destDB = this.destinationDB,
      this.archiveDbFormEdit.destTable = this.destinationTable,
      this.archiveDbFormEdit.queryColumn = this.queryColumn,
      this.archiveDbFormEdit.archiveFlag = this.archiveFlag,
      this.archiveDbFormEdit.archiveDays = this.archiveDays,
      this.archiveDbFormEdit.deleteFlag = this.deleteFlag,
      this.archiveDbFormEdit.deleteDays = this.deleteDays,
      this.archiveDbFormEdit.desiredBatchSize = this.desiredBatchSize,
      this.archiveDbFormEdit.exclusionRule_Archiving = this.exclusionRuleArchiving,
      this.archiveDbFormEdit.exclusionRule_Purging = this.exclusionRulePurging
    this.configurationService.editDbArchiveInfo(this.archiveDbFormEdit)
      .subscribe(res => {
        this.dbArchiveRecordUpdated = res;
        this.clear();
        this.msgs.push({ severity: 'Success', summary: 'Edit Request ', detail: 'DB Archive Record Modified' });
      })
      this.getDbTableList();

    return;

  }


  insertArchive(): void {
    console.debug('ArchiveComponent::insertArchive');

    if (this.fileTableType) {
      this.insertFileArchiveRecord();
    } else {
      this.insertDbArchiveRecord();
    }
  }


  archiveFileFormAdd: ArchiveFileForm = new ArchiveFileForm(0, '', 0, '', '', '', '', 0, 0, 0, 0, '', '', '')
  insertFileArchiveRecord(): void {
    console.debug('ArchiveComponent::submitFileArchiveForEdit');

    this.displayDialogAdd = false;
    this.archiveFileFormAdd.dateFormat = this.dateFormat;
    this.archiveFileFormAdd.dateSearchParameter = this.dateSearchParameter;
    this.archiveFileFormAdd.fileNamePattern = this.fileNamePattern;
    this.archiveFileFormAdd.sourcePath = this.sourcePath;
    this.archiveFileFormAdd.archivePath = this.archivePath;
    this.archiveFileFormAdd.purgePath = this.purgePath;
    this.archiveFileFormAdd.archiveFlag = this.archiveFlag;
    this.archiveFileFormAdd.archiveDays = this.archiveDays;
    this.archiveFileFormAdd.deleteFlag = this.deleteFlag;
    this.archiveFileFormAdd.deleteDays = this.deleteDays;
    this.archiveFileFormAdd.archive_ExclusionRule = this.archiveExclusionRule,
      this.archiveFileFormAdd.purging_ExclusionRule = this.purgingExclusionRule;
    this.archiveFileFormAdd.readyFilePattern = this.readyFilePattern;

    this.configurationService.insertFileArchiveRec(this.archiveFileFormAdd)
      .subscribe(res => {
        this.fileArchiveRecordUpdated = res;
        this.clear();
        this.msgs.push({ severity: 'Success', summary: 'New Request ', detail: 'File Archive Record Added' });
        this.getFilesTableList();
      })
      
    return;
  }

  archiveDbFormAdd: ArchiveDbForm = new ArchiveDbForm(0, '', '', '', '', '', 0, 0, 0, 0, 0, '', '');
  insertDbArchiveRecord(): void {
    console.debug('ArchiveComponent::insertDbArchiveRecord');
    this.displayDialogAdd = false;
    this.archiveDbFormAdd.sourceDB = this.sourceDB,
      this.archiveDbFormAdd.sourceTable = this.sourceTable,
      this.archiveDbFormAdd.destDB = this.destinationDB,
      this.archiveDbFormAdd.destTable = this.destinationTable,
      this.archiveDbFormAdd.queryColumn = this.queryColumn,
      this.archiveDbFormAdd.archiveFlag = this.archiveFlag,
      this.archiveDbFormAdd.archiveDays = this.archiveDays,
      this.archiveDbFormAdd.deleteFlag = this.deleteFlag,
      this.archiveDbFormAdd.deleteDays = this.deleteDays,
      this.archiveDbFormAdd.desiredBatchSize = this.desiredBatchSize,
      this.archiveDbFormAdd.exclusionRule_Archiving = this.exclusionRuleArchiving,
      this.archiveDbFormAdd.exclusionRule_Purging = this.exclusionRulePurging
    this.configurationService.insertDbArchiveInfo(this.archiveDbFormAdd)
      .subscribe(res => {
        this.dbArchiveRecordUpdated = res;
        this.clear();
        this.msgs.push({ severity: 'Success', summary: 'New Request ', detail: 'DB Archive Record Added' });
        this.getDbTableList();
      })
      
    return;

  }



}
