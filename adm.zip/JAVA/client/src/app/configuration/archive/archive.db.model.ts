export class ArchiveDbForm{
    constructor(public id:number,
        public sourceDB:string,
        public sourceTable:string,
        public destDB:string,
        public destTable:string,
        public queryColumn:string,
        public archiveFlag:number,
        public archiveDays:number,
        public deleteFlag:number,
        public deleteDays:number,
        public desiredBatchSize:number,
        public exclusionRule_Archiving:string,
        public exclusionRule_Purging:string){}
}