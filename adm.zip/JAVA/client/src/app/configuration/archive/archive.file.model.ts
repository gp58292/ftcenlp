export class ArchiveFileForm {


    constructor(public id:number,
        public dateFormat: String,
        public dateSearchParameter: number,
        public fileNamePattern: String,
        public sourcePath: String,
        public archivePath: String,
        public purgePath: String,
        public archiveFlag: number,
        public archiveDays: number,
        public deleteFlag: number,
        public deleteDays: number,
        public archive_ExclusionRule: String,
        public purging_ExclusionRule: String,
        public readyFilePattern: String) { }
}