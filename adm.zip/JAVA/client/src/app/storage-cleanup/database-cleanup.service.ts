/**
 * Created by jm27909 on 03/20/2017.
 */
import { Injectable, } from '@angular/core';
import { Observable }     from 'rxjs/Observable';
import "../common/rxjs-operators";
import {MyHttp} from "../services/http";
import {Response} from "@angular/http";

@Injectable()
export class DatabaseCleanupService {

    constructor(private http: MyHttp) { }


    handleError(error: any) {
        // we might use a remote logging infrastructure
        let errMsg = (error.message) ? error.message :
            error.status ? `${error.status} - ${error.statusText}` : 'Server error';
        console.error(errMsg); // log to console instead

        return Observable.throw(errMsg);
    }

    extractUserData(res: Response) {
        let data = res.json();

        return data;
    }

}