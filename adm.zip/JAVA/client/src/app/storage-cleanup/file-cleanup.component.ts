import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { Message, ListboxModule } from 'primeng/primeng';
import { SelectItem } from 'primeng/primeng';
import { InputTextModule } from 'primeng/primeng';
import { SelectButtonModule } from 'primeng/primeng';
import { LoginService } from "../services/login.service";
import { FileCleanupService } from "./file-cleanup.service";
import { UserParams } from "../shared/dto";
import { AutoCompleteModule } from 'primeng/primeng';
import { InputTextareaModule } from 'primeng/primeng';
import { ConfirmDialogModule } from 'primeng/primeng';
import { ConfirmationService } from 'primeng/primeng';
import { TabViewModule } from 'primeng/primeng';


@Component({
    selector: 'file-cleanup',
    templateUrl: './file-cleanup.component.html',
    styleUrls: ['./file-cleanup.component.scss'],
    encapsulation: ViewEncapsulation.None,
    providers: [FileCleanupService],

})
export class FileCleanupComponent {

    public disabled: boolean;
    public displayDialogAdd:boolean; 
    public displayDialogEdit:boolean;
    public data:any;


    constructor(private router: Router, private fileCleanupService: FileCleanupService, private confirmationService: ConfirmationService) {

    }


    public showDialog(){}

}
