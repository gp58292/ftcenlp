import { Component } from '@angular/core';

@Component({
    selector: 'storage-cleanup',
    templateUrl: './nav-bar.component.html'
})

export class NavBarComponent {
    name = 'navbar';
}
