import { Component,OnInit } from '@angular/core';
import {EnvironmentVersion} from "../shared/dto";
import {ReferenceDataService} from "../services/reference-data.service";
import {AppStateService} from "../services/app-state.service";

@Component({
    selector: 'cba-footer',
    styleUrls: ['./footer.component.scss'],
    templateUrl: './footer.component.html'
})

export class FooterComponent {
    name = 'footer';
    env: EnvironmentVersion;
    
    constructor(private refDataService: ReferenceDataService,
                private appStateService:AppStateService) {
        console.debug('FooterComponent::constructor');
    }

    ngOnInit() {
    	console.debug('FooterComponent::ngOnInit ');
    	this.refDataService.subscribeToEnvDetails().subscribe((env: EnvironmentVersion) => {
        	this.env = env;
        	this.appStateService.createAppState(env.buildVersion);
        	
        });        
    }
}
