import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { HomeComponent } from './home/home.component';
import { CalendarComponent } from './calendar/calendar.component'

import { PrivatePageGuard } from './services/private-page.guard';
import { LoginComponent } from './login/login.component';
import { CPCDataComponent } from "./cpc-data/cpc-data.component"
import { DataLoggingComponent } from "./data-logging/data-logging.component"
import { AdminComponent } from "./admin/admin.component"
import { RequestComponent } from "./request/request.component"
import { BatchStatusComponent } from "./batch-status/batch-status.component"
import { DatabaseCleanupComponent } from "./storage-cleanup/database-cleanup.component"
import { FileCleanupComponent } from "./storage-cleanup/file-cleanup.component"
import { BatchAutomationComponent } from "./batch-automation/batch-automation.component"

const appRoutes: Routes = [

    {
        path: '',
        component: LoginComponent
    },
    {
        path: 'login',
        component: LoginComponent
    },
    {
        path: 'cpc-data',
        component: CPCDataComponent,
        canActivate: [PrivatePageGuard],
    },
    {
        path: 'data-logging',
        component: DataLoggingComponent,
        canActivate: [PrivatePageGuard],
    },
    {
        path: 'admin',
        component: AdminComponent,
        canActivate: [PrivatePageGuard],
    },
    {
        path: 'request',
        component: RequestComponent,
        canActivate: [PrivatePageGuard],
    },
    // {
    //     path: 'batch-status',
    //     component: BatchStatusComponent,
    //     canActivate: [PrivatePageGuard],
    // },
    
    {
        path: 'storage-cleanup',
        component: HomeComponent,
        canActivate: [PrivatePageGuard],
        children: [
            {
                path: 'database-cleanup',
                component: DatabaseCleanupComponent,
                canActivate: [PrivatePageGuard],
            },
            {
                path: 'file-cleanup',
                component: FileCleanupComponent,
                canActivate: [PrivatePageGuard],
            }
        ]
    },


];

export const appRouterProviders: any[] = [];

export const routing: ModuleWithProviders =
    RouterModule.forRoot(appRoutes);
