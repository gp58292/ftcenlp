/**
 * Created by jm27909 on 11/8/2016.
 */
import {Component, OnInit, ViewEncapsulation} from '@angular/core';
import {FormGroup, FormControl, FormBuilder, Validators} from '@angular/forms';
import {Message} from 'primeng/primeng';
import {AdminService} from "./admin.service";
import { Router } from '@angular/router';
import {UserParams} from "../shared/dto";
import {Data} from './data';
import {MultiSelectModule} from 'primeng/primeng';
import {SelectItem} from 'primeng/primeng';
import {DropdownModule} from 'primeng/primeng';
import {TooltipModule} from 'primeng/primeng';
import {ToggleButtonModule} from 'primeng/primeng';
import {ConfirmDialogModule} from 'primeng/primeng';
import {ConfirmationService} from 'primeng/primeng';
import {LoginService} from "../services/login.service";

@Component({
    selector: 'admin',
    templateUrl: './admin.component.html',
    styleUrls: ['./admin.component.scss'],
    encapsulation: ViewEncapsulation.None,
    providers: [AdminService, ConfirmationService],

})
export class AdminComponent implements OnInit {

    public data: Data[];
 
    public userSOEID:string;
    //to display add or delete pop up menu    
    public displayDialogAdd: boolean = false;
    public displayDialogEdit: boolean = false;
    public displayDialog: boolean = false;
    //store drop down items 
    public permissions: SelectItem[];
    public scrollHeight:string='150px';

    
    public totalUsers:number=0;
    // private entitlement_adminPage:number=0;
    // private entitlement_batchstatusPage:number=0;
    // private entitlement_cpcdataPage:number=0;
    // private entitlement_dataloggingPage:number=0;
    // private entitlement_accessrequestPage:number=0;
    public msgs: Message[] = [];
    public doesExist: boolean = false;
    public selectedRecord: Data;
    public disabled = true;



    constructor(private router: Router, private adminService: AdminService, private confirmationService: ConfirmationService, private loginService:LoginService) {
        this.permissions = [];
        
        //this.permissions.push({ label: 'None', value: 'None' });
        this.permissions.push({ label: 'Yes', value: 1 });
        this.permissions.push({ label: 'No', value: 0 });
        this.userSOEID=this.loginService.getUserParams().soeid;
    }

    ngOnInit(): void {
        this.loadData();

        return;
    }

    //used to show the add delete menu for admin
    showDialog() {
        this.displayDialog = true;

        return;
    }

    //initially load data from admin table when page loads
    loadData() {
        document.body.style.cursor='progress';
        this.adminService.loadData()
            .subscribe(res => {
                this.data = res;
                this.totalUsers=this.data.length;
                this.scrollHeight=(this.totalUsers*10 +30)+'px';
                document.body.style.cursor='default';
            })

        return;
    }
}
