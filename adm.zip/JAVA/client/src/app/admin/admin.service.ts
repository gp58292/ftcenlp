/**
 * Created by jm27909 on 11/8/2016.
 */
import "../common/rxjs-operators";
import { Injectable, } from '@angular/core';
import { Observable }     from 'rxjs/Observable';
import {MyHttp} from "../services/http";
import {Data} from './data'

import {Response} from "@angular/http";

@Injectable()
export class AdminService {

    constructor(private http: MyHttp) { }

    loadData(): Observable<Data[]> {

        return this.http.get(`/api/adm/getAdminList`)
            .map(this.extractUserData)
            .catch(this.handleError);
    }
    
    insertAdmin(soeid, readPermission,writePermission,entitlement): Observable<Data[]> {
        const data = {
            soeid: soeid,
            readPermission: readPermission,
            writePermission: writePermission,
            entitlement: entitlement                                    
        };

        return this.http.post(`/api/adm/insertAdmin`, data)
            .map(this.extractUserData)
            .catch(this.handleError);
    }
    
    deleteAdmin(soeid,entitlement): Observable<Data[]> {
        return this.http.delete(`/api/adm/deleteAdmin/soeid/`+soeid+`/entitlement/`+entitlement)
            .map(this.extractUserData)
            .catch(this.handleError);
    }

    editAdminDetails(data: any): Observable<Data[]> {
        // const data = {
        //     soeid: soeid,
        //     readPermission: readPermission,
        //     writePermission: writePermission,
        //     entitlement: entitlement                 
        // };
        console.log(data);
        return this.http.put(`/api/adm/editAdmin`,data)
            .map(this.extractUserData)
            .catch(this.handleError);
        
    }

    handleError(error: any) {
        // we might use a remote logging infrastructure
        let errMsg = (error.message) ? error.message :
            error.status ? `${error.status} - ${error.statusText}` : 'Server error';
        console.error(errMsg); // log to console instead

        return Observable.throw(errMsg);
    }

    extractUserData(res: Response) {
      
        let data = res.json();

        return data;
    }
}