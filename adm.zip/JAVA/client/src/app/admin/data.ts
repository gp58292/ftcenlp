export class Data {
    
    constructor(
    		
    		public  soeid?:string,
			public  friendly_name?: string,    		
			public  lastUpdateDate?: string,			
			public admin?:string,
			public batchstatus?:string,
			public cpcdata?:string,
			public datalogging?:string,
			public accessrequest?:string,
    ){}

}