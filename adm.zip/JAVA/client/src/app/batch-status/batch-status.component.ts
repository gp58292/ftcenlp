/**
 * Created by jm27909 on 11/8/2016.
 */
import { Component, OnInit } from '@angular/core';
import { DatePipe } from '@angular/common';
import { BatchStatusService } from "./batch-status.service";
import { Data } from './data';
import { BatchAutomationConfigForm } from '../batch-automation/batch-automation-config.model';


@Component({
	selector: 'batch-status',
	templateUrl: './batch-status.component.html',
	styleUrls: ['./batch-status.component.scss'],
	providers: [BatchStatusService, DatePipe],
})

export class BatchStatusComponent implements OnInit {

	public cobDate: Date = new Date();
	public data: Data[] = []; //daily batch status data
	private cobDateString: string = "20170613";
	public response: boolean;
	public configForm: BatchAutomationConfigForm;
	public cols: any[] = [];

	constructor(private batchstatusService: BatchStatusService,
		private datepipe: DatePipe) {

		this.cols = [
			{ header: 'Feed/Data', field: 'jobName', style: { 'text-align': 'center', 'width': '35%' }, editable: false },
			{ header: 'SLA', field: 'sla', style: { 'text-align': 'center', 'width': '10%' }, editable: false },
			{ header: 'Actual Time', field: 'actualTime', style: { 'text-align': 'center', 'width': '10%' }, editable: true },
			{ header: 'Status', field: 'status', style: { 'text-align': 'center', 'width': '10%' }, editable: false },
			{ header: 'Comment', field: 'comment', style: { 'text-align': 'center', 'width': '35%' }, editable: true },
		];
	}

	ngOnInit(): void {
	}

	loadData(cobDate: String) {
		this.batchstatusService.loadData(cobDate)
			.subscribe(res => {
				this.data = res;
			})
		return;
	}



	showBatchStatus(): void {
		let latest_date = this.datepipe.transform(this.cobDate, 'yyyyMMdd');
		console.log(latest_date);
		this.loadData(latest_date);
	}

	emailBatchStatus(): void {
		let latest_date = this.datepipe.transform(this.cobDate, 'yyyyMMdd');
		let emailData = {
			'cobDate': latest_date,
			'jobData': this.data,
			'configForm': null
		}
		this.batchstatusService.sendMailData(emailData)
			.subscribe(res => {
				this.response = res;
			});
	}



}

