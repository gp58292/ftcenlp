export class Data {
    
    constructor(
        public jobName: string,
        public sla: string,
        public actualTime: string,
        public status: boolean,
        public comment: string
        
    ){}

}