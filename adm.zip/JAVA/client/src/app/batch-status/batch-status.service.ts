/**
 * Created by gp47905 on 20/7/2016.
 */
import "../common/rxjs-operators";
import { Injectable, } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { MyHttp } from "../services/http";
import { Data } from './data'

import { Response } from "@angular/http";

@Injectable()
export class BatchStatusService {

    constructor(private http: MyHttp) { }

    loadData(cobDate: String): Observable<Data[]> {
        return this.http.get('/api/batchstatus/getBatchStatusDetails/' + cobDate)
            .map(res => res.json())
            .catch(this.handleError);
    }

    sendMailData(emailData: any): Observable<boolean> {
        return this.http.post('/api/batchstatus/sendBatchEmail', emailData)
            .map(res => res.json())
            .catch(this.handleError);
    }

    handleError(error: any) {
        // we might use a remote logging infrastructure
        let errMsg = (error.message) ? error.message :
            error.status ? `${error.status} - ${error.statusText}` : 'Server error';
        console.error(errMsg); // log to console instead

        return Observable.throw(errMsg);
    }
}