import { Component, ViewEncapsulation } from '@angular/core';

@Component({
    selector: 'cba-admin',
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class AppComponent {
    name = 'cba-admin';
}
