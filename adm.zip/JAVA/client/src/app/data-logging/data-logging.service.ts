/**
 * Created by jm27909 on 03/20/2017.
 */
import { Injectable, } from '@angular/core';
import { Observable }     from 'rxjs/Observable';
import "../common/rxjs-operators";
import {MyHttp} from "../services/http";
import {Data} from './data';
import {Response} from "@angular/http";

@Injectable()
export class DataLoggingService {

    constructor(private http: MyHttp) { }

    searchDB(cbaDB, raceDB, futureDB, slDB, numberOfRows): Observable<Data[]> {
        return this.http.get(`/api/datalogging/searchdb/d1/` + cbaDB + `/d2/` + raceDB + `/d3/` + futureDB + `/d4/` + slDB + `/numRows/` + numberOfRows)
            .map(this.extractUserData)
            .catch(this.handleError);
    }

    searchDBAndStoreProcedure(cbaStoreProc, raceStoreProc, futureStoreProc, slStoreProc, numberOfRows): Observable<Data[]> {
        return this.http.get(`/api/datalogging/searchDBAndStoreProcedure/p1/` + cbaStoreProc + `/p2/` + raceStoreProc + `/p3/` + futureStoreProc + `/p4/` + slStoreProc + `/numRows/` + numberOfRows)
            .map(this.extractUserData)
            .catch(this.handleError);
    }
    filterProcList(cbaquery, racequery,futurequery,slquery): Observable<Data[]> {
        return this.http.get(`/api/datalogging/filterProcList/` + cbaquery + '/' + racequery+'/'+futurequery+'/'+slquery)
            .map(this.extractUserData)
            .catch(this.handleError);
    }

    handleError(error: any) {
        // we might use a remote logging infrastructure
        let errMsg = (error.message) ? error.message :
            error.status ? `${error.status} - ${error.statusText}` : 'Server error';
        console.error(errMsg); // log to console instead

        return Observable.throw(errMsg);
    }

    extractUserData(res: Response) {
        let data = res.json();

        return data;
    }

}