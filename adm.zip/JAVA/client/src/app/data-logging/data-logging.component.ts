/**
 * Created by jm27909 on 03/20/2017.
 */
import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { Message, ListboxModule } from 'primeng/primeng';
import { InputTextModule } from 'primeng/primeng';
import { SelectButtonModule } from 'primeng/primeng';
import { DataLoggingService } from "./data-logging.service";
import { LoginService } from "../services/login.service";
import { Data } from './data';
import { UserParams } from "../shared/dto";
import { AutoCompleteModule } from 'primeng/primeng';
import { Subscription } from 'rxjs';
import { SelectItem } from 'primeng/api';
@Component({
    selector: 'data-logging',
    templateUrl: './data-logging.component.html',
    styleUrls: ['./data-logging.component.scss'],
    encapsulation: ViewEncapsulation.None,
    providers: [DataLoggingService],

})
export class DataLoggingComponent implements OnInit {


    public data: Data[];
    public msgs: Message[] = [];
    public databases: SelectItem[];
    public selectedDatabases: string[] = ['CBA', 'RACE', 'Future', 'SL'];
    public selectedProcedureNames: string[] = [];
    public cbaStoreProc: string;
    public raceStoreProc: string;
    public futureStoreProc: string;
    public slStoreProc: string;
    public storeProc: string;
    public cbaDB: string;
    public raceDB: string;
    public futureDB: string;
    public slDB: string;
    public numberOfRows: number = 50;
    public totalRecords: number = 0;
    public filteredCBAProcs: any[];
    public filteredRACEProcs: any[];
    public filteredFutureProcs: any[];
    public filteredSLProcs: any[];
    public allProcs: any[];
    public cba: string = 'CBA';
    public race: string = 'RACE';
    public future: string = 'Future';
    public sl: string = 'SL';
    public cols: any[] = [];

    constructor(private router: Router, private dataLoggingService: DataLoggingService, private builder: FormBuilder, private loginService: LoginService) {
        this.databases = [];

        this.databases.push({ label: 'CBA', value: 'CBA' });
        this.databases.push({ label: 'RACE', value: 'RACE' });
        this.databases.push({ label: 'Future', value: 'Future' });
        this.databases.push({ label: 'SL', value: 'SL' });
        
    
        this.cols = [
            { header: 'Database Name', field: 'databaseName', style: { 'text-align': 'left', 'width': '7%' }, sortable: true },
            { header: 'Schema Name', field: 'schemaName', style: { 'text-align': 'left', 'width': '7%' }, sortable: true },
            { header: 'Proedure Name', field: 'procedureName', style: { 'text-align': 'left', 'width': '20%' }, sortable: true },
            { header: 'Step Name', field: 'stepName', style: { 'text-align': 'left', 'width': '22%' } },
            { header: 'Record Count', field: 'recordCount', style: { 'text-align': 'right', 'width': '5%' } },
            { header: 'User Name', field: 'userName', style: { 'text-align': 'left', 'width': '8%' } },
            { header: 'Log Time', field: 'logTime', style: { 'text-align': 'right', 'width': '7%' }, sortable: true },
            { header: 'Error Line', field: 'errorLine', style: { 'text-align': 'right', 'width': '4%' } },
            { header: 'Error Message', field: 'errorMessage', style: { 'text-align': 'left', 'width': '20%' }, },
        ];

    }

    ngOnInit(): void {
        document.body.style.cursor = 'progress';



        this.dataLoggingService.searchDB('CBA', 'RACE', 'Future', 'SL', this.numberOfRows)
            .subscribe(res => {
                this.data = res;
                this.totalRecords = this.data.length;
                this.msgs.push({ severity: 'success', summary: 'Search Completed', detail: 'Retrieved top 200 records for selected Databases' });
                document.body.style.cursor = 'default';
            })

        //   this.selectedDatabases = ['CBA', 'RACE', 'Future', 'SL'];

        return;
    }


    //TODO optimize the autocomeplete 
    //autocomplete for filling in stored procedures should check which DB to look into for the stored procedure
    filterProcList(event, dbName) {
        let query = event.query;
        let cbaquery = query;
        let racequery = query;
        let futurequery = query;
        let slquery = query;

        // If database is not select set query to 'xxxxx' for that DB so no stored procedures are returned.

        if (this.selectedDatabases.indexOf('CBA') < 0) {
            cbaquery = 'xxxxx'
        }
        if (this.selectedDatabases.indexOf('RACE') < 0) {
            racequery = 'xxxxx'
        }
        if (this.selectedDatabases.indexOf('Future') < 0) {
            futurequery = 'xxxxx'
        }
        if (this.selectedDatabases.indexOf('SL') < 0) {
            slquery = 'xxxxx'
        }

        this.dataLoggingService.filterProcList(cbaquery, racequery, futurequery, slquery)
            .subscribe(res => {

                this.allProcs = res;

            })

        return;
    }

    //basically to split up search functions so all checking and validation is done within this function
    preSearchValidation(refresh?: number) {

        this.totalRecords = 0;
        // Do not reset the data.
        this.data = [];

        this.cbaDB = null;
        this.raceDB = null;
        this.futureDB = null;
        this.slDB = null;
        this.selectedProcedureNames = [];
        this.cbaStoreProc = null;
        this.raceStoreProc = null;
        this.futureStoreProc = null;
        this.slStoreProc = null;


        if (this.selectedDatabases.indexOf('CBA') >= 0) {
            this.cbaStoreProc = this.storeProc != '' ? this.storeProc : null;

        }

        if (this.selectedDatabases.indexOf('RACE') >= 0) {
            this.raceStoreProc = this.storeProc != '' ? this.storeProc : null;
        }


        if (this.selectedDatabases.indexOf('Future') >= 0) {
            this.futureStoreProc = this.storeProc != '' ? this.storeProc : null;
        }


        if (this.selectedDatabases.indexOf('SL') >= 0) {
            this.slStoreProc = this.storeProc != '' ? this.storeProc : null;
        }






        //to check which stored procedure were selected to send to stored procedure as parameter 
        if (this.cbaStoreProc != null) {
            this.selectedProcedureNames.push(this.cbaStoreProc);
        }
        if (this.raceStoreProc != null) {
            this.selectedProcedureNames.push(this.raceStoreProc);
        }
        if (this.futureStoreProc != null) {
            this.selectedProcedureNames.push(this.futureStoreProc);
        }
        if (this.slStoreProc != null) {
            this.selectedProcedureNames.push(this.slStoreProc);
        }

        //to check which databases were selected to send to stored procedure as parameter

        if (this.selectedDatabases.indexOf('CBA') >= 0) {
            this.cbaDB = 'CBA';
        }
        if (this.selectedDatabases.indexOf('RACE') >= 0) {
            this.raceDB = 'RACE';
        }
        if ((this.selectedDatabases.indexOf('Future') >= 0)) {
            this.futureDB = 'Future';
        }
        if ((this.selectedDatabases.indexOf('SL') >= 0)) {
            this.slDB = 'SL';
        }


        return;
    }

    search() {
        document.body.style.cursor = 'progress';

        //error checking prior to search
        this.preSearchValidation();

        //if no database is selected and no proc is selected throw an error message
        if (this.selectedDatabases.length < 1 && this.selectedProcedureNames.length < 1) {
            this.msgs.push({ severity: 'error', summary: 'Data Missing', detail: 'Database Selection or procedure Name Required' });
            document.body.style.cursor = 'default';
            return;
        }

        //if procedure is selected with improper database selection throw error message
        if ((this.cbaStoreProc != null && this.cbaDB == null)
            || (this.raceStoreProc != null && this.raceDB == null)
            || (this.futureStoreProc != null && this.futureDB == null)
            || (this.slStoreProc != null && this.slDB == null)) {
            this.msgs.push({ severity: 'error', summary: 'Data Missing', detail: 'Missing Proper Database Selection' });
            document.body.style.cursor = 'default';
            return;
        }

        //if no database is selected and 1 or more proc is selected throw an error message	
        if (this.selectedDatabases.length < 1 && this.selectedProcedureNames.length >= 1) {
            this.msgs.push({ severity: 'error', summary: 'Data Missing', detail: 'Database Selection Required' });
            document.body.style.cursor = 'default';
            return;
        }

        //if the number of chosen criteria does not match ie. if 2 stored procedures are chosen there should be 2 databases chosen throw error message
        if ((this.selectedDatabases.length >= 1 && this.selectedProcedureNames.length >= 1) && this.selectedDatabases.length != this.selectedProcedureNames.length) {
            this.msgs.push({ severity: 'error', summary: 'Data Missing', detail: 'Selection chosen does not match' });
            document.body.style.cursor = 'default';
            return;
        }

        //only database search for top 50 of which ever database chosen 
        if (this.selectedDatabases.length >= 1 && this.selectedProcedureNames.length < 1) {
            this.dataLoggingService.searchDB(this.cbaDB, this.raceDB, this.futureDB, this.slDB, this.numberOfRows)
                .subscribe(res => {
                    this.data = res;
                    this.totalRecords = this.data.length;
                    document.body.style.cursor = 'default';
                })

            this.msgs.push({ severity: 'success', summary: 'Top ' + this.numberOfRows + ' from databases', detail: 'Retrieved top ' + this.numberOfRows + ' records from ' + this.selectedDatabases });

            return;
        }

        // console.log(this.cbaStoreProc+' '+this.raceStoreProc+' '+this.futureStoreProc+' '+this.slStoreProc+''+this.numberOfRows);
        // database and stored procedure chosen 
        if (this.selectedDatabases.length >= 1 && this.selectedProcedureNames.length >= 1) {
            this.dataLoggingService.searchDBAndStoreProcedure(this.cbaStoreProc, this.raceStoreProc, this.futureStoreProc, this.slStoreProc, this.numberOfRows)
                .subscribe(res => {
                    this.data = res;
                    this.totalRecords = this.data.length;
                    document.body.style.cursor = 'default';
                })

            this.msgs.push({ severity: 'success', summary: 'Search Completed', detail: 'Successfully Retrieved Records with specified Stored Procedure' });

            return;
        }
    }

    clear() {
        this.totalRecords = 0;
        this.numberOfRows = 50;

        this.dataLoggingService.searchDB('CBA', 'RACE', 'Future', 'SL', this.numberOfRows)
            .subscribe(res => {
                this.data = res;
                this.totalRecords = this.data.length;
                this.msgs.push({ severity: 'success', summary: 'Search Completed', detail: 'Retrievied top 200 records for selected Databases' });
            })

        this.selectedDatabases = ['CBA', 'RACE', 'Future', 'SL'];
        this.selectedProcedureNames = [];
        this.cbaStoreProc = null;
        this.raceStoreProc = null;
        this.futureStoreProc = null;
        this.slStoreProc = null;
        this.storeProc = null;

        return;

    }
}
