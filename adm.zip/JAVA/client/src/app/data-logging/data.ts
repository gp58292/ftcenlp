export class Data {
    
    constructor(
    		
    		public  databaseName:string,
    		public  schemaName:string,
    		public  procedureName:string,
    		public  stepName:string,
    		public  recordCount: string,
    		public  logTime:string,
    		public  userName:string,
    		public  errorLine:string,
    		public  errorMessage:string

    ){}

}