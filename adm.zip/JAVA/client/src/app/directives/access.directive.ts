import { Component, HostBinding, Input, Directive, ElementRef } from '@angular/core';

import {LoginService} from "../services/login.service";

@Directive({
  selector: '[accessRoles]'
})

export class AccessDirective {
	
    //@HostBinding('hidden') hideRouterLink: boolean = true;
	removeLink: boolean = true;
    
    @Input() accessRoles;
    
    constructor(private loginService: LoginService, private _elementRef: ElementRef) {
    	console.debug('AccessDirective::constructor');
    }
    
    ngOnInit() {
    	console.debug('AccessDirective::ngOnInit');
    	//let role = this.loginService.getUserRole();		

		let businesscritical:string[] = this.loginService.getBusinessCritical();
		
		// Check if the access role exists in the business critical pages entitlement 
		if(businesscritical.indexOf(this.accessRoles)>=0){
			this.removeLink = false;
			
		}

		// The access role may also be only for tech pages. Check if the user has access to the techpages.If so set this.removeLink=false.
		if(this.accessRoles='tech_pages' && this.removeLink){
			this.removeLink= !(this.loginService.getTechnicalPagesPermission()==1);
		}


				 		   	
    	if(this.removeLink) {
    		let el: HTMLElement = this._elementRef.nativeElement;
	    	if(el.parentNode) {
	    		el.parentNode.removeChild(el);
	    	}
    	}
    }
  
}