import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from "@angular/core";

import { BrowserModule } from "@angular/platform-browser";
import { JsonpModule, HttpModule } from "@angular/http";
import { ReactiveFormsModule, FormsModule } from "@angular/forms";
import { DatepickerModule } from "ngx-bootstrap";

import { CommonModule } from "@angular/common";
import { CheckboxModule } from "primeng/components/checkbox/checkbox";
import { GrowlModule } from "primeng/components/growl/growl";
import { TableModule } from "primeng/table";

import { CalendarModule } from "primeng/components/calendar/calendar";
import { routing } from "../app.routing";
import { InputTextModule, DataTableModule, ButtonModule, DialogModule, ListboxModule, SelectItem, FileUploadModule, RadioButtonModule, InputTextareaModule, PasswordModule } from 'primeng/primeng';
import { AccordionModule, PanelMenuModule, OverlayPanelModule, SharedModule, TabViewModule, FieldsetModule, AutoCompleteModule, ContextMenuModule, SelectButtonModule } from 'primeng/primeng';
import { ConfirmDialogModule, ConfirmationService, MultiSelectModule, ToggleButtonModule, DropdownModule, TooltipModule,SliderModule,CodeHighlighterModule } from 'primeng/primeng';

import { DownstreamNotificationComponent } from "./downstream-notification/downstream-notification.component";
import { UserNotificationComponent } from "./user-notification/user-notification.component";
import { BatchAutomationRoutesModule } from "./batch-automation.routing";
import { BatchAutomationService } from "./batch-automation.service";
import { ConfigComponent } from "./config/config.component";
import { BatchDelayComponent } from "./batch-delay/batch-delay.component";



@NgModule({
   declarations: [
    BatchDelayComponent,
    DownstreamNotificationComponent,
    UserNotificationComponent,
    ConfigComponent,
    
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    HttpModule,
    JsonpModule,
    DatepickerModule,
    InputTextModule,
    DataTableModule,
    ButtonModule,
    DialogModule,
    CalendarModule,
    GrowlModule,
    CheckboxModule,
    BatchAutomationRoutesModule,
    CommonModule,
		FormsModule,
		SliderModule,
		DialogModule,
		MultiSelectModule,
		ContextMenuModule,
		DropdownModule,
		ButtonModule,
		GrowlModule,
		InputTextModule,
		TabViewModule,
    CodeHighlighterModule,
    TableModule
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  providers: [
    BatchAutomationService
  ]

})


export class BatchAutomationModule { }