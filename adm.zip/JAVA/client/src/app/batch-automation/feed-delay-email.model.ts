import { BatchAutomationConfigForm } from './batch-automation-config.model';
import { DashboardResponseData } from "./response-dashboard-data.model";
import { BatchDelayForm } from "./batch-delay-form.model";

export class FeedDelayEmailForm {

    constructor(public feedDelayForm: BatchDelayForm,
        public cbaDashboardResponseData: DashboardResponseData[],
        public slDashboardResponseData: DashboardResponseData[],
        public reportResponseData: DashboardResponseData[],
        public cadResponseData: DashboardResponseData[],
        public feedResponseData: DashboardResponseData[],
        public configForm: BatchAutomationConfigForm) { }
}