import { BatchAutomationConfigForm } from './../batch-automation-config.model';
import { Component, OnInit, EventEmitter, Output, OnDestroy } from '@angular/core';
import { DashboardResponseData } from "../response-dashboard-data.model";
import { BatchAutomationService } from "../batch-automation.service";
import { Observable } from "rxjs/Observable";
import { BatchDelayForm } from '../batch-delay-form.model';
import { FeedDelayEmailForm } from '../feed-delay-email.model';
import { Message, ListboxModule } from 'primeng/primeng';

@Component({
  selector: 'app-downstream-notification',
  templateUrl: './downstream-notification.component.html',
  styleUrls: ['./downstream-notification.component.scss']
})
export class DownstreamNotificationComponent implements OnInit, OnDestroy {
  public feedDataCols: any[] = [];
  public feedData: Observable<any[]>;
  public columns: string[];
  public title: string = "Impact";
  public feedResponseData: DashboardResponseData[] = [];
  public message: boolean = false;
  public formSubmission = new BatchDelayForm(null,'', '', '', '', '', '','');
  public formSubmissionMsg: Boolean = false;
  public dnEmailForm: FeedDelayEmailForm = undefined;
  public selectionFormatState: any;
  public dnMailFlag: boolean = false;
  public msgs: Message[] = [];

  constructor(private batchAutomationService: BatchAutomationService) {
    this.feedDataCols = [
      { header: 'Feed/Data', field: 'name', style: { 'text-align': 'center', 'width': '25%' }, editable: false },
      { header: 'BAU', field: 'bau', style: { 'text-align': 'center', 'width': '15%' }, editable: false },
      { header: 'SLA Time', field: 'sla', style: { 'text-align': 'center', 'width': '15%' }, editable: false },
      { header: 'ETA/Status', field: 'eta', style: { 'text-align': 'center', 'width': '10%' }, editable: true }
    ]
  }

  ngOnInit() {
    this.listNotificationForm();
  }

  private listNotificationForm(): void {
    this.batchAutomationService
      .notifiedDNByFormSubmission()
      .subscribe(formSubmission => {
        this.formSubmission = formSubmission;
        if (this.formSubmission && this.formSubmission.issue != '') {
          this.feedData = this.getFeedData();
          this.formSubmissionMsg = true;
        }
      });

  }

  //Get FEED/DATA sources
  getFeedData(): Observable<any[]> {
    console.debug("DelayResponseComponent::getFeedData");
    this.batchAutomationService.loadFeedData()
      .subscribe(res => {
        this.feedResponseData = res;
      })
    return;
  }

  //send email for the delay feeds
  emailDNReport(): void {
    console.debug("UserNotificationComponent::getClientAlertDashboardData");
    console.debug("FeedResponse Data ", this.feedData);
    this.dnEmailForm = new FeedDelayEmailForm(this.formSubmission, null, null, null, null, this.feedResponseData, null);
    this.batchAutomationService.sendDNMailData(this.dnEmailForm).subscribe(res => {
      this.dnMailFlag = res;
      if (this.dnMailFlag) {
        this.msgs.push({ severity: 'success', summary: 'Email Sent', detail: 'Email sent to the downstream' });
      }
      else {
        this.msgs.push({ severity: 'error', summary: 'Email Not Sent', detail: 'Email is not sent to the downstream' });
      }
    })



    return;
  }

  //Get classes for CSS based on conditions
  getCSSClasses(value: string) {
    let cssClasses;
    if (value == 'Available') {
      cssClasses = {
        'greenClass': true,
        'yellowClass': false
      }
    }
    else if (value == 'Available in Second Refresh') {
      cssClasses = {
        'greenClass': true,
        'yellowClass': false
      }
    }
    else {
      cssClasses = {
        'greenClass': false,
        'yellowClass': true
      }
    }
    return cssClasses;
  }

  ngOnDestroy(): void {
    this.feedResponseData = [];
    this.formSubmissionMsg = false;
    this.formSubmission = new BatchDelayForm(null,'', '', '', '', '', '','');
    this.dnEmailForm = undefined;
    this.dnMailFlag = false;

  }

}
