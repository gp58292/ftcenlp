import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DownstreamNotificationComponent } from './downstream-notification.component';

describe('DownstreamNotificationComponent', () => {
  let component: DownstreamNotificationComponent;
  let fixture: ComponentFixture<DownstreamNotificationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DownstreamNotificationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DownstreamNotificationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
