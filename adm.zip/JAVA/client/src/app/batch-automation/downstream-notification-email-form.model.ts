import { DashboardResponseData } from "./response-dashboard-data.model";
import { BatchDelayForm } from "./batch-delay-form.model";

export class DownstreamNotificationEmailForm {

    constructor(public feedDelayForm: BatchDelayForm,
        public feedResponseData: DashboardResponseData[]
       ) { }
}