/**
 * @author ak92283 
 */
import { BatchAutomationConfigForm } from './batch-automation-config.model';
import "../common/rxjs-operators";
import { Injectable, } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { MyHttp } from "../services/http";


import { Response } from "@angular/http";
import { BehaviorSubject } from "rxjs/BehaviorSubject";
import { FeedDelayEmailForm } from "./feed-delay-email.model";
import { Subject } from "rxjs/Rx";
import { BatchDelayForm } from "./batch-delay-form.model";
import * as loadash from 'lodash';



@Injectable()
export class BatchAutomationService {

    constructor(private http: MyHttp) { }

    private batchDelayForm: BatchDelayForm;
    private currentBatchDelayForm: BatchDelayForm;
    //To send notification from one component to another
    private formSubmitSubject = new BehaviorSubject<BatchDelayForm>(undefined);
    private configSubject = new BehaviorSubject<BatchAutomationConfigForm>(undefined);
    COBDates: Observable<any>;

    notifyUNForFormSubmission(message: BatchDelayForm) {
        this.currentBatchDelayForm = message;
        this.formSubmitSubject.next(message);
    }

    notifiedUNByFormSubmission(): Observable<any> {
        return this.formSubmitSubject.asObservable();
    }

    notifyDNForFormSubmission(message: BatchDelayForm) {
        this.currentBatchDelayForm = message;
        this.formSubmitSubject.next(message);
    }

    getCurrentBatchDelayForm(): BatchDelayForm {
        return this.currentBatchDelayForm;
    }

    notifiedDNByFormSubmission(): Observable<any> {

        return this.formSubmitSubject.asObservable();
    }
    

    sendEmailConfigToBatchStatus(message: BatchAutomationConfigForm) {
        this.configSubject.next(message);
    }

    getEmailConfigInBatchStatus(): Observable<any> {
        return this.configSubject.asObservable();
    }

    //To get the list of sources aviable for feed delay
    loadFeedSources(): Observable<string[]> {
        console.debug("BatchAutomationService::loadFeedSources()::");
        const requestUrl: string = '/api/batch/feed/sources';
        return this.http.get(requestUrl).map(res => res.json()).catch(this.handleError);
    }

    //This method is used to submit the feed delay form to db
    submitDelayFeeds(batchDelayForm: BatchDelayForm): Observable<any> {
        console.debug("BatchAutomationService::submitDelayFeeds", batchDelayForm);
        this.batchDelayForm = batchDelayForm;
        if (batchDelayForm) {
            return this.http.post('/api/batch/delay', batchDelayForm)
                .map((res) => res.json())
                .catch(this.handleError);
        }
    }

    handleError(error: any) {
        // we might use a remote logging infrastructure
        let errMsg = (error.message) ? error.message :
            error.status ? `${error.status} - ${error.statusText}` : 'Server error';
        console.log(errMsg); // log to console instead

        return Observable.throw(errMsg);
    }

    //This method is used to load the dashboard feed delay data  for user notification
    loadCBADashboardData(): Observable<any> {
        console.debug("BatchAutomationService::loadCBADashboardData");
        return this.http.get('/api/batch/delay/user-notification/cbaDashboard')
            .map((res) => res.json())
            .catch(this.handleError);
    }

    //This method is used to load the dashboard feed delay data  for user notification
    loadSLDashboardData(): Observable<any> {
        console.debug("BatchAutomationService::loadSLDashboardData");
        return this.http.get('/api/batch/delay/user-notification/slDashboard')
            .map((res) => res.json())
            .catch(this.handleError);
    }


    //This method is used to load the reports feed delay data  for user notification
    loadReportData(): Observable<any> {
        console.debug("BatchAutomationService::loadReportData");
        return this.http.get('/api/batch/delay/user-notification/reports')
            .map((res) => res.json())
            .catch(this.handleError);
    }


    //This method is used to load the CAD feed delay data  for user notification
    loadCADData(): Observable<any> {
        console.debug("BatchAutomationService::loadCADData");
        return this.http.get('/api/batch/delay/user-notification/cad')
            .map((res) => res.json())
            .catch(this.handleError);
    }



    //This method is used to load the feed/data for downstream notification
    loadFeedData(): Observable<any> {
        console.debug("BatchAutomationService::loadCADData");
        return this.http.get('/api/batch/delay/downstream-notification/feedData')
            .map((res) => res.json())
            .catch(this.handleError);
    }


    //This method is used to send the delay email to users 
    sendUNMailData(emailData: FeedDelayEmailForm): Observable<boolean> {
        console.debug("BatchAutomationService::sendUNMailData");
        return this.http.post('/api/batch/delay/mail/user-notification', emailData)
            .map(res => res.json())
            .catch(this.handleError);
    }


    //This method is used to send the delay email to downstream 
    sendDNMailData(emailData: FeedDelayEmailForm): Observable<boolean> {
        console.debug("BatchAutomationService::sendDNMailData");
        return this.http.post('/api/batch/delay/mail/downstream-notification', emailData)
            .map(res => res.json())
            .catch(this.handleError);
    }

    //This method is used to get the list of all cob dates
    getCOBDates(): Observable<any> {
        console.debug('ClientOverviewService::getCOBDates');
        if (!this.COBDates) {
            this.COBDates = this.http.get('/api/batch/getCOBDateList')
                .map(this.extractCOBDate)
                .publishReplay(1)
                .refCount()
        }
        return this.COBDates;
    }


    extractCOBDate(res: Response) {
        console.debug('ClientOverviewService::extractCOBDate ', res);
        let response = res.json();
        var date = loadash.map(response, function (item) {
            return {
                "value": item,
                "label": item.toString().substring(4, 6) + '/' + item.toString().substring(6, 8) + '/' + item.toString().substring(0, 4)
            };
        });
        return date;
    }


    //This method is used to submit the feed delay form to db
    submitBatchConfig(configForm: BatchAutomationConfigForm): Observable<any> {
        console.debug("BatchAutomationService::submitBatchConfig", configForm);
        if (configForm) {
            return this.http.post('/api/batch/config', configForm)
                .map((res) => res.json())
                .catch(this.handleError);
        }
    }

    //This method is used to load the list of email config
    loadConfigList(): Observable<any> {
        console.debug("BatchAutomationService::loadConfigList");
        return this.http.get('/api/batch/config/getConfigList')
            .map((res) => res.json())
            .catch(this.handleError);
    }


    //This method is used to load the list of email config
    loadBatchDelayList(cobdate:any): Observable<any> {
        console.debug("BatchAutomationService::loadBatchDelayList");
        let url:string='/api/batch/delay/getDelayList';
        if(cobdate)
            url+='/'+cobdate;
        return this.http.get(url)
            .map((res) => res.json())
            .catch(this.handleError);
    }



}
