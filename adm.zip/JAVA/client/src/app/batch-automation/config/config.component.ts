import { ActivatedRoute } from '@angular/router';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { BatchAutomationConfigForm } from '../batch-automation-config.model';
import { NgForm } from '@angular/forms';
import { BatchAutomationService } from '../batch-automation.service';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { Message, ListboxModule } from 'primeng/primeng';
import { Observable } from "rxjs/Observable";
import {ScrollPanelModule} from 'primeng/scrollpanel';

@Component({
  selector: 'app-config',
  templateUrl: './config.component.html',
  styleUrls: ['./config.component.scss']
})
export class ConfigComponent implements OnInit, OnDestroy {


  public configForm: BatchAutomationConfigForm = new BatchAutomationConfigForm('', '', '', '', '', '', '');
  public email: string = '';
  public emailTo: string = '';
  public emailFrom: string = '';
  public emailCC: string = '';
  public emailBCC: string = '';
  public emailSubject: string = '';
  public emailUpdate: string = '1';
  public notificationType: string = '';
  public msgs: Message[] = [];

  public cobDate: number;
  public formattedCOBDate: Date = new Date();
  public notification: string = '';

  public notificationTypes: string[] = ['User Notification', 'Downstream Notification', 'Batch Status'];
  public formSubmitFlag: boolean = false;
  public emailConfigList: BatchAutomationConfigForm[];
  public configCols: any[] = [];
  public configFormSubmitMsg: boolean = true; 
  public selectedItem: BatchAutomationConfigForm;
  public notificationSrc: NotificationItem[] = [
                                                new NotificationItem('User Notification','UN'), 
                                                new NotificationItem('Downstream Notification','DN'), 
                                                new NotificationItem('Batch Status','BS')];


  constructor(private router: Router, private batchAutomationService: BatchAutomationService, private route: ActivatedRoute) {
     this.configCols = [
       { header: 'EMAIL TO', field: 'emailTo', style: { 'text-align': 'center', 'width': '30%' }, editable: false },
       { header: 'EMAIL FROM', field: 'emailFrom', style: { 'text-align': 'center', 'width': '30%' }, editable: false },
       { header: 'CC', field: 'emailCC', style: { 'text-align': 'center', 'width': '30%' }, editable: false },
       { header: 'BCC', field: 'emailBCC', style: { 'text-align': 'center', 'width': '30%' }, editable: false },
       { header: 'SUBJECT', field: 'emailSubject', style: { 'text-align': 'center', 'width': '16%' }, editable: false },
       { header: 'UPDATE', field: 'emailUpdate', style: { 'text-align': 'center', 'width': '2%' }, editable: false },
       { header: 'TYPE', field: 'notificationType', style: { 'text-align': 'center', 'width': '2%' }, editable: false }
     ]

  }

  ngOnInit() {
    this.getConfigList();
    this.notification='UN';
  }


  //To get the list of cob dates 
  getConfigList(): Observable<any[]> {
    console.debug('ConfigComponent::getConfigList');
    this.batchAutomationService.loadConfigList()
      .subscribe(res => {
        this.emailConfigList = res;
      })
    return;
  }


  formatCOBDate(date) {
    console.debug('ConfigComponent::formatCOBDate ', date);
    var dateString = date.toString();
    var year = dateString.substring(0, 4);
    var month = dateString.substring(4, 6);
    var day = dateString.substring(6, 8);
    this.formattedCOBDate = new Date(year, month - 1, day);
  }

  //Submit user form
  onSubmit(form: NgForm) {
    console.debug("ConfigComponent::onSubmit::", form);
    this.configForm.emailTo = this.emailTo;
    this.configForm.emailFrom = this.emailFrom;
    this.configForm.emailCC = this.emailCC;
    this.configForm.emailBCC = this.emailBCC;
    this.configForm.emailSubject = this.emailSubject;
    this.configForm.emailUpdate = this.emailUpdate;
    this.configForm.notificationType = this.notification;


    //Submit email config form by calling respective api 
    this.batchAutomationService
      .submitBatchConfig(this.configForm)
      .subscribe(res => {
        console.debug("ConfigComponent::onSubmit::", res);
        this.formSubmitFlag = res;
        if (this.formSubmitFlag) {
          this.msgs.push({ severity: 'success', summary: 'Successfully Inserted', detail: 'Email Configuration Data Submitted' });
        } else {
          this.msgs.push({ severity: 'error', summary: 'Inserted failed', detail: 'Email Configuration Data Not Submitted' });
        }
      })
  }

  ngOnDestroy(): void {
    this.reset(this.configForm);
    console.debug('The Email Configuration mail had been reset');
  }


  reset(form: BatchAutomationConfigForm) {
    this.emailTo = '';
    this.emailFrom = '';
    this.emailCC = '';
    this.emailBCC = '';
    this.emailSubject = '';
    this.emailUpdate = '';
  }

  public changeCobDate(): void {
    console.debug("ConfigComponent::changeCobDate::");
  }

  trackByIssue(issueName: string, index: number): any {
    return issueName;
  }


   //On selecting particular row of grid, pass the values to the form
   onRowSelect(event) {
    this.emailTo = event.data.emailTo;
    this.emailFrom =event.data.emailFrom;
    this.emailCC =event.data.emailCC;
    this.emailBCC = event.data.emailBCC;
    this.emailSubject = event.data.emailSubject;
    this.emailUpdate = event.data.emailUpdate;
    this.notification=event.data.notificationType;
  }

  onRowUnselect(event) {
    console.debug('UnSelected value in the Config grid is as :: ISSUE ' + event.data.emailTo);
  }

}



export class NotificationItem {
  constructor(public label: string, public value: string) { }
  
}


