
export class BatchDelayForm {

  constructor(
    public batch_delay_id: number,
    public issue: string = "---Select---",
    public source_issue: string,
    public area_impacted: string = "NAM, EMEA, APAC",
    public eta_resolution: string,
    public inc_mim: string,
    public next_update: string,
    public description: string,
    public cobdate: string = '20180531') { }
}