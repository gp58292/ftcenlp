import { ModuleWithProviders } from '@angular/core';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { BatchAutomationComponent } from "./batch-automation.component";
import { BatchStatusComponent } from "../batch-status/batch-status.component";
import { PrivatePageGuard } from "../services/private-page.guard";
import { BatchDelayComponent } from "./batch-delay/batch-delay.component";
import { UserNotificationComponent } from "./user-notification/user-notification.component";
import { DownstreamNotificationComponent } from "./downstream-notification/downstream-notification.component";
import { ConfigComponent } from './config/config.component';


const alertsRoutes: Routes = [

    {
        path: 'batch_automation',
        component: BatchAutomationComponent,
        canActivate: [PrivatePageGuard],
        children: [
            {
                path: 'batch-status',
                component: BatchStatusComponent,
                canActivate: [PrivatePageGuard]
            },
            {
                path: 'batch-delay',
                component: BatchDelayComponent,
                canActivate: [PrivatePageGuard]
            },
            {
                path: 'user-notification',
                component: UserNotificationComponent,
                canActivate: [PrivatePageGuard]
            },
            {
                path: 'downstream-notification',
                component: DownstreamNotificationComponent,
                canActivate: [PrivatePageGuard]
            },
            {
                path: 'batch-config',
                component: ConfigComponent,
                canActivate: [PrivatePageGuard]
            },
            {
                path: '',
                redirectTo: 'batch-status',
                pathMatch: 'full'
            }
        ]
    },




];

@NgModule({
    imports: [
        RouterModule.forChild(alertsRoutes)
    ],
    exports: [
        RouterModule
    ]
})
export class BatchAutomationRoutesModule { }

