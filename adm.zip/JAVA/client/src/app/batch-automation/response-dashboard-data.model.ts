
export class DashboardResponseData {

    constructor(
        public name: string,
        public bau: string,
        public sla: string,
        public eta: string,
        public flag:string
    ) { }
}