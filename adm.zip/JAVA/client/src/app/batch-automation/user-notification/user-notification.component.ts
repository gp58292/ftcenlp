import { FeedDelayEmailForm } from './../feed-delay-email.model';
import { UserNotificationEmailForm } from './../user-notification-email-form.model';
import { Component, OnInit, EventEmitter, Output, OnDestroy } from '@angular/core';
import { DashboardResponseData } from "../response-dashboard-data.model";
import { Observable } from "rxjs/Observable";
import { BatchAutomationService } from "../batch-automation.service";
import { BatchDelayForm } from "../batch-delay-form.model";
import { BatchAutomationConfigForm } from '../batch-automation-config.model';
import { Message, ListboxModule } from 'primeng/primeng';

@Component({
  selector: 'app-user-notification',
  templateUrl: './user-notification.component.html',
  styleUrls: ['./user-notification.component.scss']
})
export class UserNotificationComponent implements OnInit, OnDestroy {


  public cbaDashboardCols: any[] = [];
  public slDashboardCols: any[] = [];
  public reportsCols: any[] = [];
  public cadCols: any[] = [];
  public cbaData: Observable<any[]>;
  public slData: Observable<any[]>;
  public reportData: Observable<any[]>;
  public cadData: Observable<any[]>;
  public columns: string[];
  public title: string = "Impact";
  public cbaDashboardResponseData: DashboardResponseData[] = [];
  public slDashboardResponseData: DashboardResponseData[] = [];
  public reportResponseData: DashboardResponseData[] = [];
  public cadResponseData: DashboardResponseData[] = [];

  public formSubmissionMsg: Boolean = false;
  public formSubmission = new BatchDelayForm(null,'', '', '', '', '', '','');

  public unEmailForm: FeedDelayEmailForm = undefined;
  public unMailFlag: boolean = false;
  public msgs: Message[] = [];


  constructor(private batchAutomationService: BatchAutomationService) {

    this.cbaDashboardCols = [
      { header: 'CBA Dashboard', field: 'name', style: { 'text-align': 'center', 'width': '25%' }, editable: false },
      { header: 'BAU', field: 'bau', style: { 'text-align': 'center', 'width': '15%' }, editable: false },
      { header: 'SLA Time', field: 'sla', style: { 'text-align': 'center', 'width': '15%' }, editable: false },
      { header: 'ETA/Status', field: 'eta', style: { 'text-align': 'center', 'width': '10%' }, editable: true }

    ],
      this.slDashboardCols = [
        { header: 'Stock Loan Dashboard', field: 'name', style: { 'text-align': 'center', 'width': '25%' }, editable: false },
        { header: 'BAU', field: 'bau', style: { 'text-align': 'center', 'width': '15%' }, editable: false },
        { header: 'SLA Time', field: 'sla', style: { 'text-align': 'center', 'width': '15%' }, editable: false },
        { header: 'ETA/Status', field: 'eta', style: { 'text-align': 'center', 'width': '10%' }, editable: true }

      ],
      this.reportsCols = [
        { header: 'Reports', field: 'name', style: { 'text-align': 'center', 'width': '25%' }, editable: false },
        { header: 'BAU', field: 'bau', style: { 'text-align': 'center', 'width': '15%' }, editable: false },
        { header: 'SLA Time', field: 'sla', style: { 'text-align': 'center', 'width': '15%' }, editable: false },
        { header: 'ETA/Status', field: 'eta', style: { 'text-align': 'center', 'width': '10%' }, editable: true }

      ],
      this.cadCols = [
        { header: 'Client Alert Dashboard', field: 'name', style: { 'text-align': 'center', 'width': '25%' }, editable: false },
        { header: 'BAU', field: 'bau', style: { 'text-align': 'center', 'width': '15%' }, editable: false },
        { header: 'SLA Time', field: 'sla', style: { 'text-align': 'center', 'width': '15%' }, editable: false },
        { header: 'ETA/Status', field: 'eta', style: { 'text-align': 'center', 'width': '10%' }, editable: true }
      ]
  }

  ngOnInit() {
    this.listNotificationForm();
  }


  //Notification if the feed delay form is submitted or not
  private listNotificationForm(): void {
    this.batchAutomationService
      .notifiedUNByFormSubmission()
      .subscribe(formSubmission => {
        this.formSubmission = formSubmission;
        if (this.formSubmission && this.formSubmission.issue != '') {
          this.cbaData = this.getCBADashboardData();
          this.slData = this.getSLDashboardData();
          this.reportData = this.getReportsData();
          this.cadData = this.getClientAlertDashboardData();
          this.formSubmissionMsg = true;
        }
      });

  }

  //Get sources of the feed delays for CBA dashboard type
  getCBADashboardData(): Observable<any[]> {
    console.debug("UserNotificationComponent::getCBADashboardData");
    this.batchAutomationService.loadCBADashboardData()
      .subscribe(res => {
        this.cbaDashboardResponseData = res;

      })
    return;
  }

  //Get sources of the feed delays for SL  dashboard type
  getSLDashboardData(): Observable<any[]> {
    console.debug("UserNotificationComponent::getSLDashboardData");
    this.batchAutomationService.loadSLDashboardData()
      .subscribe(res => {
        this.slDashboardResponseData = res;

      })
    return;
  }

  //Get sources of the feed delays for reports 
  getReportsData(): Observable<any[]> {
    console.debug("UserNotificationComponent::getReportsData");

    this.batchAutomationService.loadReportData()
      .subscribe(res => {
        this.reportResponseData = res;
      })
    return;
  }


  //Get sources of the feed delays for CAD 
  getClientAlertDashboardData(): Observable<any[]> {
    console.debug("UserNotificationComponent::getClientAlertDashboardData");

    this.batchAutomationService.loadCADData()
      .subscribe(res => {
        this.cadResponseData = res;
      })
    return;
  }



  //send email for the delay feeds
  emailUNReport(): void {
    console.debug("UserNotificationComponent::getClientAlertDashboardData");
    this.unEmailForm = new FeedDelayEmailForm(this.formSubmission, this.cbaDashboardResponseData, this.slDashboardResponseData, this.reportResponseData, this.cadResponseData, null, null);
    this.batchAutomationService.sendUNMailData(this.unEmailForm).subscribe(res => {
      this.unMailFlag = res;
      if (this.unMailFlag) {
        this.msgs.push({ severity: 'success', summary: 'Email Sent', detail: 'Email sent to the users' });
      }
      else {
        this.msgs.push({ severity: 'error', summary: 'Email Not Sent', detail: 'Email is not sent to the users' });
      }
    })
    
    return;
  }





  //Get classes for CSS based on conditions
  getCSSClasses(value: string) {
    let cssClasses;
    if (value == 'Available') {
      cssClasses = {
        'greenClass': true,
        'yellowClass': false
      }
    }
    else if (value == 'Available in Second Refresh') {
      cssClasses = {
        'greenClass': true,
        'yellowClass': false
      }
    }
    else {
      cssClasses = {
        'greenClass': false,
        'yellowClass': true
      }
    }
    return cssClasses;
  }


  ngOnDestroy(): void {
    this.cbaDashboardResponseData = [];
    this.slDashboardResponseData = [];
    this.reportResponseData = [];
    this.cadResponseData = [];
    this.formSubmissionMsg = false;
    this.formSubmission = new BatchDelayForm(null,'', '', '', '', '', '','');
    this.unEmailForm = undefined;
    this.unMailFlag = false;
  }

}
