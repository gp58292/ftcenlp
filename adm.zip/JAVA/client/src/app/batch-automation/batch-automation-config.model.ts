
export class BatchAutomationConfigForm {

    constructor(public emailTo: string,
        public emailFrom: string,
        public emailCC: string,
        public emailBCC: string,
        public emailSubject: string,
        public emailUpdate: string,
        public notificationType: string) { }
}