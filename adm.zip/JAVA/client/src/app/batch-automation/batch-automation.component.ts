import { Component, OnInit } from '@angular/core';

import { NgForm } from "@angular/forms/src/forms";
import { BatchAutomationService } from "./batch-automation.service";
import { DashboardResponseData } from "./response-dashboard-data.model";
import { FeedDelayEmailForm } from "./feed-delay-email.model";
import { Subscription } from "rxjs/Subscription";
import { BatchDelayForm } from "./batch-delay-form.model";


@Component({
  selector: 'batch_automation',
  templateUrl: 'batch-automation.component.html',
  styleUrls: ['./batch-automation.component.scss'],
})
export class BatchAutomationComponent {
  constructor() {
  }

  ngOnInit() {
  }


}