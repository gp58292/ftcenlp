export interface SelectItem {
    label: String;
    value: any;
}