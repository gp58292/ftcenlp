import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BatchDelayComponent } from './batch-delay.component';

describe('BatchDelayComponent', () => {
  let component: BatchDelayComponent;
  let fixture: ComponentFixture<BatchDelayComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BatchDelayComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BatchDelayComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
