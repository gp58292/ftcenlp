import { Message } from 'primeng/primeng';
import { Component, OnInit, OnChanges, SimpleChange, SimpleChanges, EventEmitter, Output, ViewChild } from '@angular/core';
import { BatchDelayForm } from "../batch-delay-form.model";
import { BatchAutomationService } from "../batch-automation.service";
import { NgForm } from "@angular/forms";
import { Router, ActivatedRoute } from "@angular/router";

import { Observable } from "rxjs/Observable";
import { SelectItem } from "../Selected.Item.model";


@Component({
  selector: 'app-batch-delay',
  templateUrl: './batch-delay.component.html',
  styleUrls: ['./batch-delay.component.scss']
})
export class BatchDelayComponent implements OnInit {
  public sources: string[] = [];
  public title = 'Batch Delay Report Form';
  public areaImpacted: string = "NAM, EMEA, APAC";
  public batchDelayForm = new BatchDelayForm(null, '', '', '', '', '', '', '');
  public message: boolean = false;
  private sourceId: string;
  public products: string;
  public COBDates: SelectItem[] = [];
  public selectedCOBDate: number = 0;
  public formSubmitFlag: boolean = false;

  public issue_sel: string = '';
  public source_issue: string = '';
  public eta_resolution_sel: string = '';
  public next_update_sel: string = '';
  public inc_mim_sel: string = '';
  public description_sel: string = '';
  public batchDelayFormSubmitMsg: boolean = true;
  

  //For grid public emailConfigList:BatchAutomationConfigForm[];
  public batchDelayFormList: BatchDelayForm[];
  public batchDelayGridCols: any[] = [];

  selectedCar4: BatchDelayForm;
  public msgs: Message[] = [];

  @ViewChild('myFormFilled')
  public myFormFilled: NgForm;

  ngOnInit() {
    console.debug("BatchDelayComponent::ngOnInit");
    // call the method on initial load of page to bind dropdown   
    
    this.getCurrentCobDate();
    this.getFeedSources();
    this.getBatchDelayList(null);
    this.getCurrentFormValues();
  }


  ngOnChanges(change: SimpleChanges) {
    console.debug("BatchDelayComponent::ngOnChanges::", change);
  }

  constructor(private router: Router, private batchAutomationService: BatchAutomationService) {

    this.batchDelayGridCols = [
      { header: 'Id', field: 'batch_delay_id', style: { 'text-align': 'center', 'width': '5%' }, editable: true, sortable: true },
      { header: 'Feed', field: 'issue', style: { 'text-align': 'center', 'width': '25%' }, editable: true, sortable: true },
      { header: 'Source of Issue', field: 'source_issue', style: { 'text-align': 'center', 'width': '25%' }, editable: true, sortable: true },
      { header: 'Impact Area', field: 'area_impacted', style: { 'text-align': 'center', 'width': '15%' }, editable: true, sortable: true },
      { header: 'ETA', field: 'eta_resolution', style: { 'text-align': 'center', 'width': '5%' }, editable: true, sortable: true },
      { header: 'MIM', field: 'inc_mim', style: { 'text-align': 'center', 'width': '10%' }, editable: true, sortable: true },
      { header: 'Next Update', field: 'next_update', style: { 'text-align': 'center', 'width': '10%' }, editable: true, sortable: true },
      { header: 'COB Date', field: 'cobdate', style: { 'text-align': 'center', 'width': '5%' }, editable: true, sortable: true },
      { header: 'Description', field: 'description', style: { 'text-align': 'center', 'width': '25%' }, editable: true, sortable: true }
    ]
  }

  //To get the list of cob dates 
  getCurrentCobDate(): void {
    console.debug('BatchDelayComponent::initChartFilter');
    this.batchAutomationService.getCOBDates().subscribe(res => {
      this.COBDates = res;
      var date = res[0].value;
      this.selectedCOBDate = date;

    })
  }
  

  //Get sources of the feed delays
  getFeedSources(): void {
    console.debug("BatchDelayComponent::getFeedSources");
    this.batchAutomationService.loadFeedSources()
      .subscribe(res => {
        this.sources = res;
        var firstItem=res[0];
        this.issue_sel=firstItem;
        this.source_issue=this.issue_sel;
      })
  }

  //TO GET THE LIST OF Batch Delay Form LIST
  getBatchDelayList(selectedCOBDate: any): Observable<any[]> {
    console.debug('BatchDelayComponent::getBatchDelayList');
    this.batchAutomationService.loadBatchDelayList(selectedCOBDate)
      .subscribe(res => {
        this.batchDelayFormList = res;
        console.debug("BatchDelayComponent::getBatchDelayList ::The list of batch delay forms ", this.batchDelayFormList);
      })

    return;
  }

  //To get the current state for movement between tabs
  getCurrentFormValues() {
    if (this.batchAutomationService.getCurrentBatchDelayForm()) {
      this.batchDelayForm = this.batchAutomationService.getCurrentBatchDelayForm();
    }
  }

  //validate input 
  _keyPress(event: any) {
    const pattern = /[0-9\+\-\+\.\ ]/;
    let inputChar = String.fromCharCode(event.charCode);

    if (!pattern.test(inputChar)) {
      // invalid character, prevent input
      event.preventDefault();
    }
  }

  trackByIssue(issueName: string, index: number): any {
    return issueName;
  }

  //to identify the change of cob date
  onCobDateChange(cobDate: any) {
    console.debug("BatchDelayComponent:: onCobDateChange " + this.selectedCOBDate);
    this.getBatchDelayList(this.selectedCOBDate);
  }

  //Submit user form
  onSubmit(form: NgForm) {
    console.debug("BatchDelayComponent::onSubmit::", form);

    this.batchDelayForm.issue = this.issue_sel;
    this.batchDelayForm.source_issue = this.source_issue;
    this.batchDelayForm.area_impacted = this.areaImpacted;
    this.batchDelayForm.eta_resolution = this.eta_resolution_sel;
    this.batchDelayForm.next_update = this.next_update_sel;
    this.batchDelayForm.inc_mim = this.inc_mim_sel;
    this.batchDelayForm.description = this.description_sel;
    this.batchDelayForm.cobdate = form.controls['selectedCOBDate'].value;

    this.batchAutomationService
      .submitDelayFeeds(this.batchDelayForm)
      .subscribe(res => {
        this.formSubmitFlag = res;
        //Send the form submitted by user to parent component
        this.batchAutomationService.notifyDNForFormSubmission(this.batchDelayForm);
        this.batchAutomationService.notifyUNForFormSubmission(this.batchDelayForm);
        this.router.navigate(["/batch_automation/user-notification"]);
      })
    //Now we can gather data for the grid
    this.batchDelayFormSubmitMsg = true;
    console.debug("BatchDelayComponent:: Form Submitted!");
  }

  //On selecting particular row of grid, pass the values to the form
  onRowSelect(event) {
    this.issue_sel = event.data.issue;;
    this.source_issue = event.data.source_issue;;
    this.areaImpacted = this.areaImpacted;;
    this.eta_resolution_sel = event.data.eta_resolution;;
    this.next_update_sel = event.data.next_update;;
    this.inc_mim_sel = event.data.inc_mim;;
    this.description_sel = event.data.description;;
    this.selectedCOBDate = event.data.cobdate;
  }

  onRowUnselect(event) {
    console.debug('UnSelected value in the Batch delay grid is as :: ISSUE ' + event.data.issue);
  }


  onFeedChange(feed: any) {
    console.debug("BatchDelayComponent:: onFeedChange " + feed);
    this.source_issue=feed;
  }


}
