import { DashboardResponseData } from "./response-dashboard-data.model";
import { BatchDelayForm } from "./batch-delay-form.model";

export class UserNotificationEmailForm {

    constructor(public feedDelayForm: BatchDelayForm,
        public dashboardResponseData: DashboardResponseData[],
        public reportResponseData: DashboardResponseData[],
        public cadResponseData: DashboardResponseData[]
       ) { }
}