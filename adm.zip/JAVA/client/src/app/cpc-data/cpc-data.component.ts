import { SelectItem } from './../batch-automation/Selected.Item.model';
import { BatchAutomationService } from './../batch-automation/batch-automation.service';
/**
 * Created by jm27909 on 11/8/2016.
 * Modified by AK92283 on 08/06/2018.
 */
import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Data } from './data';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { Message } from 'primeng/primeng';
import { CPCDataService } from "./cpc-data.service";
import { Router } from '@angular/router';
import { LoginService } from "../services/login.service";
import { UserParams } from "../shared/dto";
import {DataTableModule} from 'primeng/primeng';


@Component({
    selector: 'cpc-data',
    templateUrl: './cpc-data.component.html',
    styleUrls: ['./cpc-data.component.scss'],
    encapsulation: ViewEncapsulation.None,
    providers: [CPCDataService],

})
export class CPCDataComponent implements OnInit {
    public data: Data[]; // data from the Load CPC data table
    public selectedRecord: Data;
    public cobDate: Date;
    public form: FormGroup;
    public msgs: Message[] = [];
    public totalRecords: number = 0;
    public userParams: UserParams;
    public cols: any[] = [];

    //used for date formate for record submission from 2017-01-01 -> 20170101
    public year: string = '';
    public month: string = '';
    public day: string = '';

    //Cob date parameters
    public COBDates: SelectItem[] = [];
    public selectedCOBDate: number = 0;

    constructor(private router: Router, private cpcdataService: CPCDataService,
        private builder: FormBuilder, private loginService: LoginService,
        private batchAutomationService: BatchAutomationService) {
        this.createForm();
        this.dataRecord.flag = 'Y';

        this.cols = [
       
         { header: 'Cob Date', field: 'cobDate'},
         { header: 'Create User', field: 'createUser'},
         { header: 'Updated By User', field: 'lastUpdatedUser'},
         { header: 'Pending Processing', field: 'flag'},
         { header: 'Create Date', field: 'loadDate'},
         { header: 'Last Updated', field: 'lastUpdated'}
        ];
    }

    ngOnInit(): void {
        this.loadData();
        this.userParams = this.loginService.getUserParams();
        this.getCurrentCobDate();
        return;
    }

    //create the form that will be used to submit data
    createForm() {
        this.cobDate = new Date();
        this.form = this.builder.group({
            cobDate: this.cobDate,

        });

        return;
    }

    //reset form to submit a record
    reset() {
        console.log('Reset For for Submitting Records');
        this.createForm();
        this.dataRecord.cobDate = '';
        this.dataRecord.flag = 'Y';

        return;
    }

    //load data from database
    loadData() {
        this.cpcdataService.loadData()
            .subscribe(res => {
                this.data = res;
                this.countData();
            })

        return;

    }

    //display total records in table footer
    countData() {
        this.totalRecords = this.data.length;
        return;
    }


    //To get the list of cob dates 
    getCurrentCobDate(): void {
        console.debug('ConfigComponent::initChartFilter');
        this.batchAutomationService.getCOBDates().subscribe(res => {
            this.COBDates = res;
            var date = res[0].value;
            this.selectedCOBDate = date;
        })
    }

  
    //add data to the database
    private dataRecord = new DataRecord('', '', '', '');
    addData() {
        console.log('Insert data into table');
        //TODO ugly code refactor at some point            
        let isSameFlag: boolean = false;

        //set the user field for data record insertion 
        this.dataRecord.createUser = this.userParams.soeid;
        this.dataRecord.lastUpdatedUser = '';
        //if no cob-date is filled in the field this message should appear
        //then the form should reset 
        this.dataRecord.cobDate = this.selectedCOBDate.toString();
        if (this.dataRecord.cobDate == '') {
            this.msgs.push({ severity: 'error', summary: 'Data Missing', detail: 'Cob Date Required' });
            this.reset();
        }
        else {
            this.msgs.push({ severity: 'success', summary: 'Data Submitted', detail: 'Successful Record Submission' });
            this.totalRecords = this.totalRecords + 1;
        }

        this.cpcdataService.addData(this.dataRecord.cobDate, this.dataRecord.createUser, this.dataRecord.flag, this.dataRecord.lastUpdatedUser)
            .subscribe(res => {
                this.data = res;
                //this.reset();
            })

        this.reset();

        return;
    }

    //delete data from the database	
    deleteData(data) {
        console.log('Delete Record');
        //Any record with flag N can't be deleted
        //TODO ADD logging in back end for trying to delete record with N flag 
        if (data.flag == 'N') {
            this.msgs.push({ severity: 'warn', summary: 'info', detail: 'Records with Flag N have been processed and can\'t be deleted' });

            return;
        }

        this.data.splice(this.findSelecetedDataRecordIndex(data), 1);

        if (this.totalRecords <= 0) {
            this.totalRecords = 0;
        }

        else {
            this.totalRecords = this.totalRecords - 1;
        }

        this.msgs.push({ severity: 'warn', summary: 'info', detail: 'Record Deleted with cobDate: ' + data.cobDate + ' & loadDate ' + data.loadDate });

        console.log(data.cobDate, data.loadDate);

        //call service to server side to delete record
        this.cpcdataService.deleteData(data.cobDate, data.loadDate)
            .subscribe(res => {
                this.data = res;
            })

        return;
    }

    //get the index of that record to be deleted
    findSelecetedDataRecordIndex(data): number {
        this.selectedRecord = data;

        return this.data.indexOf(this.selectedRecord);
    }

}

export class DataRecord {
    constructor(
        public cobDate: string,
        public createUser: string,
        public lastUpdatedUser: string,
        public flag: string) { }
}