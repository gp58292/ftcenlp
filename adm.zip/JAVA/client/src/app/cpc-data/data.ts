export class Data {
    
    constructor(
        public cobDate: string,
        public createUser: string,
        public flag: string,
        public loadDate: string,
        public lastUpdated: string,
        public lastUpdatedUser: string
    ){}

}