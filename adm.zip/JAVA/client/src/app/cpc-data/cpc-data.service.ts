/**
 * Created by jm27909 on 11/8/2016.
 */
import "../common/rxjs-operators";
import { Injectable,} from '@angular/core';
import { Observable }     from 'rxjs/Observable';
import {MyHttp} from "../services/http";

import {Data} from './data'
import {Response} from "@angular/http";

@Injectable()
export class CPCDataService {

    constructor(private http: MyHttp) { }

    loadData(): Observable<Data[]> {
        return this.http.get(`/api/seedloadcpc/getSeedLoadCPC`)
            .map(this.extractUserData)
            .catch(this.handleError);     
    }
    
    addData(cobDate,createUser,flag,lastUpdatedUser): Observable<Data[]> {
        const data = {        		
            cobDate: cobDate,
            createUser: createUser,
            flag: flag,
            lastUpdatedUser: lastUpdatedUser,  
            
        };
        
        return this.http.post(`/api/seedloadcpc/insertSeedLoadCPC`, data)
            .map(this.extractUserData)
            .catch(this.handleError);
       
    }
    
    deleteData(cobDate,loadDate):Observable<Data[]>{
        
        return this.http.delete(`/api/seedloadcpc/deleteSeedLoadCPC/cobdate/`+cobDate+`/loaddate/`+loadDate)
            .map(this.extractUserData)
            .catch(this.handleError);
    }

    handleError(error: any) {
        // we might use a remote logging infrastructure
        let errMsg = (error.message) ? error.message :
            error.status ? `${error.status} - ${error.statusText}` : 'Server error';
        console.error(errMsg); // log to console instead
        
        return Observable.throw(errMsg);
    }

    extractUserData(res: Response) {
        let data = res.json();
        
        return data;
    }
}