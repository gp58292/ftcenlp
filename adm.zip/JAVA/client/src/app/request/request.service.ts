/**
 * Created by jm27909 on 03/20/2017.
 */
import { Injectable, } from '@angular/core';
import { Observable }     from 'rxjs/Observable';
import "../common/rxjs-operators";
import {MyHttp} from "../services/http";
import {Data} from './data';
import {Response} from "@angular/http";

@Injectable()
export class RequestService {

    constructor(private http: MyHttp) { }

    loadData(): Observable<Data[]> {
        return this.http.get(`/api/request/getRequestList`)
            .map(this.extractUserData)
            .catch(this.handleError);
    }

    insertRequest(request): Observable<Data[]> {
        return this.http.post(`/api/request/insertRequest`, request)
            .map(this.extractUserData)
            .catch(this.handleError);
    }


    deleteRequest(id): Observable<Data[]> {
        return this.http.delete(`/api/request/deleteRequest/id/` + id)
            .map(this.extractUserData)
            .catch(this.handleError);
    }

    getRequestFileList(id): Observable<Data[]> {
        return this.http.get(`/api/request/getRequestFileList/` + id)
            .map(this.extractUserData)
            .catch(this.handleError);
    }

    editRequestDetails(id, status, requestedBy, accessRequested, securityModel, securityModelStatus, qvAuthorization, qvAuthorizationStatus, qvAuthorizationLandingPage, citiVelocity, notifiedUser, comments): Observable<Data[]> {
        const data = {
            id: id,
            status: status,
            requestedBy: requestedBy,
            accessRequested: accessRequested,
            securityModel: securityModel,
            securityModelStatus: securityModelStatus,
            qvAuthorization: qvAuthorization,
            qvAuthorizationStatus: qvAuthorizationStatus,
            qvAuthorizationLandingPage: qvAuthorizationLandingPage,
            citiVelocity: citiVelocity,
            notifiedUser: notifiedUser,
            comments: comments,
        };

        return this.http.put(`/api/request/editRequest`, data)
            .map(this.extractUserData)
            .catch(this.handleError);

    }

    handleError(error: any) {
        // we might use a remote logging infrastructure
        let errMsg = (error.message) ? error.message :
            error.status ? `${error.status} - ${error.statusText}` : 'Server error';
        console.error(errMsg); // log to console instead

        return Observable.throw(errMsg);
    }

    extractUserData(res: Response) {
        let data = res.json();

        return data;
    }

}