export class Data {

    constructor(
    		
    		public  id:string,
    		public  soeid: string,
			public  userName: string,
			public  requestedBy: string,
			public  accessRequested: string,
			public  receivedOn: string,
    		public  status: string,
    		public  securityModel: string,
			public  securityModelStatus: string,			
			public  qvAuthorization: string,
			public  qvAuthorizationStatus: string,
			public  qvAuthorizationLandingPage: string,
			public  citiVelocity: string,
			public  notifiedUser: string,			
			public  lastUpdated: string,
			public  comments: string
			
    ){}

}