/**
 * Created by jm27909 on 07/20/2017.
 */
import {Component, OnInit, ViewEncapsulation, ViewChild} from '@angular/core';
import { Router } from '@angular/router';
import {FormGroup, FormControl, FormBuilder, Validators} from '@angular/forms';
import {Message, ListboxModule} from 'primeng/primeng';
import {SelectItem} from 'primeng/primeng';
import {InputTextModule} from 'primeng/primeng';
import {SelectButtonModule} from 'primeng/primeng';
import {LoginService} from "../services/login.service";
import {Data} from './data';
import {UserParams} from "../shared/dto";
import {RequestService}  from "./request.service";
import {InputTextareaModule} from 'primeng/primeng';
import {ConfirmDialogModule} from 'primeng/primeng';
import {ConfirmationService} from 'primeng/primeng';
import {CalendarModule} from 'primeng/primeng';
import {MultiSelectModule} from 'primeng/primeng';
import {FileUploadModule} from 'primeng/primeng';

@Component({
    selector: 'request',
    templateUrl: './request.component.html',
    styleUrls: ['./request.component.scss'],
    encapsulation: ViewEncapsulation.None,
    providers: [RequestService],

})

export class RequestComponent implements OnInit {
    public data: Data[];
    //to display add or delete pop up menu    
    public displayDialogAdd: boolean = false;
    public displayDialogEdit: boolean = false;
    public displayDialog: boolean = false;
    public displayDialogDelete :boolean=false;

    public msgs: Message[] = [];
    public disabled = true;
    public id: string;
    public soeid: string;
    public userName: string;
    public requestedBy: string;
    public status: string = 'Received';
    public securityModel: string;
    public comment: string;
    public statuses: SelectItem[];
    public selectedRecord: Data;
    public securityModelStatus: string;
    public qvAuthorizationStatus: string;
    public qv_securityModelStatuses: SelectItem[];
    public dashboardStatus: SelectItem[];
    public selectedFilterCritera: string[] = [];
    public accessRequested: string;
    public receivedOn: string;
    public qvAuthorization: string;
    public qvAuthorizationLandingPage: number;
    public citiVelocity: number;
    public notifiedUser: number;
    public receivedRecordCount: number = 0;
    public inProgressRecordCount: number = 0;
    public completedRecordCount: number = 0;
    public cancelledRecordCount: number = 0;

    uploadedFiles: any[] = [];
    public cols: any[] = [];

    @ViewChild('dt') dt;

    constructor(private router: Router, private requestService: RequestService, private confirmationService: ConfirmationService) {
        this.statuses = [];
        this.statuses.push({ label: 'Received', value: 'Received' });
        this.statuses.push({ label: 'In Progress', value: 'In Progress' });
        this.statuses.push({ label: 'Completed', value: 'Completed' });
        this.statuses.push({ label: 'Cancelled', value: 'Cancelled' });
        this.qv_securityModelStatuses = [];
        this.qv_securityModelStatuses.push({ label: 'Received', value: '0' });
        this.qv_securityModelStatuses.push({ label: 'Requested', value: '1' });
        this.qv_securityModelStatuses.push({ label: 'Approved', value: '2' });
        this.qv_securityModelStatuses.push({ label: 'Completed', value: '3' });
        this.qv_securityModelStatuses.push({ label: 'Cancelled', value: '4' });
        this.dashboardStatus = [];
        this.dashboardStatus.push({ label: 'Pending', value: '0' });
        this.dashboardStatus.push({ label: 'Completed', value: '1' });

        this.cols = [
            { header: 'ID', field: 'id', style: { 'width': '2%' } },
            { header: 'Soeid', field: 'soeid', style: { 'text-align': 'center','width': '6%' } },
            { header: 'User Name', field: 'userName', style: { 'width': '13%' } },
            { header: 'Requested By', field: 'requestedBy', style: { 'width': '13%' } },
            { header: 'Access Requested', field: 'accessRequested', style: { 'width': '15%' } },
            { header: 'Received On', field: 'receivedOn', style: { 'width': '7%' }, sortable: true },
            { header: 'Status', field: 'status', style: { 'width': '7%' } },
            { header: 'Security Model', field: 'securityModel', style: { 'width': '10%', 'height': '100%', 'padding': '0', 'position': 'relative' } },
            { header: 'QV Authorization', field: 'qvAuthorization', style: { 'width': '10%', 'height': '100%', 'padding': '0', 'position': 'relative' } },
            { header: '', field: 'securityModelStatus', style: { 'width': '0%' }, },
            { header: '', field: 'qvAuthorizationStatus', style: { 'width': '0%' } },
            { header: 'QV Authorization Landing Page', field: 'qvAuthorizationLandingPage', style: { 'text-align': 'center', 'width': '10%' } },
            { header: 'Citi Velocity', field: 'citiVelocity', style: { 'text-align': 'center', 'width': '7%' } },
            { header: 'Notified User', field: 'notifiedUser', style: { 'text-align': 'center', 'width': '7%' } },
            { header: 'Last Updated', field: 'lastUpdated', style: { 'width': '7%' }, sortable: true },
            { header: 'Comments', field: 'comments', style: { 'text-align': 'left', 'width': '30%' } },
            { header: '', field: '', style: { 'text-align': 'center', 'width': '4%' } }

        ];

    }

    // when page intially loads will load all records from table 
    ngOnInit(): void {
        this.loadData();
        this.qvAuthorizationLandingPage = 0;
        this.citiVelocity = 0;
        this.notifiedUser = 0;
        this.receivedOn = new Date().toISOString().slice(0, 10); // intially fills in todays date when adding request

        return;
    }

    //display Records for each status in table footer
    countData():void {
        // Count the values for each status
        this.receivedRecordCount=this.data.filter( item => item.status==='Received').length;
        this.inProgressRecordCount=this.data.filter( item => item.status==='In Progress').length;
        this.cancelledRecordCount=this.data.filter( item => item.status==='Cancelled').length;
        this.completedRecordCount=this.data.filter( item => item.status==='Completed').length;

        return;
    }

    //when the upload button is pressed upload the files and contents in the upLoadedFiles array 
    onUpload($event) {
        console.log('upload Files');

        for (let file of $event.files) {
            this.uploadedFiles.push(file);
        }

        //Because the files are in a separate table need a datbase call to update the Uploaded Files variable
        this.requestService.getRequestFileList(this.id)
            .subscribe(res => {
                this.uploadedFiles = res;
                
            })

        this.msgs = [];
        this.msgs.push({ severity: 'info', summary: 'File Uploaded', detail: '' });

        return;
    }

    //when the select buttons on top right are clicked it will filter by those statuses      
    filterStatus() {
        this.dt.onFilterKeyup(this.selectedFilterCritera, 'status', 'in');

        return;
    }

    //Based on security Model Status and the QV Authorization Dashboard Status 
    setQV_SecurityModelColor(status: String) {
        var color: string;

        switch (status) {
            case '0':
                color = 'WHITE';
                break;
            case '1':
                color = 'LIGHTGREY';
                break;
            case '2':
                color = 'ORANGE';
                break;
            case '3':
                color = 'LIGHTGREEN';
                break;
            case '4':
                color = 'RED';
                break;
        }

        return color;
    }

    //when the delete button is pressed a confirmation dialog box will appear to ensure this was the correct action
    confirmDelete() {
        this.confirmationService.confirm({
            message: 'Do you want to delete this record?',
            header: 'Delete Confirmation',
            icon: 'fa fa-trash',
            accept: () => {
                this.deleteRequest();
            }
        });

        return;
    }

    //used to show the edit, delete pop up 
    showDialogForEdit() {
        this.displayDialog = true;
        this.displayDialogDelete=true;
        this.displayDialogAdd=false;
        return;
    }

    //calls backend service to retrive all records from the table used 
    loadData() {
        document.body.style.cursor='progress';
        this.requestService.loadData()
            .subscribe(res => {
                this.data = res;
                document.body.style.cursor='default';
                this.countData();
                this.selectedFilterCritera = ['Received', 'In Progress'];
                this.filterStatus();
                
            })

        return;
    }

    private request = new Request('', '', '', '', '', '', '', '', '', '', +'', +'', +'', '');
    //insert a new Request into the table
    // TODO change the form to a FormGroup and add validators.
    insertRequest() {
        console.log('insert new request');
        
        // TODO replace form in html with formgroup so we can add validators
        this.request.soeid = this.soeid;
        this.request.userName = this.userName;
        this.request.requestedBy = this.requestedBy;
        this.request.accessRequested = this.accessRequested;
        this.request.receivedOn = this.receivedOn;
        this.request.status = this.status;
        this.request.securityModel = this.securityModel;
        this.request.securityModelStatus = this.securityModelStatus;
        this.request.qvAuthorization = this.qvAuthorization;
        this.request.qvAuthorizationStatus = this.qvAuthorizationStatus;
        this.request.qvAuthorizationLandingPage = this.qvAuthorizationLandingPage;
        this.request.citiVelocity = this.citiVelocity;
        this.request.notifiedUser = this.notifiedUser;
        this.request.comments = this.comment;
        this.disabled = false;


        console.log(this.data['status'] +''+this.request.status)
        //error checking to see all necessary fields are filled
        if (this.request.soeid.length == 0
            || typeof this.request.userName === 'undefined' || this.request.userName.length == 0
            || typeof this.request.requestedBy === 'undefined' || this.request.requestedBy.length == 0
            || typeof this.request.accessRequested === 'undefined' || this.request.accessRequested == null || this.request.accessRequested.length == 0) {
            this.msgs.push({ severity: 'error', summary: 'Data Missing', detail: 'Required Details Missing' });

            return;
        }

        // error checking for soeid length 
        if (this.request.soeid.length != 7) {
            this.msgs.push({ severity: 'error', summary: 'Data Invalid', detail: 'Soeid incorrect length' });
            this.clear();

            return;
        }

       // if passes error checking will call service to insert the request 
        this.requestService.insertRequest(this.request)
            .subscribe(res => {
                this.data = res;
                this.msgs.push({ severity: 'success', summary: 'Insert Request ', detail: 'Successfully Inserted Request' });
                this.clear();

                //reset the counts shown in table footer for each status type          
                this.receivedRecordCount = 0;
                this.inProgressRecordCount = 0;
                this.completedRecordCount = 0;
                this.cancelledRecordCount = 0;

                //update counter at footer table
                this.countData();

            })

        return;
    }

    //to edit a request, grab all the details from that row and fill in the binded variables 
    getRequestDetails(data) {
        console.log('get request details for update');
        this.selectedRecord = data;
        this.id = this.selectedRecord.id;
        this.soeid = this.selectedRecord.soeid;
        this.userName = this.selectedRecord.userName;
        this.requestedBy = this.selectedRecord.requestedBy;
        //console.log(this.selectedRecord.receivedOn.substr(0, 10));
        var date = this.selectedRecord.receivedOn.substr(0, 10);//because there is no get Date function need to subString and assign 
        this.receivedOn = date;
        this.accessRequested = this.selectedRecord.accessRequested;
        this.status = this.selectedRecord.status;
        this.securityModel = this.selectedRecord.securityModel;
        this.securityModelStatus = this.selectedRecord.securityModelStatus;
        this.qvAuthorization = this.selectedRecord.qvAuthorization;
        this.qvAuthorizationStatus = this.selectedRecord.qvAuthorizationStatus;
        this.qvAuthorizationLandingPage = +(this.selectedRecord.qvAuthorizationLandingPage);
        this.citiVelocity = +(this.selectedRecord.citiVelocity);
        this.notifiedUser = +(this.selectedRecord.notifiedUser);
        this.comment = this.selectedRecord.comments;

        //Because the files are in a separate table need a database call to update the Uploaded Files variable,  without this the link would not be made clickable
        this.requestService.getRequestFileList(this.id)
            .subscribe(res => {
                this.uploadedFiles = res;
                //this.clear();
                //this.msgs.push({ severity: 'Success', summary: 'Delete User Request', detail: 'Delete Request' });
            })

        return;
    }

    //DELETE FUNCTIONALITY IS DISABLED FOR AUDIT PURPOSES - if you need delete enable html button that is commented
    //to delete a request record 
    deleteRequest() {
        //will check if ID exists 
        if (this.id == null) {
            this.msgs.push({ severity: 'error', summary: 'Data Invalid', detail: 'Record does not exist' });
            this.clear();

            return;
        }

        //if the ID exists delete it 
        this.requestService.deleteRequest(this.id)
            .subscribe(res => {
                this.data = res;
                this.clear();

                //reset the counts shown in table footer for each status type                               
                this.receivedRecordCount = 0;
                this.inProgressRecordCount = 0;
                this.completedRecordCount = 0;
                this.cancelledRecordCount = 0;

                //update counter in table footer
                this.countData();

                this.msgs.push({ severity: 'Success', summary: 'Delete User Request', detail: 'Delete Request' });
            })

        return;
    }

    //once those details are retrieved you can now edit those specific fields 
    editRequest() {
        //because each request has a unique ID if its not found it does not exist
        this.displayDialogAdd=false;
        if (this.id == null) {
            this.msgs.push({ severity: 'error', summary: 'Data Invalid', detail: 'Record does not exist' });
            this.clear();

            return;
        }

        //send to the request service the intended fields that are to be updated
        this.requestService.editRequestDetails(this.id, this.status, this.requestedBy, this.accessRequested,
            this.securityModel, this.securityModelStatus, this.qvAuthorization, this.qvAuthorizationStatus, this.qvAuthorizationLandingPage, this.citiVelocity, this.notifiedUser, this.comment)
            .subscribe(res => {
                this.data = res;
                this.clear();

                //reset the counts shown in table footer for each status type
                this.receivedRecordCount = 0;
                this.inProgressRecordCount = 0;
                this.completedRecordCount = 0;
                this.cancelledRecordCount = 0;

                //update counter in table footer
                this.countData();

                this.msgs.push({ severity: 'Success', summary: 'Edit Request ', detail: 'Request Modified' });
            })

        return;

    }

    //clear fields after delete, add, edit, or if incorrect/ invalid data is entered
    clear() {
        this.soeid = '';
        this.userName = '';
        this.requestedBy = '';
        this.status = 'Received';
        this.securityModel = '';
        this.comment = '';
        this.securityModelStatus = '';
        this.displayDialog = false;
        this.displayDialogAdd = false;
        this.displayDialogEdit = false;
        this.accessRequested = '';
        this.receivedOn = new Date().toISOString().slice(0, 10);
        this.qvAuthorization = '';
        this.qvAuthorizationStatus = '';
        this.qvAuthorizationLandingPage = 0;
        this.citiVelocity = 0;
        this.notifiedUser = 0;
        this.uploadedFiles = [];
    }

    clearFieldForNew(){

        this.displayDialog = true;
        this.soeid = '';
        this.userName = '';
        this.requestedBy = '';
        this.status = 'Received';
        this.securityModel = '';
        this.comment = '';
        this.securityModelStatus = '';
        this.accessRequested = '';
        this.receivedOn = new Date().toISOString().slice(0, 10);
        this.qvAuthorization = '';
        this.qvAuthorizationStatus = '';
        this.qvAuthorizationLandingPage = 0;
        this.citiVelocity = 0;
        this.notifiedUser = 0;
        this.uploadedFiles = [];
        this.displayDialogEdit=false;
        this.displayDialogDelete=false;
    }
}

export class Request {

    constructor(
        public soeid: string,
        public userName: string,
        public requestedBy: string,
        public accessRequested: string,
        public receivedOn: string,
        public status: string,
        public securityModel: string,
        public securityModelStatus: string,
        public qvAuthorization: string,
        public qvAuthorizationStatus: string,
        public qvAuthorizationLandingPage: number,
        public citiVelocity: number,
        public notifiedUser: number,
        public comments: string
    ) { }
}
