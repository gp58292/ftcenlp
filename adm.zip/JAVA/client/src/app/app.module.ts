import { ConfigurationModule } from './configuration/configuration.module';
// Angular
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { LocationStrategy, HashLocationStrategy, APP_BASE_HREF, DatePipe } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule, JsonpModule } from '@angular/http';

// Vendors
//import { AlertModule, DatepickerModule } from 'ngx-bootstrap';
import { AlertModule,DatepickerModule } from 'ngx-bootstrap';
import {InputTextModule, DataTableModule,  DialogModule,ListboxModule,SelectItem} from 'primeng/primeng';
import {SelectButtonModule} from 'primeng/selectbutton';
import {ButtonModule}  from 'primeng/button';
import {TableModule} from 'primeng/table';
import {CheckboxModule} from 'primeng/primeng';
import {PasswordModule} from 'primeng/primeng';
import {CalendarModule, GrowlModule} from 'primeng/primeng';
import {AutoCompleteModule} from 'primeng/primeng';
import {MultiSelectModule} from 'primeng/primeng';
import {DropdownModule} from 'primeng/primeng';
import {TooltipModule} from 'primeng/primeng';
import {InputTextareaModule} from 'primeng/primeng';
import {ToggleButtonModule} from 'primeng/primeng';
import {ConfirmDialogModule,ConfirmationService} from 'primeng/primeng';
import {RadioButtonModule} from 'primeng/primeng';
import {TabViewModule} from 'primeng/primeng';
import {FileUploadModule} from 'primeng/primeng';

/*  app components */
import { NavBarComponent } from './home/nav-bar.component';
import { AppComponent } from './app.component';
import { CalendarComponent } from './calendar/calendar.component';
import { HomeComponent } from './home/home.component';
import { HeaderComponent } from './home/header.component';
import { FooterComponent } from './home/footer.component';
import { LoginComponent} from "./login/login.component";
import { AdminComponent } from "./admin/admin.component";
import { DataLoggingComponent } from "./data-logging/data-logging.component";
import { CPCDataComponent } from "./cpc-data/cpc-data.component";
import { RequestComponent } from "./request/request.component";
import { BatchStatusComponent } from "./batch-status/batch-status.component";
import { DatabaseCleanupComponent } from "./storage-cleanup/database-cleanup.component";
import { FileCleanupComponent } from "./storage-cleanup/file-cleanup.component";
import { BatchAutomationComponent } from "./batch-automation/batch-automation.component";


/*  app services */
import { AppStateService } from "./services/app-state.service";
import { ReferenceDataService } from "./services/reference-data.service";
import { AdminService } from "./admin/admin.service";
import { DataLoggingService } from "./data-logging/data-logging.service";
import { RequestService } from "./request/request.service";
import { CPCDataService } from "./cpc-data/cpc-data.service";
import { LoginService } from "./services/login.service";
import { MyHttp } from "./services/http";
import { JsonHttp} from "./services/json-http";
import {DatabaseCleanupService} from "./storage-cleanup/database-cleanup.service";
import {FileCleanupService} from "./storage-cleanup/file-cleanup.service";

/* app common  */
import { routing, appRouterProviders } from './app.routing';
import { MyStorage } from "./services/storage-wrapper";
import { HttpErrorHandler } from "./services/http-error-handler";
import { PrivatePageGuard } from './services/private-page.guard';

/* app directives */
import { AccessDirective } from "./directives/access.directive";

import { BatchAutomationModule } from "./batch-automation/batch-automation.module";
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ConfigurationComponent } from './configuration/configuration.component';




@NgModule({
    declarations: [AppComponent,
        CalendarComponent,
        HomeComponent,
        HeaderComponent,
        FooterComponent,
        NavBarComponent,
        LoginComponent,
        CPCDataComponent,
        DataLoggingComponent,
        DatabaseCleanupComponent,
        FileCleanupComponent,
        RequestComponent,
        AdminComponent,
        AccessDirective,
        BatchStatusComponent,
        BatchAutomationComponent,
        ConfigurationComponent       
    ],
    imports: [BrowserModule,
        FormsModule,
        ReactiveFormsModule,
        HttpModule,
        JsonpModule,
        AlertModule,
        DatepickerModule,
        InputTextModule, DataTableModule, ButtonModule, DialogModule,CalendarModule,GrowlModule,CheckboxModule,TableModule,
        ListboxModule,
        FileUploadModule,
        InputTextareaModule,
        PasswordModule,
        TabViewModule,
        SelectButtonModule,
        AutoCompleteModule,
        ConfirmDialogModule,    
        MultiSelectModule,
        ToggleButtonModule,
        RadioButtonModule,
        DropdownModule,
        TooltipModule,
		CalendarModule,
        BatchAutomationModule,
        BrowserAnimationsModule,
        ConfigurationModule,
        routing],
    schemas: [CUSTOM_ELEMENTS_SCHEMA],
    providers: [
        MyHttp,
        HttpErrorHandler,
        JsonHttp,
        AppStateService,
        LoginService,
        AdminService,
        CPCDataService,
        FileCleanupService,
        DatabaseCleanupService,
        RequestService,
        PrivatePageGuard,
        ConfirmationService,
        ReferenceDataService,
        appRouterProviders,
        DataLoggingService,
        DatePipe,
        MyStorage,
        [{ provide: APP_BASE_HREF, useValue: '/' }],
        [{ provide: LocationStrategy, useClass: HashLocationStrategy }]
    ],
    bootstrap: [AppComponent]
})
export class AppModule { }