import {Injectable} from "@angular/core";
import {Idle, DocumentInterruptSource, WindowInterruptSource} from '@ng-idle/core';
import {Keepalive} from '@ng-idle/keepalive';
import * as toastr from 'toastr';
toastr.options.preventDuplicates = true;


@Injectable()
export class IdleService {

    timedOut = false;
    lastPing?: Date = null;
    titleElement: any = null;
    originalTitle: string = "";
    
    constructor(public idle: Idle, private keepalive: Keepalive) {
    	console.debug("IdleService::constructor");
    	
    	this.titleElement = document.getElementsByTagName("title");
    	
        //keepalive.interval(5);
        keepalive.request('/api/heartBeat');

        keepalive.onPing.subscribe(() => {
            this.lastPing = new Date();
            console.debug('IdleService::Keepalive');
        });

        // sets an idle timeout of 28 min,.
        idle.setIdle(28*60);
        // sets a timeout period of 60 seconds. after 60 seconds of inactivity, the user will be considered timed out.
        idle.setTimeout(60); //60
        // sets the default interrupts, in this case, things like clicks, scrolls, touches to the document
        idle.setInterrupts([new DocumentInterruptSource('mousemove keydown DOMMouseScroll mousewheel mousedown touchstart touchmove scroll'), new WindowInterruptSource('focus')]);

        idle.onIdleStart.subscribe(() => {
            console.debug('IdleService::IdleStart ', new Date());
            this.saveOriginalTitle();
            toastr.warning("You were idle too long. In case of no further activity, application will logged out in " + idle.getTimeout() + " secs.", "Warning!! You're idle");
        });
        
        idle.onIdleEnd.subscribe(() => {
            console.debug('IdleService::IdleEnd ', new Date());
            this.restoreOriginalTitle();
        });

        idle.onTimeout.subscribe(() => {
            this.timedOut = true;
            console.debug('IdleService::IdleTimeout ', new Date());
            this.setAsTimedOut();
        });

        idle.onTimeoutWarning.subscribe((countdown) => {
            console.debug('IdleService::IdleTimeOutWarning ', new Date());
            this.setAsIdle(countdown);
        });
    }

    watch() {
    	console.debug("IdleService::watch");
        this.idle.watch();
        this.timedOut = false;
    }
    
    saveOriginalTitle() {
    	console.debug("IdleService::saveOriginalTitle ", this.titleElement[0].innerText);
    	this.originalTitle = this.titleElement[0].innerText;
    }
    
    restoreOriginalTitle() {
    	console.debug("IdleService::restoreOriginalTitle ", this.originalTitle);
    	this.titleElement[0].innerText = this.originalTitle;
    }
    
    setAsIdle(countdown) {
    	var minutes = Math.floor(countdown/60);
        var seconds = this.padLeft(countdown - minutes * 60, 2);
        this.titleElement[0].innerText = minutes + ':' + seconds + ' until your session times out!';
    }
    
    padLeft(nr, n) {
        return new Array(n-String(nr).length+1).join('0')+nr;
    }
    
    setAsTimedOut() {
    	console.debug("IdleService::setAsTimedOut");
    	this.titleElement[0].innerText = 'Your session has expired.';
    }

}