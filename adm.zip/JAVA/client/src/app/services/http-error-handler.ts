import {Injectable} from "@angular/core";
import {Router} from "@angular/router";
//import {LoginService} from "../services/login.service";
import * as toastr from 'toastr';
import {Response} from "@angular/http";

toastr.options.preventDuplicates = true;

@Injectable()
export class HttpErrorHandler {

    constructor(private router:Router) {
    	console.debug("HttpErrorHandler::constructor");
    }

    handle(error: Response | any) {
        if (error instanceof Response) {
            //SC_UNAUTHORIZED && SC_FORBIDDEN
            if (error.status === 401 ||  error.status === 403 ) {
                toastr.error('Please Sign In');
                this.router.navigate(['login']);
            }else if (error.status === 500 ){ // server error
                const body = error.json() || '';
                // display RaceApplicationException error message received from server.
                if(body.message)
                    toastr.error(body.message, "Error");
            }else if (error.status === 504 ){ // server error
                toastr.error("Application currently unavailable, please contact AQUA Support team");
            }else{   
                toastr.error('Application Error, please contact AQUA support team');
            }
       }else{
            toastr.error('Application Error, please contact AQUA support team');
        }
    }
}