import {Observable} from "rxjs";
import {Injectable} from "@angular/core";

import "rxjs/add/operator/catch";
import "rxjs/add/observable/throw";
import "rxjs/add/observable/empty";
import { HttpErrorHandler } from "../services/http-error-handler";


import {
    Http,
    RequestOptionsArgs,
    RequestOptions,
    Response,
    Headers,
    URLSearchParams
} from "@angular/http";

const mergeAuthToken = ( options: RequestOptionsArgs ) => {
    let newOptions = new RequestOptions( {}).merge( options );
    let newHeaders = new Headers( newOptions.headers );
    newHeaders.set( 'x-auth-token', localStorage.getItem( 'jwt' ) );
    newHeaders.set( 'Cache-Control', 'no-cache, no-store, max-age=0, must-revalidate' );
    newHeaders.set( 'Expires', '0');
    newHeaders.set( 'Pragma', 'no-cache');
    newOptions.headers = newHeaders;
    return newOptions;
};

@Injectable()
export class JsonHttp {

    // TODO: Clean up unused code
    // promiseList: Array<Promise<any> | Subscription> = [];

    // TODO: Please add Error condition processing from server here - like 404 unauthorized, timeout, closed socket etc.


    constructor( private http: Http, 
            private errorHandler:HttpErrorHandler) {
    	console.debug("JsonHttp::constructor");


    }

    get( url: string, options?: RequestOptionsArgs ): Observable<Response> {
    	console.debug("JsonHttp::get ", url, options);
        
        let request: Observable<Response> = this.http.get( url, mergeAuthToken( options ) )
            .catch((err) => {
                return this.handleError(err);
            })

      
        return request;
    }

    post( url: string, body: any, options?: RequestOptionsArgs ): Observable<Response> {
    	console.debug("JsonHttp::post ", url, options);
      
        let request: Observable<Response> = this.http.post( url, body, mergeAuthToken( options ) )
            .catch((err) => {
                return this.handleError(err);
            })

          
        return request;
    }

    put( url: string, body: any, options?: RequestOptionsArgs ): Observable<Response> {
    	console.debug("JsonHttp::put ", url, options);
 
        let request: Observable<Response> = this.http.put( url, body, mergeAuthToken( options ) )
            .catch((err) => {
                return this.handleError(err);
            })

        return request;
    }

    delete( url: string, options?: RequestOptionsArgs ): Observable<Response> {
    	console.debug("JsonHttp::delete ", url, options);
    	
        let request: Observable<Response> = this.http.delete( url, mergeAuthToken( options ) )
            .catch((err) => {
                return this.handleError(err);
            })

        return request;
    }

    patch( url: string, body: any, options?: RequestOptionsArgs ): Observable<Response> {
    	console.debug("JsonHttp::patch ", url, options);
 
        let request: Observable<Response> = this.http.patch( url, body, mergeAuthToken( options ) )
            .catch((err) => {
                return this.handleError(err);
            })

        return request;
    }

    head( url: string, options?: RequestOptionsArgs ): Observable<Response> {
    	console.debug("JsonHttp::head ", url, options);
    
        let request: Observable<Response> = this.http.head( url, mergeAuthToken( options ) )
            .catch((err) => {
                return this.handleError(err);
            })

        return request;
    }
    buildUlrParamFromObject(object:any):URLSearchParams{
        let params = new URLSearchParams();
        for (let key in object) {
            if (object.hasOwnProperty(key)) {
                params.set(key, object[key])
            }
        }
        return params;
    }
    
    private handleError (error: Response | any):Observable<any> {
        let errMsg: string;
        if (error instanceof Response) {
            this.errorHandler.handle(error);
            return Observable.throw(error);
        } else {
          errMsg = error.message ? error.message : error.toString();
          console.error(errMsg);
        }
        
        return null;
      }
}
