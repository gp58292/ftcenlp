import {Injectable} from "@angular/core";

@Injectable()
export class MySessionStorage {

    constructor() {
    	console.debug("MySessionStorage::constructor");
    }

	/*  removeStorage: removes a key from sessionStorage and its sibling expiracy key
	params:
	key <string>     : sessionStorage key to remove
	returns:
	<boolean> : telling if operation succeeded
	*/
	removeStorageKey(key) {
		console.debug("MySessionStorage::removeStorageKey ", key);
		try {
	        sessionStorage.removeItem(key);
	        sessionStorage.removeItem(key + '_expiresIn');
	    } catch(e) {
	        console.log('removeStorage: Error removing key ['+ key + '] from sessionStorage: ' + JSON.stringify(e) );
	        return false;
	    }
	    return true;
	} 
	
	/*  getStorage: retrieves a key from sessionStorage previously set with setStorage().
 	params:
 	key <string> : sessionStorage key
 	returns:
 	<string> : value of sessionStorage key
 	null : in case of expired key or failure
	*/
	getStorageKey(key) {
		console.debug("MySessionStorage::getStorageKey ", key);
	    var now = Date.now();  //epoch time, lets deal only with integer
	    // set expiration for storage
	    var expiresInStr = sessionStorage.getItem(key+'_expiresIn');
	    var expiresIn = 0;
	    if (!(expiresInStr===undefined || expiresInStr===null)) {
	        var expiresIn = +expiresInStr;
	    }
	
	    if ((expiresIn > 0) && (expiresIn < now)) {// Expired
	        this.removeStorageKey(key);
	        return null;
	    } else {
	        try {
	            var value = sessionStorage.getItem(key);
	            return value;
	        } catch(e) {
	            console.log('getStorage: Error reading key ['+ key + '] from sessionStorage: ' + JSON.stringify(e) );
	            return null;
	        }
	    }
	}
	
	/*  setStorage: writes a key into sessionStorage setting a expire time
	params:
	key <string>     : sessionStorage key
	value <string>   : sessionStorage value
	expires <number> : number of seconds from now to expire the key
	returns:
	<boolean> : telling if operation succeeded
	*/
	setStorageKey(key, value, expires?) {
		console.debug("MySessionStorage::setStorageKey ", key, expires);
	    if (expires===undefined || expires===null) {
	        expires = (0.5*60*60);  // default: seconds for 30 mins
	    } else {
	        expires = Math.abs(expires); //make sure it's positive
	    }
	
	    var now = Date.now();  //millisecs since epoch time, lets deal only with integer
	    var schedule ="" + (now + expires*100000);
	    try {
	        sessionStorage.setItem(key, value);
	        sessionStorage.setItem(key + '_expiresIn', schedule);
	    } catch(e) {
	        console.log('setStorage: Error setting key ['+ key + '] in sessionStorage: ' + JSON.stringify(e) );
	        return false;
	    }
	    return true;
	}
}