import {Injectable} from "@angular/core";
import {
    CanActivate,
    Router,
    ActivatedRouteSnapshot,
    RouterStateSnapshot
} from "@angular/router";
import {LoginService} from "./login.service";

@Injectable()
export class PrivatePageGuard implements CanActivate {

    constructor(private router:Router, private loginService:LoginService) {
    }

    canActivate(route:ActivatedRouteSnapshot, state:RouterStateSnapshot) {
        var result = this.loginService.isSignedIn();
        console.log("PrivatePageGuard[" + route + " :: " + state + "]");
        if (!result) {
            this.router.navigate(['/login']);
            console.log("PrivatePageGuard: is Not SignedIn!")
        } else {
            console.log("PrivatePageGuard: user is SignedId!")
        }
        return result;
    }


}