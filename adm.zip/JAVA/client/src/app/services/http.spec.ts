import {inject, async, TestBed, getTestBed} from "@angular/core/testing";
//async, TestBed
import {
    BaseResponseOptions,
    Response,
    Http,
    RequestMethod,
} from "@angular/http";
import {MockBackend} from "@angular/http/testing";
import {MyHttp} from "./http";
// import {APP_TEST_HTTP_PROVIDERS} from "./index";

describe('MyHttp', () => {
    let myHttp:MyHttp;
    let http:Http;
    let backend:MockBackend;

    // beforeEach(() => addProviders([
    //     ...APP_TEST_HTTP_PROVIDERS,
    // ]));

    beforeEach(() => {
        TestBed.configureTestingModule({
            declarations: [
                MyHttp
            ],
            imports: [
                // HttpModule, etc.
                BaseResponseOptions,
                Response,
                Http,
                RequestMethod,
            ],
            providers: [
                // { provide: ServiceA, useClass: TestServiceA }

            ]
        });
    });

    // it('should do something', async(() => {
    //     // Overrides here, if you need them
    //     TestBed.overrideComponent(MyHttp, {
    //         set: {
    //             template: '<div>Overridden template here</div>'
    //             // ...
    //         }
    //     });


        // beforeEach(inject([MyHttp, Http, MockBackend], (..._) => {
        //     [myHttp, http, backend] = _;
        // }));

        const expectCustomRequest = (method:RequestMethod) => (conn) => {
            conn.mockRespond(new Response(new BaseResponseOptions()));
            expect(conn.request.method).toEqual(method);
            expect(conn.request.headers.has('x-auth-token')).toBeTruthy();
        };

        describe('#get', () => {
            it('performs a get request', (done) => {
                backend.connections.subscribe(expectCustomRequest(RequestMethod.Get));
                myHttp.get('http://www.google.com').subscribe(done);
            });
        });

        describe('#post', () => {
            it('performs a post request', (done) => {
                backend.connections.subscribe(expectCustomRequest(RequestMethod.Post));
                myHttp.post('http://www.google.com', {}).subscribe(done);
            });
        });

        describe('#put', () => {
            it('performs a put request', (done) => {
                backend.connections.subscribe(expectCustomRequest(RequestMethod.Put));
                myHttp.put('http://www.google.com', {}).subscribe(done);
            });
        });

        describe('#delete', () => {
            it('performs a delete request', (done) => {
                backend.connections.subscribe(expectCustomRequest(RequestMethod.Delete));
                myHttp.delete('http://www.google.com').subscribe(done);
            });
        });

        describe('#patch', () => {
            it('performs a patch request', (done) => {
                backend.connections.subscribe(expectCustomRequest(RequestMethod.Patch));
                myHttp.patch('http://www.google.com', {}).subscribe(done);
            });
        });

        describe('#head', () => {
            it('performs a head request', (done) => {
                backend.connections.subscribe(expectCustomRequest(RequestMethod.Head));
                myHttp.head('http://www.google.com').subscribe(done);
            });
        });

    });



    /*
    // Example from: http://stackoverflow.com/questions/39577920/angular-2-unit-testing-components-with-routerlink/39579009#39579009
    * import { Component } from '@angular/core';
     import { Router } from '@angular/router';
     import { By } from '@angular/platform-browser';
     import { Location, CommonModule } from '@angular/common';
     import { RouterTestingModule } from '@angular/router/testing';
     import { TestBed, inject, async } from '@angular/core/testing';

     @Component({
     template: `
     <a routerLink="/settings/{{collName}}/edit/{{item._id}}">link</a>
     <router-outlet></router-outlet>
     `
     })
     class TestComponent {
     collName = 'testing';
     item = {
     _id: 1
     };
     }

     @Component({
     template: ''
     })
     class DummyComponent {
     }

     describe('component: TestComponent', function () {
     beforeEach(() => {
     TestBed.configureTestingModule({
     imports: [
     CommonModule,
     RouterTestingModule.withRoutes([
     { path: 'settings/:collection/edit/:item', component: DummyComponent }
     ])
     ],
     declarations: [ TestComponent, DummyComponent ]
     });
     });

     it('should go to url',
     async(inject([Router, Location], (router: Router, location: Location) => {

     let fixture = TestBed.createComponent(TestComponent);
     fixture.detectChanges();

     fixture.debugElement.query(By.css('a')).nativeElement.click();
     fixture.whenStable().then(() => {
     expect(location.path()).toEqual('/settings/testing/edit/1');
     console.log('after expect');
     });
     })));
     });
    * */