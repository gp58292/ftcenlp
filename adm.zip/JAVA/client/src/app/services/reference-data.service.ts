import {Observable} from "rxjs/Observable";
import {Subject} from "rxjs/Rx";
import {Injectable} from "@angular/core";
import {Response} from "@angular/http";

import "../common/rxjs-operators";
import {JsonHttp} from "../services/json-http";
import {UserParams, EnvironmentVersion} from "../shared/dto";
import {MyStorage} from "../services/storage-wrapper";

import * as _ from 'lodash';
import * as toastr from 'toastr';

//Application models

//Service End Point URI
const getEnvironmentVersionEndPoint = '/api/sso/getEnviromentDetails';

@Injectable()
export class ReferenceDataService {

    
    env: EnvironmentVersion;
    private envDetails: Subject<EnvironmentVersion> = new Subject<EnvironmentVersion>();
    
    constructor(private http:JsonHttp) {
    	console.debug("ReferenceDataService::constructor");
    	this.getEnvDetails().subscribe(
            response => {
                if (response && response.envName && response.envName != "" && response.envName.indexOf("prod") == -1) {
                	this.env = response;
                	this.envDetails.next(this.env);
                	localStorage.setItem('envName', this.env.envName);
                }                
            });
    }
    

    getEnvDetails() : Observable<EnvironmentVersion> {
    	console.debug("ReferenceDataService::getEnvDetails");
    	return this.http.get(getEnvironmentVersionEndPoint)
           	.map((res:Response) => res.json());
    }

    handleError(error: any) {
    	console.error("ReferenceDataService::handleError", error);
    	let errMsg = (error.message) ? error.message :
            error.status ? `${error.status} - ${error.statusText}` : 'Server error';
        return Observable.throw(errMsg);
    }
    
    public subscribeToEnvDetails(): Observable<EnvironmentVersion> {
        console.debug("ReferenceDataService::subscribeToEnvDetails");
        return this.envDetails.asObservable();
    }
}

