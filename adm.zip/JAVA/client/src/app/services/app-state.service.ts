    import {Injectable} from '@angular/core';
    import {ActivatedRoute, Router, NavigationStart} from "@angular/router";
    import {Subscription} from 'rxjs/Subscription'
    
    // Application
    import {MySessionStorage} from "./session-storage-wrapper";
    
    
    
    @Injectable()
    export class AppStateService {
    	
        private myStorage = new MySessionStorage();
        private appStateStore;
        private routeEventSubscription:Subscription;
        
    	constructor(private router:Router) {
            console.debug("AppStateService::constructor");
        }
    	
    	public setState(key, value){
            this.myStorage.setStorageKey(key, value);
            console.debug("AppStateService::setState key", key +' value '+ value );
        }
    	
    	public getState(key){
            console.debug("AppStateService::getState key", key);
            return this.myStorage.getStorageKey(key);
        }
        
        public clearState(key){
            console.debug("AppStateService::clearState key", key);
            this.myStorage.removeStorageKey(key);
        }
        
        /**
         * Perform check on previously stored data app version and current app version to discard it if does not match
         * @param appVersion - Application Build no
         */
        public createAppState(appVersion){
    	    this.appStateStore = this.getAppState();
    	    if(!this.appStateStore){
    	        this.appStateStore = {};
    	        this.appStateStore.version = appVersion;
    	        this.setAppState();
            }else if (this.appStateStore.version != appVersion){
                console.debug("AppStateService::setAppState previous store appVersion" + this.appStateStore.version +" does not match with current one", appVersion);
                this.appStateStore = {};
                this.appStateStore.version = appVersion;
                this.setAppState();
            }
    	    this.listenDeactivateState();
    	    console.debug("AppStateService::setAppState", this.appStateStore);
    	}
        
        public getAppState(){
            console.debug("AppStateService::setAppState app");
            return JSON.parse(this.myStorage.getStorageKey('app'));
        }
        
        public setAppState(){
            console.debug("AppStateService::setAppState app");
            this.myStorage.setStorageKey('app', JSON.stringify(this.appStateStore));
        }
        
        public clearAppState(){
            console.debug("AppStateService::getModuleState app");
            this.appStateStore = null;
            this.myStorage.removeStorageKey('app');
            this.routeEventSubscription.unsubscribe();
        }
        
        /**
         * Activate module state tracking so that new data get store in cache if enabled
         * invoke callback “activation” method after all the layout and business data retrieval to the component is completed, and in such follow your original existing workflow
         * @param module - Current module name, if null then use current context
         */    	
    	public activateModuleState(module?){
    	    if(!module){
    	        module = this.getContextPath(); 
    	    }
    	    
    	    let moduleState = this.getModuleState(module);
            if(!moduleState){
                moduleState = {};
                moduleState.active = true;
            }else{
                moduleState.active = true;
            }
            
            this.setModuleState(module, moduleState);
            console.debug("AppStateService::activateModuleState module", module  );
        }
    	
    	public deactivateModuleState(module?){
    	    if(!module){
                module = this.getContextPath(); 
            }
    	    
            let moduleState = this.getModuleState(module);
            if(moduleState){
                moduleState.active = false;
                this.setModuleState(module, moduleState);
                console.debug("AppStateService::deactivateModuleState module", module );
            }
        }
        
    	public setModuleState(module, value){
    	    if(this.appStateStore){
        	    this.appStateStore[module] =  value;
        	    this.setAppState();
        	    console.debug("AppStateService::setModuleState module", module +' value '+ value );
    	    }    
        }
        
        public getModuleState(module){
            console.debug("AppStateService::getModuleState module", module);
            if(this.appStateStore)
                return this.appStateStore[module];
            return null;
        }
        
        public clearModuleState(module){
            console.debug("AppStateService::clearModuleState module", module);
            this.appStateStore[module] = undefined;
            this.setAppState();
        }
        
        /**
         * This function will help in clearing all child routes defined by context path using string pattern match, currently used for summary module only 
         * @param moduleKey - string module name pattern
         */
        
        public clearModuleStateByMatch(moduleKey:string){
            console.debug("AppStateService::clearModuleState module", moduleKey);
            if(this.appStateStore){
                for (let moduleName in this.appStateStore){
                    if(moduleName.indexOf(moduleKey) > 0){
                        this.clearModuleState(moduleName);
                    }
                }
            }
        }
        
        /**
         * Allow setting global level paramenters on module instead of context basically for parent container which is common to childs
         * @param module - name of module like summary, rule etc
         * @param key - key to be store in module
         * @param value - value to be store in module
         */
        public setModuleGlobalState(module, key, value){
            let moduleState = this.getModuleState(module);
            if(moduleState  && moduleState.active){
                moduleState[key] = value;
                this.setModuleState(module, moduleState);
                //console.debug("AppStateService::setModuleComponentState module", module +' value '+ value );
            }
            
        }
        
        public getModuleGlobalState(module, key){
            let moduleState = this.getModuleState(module);
            if(moduleState){
                return moduleState[key];
            }
            
            return null;
        }
    	
        
        /**
         * Allow to store component state with respect to current context 
         * @param component - name of component like datatable
         * @param parameter - parameter to be store in component like current page
         * @param value - value to be store in component
         */
        public setModuleComponentState(component, parameter, value){
            let moduleState = this.getModuleState(this.getContextPath());
            
            if(moduleState && moduleState.active){
                moduleState[component +'-'+ parameter] = value;
                this.setModuleState(this.getContextPath(), moduleState);
            }
            //console.debug("AppStateService::setModuleComponentState module", component +' value '+ value );
        }
        
        public getModuleComponentState(component, parameter){
            let moduleState = this.getModuleState(this.getContextPath());
            if(moduleState){
                return moduleState[component +'-'+ parameter];
            }
            
            return null;
        }
        
        private getContextPath(){
            return this.router.routerState.snapshot.url;
        }
        
        private listenDeactivateState(){
            
            this.routeEventSubscription = this.router.events
            .map( event => event instanceof NavigationStart )
            .distinctUntilChanged()
            .subscribe( () => {
                console.log(' AppStateService::listenDeactivateState:', this.router.routerState.snapshot.url);
                let module = this.getContextPath(); 
                let moduleState = this.getModuleState(module);
                if(moduleState){
                    moduleState.active = false;
                    this.setModuleState(module, moduleState);
                    console.debug("AppStateService::listenDeactivateState for context ", this.router.routerState.snapshot.url );
                }
                
            });
            
        }
    }