import {Observable} from "rxjs/Observable";
import {Subject} from "rxjs/Rx";
import {Injectable} from "@angular/core";
import {Response} from "@angular/http";
import {Router} from "@angular/router";

import "../common/rxjs-operators";
import {MyHttp} from "../services/http";
import {UserParams, EnvironmentVersion} from "../shared/dto";
import {MyStorage} from "./storage-wrapper";
import {APIResponse} from '../models/api-response';
import * as toastr from 'toastr';


@Injectable()
export class LoginService {

    //TODO: Refactor - Remove AuthEvents - use subscribeToUserChasnge instead
    private authEvents = new Subject<AuthEvent>();

    private myStorage = new MyStorage();
    public userLoggedIn:boolean = false;

    private userParams: UserParams;
    private subject: Subject<UserParams> = new Subject<UserParams>();

    constructor(private router:Router, private http:MyHttp) {
    }
    
    private setUserParams(userParams:UserParams):void {    	
        // capture user params
        this.userParams = userParams;
        if (userParams) {
        	// this.userParams.role = (userParams as any).userRole.race_role;
        	this.userParams.isCBAAccessible = (userParams as any).isCBAAccessible;
            
        }

        // place them to storage, so can read between refresh
        if (this.userParams) {
            console.debug("LoginService::setUserParams", userParams.soeid);            
            this.myStorage.setStorageKey('userParams_name', userParams.name, 20);
            this.myStorage.setStorageKey('userParams_email', userParams.email, 20);
            this.myStorage.setStorageKey('userParams_soeid', userParams.soeid, 20);
            // this.myStorage.setStorageKey('userParams_role', (userParams as any).userRole.race_role, 20);
            this.myStorage.setStorageKey('userParams_businessCritical',(userParams.businessCriticalPages).toString(),20);
            this.myStorage.setStorageKey('userParams_techPages',userParams.techPagesPermission,20);
            let cbaAccess = (userParams as any).isCBAAccessible;
            this.myStorage.setStorageKey('userParams_cbaAccess', JSON.stringify(cbaAccess), 20);
        }
        // emmit the change to subscribed listeners
        this.subject.next(userParams);
    }

    public getUserParams() {
        console.debug("LoginService::getUserParams");
        let up:UserParams = this.userParams;
        // is it empty?
        if (!up) {
            // check if the user is still logged in, then return from storage
            if (this.isSignedIn()) {
                up = {} as any;
                up.name = this.myStorage.getStorageKey('userParams_name');
                up.email = this.myStorage.getStorageKey('userParams_email');
                up.soeid = this.myStorage.getStorageKey('userParams_soeid');
                up.role = this.myStorage.getStorageKey('userParams_role');         
                up.businessCriticalPages= new Array<string>(this.myStorage.getStorageKey('userParams_businessCritical'));    
                up.techPagesPermission =  +this.myStorage.getStorageKey('userParams_techPages');
                let cbaAccess = this.myStorage.getStorageKey('userParams_cbaAccess');
                up.isCBAAccessible = (cbaAccess === "true");
                console.debug("LoginService::getUserParams... Empty. Reading user from local Storage");
            }
        }
        return up;
    }

    public subscribeToUserChange(): Observable<UserParams> {
        console.debug("LoginService::subscribeToUserChange");    	
        return this.subject.asObservable();
    }

    login(user, password):Observable<Response> {
        console.debug("LoginService::login", user);
        const body = {soeid: user, password: password};
        return this.http.post('/api/sso/authenticate', body)
            .map((res) => this.extractUserData(res))
            .catch(this.handleError);
    }


    extractUserData(res:Response) {
        console.debug("LoginService::extractUserData",res);
        let data = res.json();
        
		if (data.statusCode == 'CBA_1000') {
			return data;
		} else {
	        if (data.isAuthenticated) {	        	
	            // init user                
	            this.setUserParams(data);
                
	            // TODO: Add all the relevant data to storage if required
	            if (this.myStorage) {
	                this.myStorage.setStorageKey('isAuthenticated', data.isAuthenticated, 20);
	                this.myStorage.setStorageKey('ssoSessionID', data.ssoSessionID, 20);
	                this.myStorage.setStorageKey('jwt', data.ssoSessionID, 20);
	                this.myStorage.setStorageKey('isAuthorized', data.isAuthorized, 20);	                
	                console.debug("LoginService::extractUserData Writing to MyStorage SessionID");
	            } else {
	                console.debug("LoginService::extractUserData Direct Storage write SessionID");
	                localStorage.setItem('jwt', data.ssoSessionID);
	                localStorage.setItem('JSESSIONID', data.JSESSIONID);
	            }
	            this.userLoggedIn = true;
	        } else {
	            this.userLoggedIn = false;
	            toastr.error('User not Authenticated', 'Error');
	        }
	        return data;
		}
    }

    handleError (error: any) {
        // we might use a remote logging infrastructure
        let errMsg = (error.message) ? error.message :
            error.status ? `${error.status} - ${error.statusText}` : 'Server error';
        console.error(errMsg); // log to console instead
        return Observable.throw(errMsg);
    }

    logout():void {
        console.debug("LoginService::logout");        
        this.invokelogout().subscribe(
           apiResponse => {
                console.log(apiResponse)
                if (apiResponse.status) {
                    toastr.success(apiResponse.message);
                    this.authEvents.next(new DidLogout());
                    this.router.navigate(['login']);
                } else {
                    toastr.error(apiResponse.message, 'Error');
                }
        }, e => this.handleError(e))

        /**
         *
         * Regardless of success or failure on Server side - client side to be reset!
         */
        this.userLoggedIn = false;
        this.setUserParams(null);
        this.removeUserParams();
        if (this.myStorage) {
            this.myStorage.removeStorageKey('jwt');
            this.myStorage.removeStorageKey('JSESSIONID');
        }
        else {
            localStorage.removeItem('jwt');
            localStorage.removeItem('JSESSIONID');
        }
        //this.appStateService.clearAppState();
        return;
    }
    
    invokelogout():Observable<APIResponse> {
    	console.debug("LoginService::invokelogout");
        return this.http.get(`/api/sso/logout`)
        	.map ((res:Response) => res.json());
    }


    isSignedIn():boolean {
        console.debug("LoginService::isSignedIn");
        var logged = false;
        if (this.myStorage) {
            logged = (this.myStorage.getStorageKey('jwt') !== null);
        }
        else {
            logged = (localStorage.getItem('jwt') !== null);
        }
        
        if(!logged) {
            this.setUserParams(null);
            this.removeUserParams();
        }
        
        return logged;
    }

    clearUserData(){
    	this.setUserParams(null);
        this.removeUserParams();
        localStorage.clear();
    }    

    getUserSoeId() {
        let up = this.getUserParams();
        console.debug("LoginService::getUserSoeId", up.soeid);
        if (up != null) {
            return up.soeid;
        }
        console.error("LoginService::getUserSoeId UserParams are not defined!");
    }

    getUserRole() {
        let up = this.getUserParams();
        console.debug("LoginService::getUserRole", up.role);
        if (up != null) {
            return up.role;
        }
        console.error("LoginService::getUserSoeId UserParams are not defined!");
    }
    
    removeUserParams() {
        this.myStorage.removeStorageKey('userParams_name');
        this.myStorage.removeStorageKey('userParams_email');
        this.myStorage.removeStorageKey('userParams_soeid');
        this.myStorage.removeStorageKey('userParams_role');
        this.myStorage.removeStorageKey('userParams_cbaAccess');
        this.myStorage.removeStorageKey('userParams_businessCritical');
        this.myStorage.removeStorageKey('userParams_techPages');
    }

    get events():Subject<AuthEvent> {
        console.debug("LoginService::events", this.authEvents);
        return this.authEvents;
    } 
    getBusinessCritical():string[]{
        let up=this.getUserParams();
        var businessCriticalArray=up.businessCriticalPages.toString().split(',');
        if(up!=null){
            return businessCriticalArray;
        }
        console.error("LoginService::businessCriticalPages UserParams are not defined!");
    }
    getTechnicalPagesPermission():number{
        let up=this.getUserParams();
        if(up!=null){
            return up.techPagesPermission;
        }
        console.error("LoginService::businessCriticalPages UserParams are not defined!");
    }
}

export class DidLogin {
}

export class DidLogout {
}

export type AuthEvent = DidLogin | DidLogout;

// if (data.status_Code == 'CBA_1000') {
//     toggleLoginChangePwd();
// } else {
//     if (data.isAuthenticated) {
//         if (data.isAuthorized) {
//             Idle.watch();
//             $state.go('exceptionsummary');
//         } else {
//             toastr.error('User not Authorised', 'Error');
//         }
//     } else if (data.statusCode == "CBA_1000") {
//         $('#' + "toggleLoginPwd").html("<strong>Log In</strong>");
//         clearData();
//         $('#' + "loginbox").hide();
//         $('#' + "changebox").show();
//         toastr.error('Please change your password', 'Alert');
//     } else {
//         toastr.error('User not Authenticated', 'Error');
//     }
//
// }