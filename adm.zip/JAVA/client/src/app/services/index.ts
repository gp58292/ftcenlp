import {Http, HttpModule, XHRBackend, RequestOptions} from "@angular/http";
import {MockBackend} from "@angular/http/testing";
import {HttpErrorHandler} from "./http-error-handler";
import {LoginService} from "./login.service";
import {PrivatePageGuard} from "./private-page.guard";
import {MyHttp} from './http';

export * from  "./storage-wrapper";
export * from './http-error-handler';
export * from './login.service';
export * from './private-page.guard';
export * from './http';


export const APP_SERVICE_PROVIDERS = [
    HttpErrorHandler,
    LoginService,
    PrivatePageGuard,
];

export const APP_TEST_SERVICE_PROVIDERS = APP_SERVICE_PROVIDERS;

export const APP_HTTP_PROVIDERS = [
    {
        provide: MyHttp,
        useFactory: (xhrBackend:XHRBackend, requestOptions:RequestOptions) => {
            const ngHttp = new Http(xhrBackend, requestOptions);
            return new MyHttp(ngHttp);
        },
        deps: [XHRBackend, RequestOptions]
    },
];

export const APP_TEST_HTTP_PROVIDERS = [
    MockBackend,
    {
        provide: MyHttp,
        useFactory: (mockBackend:MockBackend, requestOptions:RequestOptions) => {
            const http = new Http(mockBackend, requestOptions);
            return new MyHttp(http);
        },
        deps: [MockBackend, RequestOptions]
    },
];