export interface Page<T> {
    content:T[];
    totalPages:number;
    totalElements:number;
}

export interface PageRequest {
    page:number;
    size:number;
}

export interface UserParams {
    email?:string;
    password?:string;
    name?:string;
    soeid?:string;
    role?:string;
    isCBAAccessible?:boolean;
    techPagesPermission?:number;
    businessCriticalPages:Array<string>

}

export interface EnvironmentVersion {
	envName:string;
	buildVersion:string;
}
export class UserRole {
    UserRole(){}
    public GLOBAL_ADMIN : string = "global_admin";
    public ADMIN : string = "admin";
    public COVERAGE : string = "coverage_based";
    public VIEW_ONLY : string = "view_only";
}

