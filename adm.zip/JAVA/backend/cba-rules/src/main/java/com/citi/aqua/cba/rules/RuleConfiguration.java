package com.citi.aqua.cba.rules;

import org.kie.api.KieServices;
import org.kie.api.runtime.KieContainer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

/**
 * Created by ag52020 on 1/5/2016.
 */
@Configuration
@ComponentScan(basePackages = {"com.citi.aqua.cba.model"})
public class RuleConfiguration {


	@Bean
	public KieContainer kieContainer() {
		return KieServices.Factory.get().getKieClasspathContainer();
	}

	
}
