package com.citi.aqua.cba.web.controller;

import java.util.Arrays;
import java.util.List;
import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;
import org.powermock.api.support.membermodification.MemberModifier;

import com.citi.aqua.cba.model.FeedDelayData;
import com.citi.aqua.cba.model.FeedDelayDataDetails;
import com.citi.aqua.cba.services.service.impl.BatchDelayServiceImpl;
import com.citi.aqua.cba.services.service.impl.DownstreamNotificationServiceImpl;
import com.citi.aqua.cba.services.service.impl.UserNotificationServiceImpl;

import junit.framework.TestCase;

public class BatchAutomationControllerTest extends TestCase {

	private BatchAutomationController batchAutomationController;
	private BatchDelayServiceImpl batchDelayService;
	private UserNotificationServiceImpl userNotificationService;
	private DownstreamNotificationServiceImpl downstreamNotificationService;

	@Before
	public void setUp() throws Exception {
		batchAutomationController = EasyMock.createMockBuilder(BatchAutomationController.class).createMock();

		batchDelayService = EasyMock.mock(BatchDelayServiceImpl.class);
		MemberModifier.field(BatchAutomationController.class, "batchDelayService").set(batchAutomationController,
				batchDelayService);

		userNotificationService = EasyMock.mock(UserNotificationServiceImpl.class);
		MemberModifier.field(BatchAutomationController.class, "userNotificationService").set(batchAutomationController,
				userNotificationService);

		downstreamNotificationService = EasyMock.mock(DownstreamNotificationServiceImpl.class);
		MemberModifier.field(BatchAutomationController.class, "downstreamNotificationService")
				.set(batchAutomationController, downstreamNotificationService);
	}

	@Test
	public void testGetDelaySources() throws Exception {
		final List<String> feedSourcesList = Arrays.asList("PRE BORROW DELAY", "SECFIN DELAY", "RMT DELAY",
				"FUTURE BILLING DELAY", "FUTURE MONEY BALANCE DELAY", "FUTURE TRADE FEED DELAY",
				"SEQUEL CPC LONG DELAY");

		EasyMock.expect(batchDelayService.getDelaySources()).andReturn(feedSourcesList);
		EasyMock.replay(batchDelayService);

		MemberModifier.field(BatchAutomationController.class, "batchDelayService").set(batchAutomationController,
				batchDelayService);

		EasyMock.replay(batchAutomationController);
		List<String> actual = batchAutomationController.getDelaySources();
		EasyMock.verify(batchAutomationController);
		assertEquals(true, actual.contains("PRE BORROW DELAY"));
		assertEquals(feedSourcesList.size(), actual.size());
	}

	@Test
	public void testSubmitBatchDelay() throws Exception {
		FeedDelayData batchDelayData = new FeedDelayData();
		batchDelayData.setArea_impacted("NAM, EMEA, APAC");
		batchDelayData.setDescription("Pre borrow Delay");
		batchDelayData.setEta_resolution("1");
		batchDelayData.setIssue("PRE BORROW DELAY");
		batchDelayData.setInc_mim("");
		batchDelayData.setNext_update("1");

		Boolean insertFlag = true;
		batchAutomationController = EasyMock.mock(BatchAutomationController.class);
		EasyMock.expect(batchAutomationController.submitBatchDelay(batchDelayData)).andReturn(insertFlag);
		EasyMock.replay(batchAutomationController);

		assertNotNull(batchAutomationController.submitBatchDelay(batchDelayData));
	}

	@Test
	public void testGetDashboardDelayStatistics() throws Exception {
		FeedDelayDataDetails obj1 = new FeedDelayDataDetails();
		obj1.setBau("04:30 AM EST");
		obj1.setSla("03:30 AM EST");
		obj1.setEta("2:25 PM EST");
		obj1.setName("Client Revenue & Gross ROA");

		FeedDelayDataDetails obj2 = new FeedDelayDataDetails();
		obj2.setBau("04:30 AM EST");
		obj2.setSla("03:30 AM EST");
		obj2.setEta("2:25 PM EST");
		obj2.setName("PB Balances");

		List<FeedDelayDataDetails> dashboardList = Arrays.asList(obj1, obj2);

		EasyMock.expect(userNotificationService.cbaDashboardDelayEstimates()).andReturn(dashboardList);
		EasyMock.replay(userNotificationService);

		MemberModifier.field(BatchAutomationController.class, "userNotificationService").set(batchAutomationController,
				userNotificationService);

		EasyMock.replay(batchAutomationController);
		List<FeedDelayDataDetails> actual = batchAutomationController.getCBADashboardDelayStatistics();
		EasyMock.verify(batchAutomationController);
		assertEquals(true, actual.contains(obj1));
		assertEquals(dashboardList.size(), actual.size());
	}

	@Test
	public void testGetReportDelayStatistics() throws Exception {
		FeedDelayDataDetails obj1 = new FeedDelayDataDetails();
		obj1.setBau("04:30 AM EST");
		obj1.setSla("04:45 AM EST");
		obj1.setEta("Available");
		obj1.setName("PB Balances Reports");

		FeedDelayDataDetails obj2 = new FeedDelayDataDetails();
		obj2.setBau("04:30 AM EST");
		obj2.setSla("03:30 AM EST");
		obj2.setEta("2:25 PM EST");
		obj2.setName("Stock Loan P&L Reports");

		List<FeedDelayDataDetails> reportsList = Arrays.asList(obj1, obj2);

		EasyMock.expect(userNotificationService.reportsDelayEstimates()).andReturn(reportsList);
		EasyMock.replay(userNotificationService);

		MemberModifier.field(BatchAutomationController.class, "userNotificationService").set(batchAutomationController,
				userNotificationService);

		EasyMock.replay(batchAutomationController);
		List<FeedDelayDataDetails> actual = batchAutomationController.getReportDelayStatistics();
		EasyMock.verify(batchAutomationController);
		assertEquals(true, actual.contains(obj1));
		assertEquals(reportsList.size(), actual.size());
	}

	@Test
	public void testGetCADDelayStatistics() throws Exception {
		FeedDelayDataDetails obj1 = new FeedDelayDataDetails();
		obj1.setBau("04:41 AM EST");
		obj1.setSla("05:00 AM EST");
		obj1.setEta("Available");
		obj1.setName("PB Balance and Position Related Alerts ");

		FeedDelayDataDetails obj2 = new FeedDelayDataDetails();
		obj2.setBau("08:30 AM EST");
		obj2.setSla("10:30 AM EST");
		obj2.setEta("01:00 PM EST");
		obj2.setName("PB Revenue and Balance Sheet Related Alerts");

		List<FeedDelayDataDetails> cadList = Arrays.asList(obj1, obj2);

		EasyMock.expect(userNotificationService.cadDelayEstimates()).andReturn(cadList);
		EasyMock.replay(userNotificationService);

		MemberModifier.field(BatchAutomationController.class, "userNotificationService").set(batchAutomationController,
				userNotificationService);

		EasyMock.replay(batchAutomationController);
		List<FeedDelayDataDetails> actual = batchAutomationController.getCADDelayStatistics();
		EasyMock.verify(batchAutomationController);
		assertEquals(true, actual.contains(obj1));
		assertEquals(cadList.size(), actual.size());
	}

	@Test
	public void testGetFeedDataDelayStatistics() throws Exception {
		FeedDelayDataDetails obj1 = new FeedDelayDataDetails();
		obj1.setBau("04:41 AM EST");
		obj1.setSla("05:00 AM EST");
		obj1.setEta("Available");
		obj1.setName("PB Position and Balances to AQUA S&U ");

		FeedDelayDataDetails obj2 = new FeedDelayDataDetails();
		obj2.setBau("08:30 AM EST");
		obj2.setSla("10:30 AM EST");
		obj2.setEta("01:00 PM EST");
		obj2.setName("CSL Balance data to TRS");

		List<FeedDelayDataDetails> cadList = Arrays.asList(obj1, obj2);

		EasyMock.expect(downstreamNotificationService.feedDataDelayEstimates()).andReturn(cadList);
		EasyMock.replay(downstreamNotificationService);

		MemberModifier.field(BatchAutomationController.class, "downstreamNotificationService")
				.set(batchAutomationController, downstreamNotificationService);

		EasyMock.replay(batchAutomationController);
		List<FeedDelayDataDetails> actual = batchAutomationController.getFeedDataDelayStatistics();
		EasyMock.verify(batchAutomationController);
		assertEquals(true, actual.contains(obj1));
		assertEquals(cadList.size(), actual.size());
	}

	
	

}
