package com.citi.aqua.cba.web.filter;
//
//
//import static org.junit.Assert.assertNotNull;
//import static org.junit.Assert.assertTrue;
//
//import java.util.Set;
//
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.context.support.GenericApplicationContext;
//import org.springframework.mock.env.MockPropertySource;
//import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
//import org.springframework.test.context.support.AnnotationConfigContextLoader;
//
///**
// * Created by ig55749 on 8/19/2016.



//@Configuration
//@Import(AnotherConfiguration.class)
//static class ContextConfiguration {
//    @Bean
//    protected PropertyRetriever retriever() {
//        return new PropertyRetriever() {
//            @Override
//            public void addListener(PropertyListener listener) {
//                throw new UnsupportedOperationException();
//            }
//        };
//    }
//}

//
//@RunWith(SpringJUnit4ClassRunner.class)
//@org.springframework.test.context.ContextConfiguration
//        (loader = LoggingFilterTest.CustomAnnotationConfigContextLoader.class, classes = {LoggingFilter.class})
public class LoggingFilterTest {
//
//    @Autowired
//    private LoggingFilter filter;
//
//    @Test
//    public void doFilterInternal() throws Exception {
//       assertNotNull(filter);
//    }
//
//    @Test
//    public void getExcludePatterns() throws Exception {
//        assertNotNull(filter);
//        Set<String> paterns = filter.getExcludePatterns();
//        assertTrue(paterns.size()>0);
//        //("/");
//        //("/**/*.ico");
//        //("/**/*.js");
//        //("/**/*.css");
//        assertTrue(paterns.contains("/"));
//        assertTrue(paterns.contains("/**/*.ico"));
//        assertTrue(paterns.contains("/**/*.js"));
//        assertTrue(paterns.contains("/**/*.css"));
//    }
//
//    @Test
//    public void setExcludePatterns() throws Exception {
//        assertNotNull(filter);
//    }
//
//    static class CustomAnnotationConfigContextLoader extends AnnotationConfigContextLoader {
//        @Override
//        protected void customizeContext(GenericApplicationContext context) {
//            MockPropertySource source = new MockPropertySource()
//                    .withProperty("any.prop.key", "value");
//            context.getEnvironment().getPropertySources().addFirst(source);
//        }
//    }
}