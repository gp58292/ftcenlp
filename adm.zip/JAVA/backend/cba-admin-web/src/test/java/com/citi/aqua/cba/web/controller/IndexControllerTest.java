package com.citi.aqua.cba.web.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import junit.framework.TestCase;

import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;
import org.springframework.web.servlet.ModelAndView;

/**
 * @author gp58292
 *
 */
public class IndexControllerTest extends TestCase {
	
	private IndexController indexController;
	private HttpServletRequest request;
	private HttpServletResponse response;
	private ModelAndView mav;

	@Before
	public void setUp() throws Exception {
		indexController = EasyMock.createMockBuilder(IndexController.class).createMock();
		mav = EasyMock.mock(ModelAndView.class);
		request = EasyMock.mock(HttpServletRequest.class);
		response = EasyMock.mock(HttpServletResponse.class);
	}
	
	@Test
	public void testAppInit() throws Exception {
		indexController = EasyMock.mock(IndexController.class);
		EasyMock.expect(indexController.appInit()).andReturn(mav).times(2);
		EasyMock.replay(indexController);
		
		assertNotNull(indexController.appInit());
		assertEquals(mav, indexController.appInit());
	}
	
	@Test
	public void testGetUser() throws Exception {
		String user = "user";
		indexController = EasyMock.mock(IndexController.class);
		EasyMock.expect(indexController.getUser(request, response)).andReturn(user).times(2);
		EasyMock.replay(indexController);
		
		assertNotNull(indexController.getUser(request, response));
		assertEquals("user", indexController.getUser(request, response));
	}

}
