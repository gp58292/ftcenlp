package com.citi.aqua.cba.web.controller;

import java.util.ArrayList;
import java.util.List;

import junit.framework.TestCase;

import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;
import org.powermock.api.support.membermodification.MemberModifier;

import com.citi.aqua.cba.model.DropDownModel;
import com.citi.aqua.cba.model.EWSUser;
import com.citi.aqua.cba.model.LoginStatusEnum;
import com.citi.aqua.cba.model.UpdateUserCoverageRequest;
import com.citi.aqua.cba.model.UpdateUserRoleRequest;
import com.citi.aqua.cba.model.UserCoverage;
import com.citi.aqua.cba.model.UserHistory;
import com.citi.aqua.cba.services.service.AdminServiceImpl;

/**
 * @author gp58292
 *
 */
public class AdminControllerTest extends TestCase {

	private AdminController adminController;
	private AdminServiceImpl adminService;

	@Before
	public void setUp() throws Exception{
		adminController = EasyMock.createMockBuilder(AdminController.class).createMock();

		adminService = EasyMock.mock(AdminServiceImpl.class);
		MemberModifier.field(AdminController.class, "adminService").set(adminController , adminService);
	}
	
	@Test
	public void testGetEWSUsers() throws Exception {
		List<EWSUser> results = new ArrayList<EWSUser>();
		EWSUser user = new EWSUser();
		user.setSoeid("df21521");
		user.setEmail("test@test.com");
		user.setStatus(LoginStatusEnum.CBA_200.getStatusMsg());
		user.setFriendly_name("Test Test");
		results.add(user);
		
		EasyMock.expect(adminService.getEWSUsers()).andReturn(results);
		EasyMock.replay(adminService);
		
		MemberModifier.field(AdminController.class, "adminService").set(adminController , adminService);

		EasyMock.replay(adminController); 
		List<EWSUser> actual = adminController.getEWSUsers();
		EasyMock.verify(adminController);
		assertEquals(true, actual.contains(user));	
	}
	
	@Test
	public void testGetUserCoverage() throws Exception {
		List<UserCoverage> userCoverageList = new ArrayList<UserCoverage>();
		UserCoverage userCoverage = new UserCoverage();
		userCoverage.setGpnum("12345");
		userCoverage.setSoeid("gp555");
		userCoverageList.add(userCoverage);
	
		adminController = EasyMock.mock(AdminController.class);
		EasyMock.expect(adminController.getUserCoverage("1234")).andReturn(userCoverageList).times(3);		
		EasyMock.replay(adminController);
		
		assertNotNull(adminController.getUserCoverage("1234"));
		assertTrue(adminController.getUserCoverage("1234").size() > 0);		
		assertEquals(true, adminController.getUserCoverage("1234").contains(userCoverage));
	}
	
	@Test
	public void testGetEWSUser() throws Exception {
		EWSUser user = new EWSUser();
		user.setSoeid("df21521");
		user.setEmail("test@test.com");
		user.setStatus(LoginStatusEnum.CBA_200.getStatusMsg());
		user.setFriendly_name("Test Test");
	
		adminController = EasyMock.mock(AdminController.class);
		EasyMock.expect(adminController.getEWSUser("1234")).andReturn(user).times(2);		
		EasyMock.replay(adminController);
		
		assertNotNull(adminController.getEWSUser("1234"));
		assertEquals(user, adminController.getEWSUser("1234"));
	}
	
	@Test
	public void testGetClientCoverageList()  throws Exception {
		List<DropDownModel> results = new ArrayList<DropDownModel>();
		DropDownModel dropDownModel = new DropDownModel();
		dropDownModel.setText("Test Test");
		dropDownModel.setValue("Value");
		results.add(dropDownModel);
		
		EasyMock.expect(adminService.getClientCoverageList()).andReturn(results);
		EasyMock.replay(adminService);
		
		MemberModifier.field(AdminController.class, "adminService").set(adminController , adminService);
	
		EasyMock.replay(adminController); 
		List<DropDownModel> actual = adminController.getClientCoverageList();
		EasyMock.verify(adminController);
		assertEquals(true, actual.contains(dropDownModel));	
	}
	
	@Test
	public void testUpdateUserRole() throws Exception {
		adminController = EasyMock.mock(AdminController.class);
		UpdateUserRoleRequest updateUserRole = EasyMock.mock(UpdateUserRoleRequest.class);
		EasyMock.expect(adminController.updateUserRole(updateUserRole)).andReturn(true).times(2);		
		EasyMock.replay(adminController);
		
		assertNotNull(adminController.updateUserRole(updateUserRole));
		assertEquals(true, adminController.updateUserRole(updateUserRole));
	}

	@Test
	public void testUpdateUserCoverage() throws Exception {
		adminController = EasyMock.mock(AdminController.class);
		UpdateUserCoverageRequest updateUserRole = EasyMock.mock(UpdateUserCoverageRequest.class);
		EasyMock.expect(adminController.updateUserCoverage(updateUserRole)).andReturn(true).times(2);		
		EasyMock.replay(adminController);
		
		assertNotNull(adminController.updateUserCoverage(updateUserRole));
		assertEquals(true, adminController.updateUserCoverage(updateUserRole));
	}

	@Test
	public void testGetClientCoverageListById() throws Exception {
		List<UserHistory> results = new ArrayList<UserHistory>();
		UserHistory userHistory = new UserHistory();
		userHistory.setId(1234);
		userHistory.setSoeid("gp12345");
		results.add(userHistory);
		
		EasyMock.expect(adminService.getUserHistory("1234")).andReturn(results);
		EasyMock.replay(adminService);
		
		MemberModifier.field(AdminController.class, "adminService").set(adminController , adminService);
	
		EasyMock.replay(adminController); 
		List<UserHistory> actual = adminController.getClientCoverageList("1234");
		EasyMock.verify(adminController);
		assertEquals(true, actual.contains(userHistory));	
	}


	
}
