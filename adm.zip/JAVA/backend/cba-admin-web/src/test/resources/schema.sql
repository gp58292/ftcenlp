SET MODE MSSQLServer
CREATE SCHEMA [dbo]
create table [dbo].[seed_load_cpc2] (cob_date int null,flag varchar(10) null,loaddate datetime null)

--CREATE TABLE seed_load_cpc2 (cob_date int NULL, flag varchar(10) NULL,load_date datetime NULL DEFAULT (getdate()))