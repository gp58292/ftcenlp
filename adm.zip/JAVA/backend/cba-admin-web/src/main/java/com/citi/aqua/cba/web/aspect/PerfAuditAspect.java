package com.citi.aqua.cba.web.aspect;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * Aspect used for logging time taken by methods at controller, service and dao layers.
 * @author gp58292
 *
 */
@Component
@Aspect
public class PerfAuditAspect {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(PerfAuditAspect.class);

	@Pointcut("within(com.citi.aqua.cba.web.controller.*)")
	public void inController() {}

	@Pointcut("within(com.citi.aqua.cba.services.service..*)")
	public void inService() {}

	@Pointcut("within(com.citi.aqua.cba.data.mapper.cba..*)")
	public void inDAO() {}
	
	@Around("inController() || inService() || inDAO()")
	public Object audit(ProceedingJoinPoint joinPoint) throws Throwable {
		Signature methodSignature = joinPoint.getSignature();
		//LOGGER.debug("{} called", methodSignature);
		long startTime = System.currentTimeMillis();
		Object result = joinPoint.proceed();
		long stopTime = System.currentTimeMillis();
	    LOGGER.debug("{} completed in {} ms", methodSignature, (stopTime - startTime));
	    return result;
	}
	
	
}
