package com.citi.aqua.cba.web.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.ResponseStatus;
import com.citi.aqua.cba.model.SeedLoadCPC;
import com.citi.aqua.cba.services.service.SeedLoadCPCService;
//import com.wordnik.swagger.annotations.ApiOperation;
import org.springframework.http.HttpStatus;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
@RequestMapping("/api/seedloadcpc")
public class SeedLoadCPCController {

	private static final Logger LOGGER = LoggerFactory.getLogger(SeedLoadCPCController.class);

	@Autowired
	private SeedLoadCPCService seedLoadCPCService;

	@RequestMapping(value = "/getSeedLoadCPC", method = RequestMethod.GET)
	@ResponseStatus(HttpStatus.OK)
	public @ResponseBody List<SeedLoadCPC> getSeedLoadCPC() {
		LOGGER.debug("Retrieving all Records from SeedLoadCPC ");

		return seedLoadCPCService.getSeedLoadCPC();
	}

	@RequestMapping(value = "/insertSeedLoadCPC", method = RequestMethod.POST)
	public List<SeedLoadCPC> insertSeedLoadCPC(@RequestBody SeedLoadCPC seedLoadCPC) {
		LOGGER.debug("Inserting SeedLoadCPC record ");

		final String cobDate = seedLoadCPC.getCobDate();
		final String flag = seedLoadCPC.getFlag();

		// this accounts for if the user leaves a field blank then it should not add
		// record to table & database
		if ("" == cobDate || "" == flag) {
			throw new IllegalArgumentException("Either CobDate or Flag has no value");
		}

		// if the fields are not empty and no duplicate record is found in the table
		// then add the record
		seedLoadCPCService.insertSeedLoadCPC(seedLoadCPC);

		return seedLoadCPCService.getSeedLoadCPC();
	}

	@RequestMapping(value = "/findByFlag/{flag}", method = RequestMethod.GET)
	public List<SeedLoadCPC> findByFlag(@PathVariable("flag") String flag) {
		LOGGER.debug("Finding SeedLoadCPC record by flag ");

		final List<SeedLoadCPC> seedLoadCPC = seedLoadCPCService.findByFlag(flag);
		if (seedLoadCPC == null) {
			LOGGER.info("seedLoadCPC with flag " + flag + " not found");

			return null;
		}

		return seedLoadCPC;
	}

	@RequestMapping(value = "/findByCobDate/{cobDate}", method = RequestMethod.GET)
	public List<SeedLoadCPC> findByCobDate(@PathVariable("cobDate") String cobDate) {
		LOGGER.debug("Finding SeedLoadCPC record by cob Date ");
		final List<SeedLoadCPC> seedLoadCPC = seedLoadCPCService.findByCobDate(cobDate);
		if (seedLoadCPC == null) {
			LOGGER.info("seedLoadCPC with cob date " + cobDate + " not found");
			return null;
		}
		LOGGER.info("found SeedLoadCPC with cob date of:" + cobDate);
		return seedLoadCPC;
	}

	@RequestMapping(value = "/deleteSeedLoadCPC/cobdate/{cobDate}/loaddate/{loadDate}", method = RequestMethod.DELETE)
	public void deleteSeedLoadCPC(@PathVariable("cobDate") String cobDate, @PathVariable("loadDate") String loadDate) {
		LOGGER.debug("Deleting SeedLoadCPC Record by CobDate: " + cobDate + " : " + loadDate);
		seedLoadCPCService.deleteSeedLoadCPC(cobDate, loadDate);
	}

	@RequestMapping(value = "/updateByCobDate", method = RequestMethod.PUT)
	public void updateByCobDate(@RequestBody SeedLoadCPC seedLoadCPC) {
		LOGGER.debug("Updating SeedLoadCPC Record by CobDate");
	}

}
