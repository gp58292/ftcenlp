package com.citi.aqua.cba.web.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import com.citi.aqua.cba.web.CBAAdminApplication;
import com.google.gson.Gson;

@Controller
@CrossOrigin(origins = "http://localhost:3000")
@RequestMapping("/")
public class IndexController {

    @Value("${dashboard.time.interval}")
    private String dashboardInterval;
    private static final Logger LOGGER = LoggerFactory.getLogger(IndexController.class);

    @RequestMapping(value = "/cba", method = RequestMethod.GET)
    public ModelAndView appInit() {
        return new ModelAndView("/html/index.html");
    }
    
    @RequestMapping(value = "/getEnviromentDetails", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public String getUser(HttpServletRequest request, HttpServletResponse response) {   
    	Map<String, String> map = new HashMap<>();
        map.put("envName", CBAAdminApplication.getEnvName());
        map.put("buildVersion", CBAAdminApplication.getBuildNumber());
        Gson gson = new Gson();
        return gson.toJson(map);
    }
    

    
    @RequestMapping(value = "/logClientErrors", method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.OK)
    @ResponseBody
    public void logClientErrors(@RequestBody String errorMessage) {
		LOGGER.error("## UI ERROR Start ## : \n"+ errorMessage);
		LOGGER.error("## UI ERROR End   ## : ");
    }
}