package com.citi.aqua.cba.web.controller;


import com.citi.aqua.cba.model.Request;
import com.citi.aqua.cba.model.UploadFile;
import com.citi.aqua.cba.services.service.RequestService;
import org.apache.tomcat.jni.FileInfo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;

/**
 * Created by jm27909 on 7/21/2017.
 */

@RestController
@CrossOrigin(origins = "http://localhost:3000")
@RequestMapping("/api/request")
public class RequestController {

    private static final Logger LOGGER = LoggerFactory.getLogger(RequestController.class);

    @Autowired
    private RequestService requestService;

    //api/request/getRequestList
    @RequestMapping(value = "/getRequestList", method = RequestMethod.GET)
    @ResponseStatus(HttpStatus.OK)
    public @ResponseBody
    List<Request> getRequestList() {
        LOGGER.debug("Retrieving all Records from Request table");

        return requestService.getRequestList();
    }

    //api/request/insertRequest
    @RequestMapping(value = "/insertRequest", method = RequestMethod.POST)
    public List<Request> insertRequest(@RequestBody Request request) {
        LOGGER.debug("Inserting Request record ");

        requestService.insertRequest(request);

        return requestService.getRequestList();
    }

    //api/request/deleteRequest
    @RequestMapping(value = "/deleteRequest/id/{id}", method = RequestMethod.DELETE)
    public List<Request> deleteRequest(@PathVariable("id") int id) {
        LOGGER.debug("Deleting request record ");

        requestService.deleteRequest(id);

        return requestService.getRequestList();
    }

    //api/request/editRequest
    @RequestMapping(value = "/editRequest", method = RequestMethod.PUT)
    public List<Request> updateRequest(@RequestBody Request request) {
        LOGGER.debug("Retrieving Request");

        requestService.updateRequest(request);

        return requestService.getRequestList();
    }

    //api/request/getRequestFileList
    //when you click the edit button you want to get all file attachments associated with this request
    @RequestMapping(value = "/getRequestFileList/{requestId}", method = RequestMethod.GET)
    public List<UploadFile> getRequestFileList(@PathVariable("requestId") int requestId) {
        LOGGER.debug("Getting all attached files that correlate to request");

        return requestService.getRequestFileList(requestId);
    }

    //api/request/upload
    @RequestMapping(value = "/upload/{requestId}", method = RequestMethod.POST)
    public void uploadFiles(@RequestParam("file") MultipartFile[] files,@PathVariable("requestId") int requestId) throws IOException {
        LOGGER.debug("Uploading Files for request confirmation");

        requestService.upload(files,requestId);

        return;
    }

    //api/request/download/{requestId}
    //will be used to download a file corresponding to that row
    //need to specify file name as one row could have multiple attachments
    @RequestMapping(value = "/download/{requestId}/{fileName:.+}", method = RequestMethod.GET)
    public @ResponseBody void download(@PathVariable("requestId") int requestId,@PathVariable("fileName") String fileName, HttpServletResponse response) {
        LOGGER.debug("Downloading File");
        System.out.println("ID for download: " + requestId);
        System.out.println("ID for download: " + fileName);
        //retrieve file contents
        UploadFile file = requestService.getFile(requestId, fileName);
        System.out.println("ID for download: " + file.getFileName());

        //check file contents
        if (file != null) {
            LOGGER.debug("The File retrieved is not null so start download");
            try {
                InputStream is = new ByteArrayInputStream(file.getFileObject());
                LOGGER.debug("Opened stream for downloading file");
                response.setContentType("application/octet-stream");
                response.setHeader("Content-Disposition", "attachment; filename=\"" + file.getFileName() + "\"");
                OutputStream os = response.getOutputStream();
                byte[] buffer = new byte[1024];
                int len;
                while ((len = is.read(buffer)) != -1) {
                    os.write(buffer, 0, len);
                }
                os.flush();
                os.close();
                is.close();
                LOGGER.debug("Closed streams after download");
            } catch (IOException e) {
                LOGGER.error("An exception occurred: while fetching file" + e.getLocalizedMessage());
            }
        } else {
            LOGGER.debug("The File retrieved is null");
        }

        return;
    }

}