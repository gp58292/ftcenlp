package com.citi.aqua.cba.web.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.HashMap;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.CrossOrigin;
import com.citi.aqua.cba.web.CBAAdminApplication;
import com.citi.aqua.cba.model.CBAAPIResponse;
import com.citi.aqua.cba.model.UserAdmin;
import com.citi.aqua.cba.security.AuthenticationService;
import com.google.gson.Gson;

@Controller
@CrossOrigin(origins = "http://localhost:3000")
@RequestMapping("/api/sso")
public class LoginController extends BaseController {

	@Autowired
	private AuthenticationService authenticationService;
	private static final Logger LOGGER = LoggerFactory.getLogger(LoginController.class);

	@RequestMapping(value = "/authenticate", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public String checkUserIsValid(HttpServletRequest request, HttpServletResponse response,
			@RequestBody UserAdmin user) {
		HttpSession session = request.getSession(true);
		Gson gson = new Gson();
		return gson.toJson(authenticationService.authenticateUser(session, user));
	}

	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	@ResponseBody
	public CBAAPIResponse logout(HttpServletRequest request, HttpServletResponse response, HttpSession session)
			throws IOException {
		if (session != null) {
			LOGGER.info("[Invalidating session]" + session.getId());
			authenticationService.killSession(session);

		}
		CBAAPIResponse apiResponse = new CBAAPIResponse();
		apiResponse.setStatus(true);
		apiResponse.setMessage("User Logged out successfully.");
		return apiResponse;
	}

	@RequestMapping(value = "/getEnviromentDetails", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public String getUser(HttpServletRequest request, HttpServletResponse response) {
		Map<String, String> map = new HashMap<>();
		map.put("envName", CBAAdminApplication.getEnvName());
		map.put("buildVersion", CBAAdminApplication.getBuildNumber());
		Gson gson = new Gson();
		return gson.toJson(map);
	}
}
