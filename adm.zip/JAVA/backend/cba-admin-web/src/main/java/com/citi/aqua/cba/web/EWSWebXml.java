package com.citi.aqua.cba.web;


 
import javax.servlet.ServletContext;
import javax.servlet.ServletException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.ServletContextInitializer;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class EWSWebXml extends SpringBootServletInitializer {
 
    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
        return application.sources(CBAAdminApplication.class);
    }

    /*@Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
        return application.sources(Application.class);
    }*/

    public static void main(String[] args) {
        SpringApplication.run(EWSWebXml.class, args);
    }

    @Bean
    public ServletContextInitializer initializer() {
        return new ServletContextInitializer() {
            @Override
            public void onStartup(ServletContext servletContext) throws ServletException {
                //servletContext.setInitParameter("parentContextKey", "globalContext");
                //servletContext.setInitParameter("contextConfigLocation", "classpath*:application-context-datasource-cba.xml");
            }
        };
    }
    
//    @Bean(name="multipartResolver") 
//    public CommonsMultipartResolver commonsMultipartResolver() throws IOException{
//        CommonsMultipartResolver resolver = new CommonsMultipartResolver();
//         
//        //Set the maximum allowed size (in bytes) for each individual file.
//        resolver.setMaxUploadSizePerFile(5242880);//5MB
//         
//        //You may also set other available properties.
//         
//        return resolver;
//    }

}