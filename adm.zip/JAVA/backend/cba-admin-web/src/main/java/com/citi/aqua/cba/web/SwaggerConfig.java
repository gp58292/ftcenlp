package com.citi.aqua.cba.web;
//
//
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.web.servlet.config.annotation.DefaultServletHandlerConfigurer;
//import org.springframework.web.servlet.config.annotation.PathMatchConfigurer;
//import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
//import org.springframework.web.util.UrlPathHelper;
//
//import com.mangofactory.swagger.configuration.SpringSwaggerConfig;
//import com.mangofactory.swagger.models.dto.ApiInfo;
//import com.mangofactory.swagger.plugin.EnableSwagger;
//import com.mangofactory.swagger.plugin.SwaggerSpringMvcPlugin;
//
//@Configuration
//@EnableSwagger
public class SwaggerConfig
//        extends WebMvcConfigurerAdapter
{
//
//    @Autowired
//    private SpringSwaggerConfig swaggerConfig;
//
//    @Override
//    public void configureDefaultServletHandling(DefaultServletHandlerConfigurer configurer) {
//        configurer.enable();
//    }
//
//   /* @Bean
//    public InternalResourceViewResolver getInternalResourceViewResolver() {
//        InternalResourceViewResolver resolver = new InternalResourceViewResolver();
//        resolver.setPrefix("/WEB-INF/jsp/");
//        resolver.setSuffix(".jsp");
//        return resolver;
//    }*/
//
//    @Bean
//    public SwaggerSpringMvcPlugin groupOnePlugin() {
//        return new SwaggerSpringMvcPlugin(swaggerConfig).
//                apiInfo(apiInfo()).
//                swaggerGroup("admin");
//    }
//
//    private ApiInfo apiInfo() {
//        ApiInfo apiInfo = new ApiInfo(
//                "AQUA RACE Services",
//                "Application with AQUA RACE Services exposed via Swagger ",
//                "Terms of use",
//                "ashok.k.gajaraj@citi.com",
//                "SLA",
//                "ashok.k.gajaraj@citi.com"
//        );
//        return apiInfo;
//    }
//    @Override
//    public void configurePathMatch(PathMatchConfigurer configurer) {
//        UrlPathHelper urlPathHelper = new UrlPathHelper();
//        urlPathHelper.setUrlDecode(false);
//        configurer.setUrlPathHelper(urlPathHelper);
//    }
//
//
}
