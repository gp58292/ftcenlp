package com.citi.aqua.cba.web.controller;

import java.util.List;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.citi.aqua.cba.model.DataLogging;
import com.citi.aqua.cba.services.service.DataLoggingService;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
@RequestMapping("/api/datalogging")
public class DataLoggingController {
	private static final Logger LOGGER = LoggerFactory.getLogger(DataLoggingController.class);

	@Autowired
	private DataLoggingService dataLoggingService;
	
	@RequestMapping(value = "/searchDBAndStoreProcedure/p1/{cbaProc}/p2/{raceProc}/p3/{futureProc}/p4/{slProc}/numRows/{numberOfRows}", method = RequestMethod.GET)
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public List<DataLogging> searchDBAndStoreProcedure(@PathVariable("cbaProc")String cbaProc,
			@PathVariable("raceProc")String raceProc,
			@PathVariable("futureProc")String futureProc,
			@PathVariable("slProc")String slProc,
			@PathVariable("numberOfRows")int numberOfRows){
		
		LOGGER.debug(" Retrieving records from multi database : "+ cbaProc +" : " + raceProc + " : " + futureProc + " : " + slProc + " : " + numberOfRows);
		
		return dataLoggingService.searchDBAndStoreProcedure( cbaProc, raceProc, futureProc, slProc,numberOfRows);		
	}
	
	@RequestMapping(value = "/searchdb/d1/{cbaDB}/d2/{raceDB}/d3/{futureDB}/d4/{slDB}/numRows/{numberOfRows}", method = RequestMethod.GET)
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public List<DataLogging> searchDB(@PathVariable("cbaDB") String cbaDB,
			@PathVariable("raceDB") String raceDB,
			@PathVariable("futureDB") String futureDB,
			@PathVariable("slDB") String slDB,
			@PathVariable("numberOfRows") int numberOfRows){
		LOGGER.debug(" Retrieving top 50 from database : "+ cbaDB +" : " + raceDB + " : " + futureDB + " : " + slDB + " : " + numberOfRows);
		
		return dataLoggingService.searchDB(cbaDB, raceDB, futureDB, slDB,numberOfRows);	
	}

	@RequestMapping(value = "/filterProcList/{cbaquery}/{racequery}/{futurequery}/{slquery}", method = RequestMethod.GET)
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public List<String> filterProcList(@PathVariable("cbaquery") String cbaquery,@PathVariable("racequery") String racequery,@PathVariable("futurequery") String futurequery,@PathVariable("slquery") String slquery) {
		LOGGER.debug("Retrieving Procedure Names CBA: "+ cbaquery );
		LOGGER.debug("Retrieving Procedure Names RACE: "+ racequery );
		LOGGER.debug("Retrieving Procedure Names FUTURE: "+ futurequery );
		LOGGER.debug("Retrieving Procedure Names SL: "+ slquery );
		
		return dataLoggingService.filterProcList(cbaquery,racequery,futurequery,slquery);
	}	
}