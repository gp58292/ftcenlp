package com.citi.aqua.cba.web.aspect;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.citi.aqua.cba.commons.exception.RaceApplicationException;
import com.citi.aqua.cba.commons.exception.RaceException;
import com.citi.aqua.cba.web.controller.BaseController;
import com.citi.aqua.cba.web.utils.ErrorResponse;

/**
 * Global Error Handler Aspect
 * A controller advice allows you to use exactly the same exception handling techniques but apply them across the whole application, not just to an individual controller. 
 * You can think of them as an annotation driven interceptor.
 */
@Controller
@ControllerAdvice
@PropertySource(value="classpath:i18n/race-message-bundle.properties")
public class ErrorHandlerAspect {
	

	private static final Logger LOGGER = LoggerFactory.getLogger(BaseController.class);

	@Autowired
	private Environment env;
	
	/**
     * Method that catches java validation errors
     *
     * @param ve - Method Argument Not Valid Exception being thrown
     * @return - ErrorResponse
     */
    @ExceptionHandler(MethodArgumentNotValidException.class)
    @ResponseStatus(value = HttpStatus.BAD_REQUEST)
    @ResponseBody
	public ErrorResponse validationError(final MethodArgumentNotValidException ve) {

    	ErrorResponse response = new ErrorResponse();

        BindingResult result = ve.getBindingResult();
        List<ObjectError> objectErrors = result.getAllErrors();
        ObjectError objectError = objectErrors.get(0);
        
        response.setMessage(objectError.getDefaultMessage());
     
        return response;
    }
    
    /**
     * Method that catches non application errors
     *
     * @param e - Exception being thrown
     * @return - ErrorResponse
     */
    @ExceptionHandler(RaceException.class)
    @ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
    @ResponseBody
    public ErrorResponse serverError(final Throwable e) {
        ErrorResponse response = new ErrorResponse();
		if(e instanceof RaceApplicationException){
			response.setMessage(((RaceApplicationException) e).getDefaultInterpolatedMessage() +env.getProperty("G0001"));
			response.setCode(((RaceApplicationException) e).getExceptionCode());
			response.setDeveloperMessage(((RaceApplicationException) e).getCauseMessage());
    	}else{
			response.setMessage(env.getProperty("G0000"));
			response.setCode("G0000");
			response.setDeveloperMessage(e.getCause().getMessage());
    	}
    	// add logs
    	LOGGER.error("Exception in Class "+e.getClass() + ": " + e.getMessage() + "due to : " + e.getCause(), e);

    	return response;
    }
}
