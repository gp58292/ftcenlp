package com.citi.aqua.cba.web.aspect;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.citi.aqua.cba.model.LoginStatusEnum;
import com.citi.aqua.cba.model.UserAdmin;

/**
 * @author GP58292
 *
 */
@Component
@Aspect
public class AuthAuditAspect {

	private static final Logger LOGGER = LoggerFactory.getLogger(AuthAuditAspect.class);

    @Pointcut("execution(* com.citi.aqua.cba.security.manager.SingleSignOnManager.userLogout(..))")
    public void inUserLogout(){
    }

    @AfterReturning(pointcut = "execution(* com.citi.aqua.cba.security.manager.SingleSignOnManager.authenticateUser(..))"
            ,returning="result")    
    public void afterLogin(JoinPoint joinPoint,Object result) throws Throwable {
    	UserAdmin profile = ((UserAdmin) result);
    	if (profile != null) {   
    		boolean isAuthenicated = false;;
    		boolean isAuthorized = false;
    		
    		if(profile.isAuthenticated()) {
    			isAuthenicated = true;
    			LOGGER.info("User {} ({}) is succesfully authenticated in Citi SSO portal", profile.getName(), profile.getSoeid());
    		} else {
    			 LOGGER.info("User {} ({}) is not authenticated in Citi SSO portal", profile.getName(), profile.getSoeid());
    		}
    		
	    	if(isAuthenicated && profile.getBusinessCriticalPages().size()>0  || profile.getTechPagesPermission()==1) {
	    		isAuthorized = true;
	    		LOGGER.info("User {} ({}) is succesfully authorized in AQUA portal",  profile.getName(), profile.getSoeid());
	    	} else {
	    		LOGGER.info("User {} ({}) is not authorized in AQUA portal",  profile.getName(), profile.getSoeid());
	    	}
	    	
	    	if (isAuthenicated && isAuthorized) {    		
	    		LOGGER.info("User " + profile.getName() + " ("+ profile.getSoeid() +") "+ "succesfully logged in.");
	    	} else {
	    		LOGGER.info("User " + profile.getName() +" ("+ profile.getSoeid() +") "+ " failed to logged in.");
	    	}
    	} else {
    		LOGGER.info("User does not exist.");
    	}
    }

	@Around(value = "inUserLogout() && args(profile)")
    public boolean inUserLogout(final ProceedingJoinPoint joinPoint,
        final UserAdmin profile) throws Throwable {
		boolean response = (boolean) joinPoint.proceed();
		if(response) {
			LOGGER.info("User {} ({}) successfully logged out", profile.getName(), profile.getSoeid());
		} else {
    		LOGGER.info("User " + profile.getName() + " ("+ profile.getSoeid() +") "+ " failed to logged out.");
    	}
		return response;
	}

    @AfterReturning(pointcut = "execution(* com.citi.aqua.cba.security.manager.SingleSignOnManager.forceChangePassword(..))"
            ,returning="result")    
    public void afterForceChangePassword(JoinPoint joinPoint,Object result) throws Throwable {
    	UserAdmin profile = ((UserAdmin) result);
    	if (profile != null) {   
    		if(LoginStatusEnum.CBA_200.equals(profile.getStatusCode())) {
    			LOGGER.info("User {} ({}) password is successfully changed in Citi SSO portal", profile.getName(), profile.getSoeid());
    		} else {
    		LOGGER.info("User {} ({}) password is not changed in Citi SSO portal", profile.getName(), profile.getSoeid());
    		}
    	} else {
    		LOGGER.info("User does not exist.");
    	}
    }

}

