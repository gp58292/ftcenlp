package com.citi.aqua.cba.web;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceTransactionManagerAutoConfiguration;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import com.ulisesbocchio.jasyptspringboot.annotation.EnableEncryptableProperties;

import com.citi.aqua.cba.web.utils.ManifestReader;

@SpringBootApplication
@ComponentScan({ "com.citi.aqua" })
@EnableCaching
@EnableAutoConfiguration(exclude = { DataSourceAutoConfiguration.class,
		DataSourceTransactionManagerAutoConfiguration.class })
@EnableTransactionManagement
@EnableConfigurationProperties
@PropertySource({ "classpath:/application.properties", "classpath:/application-${spring.profiles.active}.properties" })
@EnableEncryptableProperties
public class CBAAdminApplication extends SpringBootServletInitializer {

	private static final String BUILD_NUMBER = "Implementation-Version";

	@Resource
	private Environment env;
	private static String envName = "";
	private static String buildNumber = "n/a";

	public static final Logger LOGGER = LoggerFactory.getLogger(CBAAdminApplication.class);

	public static void main(String[] args) {
		SpringApplication app = new SpringApplication(CBAAdminApplication.class);
		ApplicationContext applicationContext = app.run(args);
		LOGGER.info("########################## Spring Boot Application Context Loaded: ###########################");

		if (applicationContext != null && applicationContext.getEnvironment() != null) {
			List<String> profiles = Arrays.asList(applicationContext.getEnvironment().getActiveProfiles());
			if (!profiles.isEmpty()) {
				envName = StringUtils.lowerCase(profiles.get(0));
			}
		}

		Map<String, String> map = (new ManifestReader()).readAll();
		buildNumber = map.get(BUILD_NUMBER);
	}

	public static String getEnvName() {
		return envName;
	}

	public static String getBuildNumber() {
		return buildNumber;
	}

	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		return application.sources(CBAAdminApplication.class);
	}

}
