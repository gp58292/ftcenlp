package com.citi.aqua.cba.web.filter;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.citi.aqua.cba.security.constants.CBASSOConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.AntPathMatcher;
import org.springframework.util.PathMatcher;
import org.springframework.web.filter.OncePerRequestFilter;
import org.springframework.web.util.UrlPathHelper;

import com.citi.aqua.cba.model.UserAdmin;

/**
 * @author aw11769 Authentication/Authorization 11-4-2016
 */

@Component
public class RACEAuthFilter extends OncePerRequestFilter {
	private final PathMatcher pathMatcher = new AntPathMatcher();

	private static final Logger LOGGER = LoggerFactory.getLogger(RACEAuthFilter.class);

	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {

		HttpSession session = request.getSession(false);
		boolean sessionIsValid = (session != null && session.getAttribute(CBASSOConstants.ISLOGGED_IN) != null);

		final String uri = request.getRequestURI();
		boolean skip = StaticResources.EXCLUDE_RESOURCES.stream().anyMatch(pattern -> pathMatcher.match(pattern, uri));

		if (!skip) {
			String path = new UrlPathHelper().getPathWithinApplication(request);
			if (!path.startsWith("/assets") && !path.startsWith("/html/") && !path.equals("/")
					&& !path.equals("/api/getEnviromentDetails") && !path.equals("/logClientErrors/")
					&& !path.startsWith("/api/sso")) {
				if (sessionIsValid) {
					UserAdmin userProfile = (UserAdmin) session.getAttribute("user");
					if (userProfile != null) {
						LOGGER.info("[Audit] Accessed user profile: " + userProfile.getName());
					} else {
						if (!path.equals("/html/index.html") && !path.equals("/index.html")) {
							response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
							LOGGER.error("UNAUTHORIZED REQUEST:: Invalid User: trying to access resource :" + path);
							return;
						}
					}
				} else {
					if (!path.equals("/html/index.html") && !path.equals("/index.html")) {
						response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
						LOGGER.error(
								"UNAUTHORIZED REQUEST:: Invalid session, User not logged In. Trying to access resource :"
										+ path);
						return;
					}
				}

			}
		}
		filterChain.doFilter(request, response);
	}

}
