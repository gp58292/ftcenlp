package com.citi.aqua.cba.web.aspect;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Configurable;

@Aspect
@Configurable
public class ControllerAspect {

	
	private static final Logger LOGGER = LoggerFactory.getLogger(ControllerAspect.class);
	
	/**
     * Proxy method to log before and after service method calls.
     *
     * @param joinPoint ProceedingJoinPoint
     * @return object
     * @throws Throwable throw exception
     */
	@SuppressWarnings("unused")
    @Around("execution(public * com.citi.aqua.cba.web.controller.*Controller.*(..))")
    public final Object logAround(final ProceedingJoinPoint joinPoint) throws Throwable {

        Object request = null;  
        Object response = null;

        try {
            Object[] params = joinPoint.getArgs();
            request = params[0];

            response = joinPoint.proceed(params);
            
            //TODO IMPLEMENT LOGGER
      		if (LOGGER.isDebugEnabled()) LOGGER.debug("\n\n\t\t"
                    + "The class " + joinPoint.getSignature().getDeclaringTypeName()
                    + " with the method " + joinPoint.getSignature().getName()
                    + "()"
                    + " \n\t\t\t begins with " + params[0]
                    + " \n\t\t\t ends  with " + response + "\n");
               
        } catch (Exception e) {
        	Object[] params = joinPoint.getArgs();
            
        	//TODO IMPLEMENT LOGGER
            LOGGER.debug("\n\n\t\t"
                    + "Class " + joinPoint.getSignature().getDeclaringTypeName()
                    + " with the method " + joinPoint.getSignature().getName()
                    + "()"
                    + " \n\t\t\t begins with " + params[0]
                    + " \n\t\t\t and failed with the exception:",e);

            throw e;
            
        } 
        
        return response;
    }	

}
