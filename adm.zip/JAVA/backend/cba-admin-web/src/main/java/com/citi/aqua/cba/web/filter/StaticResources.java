package com.citi.aqua.cba.web.filter;


import java.util.HashSet;
import java.util.Set;

public class StaticResources {

    public static final Set<String> EXCLUDE_RESOURCES = new HashSet<>();

    static {
        EXCLUDE_RESOURCES.add("/**/*.ttf");
        EXCLUDE_RESOURCES.add("/**/*.eot");
        EXCLUDE_RESOURCES.add("/**/*.svg");
        EXCLUDE_RESOURCES.add("/**/*.woff");
        EXCLUDE_RESOURCES.add("/**/*.woff2");
        EXCLUDE_RESOURCES.add("/**/*.html");
        EXCLUDE_RESOURCES.add("/**/*.ico");
        EXCLUDE_RESOURCES.add("/**/*.gif");
        EXCLUDE_RESOURCES.add("/**/*.png");
        EXCLUDE_RESOURCES.add("/**/*.js");
        EXCLUDE_RESOURCES.add("/**/*.css");
        EXCLUDE_RESOURCES.add("/**/*.js.map");
    }
}
