package com.citi.aqua.cba.web.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.citi.aqua.cba.model.BatchEmailConfigForm;
import com.citi.aqua.cba.model.BatchStatusDetails;
import com.citi.aqua.cba.model.BatchStatusEmailData;
import com.citi.aqua.cba.services.service.BatchConfigurationService;
import com.citi.aqua.cba.services.service.BatchStatusService;

import org.springframework.http.HttpStatus;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
@RequestMapping("/api/batchstatus")
public class BatchStatusController {

	private static final Logger LOGGER = LoggerFactory.getLogger(BatchStatusController.class);

	@Autowired
	private BatchStatusService batchStatusService;

	@Autowired
	private BatchConfigurationService batchConfigurationService;

	@RequestMapping(value = "/getBatchStatusDetails/{cobDate}", method = RequestMethod.GET)
	@ResponseStatus(HttpStatus.OK)
	public @ResponseBody List<BatchStatusDetails> getBatchStatusDetails(@PathVariable("cobDate") String cobDate) {
		LOGGER.debug("Retrieving all Records from Batch Status SP ");
		return batchStatusService.getBatchStatusDetails(cobDate);
	}

	@RequestMapping(value = "/sendBatchEmail", method = RequestMethod.POST)
	public @ResponseBody boolean sendBatchEmail(@RequestBody BatchStatusEmailData data) {
		LOGGER.debug("Send email");
		try {
			final BatchEmailConfigForm configForm = batchConfigurationService.getBatchStatusEmailConfiguration();
			data.setConfigForm(configForm);
			batchStatusService.sendBatchEmail(data);
			return true;
		} catch (Exception e) {
			LOGGER.debug("Send email failed" + e.getMessage());
			return false;
		}

	}

}
