package com.citi.aqua.cba.web.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.citi.aqua.cba.model.ArchiveDbForm;
import com.citi.aqua.cba.model.ArchiveFileForm;
import com.citi.aqua.cba.services.service.ArchiveService;

@Controller
@RequestMapping("/api/configuration")
@CrossOrigin(origins = "http://localhost:3000")
public class ConfigurationController {

	private static final Logger LOGGER = LoggerFactory.getLogger(ConfigurationController.class);

	@Autowired
	private ArchiveService archiveService;

	@RequestMapping(value = "/archive/files", method = RequestMethod.GET)
	public @ResponseBody List<ArchiveFileForm> getArchiveFiles() {
		LOGGER.debug("ConfigurationController.getArchiveFiles() ::starts ");
		return archiveService.getArchiveFiles();
	}

	@RequestMapping(value = "/archive/db", method = RequestMethod.GET)
	public @ResponseBody List<ArchiveDbForm> getArchiveDbList() {
		LOGGER.debug("ConfigurationController.getArchiveDbList() ::starts ");
		return archiveService.getArchiveDb();
	}

	@RequestMapping(value = "/archive/file", method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public Boolean updateArchiveFile(@RequestBody final ArchiveFileForm archiveFileForm) {
		LOGGER.debug("ConfigurationController.updateArchiveFile() ::starts ");
		Boolean updateFlag = false;
		try {
			updateFlag = archiveService.updateArchiveFile(archiveFileForm);
			LOGGER.debug("ConfigurationController.updateArchiveFile() ::ends ");
			return updateFlag;
		} catch (Exception e) {
			LOGGER.error("ConfigurationController.updateArchiveFile() ::Exception::" + e, e);
			return false;
		}
	}

	@RequestMapping(value = "/archive/db", method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public Boolean updateArchiveDb(@RequestBody final ArchiveDbForm archiveDbForm) {
		LOGGER.debug("ConfigurationController.updateArchiveDb() ::starts ");
		Boolean updateFlag = false;
		try {
			updateFlag = archiveService.updateArchiveDb(archiveDbForm);
			LOGGER.debug("ConfigurationController.updateArchiveDb() ::ends ");
			return updateFlag;
		} catch (Exception e) {
			LOGGER.error("ConfigurationController.updateArchiveDb() ::Exception::" + e, e);
			return false;
		}
	}

	@RequestMapping(value = "/archive/file", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public Boolean createArchiveFileRecord(@RequestBody final ArchiveFileForm archiveFileForm) {
		LOGGER.debug("ConfigurationController.createArchiveFileRecord() ::starts ");
		try {
			archiveService.createArchiveFileRecord(archiveFileForm);
			LOGGER.debug("ConfigurationController.createArchiveFileRecord() ::ends ");
			return true;
		} catch (Exception e) {
			LOGGER.error("ConfigurationController.createArchiveFileRecord() ::Exception::" + e, e);
			return false;
		}
	}

	@RequestMapping(value = "/archive/db", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public Boolean createArchiveDb(@RequestBody final ArchiveDbForm archiveDbForm) {
		LOGGER.debug("ConfigurationController.createArchiveDb() ::starts ");
		try {
			archiveService.createArchiveDbRecord(archiveDbForm);
			LOGGER.debug("ConfigurationController.createArchiveDb() ::ends ");

			return true;
		} catch (Exception e) {
			LOGGER.error("ConfigurationController.createArchiveDb() ::Exception::" + e, e);
			return false;
		}
	}

}
