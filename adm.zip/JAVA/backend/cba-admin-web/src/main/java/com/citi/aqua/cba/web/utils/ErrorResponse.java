package com.citi.aqua.cba.web.utils;

import java.io.Serializable;

/**
 *
 * Error Response
 */
public class ErrorResponse implements Serializable {

    private static final long serialVersionUID = 1L;

    private String message;
    private String code;
    private String developerMessage;

	public String getMessage() {
        return message;
    }

    public void setMessage(final String message) {
        this.message = message;
    }

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getDeveloperMessage() {
		return developerMessage;
	}

	public void setDeveloperMessage(String developerMessage) {
		this.developerMessage = developerMessage;
	}

	@Override
	public String toString() {
		return "ErrorResponse [message=" + message + ", code=" + code
				+ ", developerMessage=" + developerMessage + "]";
	}
    
}

