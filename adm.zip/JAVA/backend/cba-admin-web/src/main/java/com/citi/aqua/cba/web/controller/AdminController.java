package com.citi.aqua.cba.web.controller;

import java.sql.SQLException;
import java.util.List;

import com.citi.aqua.cba.model.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import com.citi.aqua.cba.commons.exception.RaceApplicationException;
import com.citi.aqua.cba.commons.exception.RestExceptionMessage;

import com.citi.aqua.cba.security.AuthenticationService;
import com.citi.aqua.cba.services.service.AdminService;

/**
 * @author aw11769
 * 
 */

@RestController
@CrossOrigin(origins = "http://localhost:3000")
@RequestMapping("/api/adm")
public class AdminController {

	private static final Logger LOGGER = LoggerFactory.getLogger(AdminController.class);
	
	@Autowired
	private AdminService adminService;

	@RequestMapping(value = "ewsusers.json", method = RequestMethod.GET)
	@ResponseStatus(HttpStatus.OK)
	public @ResponseBody List<EWSUser> getEWSUsers() {
		try {
			return adminService.getEWSUsers();
		} catch (Exception e) {
			throw new RaceApplicationException(e, RestExceptionMessage.FAILED_ADMIN_USERS_DATA);
		}
	}

	@RequestMapping(value = "/getUserCoverage/{id}", method = RequestMethod.GET)
	@ResponseStatus(HttpStatus.OK)
	public @ResponseBody List<UserCoverage> getUserCoverage(@PathVariable("id") String id) {
		try {
			return adminService.getUserCoverage(id);
		} catch (Exception e) {
			throw new RaceApplicationException(e, RestExceptionMessage.FAILED_ALERT_RULE_USER_DATA);
		}
	}

	//	@ApiOperation("getEWSUser")
	@RequestMapping(value = "/getEWSUser/{id}", method = RequestMethod.GET)
	@ResponseStatus(HttpStatus.OK)
	public @ResponseBody EWSUser getEWSUser(@PathVariable("id") String id) {
		try {
			return adminService.getEWSUser(id);
		} catch (Exception e) {
			throw new RaceApplicationException(e, RestExceptionMessage.FAILED_ADMIN_USER_DATA);
		}
	}

	@RequestMapping(value = "/getClientCoverageList/", method = RequestMethod.GET)
	@ResponseStatus(HttpStatus.OK)
	public @ResponseBody List<DropDownModel> getClientCoverageList() {
		try {
			return adminService.getClientCoverageList();
		} catch (Exception e) {
			throw new RaceApplicationException(e, RestExceptionMessage.FAILED_ADMIN_COVERAGE_LIST);
		}
	}

	@RequestMapping(value = "/UpdateUserRole", method = RequestMethod.POST)
	public @ResponseBody boolean updateUserRole(@RequestBody UpdateUserRoleRequest updateUserRole) throws SQLException {
		if (AuthenticationService.getUser().getSoeid() != null	&& updateUserRole.getSoeid() != ""	&& updateUserRole.getRole() != "") {
			adminService.updateUserRole(updateUserRole.getSoeid(),	updateUserRole.getRole(), updateUserRole.getGpnum(), updateUserRole.getAll_client(), AuthenticationService.getUser().getSoeid());
			return true;
		}
		return false;
	}

	@RequestMapping(value = "/UpdateUserCoverage", method = RequestMethod.POST)
	public @ResponseBody boolean updateUserCoverage(@RequestBody UpdateUserCoverageRequest updateUserRole)	throws SQLException {
		if (AuthenticationService.getUser().getSoeid() != null	&& updateUserRole.getSoeid() != ""	&& updateUserRole.getGpnum() != "") {
			adminService.updateUserCoverage(updateUserRole.getSoeid(), updateUserRole.getGpnum(), AuthenticationService.getUser().getSoeid());
			return true;
		}
		return false;
	}

	@RequestMapping(value = "/getUserHistory/{soeid}", method = RequestMethod.GET)
	@ResponseStatus(HttpStatus.OK)
	public @ResponseBody List<UserHistory> getClientCoverageList(@PathVariable("soeid") String soeid) {
		try {
			return adminService.getUserHistory(soeid);
		} catch (Exception e) {
			throw new RaceApplicationException(e, RestExceptionMessage.FAILED_ADMIN_USER_HISTORY);
		}
	}

	//api/adm/getAdminList
	//@ApiOperation("getAdminList")
	@RequestMapping(value = "/getAdminList", method = RequestMethod.GET)
	@ResponseStatus(HttpStatus.OK)
	public @ResponseBody List<Admin> getAdminList() {
		LOGGER.debug("Retrieving all Records from Admin ");
		return adminService.getAdminList();
	}


}
