package com.citi.aqua.cba.web.controller;

/**
 * @author ak92283
 */
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.citi.aqua.cba.model.BatchEmailConfigForm;
import com.citi.aqua.cba.model.FeedDelayData;
import com.citi.aqua.cba.model.FeedDelayDataDetails;
import com.citi.aqua.cba.model.FeedDelayEmailData;
import com.citi.aqua.cba.services.service.BatchConfigurationService;
import com.citi.aqua.cba.services.service.BatchDelayService;
import com.citi.aqua.cba.services.service.DownstreamNotificationService;
import com.citi.aqua.cba.services.service.UserNotificationService;
import com.citi.aqua.cba.web.CBAAdminApplication;

@Controller
@RequestMapping("/api/batch")
@CrossOrigin(origins = "http://localhost:3000")
public class BatchAutomationController {

	private static final Logger LOGGER = LoggerFactory.getLogger(BatchAutomationController.class);
	@Autowired
	private BatchDelayService batchDelayService;

	@Autowired
	private DownstreamNotificationService downstreamNotificationService;

	@Autowired
	private UserNotificationService userNotificationService;

	@Autowired
	private BatchConfigurationService batchConfigurationService;

	@RequestMapping(value = "/feed/sources", method = RequestMethod.GET)
	public @ResponseBody List<String> getDelaySources() {
		LOGGER.debug("BatchAutomationController.getDelaySources() ::starts ");
		return batchDelayService.getDelaySources();
	}

	@RequestMapping(value = "/delay", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public Boolean submitBatchDelay(@RequestBody FeedDelayData delayAttributes) {
		LOGGER.debug("BatchAutomationController.submitBatchDelay() ::starts ");
		Boolean insertFlag = false;
		try {
			insertFlag = batchDelayService.submitBatchDelay(delayAttributes);
			LOGGER.debug("BatchAutomationController.submitBatchDelay() ::ends ");
			return insertFlag;
		} catch (Exception e) {
			LOGGER.error("BatchAutomationController.submitBatchDelay() ::Exception::" + e, e);
			return false;
		}
	}

	@RequestMapping(value = "/delay/user-notification/cbaDashboard", method = RequestMethod.GET)
	public @ResponseBody List<FeedDelayDataDetails> getCBADashboardDelayStatistics() {
		LOGGER.debug("BatchAutomationController.getCBADashboardDelayStatistics() ::starts ");
		List<FeedDelayDataDetails> results = userNotificationService.cbaDashboardDelayEstimates();
		return results;
	}

	@RequestMapping(value = "/delay/user-notification/slDashboard", method = RequestMethod.GET)
	public @ResponseBody List<FeedDelayDataDetails> getSLDashboardDelayStatistics() {
		LOGGER.debug("BatchAutomationController.getSLDashboardDelayStatistics() ::starts ");
		List<FeedDelayDataDetails> results = userNotificationService.slDashboardDelayEstimates();
		return results;
	}

	@RequestMapping(value = "/delay/user-notification/reports", method = RequestMethod.GET)
	public @ResponseBody List<FeedDelayDataDetails> getReportDelayStatistics() {
		LOGGER.debug("BatchAutomationController.getReportDelayStatistics() ::starts ");
		List<FeedDelayDataDetails> results = userNotificationService.reportsDelayEstimates();
		return results;
	}

	@RequestMapping(value = "/delay/user-notification/cad", method = RequestMethod.GET)
	public @ResponseBody List<FeedDelayDataDetails> getCADDelayStatistics() {
		LOGGER.debug("BatchAutomationController.getCADDelayStatistics() ::starts ");
		List<FeedDelayDataDetails> results = userNotificationService.cadDelayEstimates();
		return results;

	}

	@RequestMapping(value = "/delay/downstream-notification/feedData", method = RequestMethod.GET)
	public @ResponseBody List<FeedDelayDataDetails> getFeedDataDelayStatistics() {
		LOGGER.debug("BatchAutomationController.getFeedDataDelayStatistics() ::starts ");
		List<FeedDelayDataDetails> results = downstreamNotificationService.feedDataDelayEstimates();
		return results;

	}

	@RequestMapping(value = "/delay/mail/user-notification", method = RequestMethod.POST)
	public @ResponseBody Boolean sendUserNotificationDelayEmail(@RequestBody FeedDelayEmailData data) {
		LOGGER.debug("BatchAutomationController.sendUserNotificationDelayEmail() ::starts ");
		try {
			final BatchEmailConfigForm configForm = batchConfigurationService.getUserEmailConfiguration();
			data.setConfigForm(configForm);
			final String envName = CBAAdminApplication.getEnvName();
			userNotificationService.sendUserNotificationMail(data, envName);
			return true;
		} catch (Exception e) {
			LOGGER.error("BatchAutomationController.sendUserNotificationDelayEmail() ::Error " + e, e);
			return false;
		}
	}

	@RequestMapping(value = "/delay/mail/downstream-notification", method = RequestMethod.POST)
	public @ResponseBody Boolean sendDownstreamNotificationDelayEmail(@RequestBody FeedDelayEmailData data) {
		LOGGER.debug("BatchAutomationController.sendDownstreamNotificationDelayEmail() ::starts ");
		try {
			final BatchEmailConfigForm configForm = batchConfigurationService.getDownstreamEmailConfiguration();
			data.setConfigForm(configForm);
			final String envName = CBAAdminApplication.getEnvName();
			downstreamNotificationService.sendDownstreamNotificationMail(data, envName);
			return true;
		} catch (Exception e) {
			LOGGER.error("BatchAutomationController.sendDownstreamNotificationDelayEmail() ::Error " + e, e);
			return false;
		}
	}

	@RequestMapping(value = "/getCOBDateList", method = RequestMethod.GET)
	public @ResponseBody List<Long> getCOBDateList() {
		LOGGER.debug("BatchAutomationController.getCOBDateList() ::starts ");
		try {
			return batchConfigurationService.getCOBDateList();
		} catch (Exception e) {
			LOGGER.error("BatchAutomationController.getCOBDateList() ::Error " + e, e);
			return null;
		}
	}

	@RequestMapping(value = "/config", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public Boolean submitBatchConfig(@RequestBody BatchEmailConfigForm batchEmailConfigForm) {
		LOGGER.debug("BatchAutomationController.submitBatchConfig() ::starts ");
		Boolean insertFlag = false;
		try {
			insertFlag = batchConfigurationService.submitConfigForm(batchEmailConfigForm);
			LOGGER.debug("BatchAutomationController.submitBatchConfig() ::ends ");
			return insertFlag;
		} catch (Exception e) {
			LOGGER.error("BatchAutomationController.submitBatchConfig() ::Exception::" + e, e);
			return false;
		}
	}

	@RequestMapping(value = "/config/getConfigList", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody List<BatchEmailConfigForm> getConfigList() {
		LOGGER.debug("BatchAutomationController.getConfigList() ::starts ");
		try {
			return batchConfigurationService.getEmailConfigList();
		} catch (Exception e) {
			LOGGER.error("BatchAutomationController.getConfigList() ::Error " + e, e);
			return null;
		}
	}

	@RequestMapping(value = { "/delay/getDelayList",
			"/delay/getDelayList/{cobdate}" }, method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody List<FeedDelayData> getDelayList(@PathVariable Optional<Integer> cobdate) {
		LOGGER.debug("BatchAutomationController.getDelayList() ::starts ");
		try {
			if (cobdate.isPresent()) {
				String givenCOBDate = cobdate.get().toString();
				return batchDelayService.getDelayList(givenCOBDate);
			} else {
				return batchDelayService.getDelayList(null);
			}
		} catch (Exception e) {
			LOGGER.error("BatchAutomationController.getDelayList() ::Error " + e, e);
			return null;
		}
	}

}
