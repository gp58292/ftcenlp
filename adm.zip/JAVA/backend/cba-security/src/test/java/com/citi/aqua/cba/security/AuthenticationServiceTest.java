/*package com.citi.aqua.cba.security;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;

import com.citi.aqua.cba.security.constants.CBASSOConstants;
import com.citi.aqua.cba.security.manager.SingleSignOnManager;
import junit.framework.TestCase;
import net.sf.ehcache.CacheManager;

import org.apache.commons.lang.StringUtils;
import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.api.support.membermodification.MemberModifier;
import org.slf4j.Logger;

import com.citi.aqua.cba.model.LoginStatusEnum;
import com.citi.aqua.cba.model.User;

*//**
 * @author GP58292
 *
 *//*
//@RunWith(EasyMockRunner.class)
public class AuthenticationServiceTest extends TestCase {

	private Logger log;
	private AuthenticationService authService;
	private SingleSignOnManager singleSignOnManager;
	private CacheManager cacheManager;
	private HttpSession session;

	@Before
	public void setUp() throws Exception {
		log = PowerMockito.mock(Logger.class);
		authService = EasyMock.createMockBuilder(AuthenticationService.class).createMock();
		singleSignOnManager = EasyMock.mock(SingleSignOnManager.class);
		cacheManager = EasyMock.mock(CacheManager.class);
		session = EasyMock.mock(HttpSession.class);

		//MemberModifier.field(AuthenticationService.class, "log").set(authService , log);
		MemberModifier.field(AuthenticationService.class, "SingleSignOnManager").set(authService , singleSignOnManager);
		MemberModifier.field(AuthenticationService.class, "cacheManager").set(authService , cacheManager);
	}

	@Test
	public void testAuthenticateUser() {
		log.debug("SingleSignOnManagerTest::testAuthenticateUser method invoked");
		User user = new User();
		user.setSoeid("df21521");
		user.setPassword("testPassword");
		user.setName("Test test");
		user.setAccessList(new ArrayList<String>(Arrays.asList("Full Access")));
		user.setStatusCode(LoginStatusEnum.CBA_200);

		EasyMock.expect(singleSignOnManager.authenticateUser(StringUtils.trim(user.getSoeid()), StringUtils.trim(user.getPassword())))
		.andReturn(user);
		EasyMock.expect(session.getAttribute(CBASSOConstants.ISLOGGED_IN)).andReturn(null);
		session.setAttribute(CBASSOConstants.ISLOGGED_IN, Boolean.TRUE);
		session.setAttribute("username", user.getName());
		session.setAttribute("soeid", user.getSoeid());

		session.setAttribute("user", user);
        session.setAttribute("email", user.getEmail());
        session.setAttribute("accessList", user.getAccessList());

		EasyMock.replay(authService, singleSignOnManager, session);
		User actual = authService.authenticateUser(session, user);
		EasyMock.verify(authService);
		assertEquals("Test test", actual.getName());
	}

	@Test
	public void testKillSession(){
		User user = new User();
		user.setSoeid("df21521");
		EasyMock.expect(session.getAttribute(CBASSOConstants.ISLOGGED_IN)).andReturn("value");
		EasyMock.expect(session.getAttribute("user")).andReturn(user);
		session.invalidate();

		EasyMock.expectLastCall();
		EasyMock.replay(authService,session);
		authService.killSession(session);
		EasyMock.verify(authService);
	}

	@Test
	public void testChangeUserPassword(){
		HttpSession session = PowerMockito.mock(HttpSession.class);
		User user = new User();
		user.setSoeid("df21521");
		user.setPassword("testPassword");
		user.setName("Test test");
		user.setNewpassword("New password");
		user.setStatusCode(LoginStatusEnum.CBA_200);

		EasyMock.expect(singleSignOnManager.forceChangePassword(StringUtils.trim(user.getSoeid()), StringUtils.trim(user.getPassword()),
				StringUtils.trim(user.getNewpassword()))).andReturn(user);

		EasyMock.replay(authService, singleSignOnManager);
		User actual = authService.changeUserPassword(session, user);
		EasyMock.verify(authService);
		assertEquals("df21521", actual.getSoeid());
	}

	@Test
	public void testCountUserSession(){
		ServletContext context = EasyMock.mock(ServletContext.class);
		EasyMock.expect(session.getServletContext()).andReturn(context);
		HashMap<String, HttpSession> data = new HashMap<String, HttpSession>();
		data.put("test", session);

		EasyMock.expect(context.getAttribute("activeUsers")).andReturn(data);

		EasyMock.expect(session.getAttribute("username")).andReturn("Test test");
		EasyMock.expect(session.getAttribute("email")).andReturn("test@citi.com");
		EasyMock.expect(session.getAttribute("accessList")).andReturn("full access");

		EasyMock.replay(authService, context,session);
		String actual = authService.countUserSession(session);
		EasyMock.verify(authService);
		assertNotNull(actual);
	}*/
	
    /*public static void main(String[] args) {
    	//TODO need to move this code out into test case for integrated build
    	//mainLogger.info("############### Inside SingleSignOnManager class main method ################");
    	ApplicationContext context = new ClassPathXmlApplicationContext(new String[]{"classpath:application-context-sso.xml"});
        System.setProperty("javax.net.ssl.keyStore","https://citigroupsoauat.citigroup.net/citisso/CitiSSOService");
        System.setProperty("javax.net.ssl.trustStore","C:/Work-Area/IDL/ssl-certs/uat/citi-SSO-cert-chain/aqua_uat_cacerts.jks");
        System.setProperty("javax.net.ssl.keyStorePassword","welcome2");
        System.setProperty("javax.net.ssl.trustStorePassword","welcome2");
        System.setProperty("javax.net.ssl.keyStoreType","JKS");
        System.setProperty("javax.net.ssl.trustStoreType","JKS");

        try {            
            SingleSignOnManager client = (SingleSignOnManager) context.getBean("SingleSignOnManager");
           // mainLogger.info("client.citiSSOURL " + System.getProperty("citi.sso.url"));

            //authenticate user
             client.authenticateUser("ag52020", "Newyork#11");            
            //mainLogger.info("Name:" + response.getName());
            *//*System.out.println("Email:" + response.getEmail());
            System.out.println("SOEID:" + response.getSoeid());
            System.out.println("Session:" + response.getSsoSessionID());
            System.out.println("Access : " + response.getAccessList());
            System.out.println("Status : " + response.getStatusCode());*//*
            *//*
            //Validate Session
            response = client.validateSession(response);
            System.out.println("V-Name:" + response.getName());
            System.out.println("V-Email:" + response.getEmail());
            System.out.println("V-SOEID:" + response.getSoeid());
            System.out.println("V-Session:" + response.getSsoSessionID());
            System.out.println("V-Access : " + response.getAccessList());
            System.out.println("V-Status : " + response.getStatusCode());
            //Logout User
            boolean logoutStat = client.userLogout(response); *//*
        } catch (Exception e) {
        	log.error("Err", e);
        	//mainLogger.error("Exception occured inside SingleSignOnManager class main method", e);

        } finally {
        	((ClassPathXmlApplicationContext) context).close();
        }
    }*/
	

