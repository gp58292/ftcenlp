package com.citi.aqua.cba.security.constants;

/**
 * Created by ag52020 on 1/5/2016.
 */
public class CBASSOConstants {

    public static final String ISLOGGED_IN = "isloggedIn";
    public static final String USER = "user";
    public static final String FORCE_CHANGE_PASSWORD = "\"Force password change requested for user\"";
    public static final String LOGIN = "LOGIN";
    public static final String LOGOUT = "LOGOUT";
    public static final String CHANGE_PASSWORD = "CHANGE_PASSWORD";
    public static final String ROLE_ADMIN="admin";
    public static final String ROLE_GLOBAL_ADMIN="global_admin";
    public static final String ROLE_COVERAGE_BASED="coverage_based";
    public static final String ROLE_VIEW_ONLY="view_only";
    
    public static final String MANAGE_ALERT="/html/partials/exceptionsummary/viewsummary.html";
    //public static final String MANAGE_ALERT_RULE="/html/partials/exceptions/edit";
    public static final String CREATE_ALERT_RULE="/html/partials/exceptions/add";
    public static final String ADMIN="/html/partials/admin/layout.html";
    public static final String MANAGE_ADMIN="/html/partials/admin/edit";
    public static final String COVERAGE="/html/partials/coverage/layout.html";
    public static final String CLIENT_OVERVIEW="/html/partials/clientoverview/layout.html";
    
    public static final String MANAGE_ALERT_API="/exceptionsummary/update";
    public static final String MANAGE_ALERT_RULE_API="/exceptionrule/update";
    public static final String CREATE_ALERT_RULE_API="/exceptionrule/add";
    public static final String ADMIN_API="/adm";    
  
}
