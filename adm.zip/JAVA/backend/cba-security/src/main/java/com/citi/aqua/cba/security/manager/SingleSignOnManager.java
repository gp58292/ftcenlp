package com.citi.aqua.cba.security.manager;

import static com.google.common.collect.Maps.newHashMap;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.citi.aqua.cba.data.domain.cba.AquaCoreUserEntitlement;
import com.citi.aqua.cba.data.mapper.cba.CBAUtilitiesMapper;
import com.citi.aqua.cba.model.LoginStatusEnum;
import com.citi.aqua.cba.model.UserAdmin;
import com.citi.aqua.cba.model.UserToken;
import com.citi.aqua.cba.security.constants.AuthConstants;
import com.citi.aqua.cba.security.constants.CBASSOConstants;
import com.citi.aqua.cba.security.ping.core.UserAuthenticationResolver;
import com.citi.citisso.ws.UserAuthenticationResponseObj;

@Service
public class SingleSignOnManager {

	@Autowired
	private CBAUtilitiesMapper cbaUtilitiesMapper;

	private static final Logger LOGGER = LoggerFactory.getLogger(SingleSignOnManager.class);

	@Autowired
	private UserAuthenticationResolver userAuthenticationResolver;

	public SingleSignOnManager() {
		LOGGER.debug("SingleSignOnManager::SingleSignOnManager: Single Sign on Intitialized");
	}

	public UserAdmin authenticateUser(String userName, String password) {
		LOGGER.debug("SingleSignOnManager:: authenticateUser()::starts");
		final UserAdmin profile = new UserAdmin();
		try {
			UserAuthenticationResponseObj ssoResponse = new UserAuthenticationResponseObj();
			// Create Profile Object with incoming Data
			profile.setSoeid(userName);
			Map<String, String> userAuthenticationResult = new HashMap<>();
			LOGGER.debug("SingleSignOnManager::authenticateUser:: Executing...");
			userAuthenticationResult = userAuthenticationResolver.validateUserIdentify(userName, password);
			ssoResponse.setStatusCode(Integer.parseInt(String.valueOf(userAuthenticationResult.get("statusCode"))));

			// Authorize User in AQUA only if User is Authenticated in SSO
			if (0 == ssoResponse.getStatusCode()) {
				profile.setStatusCode(LoginStatusEnum.CBA_200);
				profile.setAuthenticated(Boolean.TRUE);
				authorizeUserInAQUA(profile, userName);
			} else {
				updateLoginStatus(profile, ssoResponse.getStatusCode(), ssoResponse.getMessage());
			}
		} catch (Exception e) {
			LOGGER.error("Exception occured while authenticating user {}", userName);
			LOGGER.error("Excpetion is" + e.getLocalizedMessage());
			profile.setStatusCode(LoginStatusEnum.CBA_800);
		}
		// Audit User Login
		auditUserAction(CBASSOConstants.LOGIN, profile);
		LOGGER.debug("SingleSignOnManager:: authenticateUser method completed");
		return profile;
	}

	private void updateLoginStatus(UserAdmin profile, int responseCode, String message) {

		switch (responseCode) {
		case 0:
			profile.setStatusCode(LoginStatusEnum.CBA_200);
			break;

		case -1:
			profile.setStatusMessage(message);
			if (CBASSOConstants.FORCE_CHANGE_PASSWORD.equalsIgnoreCase(message)) {
				profile.setStatusCode(LoginStatusEnum.CBA_1000);
			} else {
				profile.setStatusCode(LoginStatusEnum.CBA_300);
			}
			break;

		case -2:
			profile.setStatusCode(LoginStatusEnum.CBA_300);
			break;

		case -3:
			profile.setStatusCode(LoginStatusEnum.CBA_300);
			break;

		case 400:
			profile.setStatusCode(LoginStatusEnum.CBA_400);
			break;

		case 900:
			profile.setStatusCode(LoginStatusEnum.CBA_900);
			break;

		default:
			profile.setStatusCode(LoginStatusEnum.CBA_800);
		}
	}

	private UserAdmin authorizeUserInAQUA(UserAdmin profile, String soeid) {
		try {
			List<AquaCoreUserEntitlement> userEntitlements = fetchUserProfile(soeid);
			if (userEntitlements.isEmpty() || userEntitlements.contains(null)) {
				updateLoginStatus(profile, 400, AuthConstants.NOT_AUTHORIZED_IN_AQUA);
				profile.setAuthorized(false);
			} else {
				final List<String> businessCritical = new ArrayList<>();
				for (AquaCoreUserEntitlement singleEntitlement : userEntitlements) {
					if (singleEntitlement.getPermission_level().equals(AuthConstants.TECH_PAGES)) {
						profile.setTechPagesPermission(1);
					}
					if (!singleEntitlement.getPermission_level().equals(AuthConstants.TECH_PAGES)) {
						businessCritical.add(singleEntitlement.getPermission_level());
					}
				}
				profile.setName(userEntitlements.get(0).getName());
				profile.setBusinessCriticalPages(businessCritical);
			}

		} catch (Exception e) {
			LOGGER.error("Exception occurred while authenticating user {} in Aqua  Portal ", soeid);
			LOGGER.error("Error is ..." + e.getLocalizedMessage());
			updateLoginStatus(profile, 900, e.getLocalizedMessage());
		}
		return profile;
	}

	private List<AquaCoreUserEntitlement> fetchUserProfile(String soeId) {
		return cbaUtilitiesMapper.getEntitlements(soeId);
	}

	private void auditUserAction(String action, UserAdmin profile) {
		// Prepare Query Parameters
		Map<String, Object> paramsIn = newHashMap();
		paramsIn.put("soeid", profile.getSoeid());
		paramsIn.put("fullName", profile.getName());
		paramsIn.put("action", action);
		paramsIn.put("status", profile.getStatusCode().getStatusMsg());
		paramsIn.put("details", profile.getAccessList().toString());
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = new Date();
		paramsIn.put("create_time", dateFormat.format(date));
		LOGGER.info("User Login Audit Params " + paramsIn);
		cbaUtilitiesMapper.insertUserActionDetails(paramsIn);
	}

	public boolean isUserTokenValid(String token) {
		return userAuthenticationResolver.validateUserIdentify(token);
	}

	public UserToken getUserToken(String userId, String password) {
		Map<String, String> userAuthenticationResult = userAuthenticationResolver.validateUserIdentify(userId,
				password);
		UserToken userToken = new UserToken();
		userToken.setToken(userAuthenticationResult.get(AuthConstants.TOKEN));
		return userToken;
	}

}
