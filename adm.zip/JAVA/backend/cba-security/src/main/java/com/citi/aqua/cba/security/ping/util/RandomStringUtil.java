package com.citi.aqua.cba.security.ping.util;

import java.security.SecureRandom;
import java.util.Locale;
import java.util.Objects;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class RandomStringUtil {

	private static final Logger LOGGER = LoggerFactory.getLogger(RandomStringUtil.class);

	public static final String UPPER = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

	public static final String LOWER = UPPER.toLowerCase(Locale.ROOT);

	public static final String DIGITS = "0123456789";

	public static final String ALPHANUM = UPPER + LOWER + DIGITS;

	public static final String ALPHA = UPPER + LOWER;

	private final Random random;

	private final char[] letters;

	private final char[] symbols;

	private final char[] buf;

	public RandomStringUtil(int length, Random random, String symbols, String letters) {
		if (length < 1)
			throw new IllegalArgumentException();
		if (symbols.length() < 2)
			throw new IllegalArgumentException();
		this.random = Objects.requireNonNull(random);
		this.symbols = symbols.toCharArray();
		this.letters = letters.toCharArray();
		this.buf = new char[length];
	}

	/**
	 * Create an alphanumeric string generator.
	 */
	public RandomStringUtil(int length, Random random) {
		this(length, random, ALPHANUM, ALPHA);
	}

	/**
	 * Create an alphanumeric strings from a secure generator.
	 */
	public RandomStringUtil(int length) {
		this(length, new SecureRandom());
	}

	/**
	 * Generate a random string with alpha at the first.
	 */
	public String nextString() {
		for (int idx = 0; idx < buf.length; ++idx)
			if (idx == 0) {
				buf[idx] = letters[random.nextInt(letters.length)];
			} else {
				buf[idx] = symbols[random.nextInt(symbols.length)];
			}
		return new String(buf);
	}

	public static void main(String[] args) {
		RandomStringUtil gen = new RandomStringUtil(28, ThreadLocalRandom.current());
		 String next = gen.nextString();
		LOGGER.debug("Random 28 charaters: \n {}", next);
	}

}
