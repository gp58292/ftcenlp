package com.citi.aqua.cba.security.ping.core;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.util.Base64;
import javax.annotation.PostConstruct;
import javax.net.ssl.KeyManager;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.citi.aqua.cba.security.constants.AuthConstants;
import com.citi.aqua.cba.security.ping.config.CitiFederationKeys;

@Service
public class PingServiceSSLContext {

	
	private static final Logger LOGGER = LoggerFactory.getLogger(PingServiceSSLContext.class);
	@Autowired
	private CitiFederationKeys citiFederationKeys;
	
	SSLContext pingSSLContext;
	
	@PostConstruct
	public void postConstructPingServiceSSLContext() {
			
        try(
    		InputStream inputStreamTrustStore=	new FileInputStream(new File(citiFederationKeys.getTruststore().getPath()));
    		InputStream	inputStreamKeyStore=new FileInputStream(new File(citiFederationKeys.getKeystore().getPath()));
        	) {
            //create key and trust managers
            //create Input stream to key store file
            KeyStore keyStore = KeyStore.getInstance(citiFederationKeys.getKeystore().getType());
            String keyStorePassword = new String(Base64.getDecoder().decode(citiFederationKeys.getKeystore().getPassword()));
            keyStore.load(inputStreamKeyStore, keyStorePassword.toCharArray());
            
            //create key manager factory and load the key store object in it
            KeyManagerFactory keyManagerFactory =  KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
            keyManagerFactory.init(keyStore, keyStorePassword.toCharArray());
            KeyManager[] managers = keyManagerFactory.getKeyManagers();

            //create Input stream to trust store file
            KeyStore trustStore = KeyStore.getInstance(citiFederationKeys.getTruststore().getType());
            String trustStorePassword = new String(Base64.getDecoder().decode(citiFederationKeys.getTruststore().getPassword()));
            trustStore.load(inputStreamTrustStore, trustStorePassword.toCharArray());

            //create trust manager factory and load the key store object in it
            TrustManagerFactory trustManagerFactory = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
            trustManagerFactory.init(trustStore);
            TrustManager[] trustManagers = trustManagerFactory.getTrustManagers();

            //in it context with managers data
            System.setProperty("https.protocols", "TLSv1,TLSv1.1,TLSv1.2");
            this.pingSSLContext = SSLContext.getInstance(AuthConstants.SSLV3);
            this.pingSSLContext.init(managers, trustManagers, null);
        } catch (KeyStoreException | CertificateException | NoSuchAlgorithmException | IOException | UnrecoverableKeyException | KeyManagementException e) {
           LOGGER.error("PingServiceSSLContext::postConstructPingServiceSSLContext::Exception occerured  while trusting ping web service... ",e);
           this.pingSSLContext=null;
        } 
	}
	
	public SSLContext getPingSSLContext() {
		return this.pingSSLContext;
	}
}
