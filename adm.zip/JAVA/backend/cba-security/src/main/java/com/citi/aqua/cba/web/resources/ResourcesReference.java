package com.citi.aqua.cba.web.resources;

import java.util.HashSet;
import java.util.Set;

/**
 * @name ResourcesReference
 *
 */
public class ResourcesReference {
	private static final Set<String> DYNAMIC_REDIRECT_URIS = new HashSet<>();

	private ResourcesReference() {
	}

	public static Set<String> getDynamicURI() {
		return DYNAMIC_REDIRECT_URIS;
	}

}
