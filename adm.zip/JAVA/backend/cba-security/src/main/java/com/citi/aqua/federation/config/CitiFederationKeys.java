package com.citi.aqua.federation.config;


public class CitiFederationKeys {

    public static final String CITI_FEDERATE_URL = "citi.pingfederation.service.url";

    public static final String CITI_FEDERATE_TIEMOUT = "citi.pingfederation.service.timeout";

    public static final String CITI_FEDERATE_KEYSTORE_PATH = "citi.pingfederation.service.keystore.path";

    public static final String CITI_FEDERATE_KEYSTORE_TYPE = "citi.pingfederation.service.keystore.type";

    public static final String CITI_FEDERATE_KEYSTORE_PWD= "citi.pingfederation.service.keystore.password";

    public static final String CITI_FEDERATE_TRUSTSTORE_PATH = "citi.pingfederation.service.truststore.path";

    public static final String CITI_FEDERATE_TRUSTSTORE_TYPE = "citi.pingfederation.service.truststore.type";

    public static final String CITI_FEDERATE_TRUSTSTORE_PWD = "citi.pingfederation.service.truststore.password";

    public static final String CITI_FEDERATE_TOKENNAME = "";

    public static final String CITI_FEDERATE_TEMPLATE_PATH = "citi.pingfederation.service.soap.request.template.path";

    public static final String CITI_FEDERATE_ISENABLE = "citi.pingfederation.service.isenabled";
    
}
