package com.citi.aqua.cba.security.constants;

import java.nio.charset.StandardCharsets;
import org.springframework.http.MediaType;

/**
 * @name DerivzCommonConstants
 * @description Class is used to maintain constants
 */

public class AuthConstants {
	public static final String ADMIN_API = "/adm";
	public static final String HOME_PAGE = "/index.html";
	public static final String API_CALL = "/api/";

	// SSO constants
	public static final String ISLOGGED_IN = "isloggedIn";
	public static final String USER = "user";
	public static final String FORCE_CHANGE_PASS = "\"Force password change requested for user\"";
	public static final String LOGIN = "LOGIN";
	public static final String LOGOUT = "LOGOUT";
	public static final String CHANGE_PASS = "CHANGE_PASSWORD";
	public static final String ROLE_ADMIN = "admin";
	public static final String ROLE_GLOBAL_ADMIN = "global_admin";
	public static final String ROLE_VIEW_ONLY = "view_only";
	public static final String USER_ROLE_APPUSER = "APPUSER";

	public static final String USER_NAME = "username";
	public static final String SOE_ID = "soeid";
	public static final String EMAIL = "email";
	public static final String ACCESS_LIST ="accessList";

	public static final Boolean BOOLEAN_TRUE = true;

	public static final String PROD_ENV_NAME = "prod";
	
	public static final String STATUS_CODE = "statusCode";
	public static final String STATUS_CODE_ZERO = "0";
	public static final String STATUS_MESSAGE = "statusMessage";
	public static final String IS_TOKEN_VALID = "isTokenValid";
	public static final String TOKEN = "token";
	public static final String STATUS_MESSAGE_RETURN = "User validated successfully";
	
	public static final String NOT_AUTHORIZED_IN_AQUA="Not Authorized in AQUA";
	
	public static final String CITI_PINGFEDERATION_SERVICE= "citi.pingfederation.service";
	
	public static final String SSLV3= "SSLv3";
	
	
	public static final String PING_REQUEST_CREATE_TIME_STAMPE="createTimeStampe";
	public static final String PING_REQUEST_EXPIRE_TIME_STAMPE="expireTimeStampe";
	public static final String PING_REQUEST_BINARY_SECURITY_TOKEN="binarySecurityToken";
	public static final String PING_REQUEST_WSU_ID_FOR_TIMESTAMP="wsuIdForTimestamp";
	public static final String PING_REQUEST_WSU_ID_FOR_TOKEN="wsuIdForToken";
	public static final String PING_REQUEST_WSU_ID_FOR_BODY="wsuIdForBody";
	public static final String PING_REQUEST_URI_FOR_REFERENCE="uriForReference";
	public static final String PING_REQUEST_ADDRESS="address";
	public static final String PING_REQUEST_RP_TEST="rptest";
	
	public static final String PING_REQUEST_SOAP_ACTION="SOAPAction";
	public static final String CONTENT_LENGTH="Content-Length";
	public static final String CONTENT_TYPE="Content-type";
	public static final String CONTENT_TYPE_VALUE=MediaType.TEXT_XML_VALUE+"; charset="+StandardCharsets.UTF_8;
	
	public static final String PING_REQUEST_DATE_FORMAT="yyyy-MM-dd'T'HH:mm:ss.SZ";
	
	public static final String PING_REQUEST_TOKEN_START = "ValueType=\"urn:pingidentity:wam\" xmlns:wsse=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd\" xmlns:wsu=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd\">" ;
	public static final String PING_REQUEST_TOKEN_END = "</wsse:BinarySecurityToken>";
	
	
	public static final String TECH_PAGES="tech_pages";

	private AuthConstants() {}

}
