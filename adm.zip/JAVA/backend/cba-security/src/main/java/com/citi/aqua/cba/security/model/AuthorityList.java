package com.citi.aqua.cba.security.model;

public enum AuthorityList {
    ROLE_USER, ROLE_ADMIN
}
