package com.citi.aqua.cba.security.model;


import java.util.Optional;

import org.springframework.beans.factory.annotation.Value;

/*@ConfigurationProperties(prefix=SecurityConstant.AQUA_SSL)
@Component*/
public class AquaSSL {

	/*@Value(SecurityConstant.PROP_SSO_CITI_URL)
	private Optional<String> ssoUrl;
	
	private JKSStore keystore;
	private JKSStore truststore;
	
	public static class JKSStore {		
		
		private Optional<String> password;
		private Optional<String> type;
		private Optional<String> location;
		
		public Optional<String> getLocation() {return location;}
		public Optional<String> getPassword() {return password;}
		public Optional<String> getType() {return type;}
		
		public void setPassword(Optional<String> password) {this.password = password;}
		public void setType(Optional<String> type) {this.type = type;}
		public void setLocation(Optional<String> location) {this.location = location;}
		
		@Override
		public String toString() {return "JKSStore [password=" + password + ", type=" + type + ", location=" + location + "]";}
	}

	public JKSStore getKeystore() 					{return keystore;}
	public JKSStore getTruststore() 				{return truststore;}
	public Optional<String>   getSsoUrl() 			{return ssoUrl;}
	
	public void setKeystore(JKSStore keystore) 		{this.keystore = keystore;}
	public void setTruststore(JKSStore truststore) 	{this.truststore = truststore;}
	public void setSsoUrl(Optional<String> sSOUrl) 	{this.ssoUrl = sSOUrl;}
	
		@Override
	public String toString() { return "AquaSSL [SSOUrl=" + ssoUrl + ", keystore=" + keystore + ", truststore=" + truststore + "]";}*/
	
}