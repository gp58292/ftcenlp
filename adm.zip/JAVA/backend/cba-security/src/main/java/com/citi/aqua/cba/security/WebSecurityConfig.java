package com.citi.aqua.cba.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import com.citi.aqua.cba.web.resources.StaticResources;
import org.springframework.boot.actuate.autoconfigure.security.servlet.EndpointRequest;
import org.springframework.boot.autoconfigure.security.servlet.PathRequest;

@Configuration
@EnableWebSecurity
public class WebSecurityConfig {

	@Bean
	public WebSecurityConfigurerAdapter applicationSecurity() {
		return new WebSecurityConfigurerAdapter() {

			@Override
			protected void configure(HttpSecurity http) throws Exception {
				String[] staticResource = StaticResources.getExcludeResources()
						.toArray(new String[StaticResources.getExcludeResources().size()]);
				String[] allowedURIS = StaticResources.getExcludeResources()
						.toArray(new String[StaticResources.getExcludeURIS().size()]);

				http.csrf().disable().authorizeRequests().requestMatchers(EndpointRequest.to("env")).permitAll()
						.requestMatchers(EndpointRequest.toAnyEndpoint()).hasRole("ACTUATOR")

						.requestMatchers(PathRequest.toStaticResources().atCommonLocations()).permitAll()
						.antMatchers(staticResource).permitAll().antMatchers(allowedURIS).permitAll();
			}
		};
	}

}
