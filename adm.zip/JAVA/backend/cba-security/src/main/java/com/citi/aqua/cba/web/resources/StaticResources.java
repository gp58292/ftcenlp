package com.citi.aqua.cba.web.resources;

/**
 * @name StaticResources
 */

import java.util.HashSet;
import java.util.Set;

public class StaticResources {

	public static final String URI_CACHE_ADMIN = "/cba-cache";

	private static final Set<String> EXCLUDE_URIS = new HashSet<>();
	private static final Set<String> EXCLUDE_RESOURCES = new HashSet<>();

	static {
		EXCLUDE_URIS.add("/redirectTo");
		EXCLUDE_URIS.add("/api/getEnviromentDetails");
		EXCLUDE_URIS.add("/logClientErrors/");
		EXCLUDE_URIS.add("/api/sso/authenticate");
		EXCLUDE_URIS.add("/api/cache/data/refreshed/status");
		EXCLUDE_URIS.add("/api/sso/changePassword");
	}

	// static resources
	static {
		EXCLUDE_RESOURCES.add("/");
		EXCLUDE_RESOURCES.add("/assets/**");
		EXCLUDE_RESOURCES.add("/login/**");
		EXCLUDE_RESOURCES.add("/**/*.ttf");
		EXCLUDE_RESOURCES.add("/**/*.eot");
		EXCLUDE_RESOURCES.add("/**/*.svg");
		EXCLUDE_RESOURCES.add("/**/*.woff");
		EXCLUDE_RESOURCES.add("/**/*.woff2");
		EXCLUDE_RESOURCES.add("/**/*.html");
		EXCLUDE_RESOURCES.add("/**/*.ico");
		EXCLUDE_RESOURCES.add("/**/*.gif");
		EXCLUDE_RESOURCES.add("/**/*.png");
		EXCLUDE_RESOURCES.add("/**/*.jpg");
		EXCLUDE_RESOURCES.add("/**/*.js");
		EXCLUDE_RESOURCES.add("/**/*.css");
		EXCLUDE_RESOURCES.add("/**/*.js.map");
	}

	private StaticResources() {
	}

	public static Set<String> getExcludeURIS() {
		return EXCLUDE_URIS;
	}

	public static Set<String> getExcludeResources() {
		return EXCLUDE_RESOURCES;
	}

}
