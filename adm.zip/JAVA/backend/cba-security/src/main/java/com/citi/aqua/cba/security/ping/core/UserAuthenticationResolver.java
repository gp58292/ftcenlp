package com.citi.aqua.cba.security.ping.core;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.SyncFailedException;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLHandshakeException;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.text.StringSubstitutor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestMethod;
import com.citi.aqua.cba.security.constants.AuthConstants;
import com.citi.aqua.cba.security.ping.config.CitiFederationKeys;
import com.citi.aqua.cba.security.ping.util.RandomStringUtil;

@Service
public class UserAuthenticationResolver {

	private static final Logger LOGGER = LoggerFactory.getLogger(UserAuthenticationResolver.class);
	
	@Autowired
	private CitiFederationKeys citiFederationKeys;
	
	@Autowired
	private PingServiceSSLContext pingServiceSSLContext;

	public Map<String, String> validateUserIdentify(String userId, String credential) {
		LOGGER.debug("UserAuthenticationResolver:: validateUserIdentify by credentials::{}",this.citiFederationKeys);
		String token = createOpenToken(StringUtils.trim(userId), StringUtils.trim(new String(Base64.getMimeDecoder().decode(credential))));
		//String token = createOpenToken(StringUtils.trim(userId), StringUtils.trim(new String(credential)));
		return getPingServiceResponse(token);
	}

	public boolean validateUserIdentify(String token) {
		LOGGER.debug("UserAuthenticationResolver:: validateUserIdentify by token::{}",this.citiFederationKeys);
		Map<String, String> userAuthenticationResult = getPingServiceResponse(token);
		return Boolean.parseBoolean(userAuthenticationResult.get(AuthConstants.IS_TOKEN_VALID));
	}
	
	public String refreshToken(String token) {
		LOGGER.debug("Inside UserAuthenticationResolver:: validateUserIdentify by token::{}",this.citiFederationKeys);
		Map<String, String> userAuthenticationResult = getPingServiceResponse(token);
		return userAuthenticationResult.get(AuthConstants.TOKEN);
	}
	
	private Map<String, String> getPingServiceResponse (String token) {
		
		
		HttpsURLConnection connection = null;
		Map<String, String> userAuthenticationResult = new HashMap<>();
		Integer statusCode = -1;
		String statusMessage = "";
		boolean isTokenValid = false;
		String tokenReponse = "";
		boolean exceptionOccured = false;
		try {
			// SET TO WSTRUST_IDP_URL OR WSTRUST_SP_URL
			String pingURL = citiFederationKeys.getUrl();
			LOGGER.debug("Ping Federation Service URL: {}", pingURL);
			// SET TO WSTRUST_IDP_URL OR WSTRUST_SP_URL
			connection =this.getHttpConnection(pingURL);
			// PROCESS RST TO SET TIMESTAMPS & IDs & TOKEN
			// SMSESSION value or OpenToken value or SAML 2.0 Assertion
			String request = constructSOAPRquestXML(token);
			this.submitRequest(request, connection);

			if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
				statusCode = 0;
				statusMessage = "User authenticated successfully";
				isTokenValid = true;
				tokenReponse = extractToken(readResponse(connection));
				LOGGER.info("Inside UserAuthenticationResolver:: ping success response : User successfully authenticated" );
			} else {
				statusCode = -1;
				statusMessage = "User is not authenticated";
				LOGGER.info("Inside UserAuthenticationResolver:: ping failure response : User is not authenticated");
			}
		} catch (SocketTimeoutException ste) {
			LOGGER.error("SocketTimeoutException: {}", ste);
			exceptionOccured = true;
		} catch (UnknownHostException e) {
			LOGGER.error("UnknownHostException: {}", e);
			exceptionOccured = true;
		} catch (SSLHandshakeException e) {
			LOGGER.error("SSL Hand Shake Error. Please check certificates {}", e);
			exceptionOccured = true;
		} catch (ProtocolException | MalformedURLException | UnsupportedEncodingException | SyncFailedException e) {
			LOGGER.error("Protocol Exception occured. Please check with admin {}", e);
			exceptionOccured = true;
		} catch (IOException e) {
			LOGGER.error("IO Exception occured. Please check with admin",e);
			exceptionOccured = true;
		} catch (Exception e) {
			LOGGER.error("General Exception occured. Please check with admin",e);
			exceptionOccured = true;
		} 
		if(exceptionOccured) {
			statusMessage = "Citi federation ping webservice is down. Please check with admin";
		}
		userAuthenticationResult.put(AuthConstants.STATUS_CODE, String.valueOf(statusCode));
		userAuthenticationResult.put(AuthConstants.STATUS_MESSAGE, statusMessage);
		userAuthenticationResult.put(AuthConstants.IS_TOKEN_VALID, Boolean.toString(isTokenValid));
		userAuthenticationResult.put(AuthConstants.TOKEN, tokenReponse);
		return userAuthenticationResult;
	}
	
	private HttpsURLConnection getHttpConnection(final String pingURL) throws IOException {
		URL url = new URL(pingURL);
		HttpsURLConnection connection = (HttpsURLConnection) url.openConnection();
		connection.setSSLSocketFactory(this.pingServiceSSLContext.getPingSSLContext().getSocketFactory());
		return connection;
	}
	
	private String readResponse(HttpsURLConnection connection) throws IOException {
		StringBuilder response = new StringBuilder();
		String line = null;
		try(BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream()))) {
			while ((line = br.readLine()) != null) {
				response.append(line);
			}
		} 
		
		return response.toString();
	}


	private String constructSOAPRquestXML(String token) {
		LOGGER.info("Inside UserAuthenticationResolver :: constructSOAPRquestXML");
		Map<String, String> requestParameters = new HashMap<>();
		StringBuilder request = new StringBuilder();
		String wsuIdForToken = new RandomStringUtil(28).nextString();
		requestParameters.put(AuthConstants.PING_REQUEST_CREATE_TIME_STAMPE, getCreateTimestamp());
		requestParameters.put(AuthConstants.PING_REQUEST_EXPIRE_TIME_STAMPE, getExpiredTimestamp());
		requestParameters.put(AuthConstants.PING_REQUEST_BINARY_SECURITY_TOKEN, token);
		requestParameters.put(AuthConstants.PING_REQUEST_WSU_ID_FOR_TIMESTAMP, new RandomStringUtil(28).nextString());
		requestParameters.put(AuthConstants.PING_REQUEST_WSU_ID_FOR_TOKEN, wsuIdForToken);
		requestParameters.put(AuthConstants.PING_REQUEST_WSU_ID_FOR_BODY, new RandomStringUtil(28).nextString());
		requestParameters.put(AuthConstants.PING_REQUEST_URI_FOR_REFERENCE, wsuIdForToken);
		requestParameters.put(AuthConstants.PING_REQUEST_ADDRESS, AuthConstants.PING_REQUEST_RP_TEST);
		String soapRequest = null;

		try {
			String reqPathStr = citiFederationKeys.getSoapRequestTemplatePath();
			InputStream reqPath = UserAuthenticationResolver.class.getResourceAsStream(reqPathStr);
			BufferedReader br = new BufferedReader(new InputStreamReader(reqPath));
			String r;
			while ((r = br.readLine()) != null) {
				request.append(r);
			}
			StringSubstitutor sub = new StringSubstitutor(requestParameters);
			soapRequest = sub.replace(request);
		} catch (IOException e) {
			LOGGER.error("Exception occerured in  LOGGER.error(\"Exception occerured in  getSSLContext()\");()");
		}
		return soapRequest;
	}
	
	private void submitRequest(String request, HttpsURLConnection connection) throws IOException {
		if(request != null) {
			// Submit RST
			connection.setRequestMethod(RequestMethod.POST.name());
			connection.setRequestProperty(AuthConstants.PING_REQUEST_SOAP_ACTION, "\"\"");
			connection.setRequestProperty(AuthConstants.CONTENT_LENGTH, Integer.toString(request.length()));
			connection.setRequestProperty(AuthConstants.CONTENT_TYPE,AuthConstants.CONTENT_TYPE_VALUE);
			connection.setReadTimeout(citiFederationKeys.getTimeout() * 1000);
			connection.setAllowUserInteraction(false);
			connection.setDoInput(true);
			connection.setDoOutput(true);
			HttpsURLConnection.setFollowRedirects(false);
			
			OutputStream out = connection.getOutputStream();

			OutputStreamWriter wout = new OutputStreamWriter(out, StandardCharsets.UTF_8);
			wout.write(request);
			wout.flush();
			out.close();
		}
	}

	private static String createOpenToken(String userId, String credential) {
		
		return new String(Base64.getEncoder().encode((userId + "|" + credential).getBytes()));
	}

	private static String getCreateTimestamp() {
		SimpleDateFormat df = new SimpleDateFormat(AuthConstants.PING_REQUEST_DATE_FORMAT);
		String outputDate = null;
		try {
			outputDate = df.format(new Date());
		} catch (Exception e) {
			LOGGER.error("Exception occerured in  getCreateTimestamp()");
		}
		if(outputDate!=null)
			outputDate = outputDate.substring(0, outputDate.length() - 2) + ":"	+ outputDate.substring(outputDate.length() - 2);
		return outputDate;
	}
	
	private static String extractToken(String xmlString) {
		return StringUtils.substringBetween(xmlString, AuthConstants.PING_REQUEST_TOKEN_START, AuthConstants.PING_REQUEST_TOKEN_END);
	}

	private static String getExpiredTimestamp() {
		SimpleDateFormat df = new SimpleDateFormat(AuthConstants.PING_REQUEST_DATE_FORMAT);
		String outputDate = null;
		Calendar now = Calendar.getInstance();
		now.add(Calendar.MILLISECOND, 800000);
		try {
			outputDate = df.format(now.getTime());
		} catch (Exception e) {
			LOGGER.error("Exception occerured in  getExpiredTimestamp()");
		}
		if (outputDate != null)
			outputDate = outputDate.substring(0, outputDate.length() - 2) + ":"	+ outputDate.substring(outputDate.length() - 2);
		return outputDate;
	}

}
