package com.citi.aqua.cba.services.service;

import com.citi.aqua.cba.model.Request;
import com.citi.aqua.cba.model.UploadFile;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

public interface RequestService {

	public List<Request> getRequestList();

	public void insertRequest(Request request);

	public void deleteRequest(int id);

	public void updateRequest(Request request);

	public void upload(MultipartFile[] files, int requestId) throws IOException;

	public UploadFile getFile(int requestId, String fileName);

	public List<UploadFile> getRequestFileList(int requestId);

}
