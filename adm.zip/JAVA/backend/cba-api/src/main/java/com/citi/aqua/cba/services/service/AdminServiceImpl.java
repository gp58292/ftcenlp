package com.citi.aqua.cba.services.service;

import java.util.List;

import com.citi.aqua.cba.model.*;
import com.citi.aqua.cba.services.service.AdminService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.citi.aqua.cba.data.mapper.cba.AdminMapper;

/**
 * @author: aw11769
 *
 * 
 */
@Service("AdminService")
public class AdminServiceImpl implements AdminService {

	private static final Logger LOGGER = LoggerFactory.getLogger(AdminServiceImpl.class);
	
	@Autowired
	private AdminMapper adminMapper;

	@Override
	public List<EWSUser> getEWSUsers() {
		return adminMapper.getEWSUsers();
	}

	@Override
	public List<UserCoverage> getUserCoverage(String id) {
		return adminMapper.getUserCoverage(id);
	}

	@Override
	public EWSUser getEWSUser(String id) {
		return adminMapper.getEWSUser(id);
	}

	@Override
	public List<DropDownModel> getClientCoverageList() {
		return adminMapper.getClientCoverageList();
	}

	@Override
	public void updateUserRole(String soeid, String role, String gpnum,	int all_client, String updatedby) {
		adminMapper.updateUserRole(soeid, role, gpnum, all_client, updatedby);
	}

	@Override
	public void updateUserCoverage(String soeid, String gpnum, String updatedby) {
		adminMapper.updateUserCoverage(soeid, gpnum, updatedby);
	}

	@Override
	public List<UserHistory> getUserHistory(String soeid) {
		return adminMapper.getUserHistory(soeid);
	}

	@Override
	public List<Admin> getAdminList() {
		LOGGER.debug("Retrieving Admin List");
		
		return adminMapper.getAdminList();		
	}

	@Override
	public void insertAdmin(Admin admin) {
		LOGGER.debug("Inserting Admin: " + admin.getSoeid());
		
		adminMapper.insertAdmin(admin);
		
		return; 
		
	}

	@Override
	public void deleteAdmin(String soeid, String entitlement) {
		LOGGER.debug("Deleting Admin: " + soeid);

		adminMapper.deleteAdmin(soeid, entitlement);
		
		return; 
		
	}


	@Override
	public void editAdminPermission(Admin admin) {
		LOGGER.debug("Editing Admin Permission with: " + admin.getSoeid());
		
		adminMapper.editAdminPermission(admin);

		return;

	}
}
