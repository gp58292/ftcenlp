package com.citi.aqua.cba.services.service;
/**
 * @author: jm27909
 *
 * 
 */
import java.util.List;

import com.citi.aqua.cba.model.SeedLoadCPC;


public interface SeedLoadCPCService {

	
	//Retrieve all records from the SeedLoadCPC table
	public List<SeedLoadCPC> getSeedLoadCPC();
	
	//insert record into SeedLoadCPC table 
	public void insertSeedLoadCPC(SeedLoadCPC seedLoadCPC);
	
	//Retrieve records by SeedLoadCPC flag from SeedLoadCPC table
	public List<SeedLoadCPC> findByFlag(String flag);

	//Retrieve record by SeedLoadCPC flag from SeedLoadCPC table
	public List<SeedLoadCPC> findByCobDate(String cobDate);

	//Delete record by COB Date from SeedLoadCPC table
	public void deleteSeedLoadCPC(String cobDate, String loadDate);

	//update record in the SeedLoadCPC table
	public void updateByCobDate(SeedLoadCPC seedLoadCPC);
		
}
