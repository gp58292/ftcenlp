
package com.citi.aqua.cba.services.service.impl;

import java.util.List;

import javax.activation.DataHandler;
import javax.mail.BodyPart;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.mail.util.ByteArrayDataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import com.citi.aqua.cba.commons.util.CommonUtility;
import com.citi.aqua.cba.commons.util.DownstreamEmailTemplateUtility;
import com.citi.aqua.cba.data.mapper.cba.BatchAutomationMapper;
import com.citi.aqua.cba.model.FeedDelayDataDetails;
import com.citi.aqua.cba.model.FeedDelayEmailData;
import com.citi.aqua.cba.services.service.DownstreamNotificationService;

/**
 * @author ak92283
 *
 */
@Service("DownstreamNotificationService")
public class DownstreamNotificationServiceImpl implements DownstreamNotificationService {

	private static final Logger LOGGER = LoggerFactory.getLogger(DownstreamNotificationServiceImpl.class);

	@Autowired
	BatchAutomationMapper batchAutomationMapper;

	@Autowired
	private CommonUtility commonUtility;

	@Autowired
	private DownstreamEmailTemplateUtility downstreamEmailTemplateUtility;

	public List<FeedDelayDataDetails> feedDataDelayEstimates() {
		LOGGER.debug("DownstreamNotificationServiceImpl::feedDataDelayEstimates()::starts");
		return batchAutomationMapper.getDelayInformationForETA("Feed/Data");
	}

	public String getCOBDate() throws Exception {
		LOGGER.debug("DownstreamNotificationServiceImpl::getCOBDate()::starts");
		return batchAutomationMapper.getCOBDate();
	}

	public Boolean sendDownstreamNotificationMail(FeedDelayEmailData emailData, final String envName) throws Exception {
		LOGGER.debug("DownstreamNotificationServiceImpl::sendDownstreamNotificationMail()::starts");
		try {
			if (null != emailData.getConfigForm().getEmailUpdate()
					&& !emailData.getConfigForm().getEmailUpdate().equalsIgnoreCase("")) {
				String updateType = emailData.getConfigForm().getEmailUpdate();
				switch (updateType) {
				case ("1"):
					emailData.getConfigForm().setEmailUpdate("First");
					break;
				case ("2"):
					emailData.getConfigForm().setEmailUpdate("Second");
					break;
				default:
					emailData.getConfigForm().setEmailUpdate("Final");
				}
			}

			// Get the cob date
			final String cobDate = getCOBDate();
			final String subjectEnv = envName != null ? envName.toUpperCase() : envName;

			// create subject of the email
			final String emailSubject = "***" + emailData.getConfigForm().getEmailUpdate() + " Update*** :"
					+ emailData.getConfigForm().getEmailSubject() + " for " + cobDate + "  [" + subjectEnv + "]";

			final JavaMailSenderImpl sender = new JavaMailSenderImpl();
			sender.setHost("mailhub-vip.ny.ssmb.com");
			final MimeMessage message = sender.createMimeMessage();
			// use the true flag to indicate you need a multipart message
			final MimeMessageHelper helper = new MimeMessageHelper(message, true);
			helper.setTo(emailData.getConfigForm().getEmailTo());
			helper.setFrom("dl.gt.global.aqua.cba.build.team@imcnam.ssmb.com");
			if (null != emailData.getConfigForm().getEmailBCC()
					&& !("").equals(emailData.getConfigForm().getEmailBCC())) {
				helper.setBcc(emailData.getConfigForm().getEmailBCC());
			}
			if (null != emailData.getConfigForm().getEmailCC()
					&& !("").equals(emailData.getConfigForm().getEmailCC())) {
				helper.setCc(emailData.getConfigForm().getEmailCC());
			}
			helper.setSubject(emailSubject);

			BodyPart messageBodyPart = new MimeBodyPart();
			String contentId = commonUtility.generateContentId("DN");
			// Get the contents for the body
			String htmlText = downstreamEmailTemplateUtility.formHtmlText(contentId, emailData);
			LOGGER.debug("The template is as for downstream mail ::" + htmlText);
			messageBodyPart.setContent(htmlText, "text/html; charset=ISO-8859-1");
			MimeMultipart multipart = new MimeMultipart("related");
			multipart.addBodyPart(messageBodyPart);
			// second part (the image)
			messageBodyPart = new MimeBodyPart();
			java.io.InputStream inputStream = this.getClass().getResourceAsStream("/Citi_Header.jpg");
			ByteArrayDataSource ds = new ByteArrayDataSource(inputStream, "image/jpg");
			messageBodyPart.setDataHandler(new DataHandler(ds));
			messageBodyPart.setHeader("Content-ID", "<" + contentId + ">");
			messageBodyPart.setDisposition(MimeBodyPart.INLINE);
			multipart.addBodyPart(messageBodyPart);
			message.setContent(multipart);
			sender.send(message);
			return true;
		} catch (Exception e) {
			LOGGER.error("DownstreamNotificationServiceImpl::sendDownstreamNotificationMail()::Exception ::" + e, e);
			return false;
		}
	}

}
