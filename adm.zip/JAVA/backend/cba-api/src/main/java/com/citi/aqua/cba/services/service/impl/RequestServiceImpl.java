package com.citi.aqua.cba.services.service.impl;

import com.citi.aqua.cba.data.mapper.cba.RequestMapper;
import com.citi.aqua.cba.model.Request;
import com.citi.aqua.cba.model.UploadFile;
import com.citi.aqua.cba.services.service.RequestService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

/**
 * 
 * @author ak92283
 *
 */
@Service("RequestService")
public class RequestServiceImpl implements RequestService {

	private static final Logger LOGGER = LoggerFactory.getLogger(RequestServiceImpl.class);

	@Autowired
	private RequestMapper requestMapper;

	@Override
	public List<Request> getRequestList() {
		LOGGER.debug("Retrieving All Requests");

		return requestMapper.getRequestList();
	}

	@Override
	public void insertRequest(Request request) {
		LOGGER.debug("Inserting Request");

		requestMapper.insertRequest(request);

		return;
	}

	@Override
	public void deleteRequest(int id) {
		LOGGER.debug("Deleting Request");

		requestMapper.deleteRequest(id);

		return;
	}

	@Override
	public void updateRequest(Request request) {
		LOGGER.debug("Updating Request");

		requestMapper.editRequest(request);

		return;

	}

	// used to upload a file sent from UI
	@Override
	public void upload(MultipartFile[] files, int requestId) throws IOException {
		LOGGER.debug("Uploading File");

		for (MultipartFile file : files) {
			UploadFile uploadFile = new UploadFile();
			if (!file.isEmpty()) {
				// set file properties
				String fileName = file.getOriginalFilename();
				uploadFile.setFileName(fileName);
				uploadFile.setFileObject(file.getBytes());
				uploadFile.setRequestId(requestId);

				// call the mapper to insert file contents into table
				// will be able to download the file
				LOGGER.info("name of file to be uploaded: " + uploadFile.getFileName());
				requestMapper.upload(uploadFile);
				LOGGER.info("file: " + uploadFile.getFileName() + " has been uploaded");
			} else {
				LOGGER.info("file: is empty");
			}
		}

		return;
	}

	@Override
	public UploadFile getFile(int requestId, String fileName) {
		LOGGER.debug("Get File by ID: " + requestId);

		return requestMapper.getFile(requestId, fileName);

	}

	@Override
	public List<UploadFile> getRequestFileList(int requestId) {

		return requestMapper.getRequestFileList(requestId);
	}
}