package com.citi.aqua.cba.services.service;
/**
 * @author ak92283
 */

import java.util.List;
import com.citi.aqua.cba.model.DataLogging;

public interface DataLoggingService {

	// Retrieve user defined number of rows given a datasource and a stored
	// Procedure
	public List<DataLogging> searchDBAndStoreProcedure(String cbaProc, String raceProc, String futureProc,
			String slProc, int numberOfRows);

	// Retrieve user defined number of rows from single or multiple datasource
	public List<DataLogging> searchDB(String cbaDB, String raceDB, String futureDB, String slDB, int numberOfRows);

	// Auto complete to retrieve list of stored procedures need the query that will
	// keep updated to filter list and which databasename to look at
	public List<String> filterProcList(String cbaquery, String racequery, String futurequery, String slquery);

}
