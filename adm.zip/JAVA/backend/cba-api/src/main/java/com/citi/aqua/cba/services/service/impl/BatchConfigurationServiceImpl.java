package com.citi.aqua.cba.services.service.impl;

/**
 * @author ak92283
 */
import java.util.LinkedList;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.citi.aqua.cba.data.mapper.cba.BatchAutomationMapper;
import com.citi.aqua.cba.model.BatchConfigParams;
import com.citi.aqua.cba.model.BatchEmailConfigForm;
import com.citi.aqua.cba.services.service.BatchConfigurationService;

@Service("BatchConfigurationService")
public class BatchConfigurationServiceImpl implements BatchConfigurationService {
	private static final Logger LOGGER = LoggerFactory.getLogger(BatchConfigurationServiceImpl.class);

	@Autowired
	BatchAutomationMapper batchAutomationMapper;

	public List<Long> getCOBDateList() {
		LOGGER.debug("BatchConfigurationServiceImpl::getCOBDateList()::starts");
		return batchAutomationMapper.getCOBDateList();
	}

	public Boolean submitConfigForm(BatchEmailConfigForm batchEmailConfigForm) {
		LOGGER.debug("BatchConfigurationServiceImpl::submitConfigForm()::starts");
		// Business login here
		Boolean flag = false;
		try {
			// Business login here
			BatchConfigParams params = new BatchConfigParams();
			params.setMail_bcc(batchEmailConfigForm.getEmailBCC());
			params.setMail_cc(batchEmailConfigForm.getEmailCC());
			params.setMail_to(batchEmailConfigForm.getEmailTo());
			params.setMail_from(batchEmailConfigForm.getEmailFrom());
			params.setSubject(batchEmailConfigForm.getEmailSubject());
			params.setType(batchEmailConfigForm.getNotificationType());
			params.setUpdate_type(batchEmailConfigForm.getEmailUpdate());
			params.setMail_from(batchEmailConfigForm.getEmailFrom());
			flag = batchAutomationMapper.insertBatchConfigData(params);
			LOGGER.debug("BatchConfigurationServiceImpl::submitConfigForm()::ends");
		} catch (Exception e) {
			LOGGER.debug("BatchConfigurationServiceImpl::submitConfigForm()::error" + e, e);
			throw e;
		}
		return flag;
	}

	public List<BatchEmailConfigForm> getEmailConfigList() {
		LOGGER.debug("BatchConfigurationServiceImpl::getEmailConfigList()::starts");
		List<BatchEmailConfigForm> configList = new LinkedList<>();
		try {
			final List<BatchConfigParams> configParamsList = batchAutomationMapper.getEmailConfigList();
			Function<BatchConfigParams, BatchEmailConfigForm> paramsToConfig = new Function<BatchConfigParams, BatchEmailConfigForm>() {
				public BatchEmailConfigForm apply(BatchConfigParams t) {
					BatchEmailConfigForm configForm = new BatchEmailConfigForm();
					configForm.setEmailBCC(t.getMail_bcc());
					configForm.setEmailCC(t.getMail_cc());
					configForm.setEmailSubject(t.getSubject());
					configForm.setEmailTo(t.getMail_to());
					configForm.setNotificationType(t.getType());
					configForm.setEmailUpdate(t.getUpdate_type());
					configForm.setEmailFrom(t.getMail_from());
					return configForm;
				}
			};

			configList = configParamsList.stream().map(paramsToConfig)
					.collect(Collectors.<BatchEmailConfigForm>toList());
		} catch (Exception e) {
			LOGGER.debug("BatchConfigurationServiceImpl::getEmailConfigList()::error" + e, e);
			throw e;
		}
		return configList;
	}

	public BatchEmailConfigForm getDownstreamEmailConfiguration() {
		LOGGER.debug("BatchConfigurationServiceImpl::getDownstreamEmailConfiguration()::starts");
		// Business login here
		BatchEmailConfigForm configForm = new BatchEmailConfigForm();
		try {
			// Business login here
			BatchConfigParams batchConfigParams = batchAutomationMapper.getDNConfig();
			configForm = convertParamsToConfig(batchConfigParams);
		} catch (Exception e) {
			LOGGER.debug("BatchConfigurationServiceImpl::getDownstreamEmailConfiguration()::error" + e, e);
			throw e;
		}
		return configForm;
	}

	public BatchEmailConfigForm getUserEmailConfiguration() {
		LOGGER.debug("BatchConfigurationServiceImpl::getUserEmailConfiguration()::starts");
		// Business login here
		BatchEmailConfigForm configForm = new BatchEmailConfigForm();
		try {
			// Business login here
			BatchConfigParams batchConfigParams = batchAutomationMapper.getUNConfig();
			configForm = convertParamsToConfig(batchConfigParams);
		} catch (Exception e) {
			LOGGER.debug("BatchConfigurationServiceImpl::getUserEmailConfiguration()::error" + e, e);
			throw e;
		}
		return configForm;
	}

	private BatchEmailConfigForm convertParamsToConfig(BatchConfigParams batchConfigParams) {
		BatchEmailConfigForm configForm = new BatchEmailConfigForm();
		Function<BatchConfigParams, BatchEmailConfigForm> paramsToConfig = new Function<BatchConfigParams, BatchEmailConfigForm>() {
			public BatchEmailConfigForm apply(BatchConfigParams t) {
				BatchEmailConfigForm configForm = new BatchEmailConfigForm();
				configForm.setEmailBCC(t.getMail_bcc());
				configForm.setEmailCC(t.getMail_cc());
				configForm.setEmailSubject(t.getSubject());
				configForm.setEmailTo(t.getMail_to());
				configForm.setNotificationType(t.getType());
				configForm.setEmailUpdate(t.getUpdate_type());
				configForm.setEmailFrom(t.getMail_from());
				return configForm;
			}
		};
		configForm = paramsToConfig.apply(batchConfigParams);
		return configForm;

	}

	public BatchEmailConfigForm getBatchStatusEmailConfiguration() {
		LOGGER.debug("BatchConfigurationServiceImpl::getBatchStatusEmailConfiguration()::starts");
		// Business login here
		BatchEmailConfigForm configForm = new BatchEmailConfigForm();
		try {
			BatchConfigParams batchConfigParams = batchAutomationMapper.getBSConfig();
			configForm = convertParamsToConfig(batchConfigParams);
		} catch (Exception e) {
			LOGGER.debug("BatchConfigurationServiceImpl::getBatchStatusEmailConfiguration()::error" + e, e);
			throw e;
		}
		return configForm;
	}

}
