package com.citi.aqua.cba.services.util;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.aqua.cba.services.service.BatchStatusServiceImpl;

/**
 * Uses UNIX mailx service to easily send e-mails.
 * 
 * @author gp47905
 *
 */
public final class MailUtil {
	private static final Logger LOGGER = LoggerFactory.getLogger(BatchStatusServiceImpl.class);

	public static final String DL_TEAM_DEVELOPMENT = "grahi.rajesh.parmar@citi.com";
	/**
	 * The log object
	 */

	/**
	 * Default empty constructor
	 */
	private MailUtil() {

	}

	/**
	 * Uses the UNIX service mailx to send e-mails.
	 * @param message The message to be sent.
	 * @param subject Email subject.
	 * @param addressee The recipients email separated by ','.
	 * @throws FefxException Error sending the e-mail.
	 */
	public static void mailx(String message, String subject, String addressee) throws Exception {		
		mailx(message, subject, addressee, null, false);
	}
	
	/**
	 * Uses the UNIX service mailx to send e-mails.
	 * @param message The message to be sent.
	 * @param subject Email subject.
	 * @param addressee The recipients email separated by ','.
	 * @throws FefxException Error sending the e-mail.
	 */
	public static void mailx(String message, String subject, String addressee, boolean isHTMLFormat) throws Exception {
		mailx(message, subject, addressee, null, isHTMLFormat);
	}
	
	
	private static void executeCommands(BufferedWriter outCommand, String ... commands) throws IOException{
		for(String command : commands){
			outCommand.write(command, 0, command.length());
			outCommand.newLine();
		}
		
	}
	
	private static String getMailCommand(String message, String subject, String addressee, String attachmentPath, boolean isHTMLFormat) { 
		
		String os = System.getProperty("os.name");
		String cmd = null;
		
		if (os != null) { 
			if (os.toLowerCase().contains("linux")) { 
				cmd = getLinuxMailCommand(message, subject, addressee, attachmentPath, isHTMLFormat);
			} else if (os.toLowerCase().contains("windows")) { 
				cmd = null;
			} else { 
				cmd = getDefaultMailCommand(message, subject, addressee, attachmentPath, isHTMLFormat);
			}			
		}	
		
		
		return cmd;		
	}
	
	private static String getLinuxMailCommand(String message, String subject, String addressee, String attachmentPath, boolean isHTMLFormat) { 
		String command = "";
		if(attachmentPath != null){
			command = "(printf \"%s\\n%s\\n\" \""+message+"\"; uuencode "+attachmentPath+" "+attachmentPath+") | mail -s \""+subject+"\" " +addressee;
			LOGGER.info(command);
			return command;
		} else {
			if (isHTMLFormat) {
				command = "echo \"" + message + "\" | mail -s \"$(echo -e \"" + subject + "\nContent-Type: text/html\")\" "+ addressee;
				LOGGER.info(command);
				return command;
			} else{
				command = "echo \"" + message + "\" | mail " + " -s \"" + subject + "\" " + addressee;
				LOGGER.info(command);
				return command;
			}
		}
	}
	
	private static String getDefaultMailCommand(String message, String subject, String addressee, String attachmentPath, boolean isHTMLFormat) { 
		String command = "";
		if(attachmentPath != null){
			command = "(printf \"%s\\n%s\\n\" \""+message+"\"; uuencode "+attachmentPath+" "+attachmentPath+") | mailx -s \""+subject+"\" " +addressee;
			LOGGER.info(command);
			return command;
		} else {
			if (isHTMLFormat) {
				command =  "echo \"" + message + "\" | mailx -s \"$(echo -e \"" + subject + "\nContent-Type: text/html\")\" "+ addressee;
				LOGGER.info(command);
				return command;
			} else {
				command =  "echo \"" + message + "\" | mailx  -s \"" + subject + "\" " + addressee;
				LOGGER.info(command);
				return command;
			}
		}
	}
	
	/**
	 * Uses the UNIX service mailx to send e-mails.
	 * @param message The message to be sent.
	 * @param subject Email subject.
	 * @param addressee The recipients email separated by ','.
	 * @param attachmentPath The path of the file to be attached to the e-mail.
	 * @throws FefxException Error sending the e-mail.
	 */
	public static void mailx(String message, String subject, String addressee, String attachmentPath, boolean isHTMLFormat) throws Exception {
		
		Process process = null;
		try {
			
			process = Runtime.getRuntime().exec("/bin/bash");
			BufferedWriter outCommand = new BufferedWriter(new OutputStreamWriter(process.getOutputStream()));
			String exit = "exit";	
			
			String sendMail = getMailCommand(message, subject, addressee, attachmentPath, isHTMLFormat);
			
			if (sendMail != null) { 
				executeCommands(outCommand, sendMail, exit);
				LOGGER.info("Email sent successfully!");
			}
			
			outCommand.flush();			
			process.waitFor();			
			outCommand.close();			

		} catch (IOException e) {
			LOGGER.info("MailService was unable to send the email: " + subject, e);
			throw new Exception(e);
		} catch (Exception e) {
			LOGGER.info("Unexpected exception when sending the email: " + subject, e);
			throw new Exception(e);
		}finally{
			try {
				if ( process != null ) {					
					try{
						if( process.getInputStream()!= null ){
							process.getInputStream().close();
						}
					}catch(IOException io){
						io.printStackTrace();
						System.out.println("IOException when trying to close inputstream from Process that sends e-mails. Msg:"+io.getMessage());
					}
					try{
						if(process.getErrorStream() != null){
							process.getErrorStream().close();
						}
					}catch(IOException io){
						io.printStackTrace();
						System.out.println("IOException when trying to close inputstream from Process that sends e-mails. Msg:"+io.getMessage());						
					}
					try{
						if( process.getOutputStream() != null ){
							process.getOutputStream().close();
						}
					}catch(IOException io){
						io.printStackTrace();
						System.out.println("IOException when trying to close inputstream from Process that sends e-mails. Msg:"+io.getMessage());
					}				  
					process.destroy();
				}
			} catch (Exception e) {
				System.out.println("Exception in MailService:"+e+". Msg:"+e.getMessage());
			}
		}
	}
	
	
}