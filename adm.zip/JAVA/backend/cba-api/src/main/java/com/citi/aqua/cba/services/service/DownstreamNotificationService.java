package com.citi.aqua.cba.services.service;

/**
 * @author ak92283
 */
import java.util.List;

import com.citi.aqua.cba.model.FeedDelayDataDetails;
import com.citi.aqua.cba.model.FeedDelayEmailData;

public interface DownstreamNotificationService {

	// This method is used to find the feed delay information for grid view of
	// feed/data
	public List<FeedDelayDataDetails> feedDataDelayEstimates();

	// This method is used to send report to downstream as email for feed delay
	public Boolean sendDownstreamNotificationMail(final FeedDelayEmailData emailData, final String envName)
			throws Exception;

}
