package com.citi.aqua.cba.services.service;

import java.util.List;

import com.citi.aqua.cba.model.BatchStatusDetails;
import com.citi.aqua.cba.model.BatchStatusEmailData;


public interface BatchStatusService {
	
	//retrieve batch status details
	public List<BatchStatusDetails> getBatchStatusDetails(final String COBDate);
	
	public String getCOBDate(final String currentDate);
	
	public Boolean sendBatchEmail(final BatchStatusEmailData data) throws Exception;
}
