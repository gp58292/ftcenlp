/**
 * 
 */
package com.citi.aqua.cba.services.service.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.citi.aqua.cba.data.mapper.cba.ConfigurationMapper;
import com.citi.aqua.cba.model.ArchiveDbForm;
import com.citi.aqua.cba.model.ArchiveFileForm;
import com.citi.aqua.cba.services.service.ArchiveService;

/**
 * @author ak92283
 *
 */
@Service("ArchiveService")
public class ArchiveServiceImpl implements ArchiveService {

	private static final Logger LOGGER = LoggerFactory.getLogger(ArchiveServiceImpl.class);

	@Autowired
	ConfigurationMapper configurationMapper;

	public List<ArchiveFileForm> getArchiveFiles() {
		LOGGER.debug("ArchiveServiceImpl::getArchiveFiles()::starts");
		return configurationMapper.getArchiveFiles();
	}

	public List<ArchiveDbForm> getArchiveDb() {
		LOGGER.debug("ArchiveServiceImpl::getArchiveDb()::starts");
		return configurationMapper.getArchiveDb();
	}

	public Boolean updateArchiveFile(final ArchiveFileForm archiveFileForm) {
		LOGGER.debug("ArchiveServiceImpl::updateArchiveFile()::starts");
		return configurationMapper.updateArchiveFile(archiveFileForm);
	}

	public Boolean updateArchiveDb(final ArchiveDbForm archiveDbForm) {
		LOGGER.debug("ArchiveServiceImpl::updateArchiveDb()::starts");
		return configurationMapper.updateArchiveDb(archiveDbForm);
	}

	public void createArchiveDbRecord(final ArchiveDbForm archiveDbForm) {
		LOGGER.debug("ArchiveServiceImpl::createArchiveDbRecord()::starts");
		configurationMapper.insertDbArchiveRecord(archiveDbForm);
	}

	public void createArchiveFileRecord(ArchiveFileForm archiveFileForm) {
		LOGGER.debug("ArchiveServiceImpl::createArchiveFileRecord()::starts");
		configurationMapper.insertFileArchiveRecord(archiveFileForm);
	}

}
