package com.citi.aqua.cba.services.service.impl;

/**
 * @author ak92283
 * 
 */
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.citi.aqua.cba.data.mapper.cba.DataLoggingMapper;

import com.citi.aqua.cba.model.DataLogging;
import com.citi.aqua.cba.services.service.DataLoggingService;

@Service("DataLoggingService")
public class DataLoggingServiceImpl implements DataLoggingService {

	private static final Logger LOGGER = LoggerFactory.getLogger(DataLoggingServiceImpl.class);

	@Autowired
	private DataLoggingMapper dataLoggingMapper;

	@Override
	public List<DataLogging> searchDBAndStoreProcedure(String cbaProc, String raceProc, String futureProc,
			String slProc, int numberOfRows) {
		LOGGER.debug("DataLoggingServiceImpl::searchDBAndStoreProcedure()::starts ");
		return dataLoggingMapper.searchDBAndStoreProcedure(cbaProc, raceProc, futureProc, slProc, numberOfRows);

	}

	@Override
	public List<DataLogging> searchDB(String cbaDB, String raceDB, String futureDB, String slDB, int numberOfRows) {
		LOGGER.debug("DataLoggingServiceImpl::searchDB()::starts ");
		return dataLoggingMapper.searchDB(cbaDB, raceDB, futureDB, slDB, numberOfRows);

	}

	@Override
	public List<String> filterProcList(String cbaquery, String racequery, String futurequery, String slquery) {
		LOGGER.debug("DataLoggingServiceImpl::filterProcList()::starts ");
		return dataLoggingMapper.filterProcList("%" + cbaquery + "%", "%" + racequery + "%", "%" + futurequery + "%",
				"%" + slquery + "%");

	}

}