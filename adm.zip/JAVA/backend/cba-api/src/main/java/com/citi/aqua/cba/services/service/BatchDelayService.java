package com.citi.aqua.cba.services.service;

/**
 * @author ak92283
 */
import java.util.List;

import com.citi.aqua.cba.model.FeedDelayData;

public interface BatchDelayService {

	// This method is used to retrieved the list of all the sources for a feed delay
	public List<String> getDelaySources();

	// This method is used to feed the information regarding delay into database
	public Boolean submitBatchDelay(final FeedDelayData delayAttributes) throws Exception;

	// This method is used to get the list of all batch delay list
	public List<FeedDelayData> getDelayList();
	
	// This method is used to get the list of  batch delay list for specific cob date
	public List<FeedDelayData> getDelayList(final String cobdate);

}
