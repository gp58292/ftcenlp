package com.citi.aqua.cba.services.service;

/**
 * @author: jm27909
 *
 * 
 */
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.citi.aqua.cba.data.mapper.pnl.SeedLoadCPCMapper;
import com.citi.aqua.cba.model.SeedLoadCPC;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Service("SeedLoadCPCService")
public class SeedLoadCPCServiceImpl implements SeedLoadCPCService {

	private static final Logger LOGGER = LoggerFactory.getLogger(SeedLoadCPCServiceImpl.class);

	@Autowired
	private SeedLoadCPCMapper seedLoadCPCMapper;

	@Override
	public List<SeedLoadCPC> getSeedLoadCPC() {
		LOGGER.debug("Retrieving all Records");

		List<SeedLoadCPC> result = seedLoadCPCMapper.getSeedLoadCPC();

		return result;
	}

	@Override
	public void insertSeedLoadCPC(SeedLoadCPC seedLoadCPC) {
		LOGGER.debug("SeedLoadCPCServiceImpl::insertSeedLoadCPC()::starts");
		seedLoadCPC.setLastUpdatedUser("NAM\\pfmis_admin");
		seedLoadCPCMapper.insertSeedLoadCPC(seedLoadCPC);

		return;
	}

	@Override
	public List<SeedLoadCPC> findByFlag(String flag) {
		LOGGER.debug("Finding Records in table with flag = " + flag);

		List<SeedLoadCPC> result = seedLoadCPCMapper.findByFlag(flag);

		return result;
	}

	@Override
	public List<SeedLoadCPC> findByCobDate(String cobDate) {
		LOGGER.debug("Finding Record in table with cob date = " + cobDate);

		List<SeedLoadCPC> result = seedLoadCPCMapper.findByCobDate(cobDate);

		return result;

	}

	@Override
	public void deleteSeedLoadCPC(String cobDate, String loadDate) {
		LOGGER.debug("Deleting Record in table with cob date of = " + cobDate + "loadDate:" + loadDate);

		seedLoadCPCMapper.deleteSeedLoadCPC(cobDate, loadDate);

		return;
	}

	@Override
	public void updateByCobDate(SeedLoadCPC seedLoadCPC) {
		String cobDate = seedLoadCPC.getCobDate();
		String flag = seedLoadCPC.getFlag();

		LOGGER.info("Updating Record in table with cob date of =  " + cobDate + "and flag = " + flag);

		return;

	}
}
