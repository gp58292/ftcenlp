package com.citi.aqua.cba.services.service;

/**
 * @author ak92283
 */
import java.util.List;

import com.citi.aqua.cba.model.BatchEmailConfigForm;

public interface BatchConfigurationService {

	public List<Long> getCOBDateList();

	public Boolean submitConfigForm(final BatchEmailConfigForm batchEmailConfigForm);

	public List<BatchEmailConfigForm> getEmailConfigList();

	public BatchEmailConfigForm getDownstreamEmailConfiguration();

	public BatchEmailConfigForm getUserEmailConfiguration();

	public BatchEmailConfigForm getBatchStatusEmailConfiguration();

}
