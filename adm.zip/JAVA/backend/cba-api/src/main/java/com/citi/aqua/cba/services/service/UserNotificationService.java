package com.citi.aqua.cba.services.service;

/**
 * @author ak92283
 */
import java.util.List;

import com.citi.aqua.cba.model.FeedDelayDataDetails;
import com.citi.aqua.cba.model.FeedDelayEmailData;

public interface UserNotificationService {

	// This method is used to find the feed delay information for grid view of
	// CBA dashboard
	public List<FeedDelayDataDetails> cbaDashboardDelayEstimates();

	// This method is used to find the feed delay information for grid view of
	// CBA dashboard
	public List<FeedDelayDataDetails> slDashboardDelayEstimates();

	// This method is used to find the feed delay information for grid view of
	// reports
	public List<FeedDelayDataDetails> reportsDelayEstimates();

	// This method is used to find the feed delay information for grid view of CAD
	public List<FeedDelayDataDetails> cadDelayEstimates();

	// This method is used to send report to the user as email for feed delay
	public Boolean sendUserNotificationMail(final FeedDelayEmailData emailData, final String envName) throws Exception;

}
