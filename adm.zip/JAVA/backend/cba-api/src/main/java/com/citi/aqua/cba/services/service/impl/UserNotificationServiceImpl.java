
package com.citi.aqua.cba.services.service.impl;

import java.util.List;

import javax.activation.DataHandler;
import javax.mail.BodyPart;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.mail.util.ByteArrayDataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import com.citi.aqua.cba.commons.util.CommonUtility;
import com.citi.aqua.cba.commons.util.UserEmailTemplateUtility;
import com.citi.aqua.cba.data.mapper.cba.BatchAutomationMapper;
import com.citi.aqua.cba.model.FeedDelayDataDetails;
import com.citi.aqua.cba.model.FeedDelayEmailData;
import com.citi.aqua.cba.services.service.UserNotificationService;

/**
 * @author ak92283
 *
 */
@Service("UserNotificationService")
public class UserNotificationServiceImpl implements UserNotificationService {
	private static final Logger LOGGER = LoggerFactory.getLogger(UserNotificationServiceImpl.class);

	@Autowired
	BatchAutomationMapper batchAutomationMapper;

	@Autowired
	private UserEmailTemplateUtility userEmailTemplateUtility;

	@Autowired
	private CommonUtility commonUtility;

	public List<FeedDelayDataDetails> cbaDashboardDelayEstimates() {
		LOGGER.debug("UserNotificationServiceImpl::cbaDashboardDelayEstimates()::starts");
		return batchAutomationMapper.getDelayInformationForETA("CBA Dashboard Data");
	}

	public List<FeedDelayDataDetails> slDashboardDelayEstimates() {
		LOGGER.debug("UserNotificationServiceImpl::slDashboardDelayEstimates()::starts");
		return batchAutomationMapper.getDelayInformationForETA("StockLoan Dashboard Data");
	}

	public List<FeedDelayDataDetails> reportsDelayEstimates() {
		LOGGER.debug("UserNotificationServiceImpl::reportsDelayEstimates()::starts");
		return batchAutomationMapper.getDelayInformationForETA("Reports");
	}

	public List<FeedDelayDataDetails> cadDelayEstimates() {
		LOGGER.debug("UserNotificationServiceImpl::cadDelayEstimates()::starts");
		return batchAutomationMapper.getDelayInformationForETA("Client Alert Dashboard");
	}

	private String getCOBDate() throws Exception {
		LOGGER.debug("UserNotificationServiceImpl::getCOBDate()::starts");
		return batchAutomationMapper.getCOBDate();
	}

	public Boolean sendUserNotificationMail(final FeedDelayEmailData emailData, final String envName) throws Exception {
		LOGGER.debug("UserNotificationServiceImpl::sendUserNotificationMail()::starts");
		try {
			// format the update type field
			if (null != emailData.getConfigForm().getEmailUpdate()
					&& !emailData.getConfigForm().getEmailUpdate().equalsIgnoreCase("")) {
				String updateType = emailData.getConfigForm().getEmailUpdate();
				switch (updateType) {
				case ("1"):
					emailData.getConfigForm().setEmailUpdate("First");
					break;

				case ("2"):
					emailData.getConfigForm().setEmailUpdate("Second");
					break;
				default:
					emailData.getConfigForm().setEmailUpdate("Final");
				}
			}

			// Get the cob date
			final String cobDate = getCOBDate();
			final String subjectEnv=envName!=null?envName.toUpperCase():envName;

			// create subject of the email
			final String emailSubject = "[***" + emailData.getConfigForm().getEmailUpdate() + " Update***]  :"
					+ emailData.getConfigForm().getEmailSubject() + " for " + cobDate + "  [" + subjectEnv + "]";

			final JavaMailSenderImpl sender = new JavaMailSenderImpl();
			sender.setHost("mailhub-vip.ny.ssmb.com");

			final MimeMessage message = sender.createMimeMessage();

			// use the true flag to indicate you need a multipart message
			final MimeMessageHelper helper = new MimeMessageHelper(message, true);
			helper.setTo(emailData.getConfigForm().getEmailTo());
			helper.setFrom("dl.gt.global.aqua.cba.build.team@imcnam.ssmb.com");
			if (null != emailData.getConfigForm().getEmailBCC()
					&& !("").equals(emailData.getConfigForm().getEmailBCC())) {
				helper.setBcc(emailData.getConfigForm().getEmailBCC());
			}
			if (null != emailData.getConfigForm().getEmailCC()
					&& !("").equals(emailData.getConfigForm().getEmailCC())) {
				helper.setCc(emailData.getConfigForm().getEmailCC());
			}
			helper.setSubject(emailSubject);
			BodyPart messageBodyPart = new MimeBodyPart();
			String contentId = commonUtility.generateContentId("UN");
			// Get the contents for the body
			String htmlText = userEmailTemplateUtility.formHtmlText(contentId, emailData);
			LOGGER.debug("The template is as for user mail ::" + htmlText);
			messageBodyPart.setContent(htmlText, "text/html; charset=ISO-8859-1");
			MimeMultipart multipart = new MimeMultipart("related");
			multipart.addBodyPart(messageBodyPart);
			// second part (the image)
			messageBodyPart = new MimeBodyPart();
			java.io.InputStream inputStream = this.getClass().getResourceAsStream("/Citi_Header.jpg");
			ByteArrayDataSource ds = new ByteArrayDataSource(inputStream, "image/jpg");
			messageBodyPart.setDataHandler(new DataHandler(ds));
			messageBodyPart.setHeader("Content-ID", "<" + contentId + ">");
			messageBodyPart.setDisposition(MimeBodyPart.INLINE);
			multipart.addBodyPart(messageBodyPart);
			message.setContent(multipart);
			sender.send(message);
			return true;
		} catch (Exception e) {
			LOGGER.debug("UserNotificationServiceImpl::sendUserNotificationMail()::Error::" + e, e);
			return false;
		}
	}

}
