package com.citi.aqua.cba.services.service.impl;

/**
 * @author ak92283
 */
import java.util.LinkedList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.citi.aqua.cba.data.mapper.cba.BatchAutomationMapper;
import com.citi.aqua.cba.model.FeedDelayData;
import com.citi.aqua.cba.services.service.BatchDelayService;

@Service("BatchDelayService")
public class BatchDelayServiceImpl implements BatchDelayService {

	private static final Logger LOGGER = LoggerFactory.getLogger(BatchDelayServiceImpl.class);

	@Autowired
	BatchAutomationMapper batchAutomationMapper;

	public List<String> getDelaySources() {
		LOGGER.debug("BatchDelayServiceImpl::getDelaySources()::starts");
		return batchAutomationMapper.getDelaySources();
	}

	public Boolean submitBatchDelay(final FeedDelayData delayData) throws Exception {
		LOGGER.debug("BatchDelayServiceImpl::submitBatchDelay()::starts");
		// Business login here
		Boolean flag = false;
		try {
			LOGGER.debug("FeedDelayServiceImpl::submitBatchDelay()::starts");
			// Business login here
			flag = batchAutomationMapper.insertFeedDelayData(delayData);
			Integer jobid = batchAutomationMapper.getJobId(delayData.getIssue());
			String eta = batchAutomationMapper.findEtaByMaxBatchDelayId();
			batchAutomationMapper.updateETAEntries();
			batchAutomationMapper.provideFeedDelayInfo(jobid, eta);
			batchAutomationMapper.updateDelayInformationForETA();
			LOGGER.debug("BatchDelayServiceImpl::feedDelayInfo()::ends");
		} catch (Exception e) {
			LOGGER.debug("BatchDelayServiceImpl::submitBatchDelay()::error" + e, e);
			throw e;
		}
		return flag;

	}

	public List<FeedDelayData> getDelayList() {
		LOGGER.debug("BatchDelayServiceImpl::getDelayList()::starts");
		List<FeedDelayData> feedDelayList = new LinkedList<>();
		try {
			feedDelayList = batchAutomationMapper.getDelayList();
		} catch (Exception e) {
			LOGGER.debug("BatchDelayServiceImpl::getDelayList()::error" + e, e);
			throw e;
		}
		return feedDelayList;

	}

	public List<FeedDelayData> getDelayList(final String cobdate) {
		LOGGER.debug("BatchDelayServiceImpl::getDelayList()::starts");
		List<FeedDelayData> feedDelayList = new LinkedList<>();
		try {
			if (null != cobdate) {
				feedDelayList = batchAutomationMapper.getDelayListForCobDate(cobdate);
			} else {
				String currentCobDate = batchAutomationMapper.getCOBDate();
				feedDelayList = batchAutomationMapper.getDelayListForCobDate(currentCobDate);
			}
		} catch (Exception e) {
			LOGGER.debug("BatchDelayServiceImpl::getDelayList()::error" + e, e);
			throw e;
		}
		return feedDelayList;
	}

}
