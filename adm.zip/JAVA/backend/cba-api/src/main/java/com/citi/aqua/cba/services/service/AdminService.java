package com.citi.aqua.cba.services.service;

import java.util.List;

import com.citi.aqua.cba.model.*;

/**
 * @author: aw11769
 * 
 */
public interface AdminService {

	public List<EWSUser> getEWSUsers();

	public EWSUser getEWSUser(String id);

	public List<UserCoverage> getUserCoverage(String id);

	public List<DropDownModel> getClientCoverageList();

	public void updateUserRole(String soeid, String role, String gpnum, int all_client, String updatedby);

	public void updateUserCoverage(String soeid, String gpnum, String updatedby);

	public List<UserHistory> getUserHistory(String soeid);

	//retrieve all records from admin table of admin app
	public List<Admin> getAdminList();

	//insert an admin into admin table
	public void insertAdmin(Admin admin);

	//delete admin from admin table
	public void deleteAdmin(String soeid, String entitlement);

	//edit admin from admin table
	public void editAdminPermission(Admin admin);
}
