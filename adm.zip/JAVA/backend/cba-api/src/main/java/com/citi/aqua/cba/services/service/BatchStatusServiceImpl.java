package com.citi.aqua.cba.services.service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.mail.internet.MimeMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;

import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.mail.javamail.JavaMailSenderImpl;

import com.citi.aqua.cba.data.mapper.cba.CBABatchStatusMapper;
import com.citi.aqua.cba.model.BatchStatusDetails;
import com.citi.aqua.cba.model.BatchStatusEmailData;

import freemarker.template.Configuration;
import freemarker.template.Template;

@Service("BatchDetailsService")
public class BatchStatusServiceImpl implements BatchStatusService {

	private static final Logger LOGGER = LoggerFactory.getLogger(BatchStatusServiceImpl.class);

	@Autowired
	private CBABatchStatusMapper cbaBatchStatusMapper;

	@Autowired
	private Configuration freemarkerConfig;

	@Override
	public List<BatchStatusDetails> getBatchStatusDetails(String cobDate) {
		LOGGER.debug("Retrieving all Records");
		return cbaBatchStatusMapper.getBatchStatusDetails(cobDate);
	}

	@Override
	public String getCOBDate(final String currentDate) {
		return cbaBatchStatusMapper.deriveCobDate(currentDate);
	}

	@Override
	public Boolean sendBatchEmail(final BatchStatusEmailData data) throws Exception {
		LOGGER.debug("BatchStatusServiceImpl::sendBatchEmail()::starts");
		try {
			// Get COB Date from service call
			String cobDate = getCOBDate(data.getCobDate());

			// You may want to use a subfolder such as /templates here
			freemarkerConfig.setClassForTemplateLoading(this.getClass(), "/template");

			final Map<String, Object> model = new HashMap<>();
			model.put("batchdata", data.getJobData());

			// create subject of the email
			final SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd");
			final Date tempdate = formatter.parse(cobDate);
			((SimpleDateFormat) formatter).applyPattern("MM/dd/yyyy");
			cobDate = formatter.format(tempdate);

			final String subject = "Daily Batch Status: " + cobDate.toString() + " - CBA";

			// create body of the email message
			final Template t = freemarkerConfig.getTemplate("batchstatusemail.ftl");
			final String text = FreeMarkerTemplateUtils.processTemplateIntoString(t, model);

			LOGGER.info("Template processed string:: " + text);

			final JavaMailSenderImpl sender = new JavaMailSenderImpl();
			sender.setHost("mailhub-vip.ny.ssmb.com");

			final MimeMessage message = sender.createMimeMessage();

			// use the true flag to indicate you need a multipart message
			final MimeMessageHelper helper = new MimeMessageHelper(message, true);
			helper.setTo(data.getConfigForm().getEmailTo());
			helper.setFrom("dl.gt.global.aqua.cba.build.team@imcnam.ssmb.com");
			if (null != data.getConfigForm().getEmailBCC() && !("").equals(data.getConfigForm().getEmailBCC())) {
				helper.setBcc(data.getConfigForm().getEmailBCC());
			}
			if (null != data.getConfigForm().getEmailCC() && !("").equals(data.getConfigForm().getEmailCC())) {
				helper.setCc(data.getConfigForm().getEmailCC());
			}
			helper.setSubject(subject);

			// use the true flag to indicate the text included is HTML
			helper.setText(text, true);

			sender.send(message);
			return true;
		} catch (Exception e) {
			LOGGER.debug("BatchStatusServiceImpl::sendBatchEmail()::Error::" + e, e);
			return false;
		}

	}
}
