package com.citi.aqua.cba.services.service;

import java.util.List;

import com.citi.aqua.cba.model.ArchiveDbForm;
import com.citi.aqua.cba.model.ArchiveFileForm;

public interface ArchiveService {

	public List<ArchiveFileForm> getArchiveFiles();

	public List<ArchiveDbForm> getArchiveDb();

	public Boolean updateArchiveFile(final ArchiveFileForm archiveFileForm);

	public Boolean updateArchiveDb(final ArchiveDbForm archiveDbForm);

	public void createArchiveDbRecord(final ArchiveDbForm archiveDbForm);

	public void createArchiveFileRecord(final ArchiveFileForm archiveFileForm);

}
