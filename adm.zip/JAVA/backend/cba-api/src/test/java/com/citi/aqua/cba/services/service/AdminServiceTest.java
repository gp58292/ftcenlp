package com.citi.aqua.cba.services.service;

import java.util.ArrayList;
import java.util.List;

import junit.framework.TestCase;

import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;

import com.citi.aqua.cba.model.DropDownModel;
import com.citi.aqua.cba.model.EWSUser;
import com.citi.aqua.cba.model.LoginStatusEnum;
import com.citi.aqua.cba.model.UserCoverage;
import com.citi.aqua.cba.model.UserHistory;

/**
 * @author gp58292
 *
 */
public class AdminServiceTest extends TestCase {

	private AdminService adminService;
	
	@Before
	public void setUp() throws Exception {
		adminService = EasyMock.mock(AdminService.class);
	}

	@Test
	public void testGetEWSUsers() throws Exception {
		List<EWSUser> results = new ArrayList<EWSUser>();
		EWSUser user = new EWSUser();
		user.setSoeid("df21521");
		user.setEmail("test@test.com");
		user.setStatus(LoginStatusEnum.CBA_200.getStatusMsg());
		user.setFriendly_name("Test Test");
		results.add(user);
		EasyMock.expect(adminService.getEWSUsers()).andReturn(results).times(2);
		EasyMock.replay(adminService);
		
		assertNotNull(adminService.getEWSUsers());
		assertEquals(true, adminService.getEWSUsers().contains(user));
	}
	
	@Test
	public void testGetUserCoverage() throws Exception {
		List<UserCoverage> userCoverageList = new ArrayList<UserCoverage>();
		UserCoverage userCoverage = new UserCoverage();
		userCoverage.setGpnum("12345");
		userCoverage.setSoeid("gp555");
		userCoverageList.add(userCoverage);
	
		adminService = EasyMock.mock(AdminService.class);
		EasyMock.expect(adminService.getUserCoverage("1234")).andReturn(userCoverageList).times(2);		
		EasyMock.replay(adminService);
		
		assertNotNull(adminService.getUserCoverage("1234"));
		assertEquals(true, adminService.getUserCoverage("1234").contains(userCoverage));
	}
	
	@Test
	public void testGetEWSUser() throws Exception {
		EWSUser user = new EWSUser();
		user.setSoeid("df21521");
		user.setEmail("test@test.com");
		user.setStatus(LoginStatusEnum.CBA_200.getStatusMsg());
		user.setFriendly_name("Test Test");
	
		adminService = EasyMock.mock(AdminService.class);
		EasyMock.expect(adminService.getEWSUser("1234")).andReturn(user).times(2);		
		EasyMock.replay(adminService);
		
		assertNotNull(adminService.getEWSUser("1234"));
		assertEquals(user, adminService.getEWSUser("1234"));
	}
	
	@Test
	public void testGetClientCoverageList()  throws Exception {
		List<DropDownModel> results = new ArrayList<DropDownModel>();
		DropDownModel dropDownModel = new DropDownModel();
		dropDownModel.setText("Test Test");
		dropDownModel.setValue("Value");
		results.add(dropDownModel);
		
		EasyMock.expect(adminService.getClientCoverageList()).andReturn(results);
		EasyMock.replay(adminService);
		
		List<DropDownModel> actual = adminService.getClientCoverageList();
		EasyMock.verify(adminService);
		assertEquals(true, actual.contains(dropDownModel));	
	}
	
	@Test
	public void testUpdateUserRole() throws Exception {
		adminService = EasyMock.mock(AdminService.class);
		adminService.updateUserRole("gp12345", "admin", "12345", 1, "gp");	
		EasyMock.replay(adminService);
	}

	@Test
	public void testUpdateUserCoverage() throws Exception {
		adminService = EasyMock.mock(AdminService.class);
		adminService.updateUserCoverage("gp12345", "12345", "gp");		
		EasyMock.replay(adminService);
	}

	@Test
	public void testGetUserHistory() throws Exception {
		List<UserHistory> results = new ArrayList<UserHistory>();
		UserHistory userHistory = new UserHistory();
		userHistory.setId(1234);
		userHistory.setSoeid("gp12345");
		results.add(userHistory);
		
		EasyMock.expect(adminService.getUserHistory("1234")).andReturn(results).times(2);
		EasyMock.replay(adminService);
		
		assertNotNull(adminService.getUserHistory("1234"));
		assertEquals(true, adminService.getUserHistory("1234").contains(userHistory));
	}

}
