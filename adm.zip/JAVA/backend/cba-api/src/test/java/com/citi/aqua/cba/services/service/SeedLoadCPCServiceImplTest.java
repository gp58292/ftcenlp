/*package com.citi.aqua.ews.services.service;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.citi.aqua.ews.data.mapper.ews.SeedLoadCPCMapper;
import com.citi.aqua.ews.model.SeedLoadCPC;


@RunWith(SpringJUnit4ClassRunner.class)
//@ContextConfiguration(loader = AnnotationConfigContextLoader.class,
//        classes = {     
//        		        SeedLoadCPCServiceImpl.class,
//		               	SeedLoadCPCService.class, 
//		                SeedLoadCPCMapper.class, 
//		                SeedLoadCPC.class 
//		                })
@PropertySource("classpath:application-test.properties")
@ContextConfiguration({ "classpath:application-context-datasource-ews-test.xml" })
public class SeedLoadCPCServiceImplTest {

	@Autowired
	SeedLoadCPCService seedLoadCPCService;

	@Test
	public void getSeedLoadCPC() {
		
		//prints out garbage but just to print how many records in the h2 table
		System.out.println(seedLoadCPCService.getSeedLoadCPC());
	}
	
	@Test
	public void insertSeedLoadCPC() {
		SeedLoadCPC seedLoadCPC = new SeedLoadCPC();
		seedLoadCPC.setCobDate(20160915);
		seedLoadCPC.setFlag("Y");
		seedLoadCPC.setLoadDate("'1998-01-01 23:59:59.990'");
		
		seedLoadCPCService.insertSeedLoadCPC(seedLoadCPC);
		//System.out.println(seedLoadCPCService.getSeedLoadCPC());
		
	}
	
	@Test
	public void findByFlag() {
		String flag = "n"; //case sensitive 
		System.out.println(seedLoadCPCService.findByFlag(flag));
	}

	@Test
	public void findByCobDate() {
		int cobDate = 20160922; //case sensitive 
		System.out.println(seedLoadCPCService.findByCobDate(cobDate));
	}

	@Test
	public void deleteByCobDate() {
	
		seedLoadCPCService.deleteByCobDate(20160926);		
		//System.out.println(seedLoadCPCService.getSeedLoadCPC());
	}
	
	
	@Test
	public void updateByCobDate() {
		
	}		
	
	
	
}

*/