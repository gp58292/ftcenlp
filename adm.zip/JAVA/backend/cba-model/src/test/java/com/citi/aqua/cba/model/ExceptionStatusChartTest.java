package com.citi.aqua.cba.model;

import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.Test;

public class ExceptionStatusChartTest {
	
	ExceptionStatusChart exceptionStatusChart;
	
	@Before
	public void setUp() throws Exception {
		exceptionStatusChart = new ExceptionStatusChart(); 

	}
	
	@Test
	public void getDate() {		
		String expected = "date";
		exceptionStatusChart.setDate(expected);
		assertEquals(expected, exceptionStatusChart.getDate());	
	}

	@Test
	public void getExceptions() {
		Integer expected =  new Integer(14);
		exceptionStatusChart.setExceptions(expected);
		assertEquals(expected, exceptionStatusChart.getExceptions());	

	}

	@Test
	public void getOpen() {
		Integer expected =  new Integer(14);
		exceptionStatusChart.setOpen(expected);
		assertEquals(expected, exceptionStatusChart.getOpen());	

	}

	@Test
	public void getReassigned() {
		Integer expected =  new Integer(14);
		exceptionStatusChart.setReassigned(expected);
		assertEquals(expected, exceptionStatusChart.getReassigned());	

	}

	@Test
	public void getResolved() {
		Integer expected =  new Integer(14);
		exceptionStatusChart.setResolved(expected);
		assertEquals(expected, exceptionStatusChart.getResolved());	

	}

	@Test
	public void getReview() {
		Integer expected =  new Integer(14);
		exceptionStatusChart.setReview(expected);
		assertEquals(expected, exceptionStatusChart.getReview());	

	}
}
