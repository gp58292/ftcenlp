package com.citi.aqua.cba.model;
import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.Test;


public class UserRoleTest {

	UserRole userRole;
	
	@Before
	public void setUp() throws Exception {
		userRole = new UserRole(); 

	}	
	
	@Test
	public void getRace_role() {
		String expected = "race role";
		userRole.setRace_role(expected);
		assertEquals(expected, userRole.getRace_role());
	}

	@Test
	public void getUser_role() {
		String expected = "user role";
		userRole.setUser_role(expected);
		assertEquals(expected, userRole.getUser_role());
		
	}

	@Test
	public void isAdd_admin() {
		boolean expected = true;
		userRole.setAdd_admin(expected);
		assertEquals(expected, userRole.isAdd_admin());
	}

	@Test
	public void isAll_client() {
		boolean expected = true;
		userRole.setAll_client(expected);
		assertEquals(expected, userRole.isAll_client());

	}

	@Test
	public void isManage_alert() {
		boolean expected = true;
		userRole.setManage_alert(expected);
		assertEquals(expected, userRole.isManage_alert());

	}

	@Test
	public void isManage_alert_rule() {
		boolean expected = true;
		userRole.setManage_alert_rule(expected);
		assertEquals(expected, userRole.isManage_alert_rule());

	}
}
