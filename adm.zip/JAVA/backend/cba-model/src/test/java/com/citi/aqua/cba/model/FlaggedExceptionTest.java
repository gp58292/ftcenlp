package com.citi.aqua.cba.model;

import static org.junit.Assert.assertEquals;

import java.util.Random;

import org.junit.Before;
import org.junit.Test;


public class FlaggedExceptionTest {
	
	FlaggedException flaggedException;
	
	@Before
	public void setUp() throws Exception {
		flaggedException = new FlaggedException(); 
	}
  
	@Test
	public void getAge() {
		long expected = 123L;
		flaggedException.setException_id(expected);
		assertEquals(expected, flaggedException.getException_id());

	}

	@Test
	public void getAggregation_level() {
		String expected ="Aggregation Level";
		flaggedException.setAggregation_level(expected);
		assertEquals(expected, flaggedException.getAggregation_level());

	}

	@Test
	public void getAggregation_level_name() {
		String expected ="Aggregation Level Name";
		flaggedException.setAggregation_level_name(expected);
		assertEquals(expected, flaggedException.getAggregation_level_name());

	}

	@Test
	public void getAttachements() {
		byte[] expected = new byte[20];
		new Random().nextBytes(expected);
		flaggedException.setAttachements(expected);
		assertEquals(expected,flaggedException.getAttachements());

	}

	@Test
	public void getClient() {
		String expected ="clients";
		flaggedException.setClient(expected);
		assertEquals(expected, flaggedException.getClient());

	}

	@Test
	public void getClient_fund() {
		String expected ="Client Fund";
		flaggedException.setClient_fund(expected);
		assertEquals(expected, flaggedException.getClient_fund());

	}

	@Test
	public void getCob_date() {
		String expected ="Cob date";
		flaggedException.setCob_date(expected);
		assertEquals(expected, flaggedException.getCob_date());

	}

	@Test
	public void getComment() {
		String expected ="comment";
		flaggedException.setComment(expected);
		assertEquals(expected, flaggedException.getComment());

	}

	@Test
	public void getCountry() {
		String expected ="Country";
		flaggedException.setCountry(expected);
		assertEquals(expected, flaggedException.getCountry());

	}

	@Test
	public void getCreate_time() {
		String expected ="Create Time";
		flaggedException.setCreate_time(expected);
		assertEquals(expected, flaggedException.getCreate_time());

	}

	@Test
	public void getCreate_user() {
	String expected ="Create User";
		flaggedException.setCreate_user(expected);
		assertEquals(expected, flaggedException.getCreate_user());

	}

	@Test
	public void getDelta() {
		String expected ="Delta";
		flaggedException.setDelta(expected);
		assertEquals(expected, flaggedException.getDelta());

	}

	@Test
	public void getDelta_percent() {
		String expected ="Delta Percent";
		flaggedException.setDelta_percent(expected);
		assertEquals(expected, flaggedException.getDelta_percent());

	}

	@Test
	public void getDescription() {
		String expected ="Description";
		flaggedException.setDescription(expected);
		assertEquals(expected, flaggedException.getDescription());

	}

	@Test
	public void getException_activity_id() {
		String expected ="Exception Activity id";
		flaggedException.setException_activity_id(expected);
		assertEquals(expected, flaggedException.getException_activity_id());

	}

	@Test
	public void getException_id() {
		long expected = 123456L;
		flaggedException.setException_id(expected);
		assertEquals(expected, flaggedException.getException_id());
	}

	@Test
	public void getException_owner() {
		String expected ="Exception Owner";
		flaggedException.setException_owner(expected);
		assertEquals(expected, flaggedException.getException_owner());

	}

	@Test
	public void getException_owner_name() {
		String expected ="Exception Owner name";
		flaggedException.setException_owner_name(expected);
		assertEquals(expected, flaggedException.getException_owner_name());

	}

	@Test
	public void getFile_name() {
		String expected ="FileName.txt";
		flaggedException.setFile_name(expected);
		assertEquals(expected, flaggedException.getFile_name());

	}

	@Test
	public void getFirst_date() {
		String expected ="First Date";
		flaggedException.setFirst_date(expected);
		assertEquals(expected, flaggedException.getFirst_date());

	}

	@Test
	public void getFirst_value() {
		String expected ="First Value";
		flaggedException.setFirst_value(expected);
		assertEquals(expected, flaggedException.getFirst_value());

	}

	@Test
	public void getFund() {
		String expected ="Fund";
		flaggedException.setFund(expected);
		assertEquals(expected, flaggedException.getFund());

	}

	@Test
	public void getIs_active() {
		String expected ="is active";
		flaggedException.setIs_active(expected);
		assertEquals(expected, flaggedException.getIs_active());

	}

	@Test
	public void getLegal_entity() {
		String expected ="Legal Entity";
		flaggedException.setLegal_entity(expected);
		assertEquals(expected, flaggedException.getLegal_entity());

	}

	@Test
	public void getLimit() {
		String expected ="limit";
		flaggedException.setLimit(expected);
		assertEquals(expected, flaggedException.getLimit());

	}

	@Test
	public void getLimit_type() {
		String expected ="limit type";
		flaggedException.setLimit_type(expected);
		assertEquals(expected, flaggedException.getLimit_type());

	}

	@Test
	public void getMeasure() {
		String expected ="Measure";
		flaggedException.setMeasure(expected);
		assertEquals(expected, flaggedException.getMeasure());

	}

	@Test
	public void getOpen_date() {
		String expected ="Open Date";
		flaggedException.setOpen_date(expected);
		assertEquals(expected, flaggedException.getOpen_date());

	}

	@Test
	public void getPriority() {
		String expected ="Priority";
		flaggedException.setPriority(expected);
		assertEquals(expected, flaggedException.getPriority());
	}

	@Test
	public void getPriority_id() {
		String expected ="Priority Id";
		flaggedException.setPriority_id(expected);
		assertEquals(expected, flaggedException.getPriority_id());

	}

	@Test
	public void getProduct() {
		String expected ="Product";
		flaggedException.setProduct(expected);
		assertEquals(expected, flaggedException.getProduct());

	}

	@Test
	public void getRegion() {
		String expected ="Region";
		flaggedException.setRegion(expected);
		assertEquals(expected, flaggedException.getRegion());

	}

	@Test
	public void getRule_group_id() {
		String expected ="Rule Group ID";
		flaggedException.setRule_group_id(expected);
		assertEquals(expected, flaggedException.getRule_group_id());

	}

	@Test
	public void getRule_id() {
		String expected ="Rule ID";
		flaggedException.setRule_id(expected);
		assertEquals(expected, flaggedException.getRule_id());

	}

	@Test
	public void getRule_period() {
		String expected ="Rule Period";
		flaggedException.setRule_period(expected);
		assertEquals(expected, flaggedException.getRule_period());

	}

	@Test
	public void getSecond_date() {
		String expected ="Second Date";
		flaggedException.setSecond_date(expected);
		assertEquals(expected, flaggedException.getSecond_date());

	}

	@Test
	public void getSecond_value() {
		String expected ="Second Value";
		flaggedException.setSecond_value(expected);
		assertEquals(expected, flaggedException.getSecond_value());

	}

	@Test
	public void getStatus() {
		String expected ="Status";
		flaggedException.setStatus(expected);
		assertEquals(expected, flaggedException.getStatus());
	}

	@Test
	public void getStatus_name() {
		String expected ="Status Name";
		flaggedException.setStatus_name(expected);
		assertEquals(expected, flaggedException.getStatus_name());

	}

	@Test
	public void getThreshold_type() {
		String expected ="Threshold Type";
		flaggedException.setThreshold_type(expected);
		assertEquals(expected, flaggedException.getThreshold_type());

	}

	@Test
	public void getType() {
		String expected ="type";
		flaggedException.setType(expected);
		assertEquals(expected, flaggedException.getType());

	}

	@Test
	public void getUpdatedby() {
		String expected ="Updated By";
		flaggedException.setUpdatedby(expected);
		assertEquals(expected, flaggedException.getUpdatedby());

	}

	@Test
	public void getVersion_id() {
		String expected ="Version ID";
		flaggedException.setVersion_id(expected);
		assertEquals(expected, flaggedException.getVersion_id());

	}
  
	@Test
	public void isIs_security() {
		boolean expected = true;
		flaggedException.setIs_security(expected);
		assertEquals(expected, flaggedException.isIs_security());

	}
}
