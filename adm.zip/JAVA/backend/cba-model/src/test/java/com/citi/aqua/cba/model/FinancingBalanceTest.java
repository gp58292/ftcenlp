package com.citi.aqua.cba.model;

import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.Test;

public class FinancingBalanceTest {

	FinancingBalance financingBalance;
	
	@Before
	public void setUp() throws Exception {
		financingBalance = new FinancingBalance(); 

	}
	
	@Test
	public void getClient() {
		String expected = "client";
		financingBalance.setClient(expected);
		assertEquals(expected, financingBalance.getClient());
	}

	@Test
	public void getCob_date() {
		String expected = "cob date";
		financingBalance.setCob_date(expected);
		assertEquals(expected, financingBalance.getCob_date());
	}

	@Test
	public void getCredit() {
		long expected = 123456L;
		financingBalance.setCredit(expected);
		assertEquals(expected, financingBalance.getCredit());

	}

	@Test
	public void getDebit() {
		long expected = 123456L;
		financingBalance.setDebit(expected);
		assertEquals(expected, financingBalance.getDebit());
		
	}

	@Test
	public void getFund() {
		String expected = "fund";
		financingBalance.setFund(expected);
		assertEquals(expected, financingBalance.getFund());

	}

	@Test
	public void getGFCID_fund() {
		String expected = "GFCID fund";
		financingBalance.setGFCID_fund(expected);
		assertEquals(expected, financingBalance.getGFCID_fund());

	}

	@Test
	public void getIndex_level() {
		long expected = 123456L;
		financingBalance.setIndex_level(expected);
		assertEquals(expected, financingBalance.getIndex_level());

	}

	@Test
	public void getOthers() {
		long expected = 123456L;
		financingBalance.setOthers(expected);
		assertEquals(expected, financingBalance.getOthers());

	}

	@Test
	public void getRegion() {
		String expected = "region";
		financingBalance.setRegion(expected);
		assertEquals(expected, financingBalance.getRegion());

	}

	@Test
	public void getShorts() {
		long expected = 123456L;
		financingBalance.setShorts(expected);
		assertEquals(expected, financingBalance.getShorts());

	}
}
