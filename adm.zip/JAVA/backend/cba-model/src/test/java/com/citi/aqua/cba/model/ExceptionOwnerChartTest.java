package com.citi.aqua.cba.model;

import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.Test;


public class ExceptionOwnerChartTest {
	
	ExceptionOwnerChart exceptionOwnerChart;
	
	@Before
	public void setUp() throws Exception {
		exceptionOwnerChart = new ExceptionOwnerChart(); 

	}
	
	@Test
	public void getClient() {
		String expected = "text";
		exceptionOwnerChart.setClient(expected);
		assertEquals(expected, exceptionOwnerChart.getClient());

	}

	@Test
	public void getOpen() {
		Integer expected = new Integer(10);
		exceptionOwnerChart.setOpen(expected);
		assertEquals(expected, exceptionOwnerChart.getOpen());
		
	}

	@Test
	public void getReassigned() {
		Integer expected = new Integer(10);
		exceptionOwnerChart.setReassigned(expected);
		assertEquals(expected, exceptionOwnerChart.getReassigned());

	}

	@Test
	public void getUnderreview() {
		Integer expected = new Integer(10);
		exceptionOwnerChart.setUnderreview(expected);
		assertEquals(expected, exceptionOwnerChart.getUnderreview());

	}
}
