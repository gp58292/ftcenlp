package com.citi.aqua.cba.model;

import org.junit.Before;


public class ExceptionRuleDescriptionTest {
 
	ExceptionRuleDescription exceptionRuleDescription;
	
	@Before
	public void setUp() throws Exception {
		exceptionRuleDescription = new ExceptionRuleDescription(); 

	}

}
