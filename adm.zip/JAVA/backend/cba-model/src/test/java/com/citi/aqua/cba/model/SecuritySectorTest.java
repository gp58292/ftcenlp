package com.citi.aqua.cba.model;
import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.Test;

public class SecuritySectorTest {
	
	SecuritySector securitySector;

	@Before
	public void setUp() throws Exception {
		securitySector = new SecuritySector(); 
	}
	
	@Test
	public void getCob_date() {
		String expected = "cob date";
		securitySector.setCob_date(expected);
		assertEquals(expected, securitySector.getCob_date());
	}

	@Test
	public void getConsumer_discretionary() {
		long expected = 123456L;
		securitySector.setConsumer_discretionary(expected);
		assertEquals(expected, securitySector.getConsumer_discretionary());
		
	}

	@Test
	public void getConsumer_staples() {
		long expected = 123456L;
		securitySector.setConsumer_staples(expected);
		assertEquals(expected, securitySector.getConsumer_staples());

	}

	@Test
	public void getEnergy() {
		long expected = 123456L;
		securitySector.setEnergy(expected);
		assertEquals(expected, securitySector.getEnergy());
	}

	@Test
	public void getFinancials() {
		long expected = 123456L;
		securitySector.setFinancials(expected);
		assertEquals(expected, securitySector.getFinancials());

	}

	@Test
	public void getHealth_care() {
		long expected = 123456L;
		securitySector.setHealth_care(expected);
		assertEquals(expected, securitySector.getHealth_care());

	}

	@Test
	public void getIndustrials() {
		long expected = 123456L;
		securitySector.setIndustrials(expected);
		assertEquals(expected, securitySector.getIndustrials());

	}

	@Test
	public void getInformation_technology() {
		long expected = 123456L;
		securitySector.setInformation_technology(expected);
		assertEquals(expected, securitySector.getInformation_technology());

	}

	@Test
	public void getMaterials() {
		long expected = 123456L;
		securitySector.setMaterials(expected);
		assertEquals(expected, securitySector.getMaterials());

	}

	@Test
	public void getOther() {
		long expected = 123456L;
		securitySector.setOther(expected);
		assertEquals(expected, securitySector.getOther());

	}

	@Test
	public void getTelecommunications() {
		long expected = 123456L;
		securitySector.setTelecommunications(expected);
		assertEquals(expected, securitySector.getTelecommunications());

	}

	@Test
	public void getUtilities() {
		long expected = 123456L;
		securitySector.setUtilities(expected);
		assertEquals(expected, securitySector.getUtilities());

	}
}
