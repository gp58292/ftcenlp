package com.citi.aqua.cba.model;
import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.Test;


public class UserHistoryTest {

	UserHistory userHistory;

	@Before
	public void setUp() throws Exception {
		userHistory = new UserHistory(); 
	}	
	
	@Test
	public void getCreated_by() {
		String expected = "created By";
		userHistory.setCreated_by(expected);
		assertEquals(expected, userHistory.getCreated_by());
	}

	@Test
	public void getCreated_time() {
		String expected = "created Time";
		userHistory.setCreated_time(expected);
		assertEquals(expected, userHistory.getCreated_time());
	}

	@Test
	public void getCreated_time_db() {
		String expected = "created time db";
		userHistory.setCreated_time_db(expected);
		assertEquals(expected, userHistory.getCreated_time_db());
	}

	@Test
	public void getDomain_name() {
		String expected = "Domain Name";
		userHistory.setDomain_name(expected);
		assertEquals(expected, userHistory.getDomain_name());
	}

	@Test
	public void getEmail() {
		String expected = "email";
		userHistory.setEmail(expected);
		assertEquals(expected, userHistory.getEmail());

	}

	@Test
	public void getFriendly_name() {
		String expected = "Friendly Name";
		userHistory.setFriendly_name(expected);
		assertEquals(expected, userHistory.getFriendly_name());
	}

	@Test
	public void getId() {
		int expected = 01;
		userHistory.setId(expected);
		assertEquals(expected, userHistory.getId());
	}

	@Test
	public void getManager_soeid() {
		String expected = "manager soeid";
		userHistory.setManager_soeid(expected);
		assertEquals(expected, userHistory.getManager_soeid());
	}

	@Test
	public void getOperation() {
		String expected = "operation";
		userHistory.setOperation(expected);
		assertEquals(expected, userHistory.getOperation());

	}

	@Test
	public void getRace_role() {
		String expected = "Race Role";
		userHistory.setRace_role(expected);
		assertEquals(expected, userHistory.getRace_role());
	}

	@Test
	public void getSoeid() {
		String expected = "soeid";
		userHistory.setSoeid(expected);
		assertEquals(expected, userHistory.getSoeid());

	}

	@Test
	public void getStatus() {
		String expected = "Status";
		userHistory.setStatus(expected);
		assertEquals(expected, userHistory.getStatus());

	}

	@Test
	public void getUser_role() {
		String expected = "user role";
		userHistory.setUser_role(expected);
		assertEquals(expected, userHistory.getUser_role());

	}
	@Test
	public void isAdd_admin() {
		boolean expected = true;
		userHistory.setAdd_admin(expected);
		assertEquals(expected, userHistory.isAdd_admin());

	}

	@Test
	public void isAll_client() {
		boolean expected = true;
		userHistory.setAll_client(expected);
		assertEquals(expected, userHistory.isAll_client());

	}

	@Test
	public void isManage_alert_rule() {
		boolean expected = true;
		userHistory.setManage_alert_rule(expected);
		assertEquals(expected, userHistory.isManage_alert_rule());

	}

	@Test
	public void isManage_coverage() {
		boolean expected = true;
		userHistory.setManage_coverage(expected);
		assertEquals(expected, userHistory.isManage_coverage());

	}

	@Test
	public void isManange_alert() {
		boolean expected = true;
		userHistory.setManange_alert(expected);
		assertEquals(expected, userHistory.isManange_alert());

	}
}
