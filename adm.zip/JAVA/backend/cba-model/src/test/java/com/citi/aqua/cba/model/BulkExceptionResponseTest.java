package com.citi.aqua.cba.model;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.assertEquals;
public class BulkExceptionResponseTest {
	BulkExceptionResponse bulkExceptionResponse;
	
	@Before
	public void beforeMethod() {
		bulkExceptionResponse = new BulkExceptionResponse();
	}
	
	@Test
	public void getComment() {
		String expected = "comment";
		bulkExceptionResponse.setComment(expected);
		assertEquals(expected,bulkExceptionResponse.getComment());

	}

	@Test
	public void getErrorMessage() {
		String expected = "errorMessage";
		bulkExceptionResponse.setErrorMessage(expected);
		assertEquals(expected,bulkExceptionResponse.getErrorMessage());

	}

	@Test
	public void getException_id() {
		int expected = 01;
		bulkExceptionResponse.setException_id(expected);
		assertEquals(expected,bulkExceptionResponse.getException_id());
	}
	
	@Test
	public void getException_owner() {
		String expected = "Exception Owner";
		bulkExceptionResponse.setException_owner(expected);
		assertEquals(expected,bulkExceptionResponse.getException_owner());


	}

	@Test
	public void getFile_name() {
		String expected = "errorMessage";
		bulkExceptionResponse.setErrorMessage(expected);
		assertEquals(expected,bulkExceptionResponse.getErrorMessage());
	
	}

	@Test
	public void getOperation_status() {
		String expected = "opStatus";
		bulkExceptionResponse.setOperation_status(expected);
		assertEquals(expected,bulkExceptionResponse.getOperation_status());


	}

	@Test
	public void getOperation_status_value() {
		int expected = 2;
		bulkExceptionResponse.setOperation_status_value(expected);
		assertEquals(expected,bulkExceptionResponse.getOperation_status_value());
		
	}

	@Test
	public void getStatus() {
		String expected = "status";
		bulkExceptionResponse.setStatus(expected);
		assertEquals(expected,bulkExceptionResponse.getStatus());

	}

	@Test
	public void getUpdatedby() {
		String expected = "updated By";
		bulkExceptionResponse.setUpdatedby(expected);
		assertEquals(expected,bulkExceptionResponse.getUpdatedby());
		
	}
	@Test
	public void isError() {
		boolean expected = true;
		bulkExceptionResponse.setError(expected);
		assertEquals(expected,bulkExceptionResponse.isError());
	
	}
}
