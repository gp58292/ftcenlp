package com.citi.aqua.cba.model;
import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.Test;



public class UserCoverageHistoryTest {

	UserCoverageHistory userCoverageHistory;
	
	@Before
	public void setUp() throws Exception {
		userCoverageHistory = new UserCoverageHistory(); 

	}	
  
	@Test
	public void getGp() {
		String expected = "Gp";
		userCoverageHistory.setGp(expected);
		assertEquals(expected, userCoverageHistory.getGp());

	}

	@Test
	public void getGpname() {
		String expected = "Gpname";
		userCoverageHistory.setGpname(expected);
		assertEquals(expected, userCoverageHistory.getGpname());

	}

	@Test
	public void getId() {
		int expected = 01;
		userCoverageHistory.setId(expected);
		assertEquals(expected, userCoverageHistory.getId());
	
	}

	@Test
	public void getOperation() {
		String expected = "operation";
		userCoverageHistory.setOperation(expected);
		assertEquals(expected, userCoverageHistory.getOperation());

	}

	@Test
	public void getSoeid() {
		String expected = "wq12345";
		userCoverageHistory.setSoeid(expected);
		assertEquals(expected, userCoverageHistory.getSoeid());


	}
}
