package com.citi.aqua.cba.model;

import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.Test;

public class FlagedSecurityExceptionRuleTest {

	FlagedSecurityExceptionRule flagedSecurityExceptionRule;
	
	@Before
	public void setUp() throws Exception {
		flagedSecurityExceptionRule = new FlagedSecurityExceptionRule(); 

	}	
	@Test
	public void getChange() {
		String expected = "Change";
		flagedSecurityExceptionRule.setChange(expected);
		assertEquals(expected, flagedSecurityExceptionRule.getChange());
	}

	@Test
	public void getChange_percent() {
		String expected = "Change percent";
		flagedSecurityExceptionRule.setChange_percent(expected);
		assertEquals(expected, flagedSecurityExceptionRule.getChange_percent());
	}

	@Test
	public void getComposition_percent() {
		String expected = "composition percent";
		flagedSecurityExceptionRule.setComposition_percent(expected);
		assertEquals(expected, flagedSecurityExceptionRule.getComposition_percent());

	}

	@Test
	public void getFirst_date() {
		String expected = "first date";
		flagedSecurityExceptionRule.setFirst_date(expected);
		assertEquals(expected, flagedSecurityExceptionRule.getFirst_date());
	}

	@Test
	public void getFirst_value() {
		String expected = "First Value";
		flagedSecurityExceptionRule.setFirst_value(expected);
		assertEquals(expected, flagedSecurityExceptionRule.getFirst_value());
	}

	@Test
	public void getSecond_date() {
		String expected = "Second Date";
		flagedSecurityExceptionRule.setSecond_date(expected);
		assertEquals(expected, flagedSecurityExceptionRule.getSecond_date());
	}

	@Test
	public void getSecond_value() {
		String expected = "Second Value";
		flagedSecurityExceptionRule.setSecond_value(expected);
		assertEquals(expected, flagedSecurityExceptionRule.getSecond_value());
	}

	@Test
	public void getSecurity_attribute() {
		String expected = "Security Attribute";
		flagedSecurityExceptionRule.setSecurity_attribute(expected);
		assertEquals(expected, flagedSecurityExceptionRule.getSecurity_attribute());
	}

	@Test
	public void getSecurity_type() {
		String expected = "Security type";
		flagedSecurityExceptionRule.setSecurity_type(expected);
		assertEquals(expected, flagedSecurityExceptionRule.getSecurity_type());
	}
	
	@Test
	public void isChange_row() {
		boolean expected = true;
		flagedSecurityExceptionRule.setChange_row(expected);
		assertEquals(expected, flagedSecurityExceptionRule.isChange_row());
	}
}
