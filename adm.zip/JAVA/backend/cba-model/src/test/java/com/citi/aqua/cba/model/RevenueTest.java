package com.citi.aqua.cba.model;

import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.Test;

public class RevenueTest {
	
	Revenue revenue;
	
	@Before
	public void setUp() throws Exception {
		revenue = new Revenue(); 
	}
	
	@Test
	public void getCash() {
		long expected = 123456L;
		revenue.setCash(expected);
		assertEquals(expected, revenue.getCash(),0);
	}

	@Test
	public void getCob_date() {
		String expected = "cob date";
		revenue.setCob_date(expected);
		assertEquals(expected, revenue.getCob_date());

	}

	@Test
	public void getFee() {
		long expected = 123456L;
		revenue.setFee(expected);
		assertEquals(expected, revenue.getFee(),0);

	}

	@Test
	public void getPnl() {
		long expected = 123456L;
		revenue.setPnl(expected);
		assertEquals(expected, revenue.getPnl(),0);

	}

	@Test
	public void getShorts() {
		long expected = 123456L;
		revenue.setShorts(expected);
		assertEquals(expected, revenue.getShorts(),0);

	}
}
