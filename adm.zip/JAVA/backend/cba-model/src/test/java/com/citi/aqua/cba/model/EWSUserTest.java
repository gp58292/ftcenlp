package com.citi.aqua.cba.model;

import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.Test;

public class EWSUserTest {

	EWSUser eWSUser;
	
	@Before
	public void setUp() throws Exception {
		eWSUser = new EWSUser(); 
	}
  
	@Test
	public void getDomain_name() {
		String expected = "domain Name";
		eWSUser.setDomain_name(expected);
		assertEquals(expected, eWSUser.getDomain_name());
		
	}

	@Test
	public void getEmail() {
		String expected = "abcd.asd@citi.com";
		eWSUser.setEmail(expected);
		assertEquals(expected, eWSUser.getEmail());
	}

	
	@Test
	public void getFriendly_name() {
		String expected = "Friendly Name";
		eWSUser.setFriendly_name(expected);
		assertEquals(expected, eWSUser.getFriendly_name());
	
	}

	@Test
	public void getId() {
		String expected = "ID";
		eWSUser.setId(expected);
		assertEquals(expected, eWSUser.getId());		

	}

	@Test
	public void getRace_role() {
		String expected = "Race role";
		eWSUser.setRace_role(expected);
		assertEquals(expected, eWSUser.getRace_role());
		
	}	

	@Test
	public void getSoeid() {
		String expected = "tm12345";
		eWSUser.setSoeid(expected);
		assertEquals(expected, eWSUser.getSoeid());
		
	}

	@Test
	public void getStatus() {
		String expected = "status";
		eWSUser.setStatus(expected);
		assertEquals(expected, eWSUser.getStatus());
		
	}

	@Test
	public void getUser_role() {
		String expected = "user Role";
		eWSUser.setUser_role(expected);
		assertEquals(expected, eWSUser.getUser_role());
			
	}
	
	@Test
	public void isAdd_admin() {  
		boolean expected = true;
		eWSUser.setAdd_admin(expected);
		assertEquals(expected, eWSUser.isAdd_admin());
	}

	@Test
	public void isAll_client() {
		boolean expected = true;
		eWSUser.setAll_client(expected);
		assertEquals(expected, eWSUser.isAll_client());

	}

	@Test
	public void isManage_alert() {
		boolean expected = true;
		eWSUser.setManage_alert(expected);
		assertEquals(expected, eWSUser.isManage_alert());
	}

	@Test
	public void isManage_alert_rule() {
		boolean expected = true;
		eWSUser.setManage_alert_rule(expected);
		assertEquals(expected, eWSUser.isManage_alert_rule());

	}

	@Test
	public void isManage_coverage() {
		boolean expected = true;
		eWSUser.setManage_coverage(expected);
		assertEquals(expected, eWSUser.isManage_coverage());

	}
}
