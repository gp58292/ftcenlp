package com.citi.aqua.cba.model;

import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.Test;
public class CBAAPIResponseTest {
	
	CBAAPIResponse cbaAPIResponse;
	
	@Before
	public void setUp() throws Exception {
		cbaAPIResponse = new CBAAPIResponse();

	}
	
	@Test
	public void getDescription() {
		String expected = "description";
		cbaAPIResponse.setDescription(expected);
		assertEquals(expected, cbaAPIResponse.getDescription());
	}
	
	@Test
	public void getMessage() {
		String expected = "Message";
		cbaAPIResponse.setMessage(expected);
		assertEquals(expected, cbaAPIResponse.getMessage());

	}
	@Test
	public void isStatus() {
		boolean expected = true;
		cbaAPIResponse.setStatus(expected);
		assertEquals(expected, cbaAPIResponse.isStatus());
    
  }
}
