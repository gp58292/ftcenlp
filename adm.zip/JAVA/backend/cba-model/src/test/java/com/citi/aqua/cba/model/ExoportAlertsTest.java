package com.citi.aqua.cba.model;
import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.Test;

public class ExoportAlertsTest {

	ExoportAlerts exoportAlerts;
	
	@Before
	public void setUp() throws Exception {
		exoportAlerts = new ExoportAlerts(); 

	}	
	@Test
	public void getAge() {
		double expected = 10.25;
		exoportAlerts.setAge(expected);
		assertEquals(expected, exoportAlerts.getAge(),0);

	}

	@Test
	public void getClient_fund() {
		String expected = "client fund";
		exoportAlerts.setClient_fund(expected);
		assertEquals(expected, exoportAlerts.getClient_fund());

	}

	@Test
	public void getCob_date() {
		String expected = "cob date";
		exoportAlerts.setCob_date(expected);
		assertEquals(expected, exoportAlerts.getCob_date());

	}
	
	@Test
	public void getDatatype() {
		String expected = "data type";
		exoportAlerts.setDatatype(expected);
		assertEquals(expected, exoportAlerts.getDatatype());

	}

	@Test
	public void getDelta() {
		double expected = 10.25;
		exoportAlerts.setDelta(expected);
		assertEquals(expected, exoportAlerts.getDelta(),0);

	}

	@Test
	public void getDelta_percent() {
		double expected = 10.25;
		exoportAlerts.setDelta_percent(expected);
		assertEquals(expected, exoportAlerts.getDelta_percent(),0);

	}

	@Test
	public void getException_id() {
		double expected = 10.25;
		exoportAlerts.setException_id(expected);
		assertEquals(expected, exoportAlerts.getException_id(),0);



	}

	@Test
	public void getException_owner_name() {
		String expected = "Exception Owner Name";
		exoportAlerts.setException_owner_name(expected);
		assertEquals(expected, exoportAlerts.getException_owner_name());

	}

	@Test
	public void getFirst_value() {
		double expected = 10.25;
		exoportAlerts.setFirst_value(expected);
		assertEquals(expected, exoportAlerts.getFirst_value(),0);

	}

	@Test
	public void getPriority() {
		String expected = "priority";
		exoportAlerts.setPriority(expected);
		assertEquals(expected, exoportAlerts.getPriority());

	}

	@Test
	public void getRegion() {
		String expected = "region";
		exoportAlerts.setRegion(expected);
		assertEquals(expected, exoportAlerts.getRegion());

	}

	@Test
	public void getRule_period() {
		String expected = "Rule Period";
		exoportAlerts.setRule_period(expected);
		assertEquals(expected, exoportAlerts.getRule_period());

	}

	@Test
	public void getSecond_value() {
		double expected = 10.25;
		exoportAlerts.setSecond_value(expected);
		assertEquals(expected, exoportAlerts.getSecond_value(),0);

	}

	@Test
	public void getStatus_name() {
		String expected = "status name";
		exoportAlerts.setStatus_name(expected);
		assertEquals(expected, exoportAlerts.getStatus_name());

	}

	@Test
	public void getThreshold() {
		String expected = "threshold";
		exoportAlerts.setThreshold(expected);
		assertEquals(expected, exoportAlerts.getThreshold());

	}
}
