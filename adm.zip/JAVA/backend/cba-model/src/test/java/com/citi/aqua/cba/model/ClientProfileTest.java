package com.citi.aqua.cba.model;

import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.Test;

public class ClientProfileTest {
	
	ClientProfile clientProfile;
	
	@Before
	public void setUp() throws Exception {
		 clientProfile = new ClientProfile(); 
	}
	
	@Test
	public void getId() {
		long expected = 12345L;
		clientProfile.setId(expected);
		assertEquals(expected,clientProfile.getId(),0);
		
	}

	@Test
	public void getName() {
		String expected = "Name";
		clientProfile.setName(expected);
		assertEquals(expected,clientProfile.getName());

	}
}
