package com.citi.aqua.cba.model;

import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.Test;

public class EquityBalanceTest {

	EquityBalance equityBalance;

	@Before
	public void setUp() throws Exception {
		equityBalance = new EquityBalance(); 
	}
	
	@Test
	public void getCash() {
		long expected = 13456L;
		equityBalance.setCash(expected);
		assertEquals(expected, equityBalance.getCash());
		
	}

	@Test
	public void getClient() {
		String expected = "client";
		equityBalance.setClient(expected);
		assertEquals(expected, equityBalance.getClient());

	}

	@Test
	public void getCob_date() {
		String expected = "cob date";
		equityBalance.setCob_date(expected);
		assertEquals(expected, equityBalance.getCob_date());

	}

	@Test
	public void getFund() {
		String expected = "fund";
		equityBalance.setFund(expected);
		assertEquals(expected, equityBalance.getFund());

	}

	@Test
	public void getGFCID_fund() {
		String expected = "GFCID fund";
		equityBalance.setGFCID_fund(expected);
		assertEquals(expected, equityBalance.getGFCID_fund());

	}

	@Test
	public void getIndex_level() {
		long expected = 13456L;
		equityBalance.setIndex_level(expected);
		assertEquals(expected, equityBalance.getIndex_level());

	}

	@Test
	public void getLmv() {
		long expected = 13456L;
		equityBalance.setLmv(expected);
		assertEquals(expected, equityBalance.getLmv());

	}

	@Test
	public void getNetequity() {
		long expected = 13456L;
		equityBalance.setNetequity(expected);
		assertEquals(expected, equityBalance.getNetequity());

	}

	@Test
	public void getRegion() {
		String expected = "region";
		equityBalance.setRegion(expected);
		assertEquals(expected, equityBalance.getRegion());

	}

	@Test
	public void getSmv() {
		long expected = 13456L;
		equityBalance.setSmv(expected);
		assertEquals(expected, equityBalance.getSmv());

	}

	@Test
	public void getTotalequity() {
		long expected = 13456L;
		equityBalance.setTotalequity(expected);
		assertEquals(expected, equityBalance.getTotalequity());

	}
}
