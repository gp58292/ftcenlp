package com.citi.aqua.cba.model;

import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.Test;

public class ExceptionMastersTest {
	
	ExceptionMasters exceptionMasters;
	
	@Before
	public void setUp() throws Exception {
		exceptionMasters = new ExceptionMasters(); 

	}
	
	@Test
	public void getText() {
		String expected = "text";
		exceptionMasters.setText(expected);
		assertEquals(expected, exceptionMasters.getText());

	}

	@Test
	public void getType() {
		String expected = "type";
		exceptionMasters.setType(expected);
		assertEquals(expected, exceptionMasters.getType());
	}

	@Test
	public void getValue() {
		String expected = "Value";
		exceptionMasters.setValue(expected);
		assertEquals(expected, exceptionMasters.getValue());

	}
}
