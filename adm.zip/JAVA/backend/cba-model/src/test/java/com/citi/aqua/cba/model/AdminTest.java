package com.citi.aqua.cba.model;

import org.junit.Before;
import org.junit.Test;


import static org.junit.Assert.assertEquals;

/**
 * Created by jm27909 on 8/3/2017.
 */
public class AdminTest {

    Admin admin;

    @Before
    public void beforeMethod() {
        admin = new Admin();
    }

    @Test
    public void getSoeid() {
        String expected = "jm27909";
        admin.setSoeid(expected);
        assertEquals(expected,admin.getSoeid());
    }
    @Test
    public void getFriendlyName() {
        String expected = "Mascarenhas,Justin";
        admin.setFriendly_name(expected);
        assertEquals(expected,admin.getFriendly_name());
    }
    @Test
    public void getAdmin() {
        Integer expected = 1;
        admin.setAdmin(expected);
        assertEquals(expected,admin.getAdmin());
    }
    @Test
    public void getCPCData() {
        Integer expected = 1;
        admin.setCpcdata(expected);
        assertEquals(expected,admin.getCpcdata());
    }
    @Test
    public void getBatchStatus() {
        Integer expected = 1;
        admin.setBatchstatus(expected);
        assertEquals(expected,admin.getBatchstatus());
    }
    @Test
    public void getAccessRequest() {
        Integer expected = 1;
        admin.setAccessrequest(expected);
        assertEquals(expected,admin.getAccessrequest());
    }
    @Test
    public void getDatalogging() {
        Integer expected = 1;
        admin.setDatalogging(expected);
        assertEquals(expected,admin.getDatalogging());
    }

    @Test
    public void getLastUpdateDate() {
        String expected = "2017-08-01 13:23:00.0";
        admin.setLastUpdateDate(expected);
        assertEquals(expected,admin.getLastUpdateDate());
    }

}
