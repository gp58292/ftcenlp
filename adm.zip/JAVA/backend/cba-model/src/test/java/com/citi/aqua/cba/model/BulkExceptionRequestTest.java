package com.citi.aqua.cba.model;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class BulkExceptionRequestTest {

	BulkExceptionRequest bulkExceptionRequest;
	
	@Before
	public void beforeMethod() {
		bulkExceptionRequest = new BulkExceptionRequest();
	}

	
	@Test
	public void getAlert_status() {
		String expected = "Alert_status";
		bulkExceptionRequest.setAlert_status(expected);
		assertEquals(expected,bulkExceptionRequest.getAlert_status());

	}

	@Test
	public void getComment() {
		String expected = "Comment";
		bulkExceptionRequest.setComment(expected);
		assertEquals(expected,bulkExceptionRequest.getComment());

	}

	@Test
	public void getException_id_list() {
		String expected = "ExceptionList";
		bulkExceptionRequest.setException_id_list(expected);
		assertEquals(expected,bulkExceptionRequest.getException_id_list());

	}

	@Test
	public void getException_ids() {
		String expected = "ExceptionIDs";
		bulkExceptionRequest.setException_ids(expected);
		assertEquals(expected,bulkExceptionRequest.getException_ids());

	}

	@Test
	public void getException_owner() {
		String expected = "ExceptionOwner";
		bulkExceptionRequest.setException_owner(expected);
		assertEquals(expected,bulkExceptionRequest.getException_owner());

	}

	@Test
	public void getFile_name() {
		String expected = "FileName.txt";
		bulkExceptionRequest.setFile_name(expected);
		assertEquals(expected,bulkExceptionRequest.getFile_name());

	}

	@Test
	public void getFile_object() {
		byte[] expected = new byte[20];
		new Random().nextBytes(expected);
		bulkExceptionRequest.setFile_object(expected);
		assertEquals(expected,bulkExceptionRequest.getFile_object());

	}

	@Test
	public void getSelectedExceptionIdList() {
		List<String> expectedExceptionIdList = new ArrayList<String>();
		expectedExceptionIdList.add("id1");
		expectedExceptionIdList.add("id2");
		expectedExceptionIdList.add("id3");
		expectedExceptionIdList.add("id4");
		bulkExceptionRequest.setSelectedExceptionIdList(expectedExceptionIdList);
		assertEquals(expectedExceptionIdList,bulkExceptionRequest.getSelectedExceptionIdList());
		
	}

	@Test
	public void getStatus() {
		String expected = "status";
		bulkExceptionRequest.setStatus(expected);
		assertEquals(expected,bulkExceptionRequest.getStatus());

	}

	@Test
	public void getUpdatedby() {
		String expected = "updateBy";
		bulkExceptionRequest.setUpdatedby(expected);
		assertEquals(expected,bulkExceptionRequest.getUpdatedby());

	}
}
