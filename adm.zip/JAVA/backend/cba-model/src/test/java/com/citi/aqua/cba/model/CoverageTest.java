package com.citi.aqua.cba.model;

import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.Test;
public class CoverageTest {

	Coverage coverage;
	
	@Before
	public void setUp() throws Exception {
		coverage = new Coverage(); 
	}
	
	@Test
	public void getClient() {
		String expected = "Client";
		coverage.setClient(expected);
		assertEquals(expected,coverage.getClient());

	}

	@Test
	public void getCoverage_client() {
		String expected = "coverage";
		coverage.setCoverage_client(expected);
		assertEquals(expected,coverage.getCoverage_client());
	}

	@Test
	public void getCoverage_region() {
		String expected = "coverage Region";
		coverage.setCoverage_region(expected);
		assertEquals(expected,coverage.getCoverage_region());

	}

	@Test
	public void getCoverage_subregion() {
		String expected = "coverage subregion";
		coverage.setCoverage_subregion(expected);
		assertEquals(expected,coverage.getCoverage_subregion());

	}

	@Test
	public void getCoverage_team() {
		String expected = "coverage team";
		coverage.setCoverage_team(expected);
		assertEquals(expected,coverage.getCoverage_team());

	}

	@Test
	public void getCoverer() {
		String expected = "Coverer";
		coverage.setCoverer(expected);
		assertEquals(expected, coverage.getCoverer());
		
	}

	@Test
	public void getGlobal_priority() {
		String expected = "global priority";
		coverage.setGlobal_priority(expected);
		assertEquals(expected, coverage.getGlobal_priority());
	}

	@Test
	public void getGpnum() {
		String expected = "Gpnum";
		coverage.setGpnum(expected);
		assertEquals(expected, coverage.getGpnum());

	}

	@Test
	public void getMarkets_platinum() {
		String expected = "markets platinum";
		coverage.setMarkets_platinum(expected);
		assertEquals(expected, coverage.getMarkets_platinum());

	}

	@Test
	public void getProduct() {
		String expected = "Products";
		coverage.setProduct(expected);
		assertEquals(expected, coverage.getProduct());

	}

	@Test
	public void getRoletype() {
		String expected = "Role type";
		coverage.setRoletype(expected);
		assertEquals(expected, coverage.getRoletype());

	}	

	@Test
	public void getSoeid() {
		String expected = "sd12345";
		coverage.setSoeid(expected);
		assertEquals(expected, coverage.getSoeid());

	}

	@Test
	public void getSource() {
		String expected = "source";
		coverage.setSource(expected);
		assertEquals(expected, coverage.getSource());

	}
}
