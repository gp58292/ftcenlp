package com.citi.aqua.cba.model;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.assertEquals;

public class AlertRulesTest {
	
	AlertRules alertRules;
	
	@Before
	public void beforeMethod() {
		alertRules = new AlertRules();
	}

	@Test
	public void getAlert_owner() {
		String expected = "testGetAlertOwner";
		alertRules.setAlert_owner(expected);
		assertEquals(expected,alertRules.getAlert_owner());
	}

	@Test
	public void getClient() {
		String expected = "getClient";
		alertRules.setClient(expected);
		assertEquals(expected,alertRules.getClient());
	}

	@Test
	public void getData_type() {
		String expected = "getDataType";
		alertRules.setData_type(expected);
		assertEquals(expected,alertRules.getData_type());
	}

	@Test
	public void getFund() {
		String expected = "getFund";
		alertRules.setFund(expected);
		assertEquals(expected,alertRules.getFund());
	}
  
	@Test
	public void getPriority() {
		String expected = "getPriority";
		alertRules.setPriority(expected);
		assertEquals(expected,alertRules.getPriority());  
	}

	@Test
	public void getRegion() {  
		String expected = "getRegion";
	    alertRules.setRegion(expected);
	    assertEquals(expected,alertRules.getRegion());

	}

	@Test
	public void getRule_group_id() {
		double expected = 10.05;
		alertRules.setRule_group_id(expected);
		assertEquals(expected,alertRules.getRule_group_id(),0);
	}

	@Test
	public void getRule_period() {
		String expected = "getRulePeriod";
	    alertRules.setRule_period(expected);
	    assertEquals(expected,alertRules.getRule_period());		
	}

	@Test
	public void getStatus() {
		String expected = "getStatus";
	    alertRules.setStatus(expected);
	    assertEquals(expected,alertRules.getStatus());
	}

	@Test
	public void getThreshold() {
		String expected = "getThreshold";
	    alertRules.setThreshold(expected);
	    assertEquals(expected,alertRules.getThreshold());
	}

	@Test
	public void getToday_open_alerts() {
		double expected = 12.34;
	    alertRules.setToday_open_alerts(expected);
	    assertEquals(expected,alertRules.getToday_open_alerts(),0);

	}

	@Test
	public void getTotal_open_alerts() {
		double expected = 13.34;
	    alertRules.setTotal_open_alerts(expected);
	    assertEquals(expected,alertRules.getTotal_open_alerts(),0);

	}

	@Test
	public void getType() {
		String expected = "getType";
	    alertRules.setType(expected);
	    assertEquals(expected,alertRules.getType());
	}

}
