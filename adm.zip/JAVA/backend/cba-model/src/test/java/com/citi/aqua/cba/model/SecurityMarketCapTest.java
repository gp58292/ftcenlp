package com.citi.aqua.cba.model;

import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.Test;

public class SecurityMarketCapTest {

	SecurityMarketCap securityMarketCap;
	
	@Before
	public void setUp() throws Exception {
		securityMarketCap = new SecurityMarketCap(); 
	}
	
	
	@Test
	public void getBigLarge() {
		long expected = 123456L;
		securityMarketCap.setBigLarge(expected);
		assertEquals(expected, securityMarketCap.getBigLarge());

	}

	@Test
	public void getCob_date() {
		String expected = "cob date";
		securityMarketCap.setCob_date(expected);
		assertEquals(expected, securityMarketCap.getCob_date());
	}

	@Test
	public void getMega() {
		long expected = 123456L;
		securityMarketCap.setMega(expected);
		assertEquals(expected, securityMarketCap.getMega());

	}

	@Test
	public void getMicro() {
		long expected = 123456L;
		securityMarketCap.setMicro(expected);
		assertEquals(expected, securityMarketCap.getMicro());
	}

	@Test
	public void getMid() {
		long expected = 123456L;
		securityMarketCap.setMid(expected);
		assertEquals(expected, securityMarketCap.getMid());
	}

	@Test
  	public void getNano() {
		long expected = 123456L;
		securityMarketCap.setNano(expected);
		assertEquals(expected, securityMarketCap.getNano());
	}
	
	@Test
	public void getOther() {
		long expected = 123456L;
		securityMarketCap.setOther(expected);
		assertEquals(expected, securityMarketCap.getOther());

	}

	@Test
	public void getSmall() {
		long expected = 123456L;
		securityMarketCap.setSmall(expected);
		assertEquals(expected, securityMarketCap.getSmall());

	}
}
