package com.citi.aqua.cba.model;

import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.Test;

public class MasterDataTest {

	
	MasterData masterData;
	
	@Before
	public void setUp() throws Exception {
		masterData = new MasterData(); 
	}	
	
	@Test
	public void getClient() {
		String expected = "client";
		masterData.setClient(expected);
		assertEquals(expected, masterData.getClient());
	}

	@Test
	public void getClient_id() {
		String expected = "client id";
		masterData.setClient_id(expected);
		assertEquals(expected, masterData.getClient_id());
	}

	@Test
	public void getEntity() {
		String expected = "entity";
		masterData.setEntity(expected);
		assertEquals(expected, masterData.getEntity());
	}

	@Test
	public void getEntity_id() {
		String expected = "entity id";
		masterData.setEntity_id(expected);
		assertEquals(expected, masterData.getEntity_id());
	}

	@Test
	public void getFund() {
		String expected = "fund";
		masterData.setFund(expected);
		assertEquals(expected, masterData.getFund());
	}

	@Test
	public void getFund_id() {
		String expected = "fund ID";
		masterData.setFund_id(expected);
		assertEquals(expected, masterData.getFund_id());

	}

	@Test
	public void getRegion() {
		String expected = "region";
		masterData.setRegion(expected);
		assertEquals(expected, masterData.getRegion());
	}

	@Test
	public void getRegion_id() {
		String expected = "region ID";
		masterData.setRegion_id(expected);
		assertEquals(expected, masterData.getRegion_id());


	}
}
