package com.citi.aqua.cba.model;
import static org.junit.Assert.assertEquals;

import java.util.Random;

import org.junit.Before;
import org.junit.Test;

public class UserFileTest {

	UserFile userFile;

	@Before
	public void setUp() throws Exception {
		userFile = new UserFile(); 

	}
	
	@Test
	public void getCreate_time() {
		String expected = "create time";
		userFile.setCreate_time(expected);
		assertEquals(expected, userFile.getCreate_time());
	}

	@Test
	public void getCreate_user() {
		String expected = "create user";
		userFile.setCreate_user(expected);
		assertEquals(expected, userFile.getCreate_user());
	}

	@Test
	public void getException_activity_id() {
		String expected = "exception activity id";
		userFile.setException_activity_id(expected);
		assertEquals(expected, userFile.getException_activity_id());
	}

	@Test
	public void getFile_id() {
		String expected = "fild id";
		userFile.setFile_id(expected);
		assertEquals(expected, userFile.getFile_id());
	}

	@Test
	public void getFile_name() {
		String expected = "fileName.txt";
		userFile.setFile_name(expected);
		assertEquals(expected, userFile.getFile_name());
	}

	@Test
	public void getFile_object() {
		byte[] expected = new byte[20];
		new Random().nextBytes(expected);
		userFile.setFile_object(expected);
		assertEquals(expected,userFile.getFile_object());

	}
}
