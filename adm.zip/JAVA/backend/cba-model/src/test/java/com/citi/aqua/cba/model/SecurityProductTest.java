package com.citi.aqua.cba.model;
 
import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.Test;


public class SecurityProductTest {

	SecurityProduct securityProduct;
	
	@Before
	public void setUp() throws Exception {
		securityProduct = new SecurityProduct(); 

	}
	
	@Test
	public void getCob_date() {
		String expected = "cob date";
		securityProduct.setCob_date(expected);
		assertEquals(expected, securityProduct.getCob_date());
	}

	@Test
	public void getConvertibles() {
		long expected = 123456L;
		securityProduct.setConvertibles(expected);
		assertEquals(expected, securityProduct.getConvertibles());
		
	}

	@Test
	public void getCorporates() {
		long expected = 123456L;
		securityProduct.setCorporates(expected);
		assertEquals(expected, securityProduct.getCorporates());

	}

	@Test
	public void getEquities() {
		long expected = 123456L;
		securityProduct.setEquities(expected);
		assertEquals(expected, securityProduct.getEquities());

	}

	@Test
	public void getOther() {
		long expected = 123456L;
		securityProduct.setOther(expected);
		assertEquals(expected, securityProduct.getOther());
	}

	@Test
	public void getPreferreds() {
		long expected = 123456L;
		securityProduct.setPreferreds(expected);
		assertEquals(expected, securityProduct.getPreferreds());

	}

	@Test
	public void getSovereigns() {
		long expected = 123456L;
		securityProduct.setSovereigns(expected);
		assertEquals(expected, securityProduct.getSovereigns());
	}

	@Test
	public void getWarrants() {
		long expected = 123456L;
		securityProduct.setWarrants(expected);
		assertEquals(expected, securityProduct.getWarrants());

	}
}
