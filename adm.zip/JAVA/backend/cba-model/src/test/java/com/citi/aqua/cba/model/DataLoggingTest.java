package com.citi.aqua.cba.model;

import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.Test;
public class DataLoggingTest {

	DataLogging dataLogging;
	
	@Before
	public void setUp() throws Exception {
		dataLogging = new DataLogging(); 
	}
	
	@Test
	public void getDatabaseName() {
		String expected = "CBA";
		dataLogging.setDatabaseName(expected);
		assertEquals(expected,dataLogging.getDatabaseName());

	}
	@Test
	public void getSchemaName() {
		String expected = "audit";
		dataLogging.setSchemaName(expected);
		assertEquals(expected,dataLogging.getSchemaName());

	}
	@Test
	public void getProcedureName() {
		String expected = "usp_data_logging";
		dataLogging.setProcedureName(expected);
		assertEquals(expected,dataLogging.getProcedureName());

	}
	@Test
	public void getStepName() {
		String expected = "[PARENT PROCEDURE STARTED EXECUTING]";
		dataLogging.setStepName(expected);
		assertEquals(expected,dataLogging.getStepName());

	}
	@Test
	public void getRecordCount() {
		int expected = 5;
		dataLogging.setRecordCount(expected);
		assertEquals(expected,dataLogging.getRecordCount());

	}
	@Test
	public void getLogTime() {
		String expected = "2017-05-05 15:06:25.777";
		dataLogging.setLogTime(expected);
		assertEquals(expected,dataLogging.getLogTime());

	}
	@Test
	public void getUserName() {
		String expected = "dbo";
		dataLogging.setUserName(expected);
		assertEquals(expected,dataLogging.getUserName());

	}
	@Test
	public void getErrorLine() {
		String expected = "67";
		dataLogging.setErrorLine(expected);
		assertEquals(expected,dataLogging.getErrorLine());

	}
	@Test
	public void getErrorMessage() {
		String expected = "test error message";
		dataLogging.setErrrorMessage(expected);
		assertEquals(expected,dataLogging.getErrrorMessage());

	}	
}
