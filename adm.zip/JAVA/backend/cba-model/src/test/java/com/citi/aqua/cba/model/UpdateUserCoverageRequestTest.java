package com.citi.aqua.cba.model;
import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.Test;

public class UpdateUserCoverageRequestTest {
	
	UpdateUserCoverageRequest updateUserCoverageRequest;
	
	@Before
	public void setUp() throws Exception {
		updateUserCoverageRequest = new UpdateUserCoverageRequest(); 
	}
  
	@Test
	public void getGpnum() {
		String expected = "Gpnum";
		updateUserCoverageRequest.setGpnum(expected);
		assertEquals(expected, updateUserCoverageRequest.getGpnum());
	}

	@Test
	public void getSoeid() {
		String expected = "hj12345";
		updateUserCoverageRequest.setSoeid(expected);
		assertEquals(expected, updateUserCoverageRequest.getSoeid());
	}

	@Test
	public void getUpdatedby() {
		String expected = "updated by";
		updateUserCoverageRequest.setUpdatedby(expected);
		assertEquals(expected, updateUserCoverageRequest.getUpdatedby());
	}
}
