package com.citi.aqua.cba.model;

import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.Test;
public class ChartFilterTest {

	ChartFilter chartFilter;
	
	@Before
	public void setUp() throws Exception {
		chartFilter = new ChartFilter(); 
	
	}

	@Test
	public void getClient() {		
		String expected = "client";
		chartFilter.setClient(expected);
		assertEquals(chartFilter.getClient(),expected);
	
	}

	@Test
	public void getCob_date() {
		long expected = 12345678L;
		chartFilter.setCob_date(expected);
		assertEquals(expected,chartFilter.getCob_date(),0);

	}

	@Test
	public void getFund() {
		String expected = "Fund";
		chartFilter.setFund(expected);
		assertEquals(expected,chartFilter.getFund());

	}

	@Test
	public void getRegion() {
		String expected = "region";
		chartFilter.setRegion(expected);
		assertEquals(expected,chartFilter.getRegion());

	}

	@Test
	public void getSoeid() {
		String expected = "gd12345";
		chartFilter.setSoeid(expected);
		assertEquals(expected,chartFilter.getSoeid());

	}

	@Test
	public void getType() {
		String expected = "type";
		chartFilter.setType(expected);
		assertEquals(expected,chartFilter.getType());

	}
}
