package com.citi.aqua.cba.model;
import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.Test;
public class DropDownModelTest {
	
	DropDownModel dropDownModel;
	
	@Before
	public void setUp() throws Exception {
		dropDownModel = new DropDownModel(); 
	}
	
	@Test
	public void getText() {
		String expected = "text";
		dropDownModel.setText(expected);
		assertEquals(expected, dropDownModel.getText());

	}

	@Test
	public void getValue() {
		String expected = "value";
		dropDownModel.setValue(expected);
		assertEquals(expected, dropDownModel.getValue());
	
	}

}
