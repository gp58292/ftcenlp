package com.citi.aqua.cba.model;

import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.Test;


public class ExceptionRuleTest {

	ExceptionRule exceptionRule;
	
	@Before
	public void setUp() throws Exception {
		exceptionRule = new ExceptionRule(); 

	}
	
	@Test
	public void getAggregation_level() {
		String expected = "aggregate level";
		exceptionRule.setAggregation_level(expected);
		assertEquals(expected, exceptionRule.getAggregation_level());

	}

	@Test
	public void getAggregation_level_name() {
		String expected = "aggregate level name";
		exceptionRule.setAggregation_level_name(expected);
		assertEquals(expected, exceptionRule.getAggregation_level_name());

	}

	@Test
	public void getAlert_assignee() {
		String expected = "alert assignee";
		exceptionRule.setAlert_assignee(expected);
		assertEquals(expected, exceptionRule.getAlert_assignee());
		
	}

	@Test
	public void getAlert_owner() {
		String expected = "alert owner";
		exceptionRule.setAlert_owner(expected);
		assertEquals(expected, exceptionRule.getAlert_owner());
	}

	@Test
	public void getClient() {
		String expected = "client";
		exceptionRule.setClient(expected);
		assertEquals(expected, exceptionRule.getClient());

	}

	@Test
	public void getClientName() {
		String expected = "client Name";
		exceptionRule.setClientName(expected);
		assertEquals(expected, exceptionRule.getClientName());

	}

	@Test
	public void getCreate_time() {
		String expected = "create time";
		exceptionRule.setCreate_time(expected);
		assertEquals(expected, exceptionRule.getCreate_time());
	}

	@Test
	public void getExceptionComments() {
		String expected = "Exception Comments";
		exceptionRule.setExceptionComments(expected);
		assertEquals(expected, exceptionRule.getExceptionComments());
		
	}

	@Test
	public void getExceptionPriority() {
		String expected = "Exception Priority";
		exceptionRule.setExceptionPriority(expected);
		assertEquals(expected, exceptionRule.getExceptionPriority());

	}

	@Test
	public void getExceptionPriorityName() {
		String expected = "Exception Priority Name";
		exceptionRule.setExceptionPriorityName(expected);
		assertEquals(expected, exceptionRule.getExceptionPriorityName());
	}

	@Test
	public void getExceptionRuleDataType() {
		String expected = "Exception Rule data type";
		exceptionRule.setExceptionRuleDataType(expected);
		assertEquals(expected, exceptionRule.getExceptionRuleDataType());

	}

	@Test
	public void getExceptionRuleDataTypeName() {
		String expected = "Exceptio Rule Data Type Name";
		exceptionRule.setExceptionRuleDataTypeName(expected);
		assertEquals(expected, exceptionRule.getExceptionRuleDataTypeName());

	}

	@Test
	public void getExceptionRuleId() {
		long expected = 1234456L;
		exceptionRule.setExceptionRuleId(expected);
		assertEquals(expected, exceptionRule.getExceptionRuleId(),0);
	}

	@Test
	public void getExceptionRuleLimitType() {
		String expected = "Exception Rule Limit Type";
		exceptionRule.setExceptionRuleLimitType(expected);
		assertEquals(expected, exceptionRule.getExceptionRuleLimitType());

	}

	@Test
	public void getExceptionRuleLimitTypeName() {
		String expected = "Exception Rule Limit Type Name";
		exceptionRule.setExceptionRuleLimitTypeName(expected);
		assertEquals(expected, exceptionRule.getExceptionRuleLimitTypeName());

	}

	@Test
	public void getExceptionRuleLimits() {
		String expected = "Exception Rule Limits";
		exceptionRule.setExceptionRuleLimits(expected);
		assertEquals(expected, exceptionRule.getExceptionRuleLimits());

	}

	@Test
	public void getExceptionRuleThresholdType() {
		String expected = "Exception Rule Threshold Type";
		exceptionRule.setExceptionRuleThresholdType(expected);
		assertEquals(expected, exceptionRule.getExceptionRuleThresholdType());

	}

	@Test
	public void getExceptionRuleThresholdTypeName() {
		String expected = "Exception Threshold type name";
		exceptionRule.setExceptionRuleThresholdTypeName(expected);
		assertEquals(expected, exceptionRule.getExceptionRuleThresholdTypeName());

	}

	@Test
	public void getExceptionRuleTimePeriod() {
		String expected = "Exception Rule Time Period";
		exceptionRule.setExceptionRuleTimePeriod(expected);
		assertEquals(expected, exceptionRule.getExceptionRuleTimePeriod());

	}

	@Test
	public void getExceptionRuleTimePeriodName() {
		String expected = "Exception Rule time period name";
		exceptionRule.setExceptionRuleTimePeriodName(expected);
		assertEquals(expected, exceptionRule.getExceptionRuleTimePeriodName());

	}

	@Test
	public void getExceptionRuleType() {
		String expected = "Exception Rule Type";
		exceptionRule.setExceptionRuleType(expected);
		assertEquals(expected, exceptionRule.getExceptionRuleType());

	}

	@Test
	public void getExceptionRuleTypeName() {
		String expected = "Exception Rule Type Name";
		exceptionRule.setExceptionRuleTypeName(expected);
		assertEquals(expected, exceptionRule.getExceptionRuleTypeName());

	}

	@Test
	public void getExceptionStatus() {
		String expected = "Exception Status";
		exceptionRule.setExceptionStatus(expected);
		assertEquals(expected, exceptionRule.getExceptionStatus());

	}

	@Test
	public void getExceptionStatusName() {
		String expected = "Exception Status Name";
		exceptionRule.setExceptionStatusName(expected);
		assertEquals(expected, exceptionRule.getExceptionStatusName());

	}

	@Test
	public void getFund() {
		String expected = "Fund";
		exceptionRule.setFund(expected);
		assertEquals(expected, exceptionRule.getFund());

	}

	@Test
	public void getFundName() {
	String expected = "Fund Name";
		exceptionRule.setFundName(expected);
		assertEquals(expected, exceptionRule.getFundName());

	}

	@Test
	public void getLegalEntity() {
		String expected = "legal entity";
		exceptionRule.setLegalEntity(expected);
		assertEquals(expected, exceptionRule.getLegalEntity());

	}

	@Test
	public void getLegalEntityName() {
		String expected = "Legal Entity Name";
		exceptionRule.setLegalEntityName(expected);
		assertEquals(expected, exceptionRule.getLegalEntityName());

	}

	@Test
	public void getRegion() {
		String expected = "region";
		exceptionRule.setRegion(expected);
		assertEquals(expected, exceptionRule.getRegion());

	}

	@Test
	public void getRegionName() {
		String expected = "Region Name";
		exceptionRule.setRegionName(expected);
		assertEquals(expected, exceptionRule.getRegionName());

	}

	@Test
	public void getRuleOwner() {
		String expected = "Rule Owner";
		exceptionRule.setRuleOwner(expected);
		assertEquals(expected, exceptionRule.getRuleOwner());

	}

	@Test
	public void getRule_group_id() {
		String expected = "Rule Group Id";
		exceptionRule.setRule_group_id(expected);
		assertEquals(expected, exceptionRule.getRule_group_id());

	}

	@Test
	public void getThreshold_dollar() {
		long expected = 1234456L;
		exceptionRule.setThreshold_dollar(expected);
		assertEquals(expected, exceptionRule.getThreshold_dollar(),0);
		
	}

	@Test
	public void getThreshold_dollar_mask() {
		String expected = "Threshold dollar mask";
		exceptionRule.setThreshold_dollar_mask(expected);
		assertEquals(expected, exceptionRule.getThreshold_dollar_mask());

	}

	@Test
	public void getThreshold_percent() {
		long expected = 1234456L;
		exceptionRule.setThreshold_percent(expected);
		assertEquals(expected, exceptionRule.getThreshold_percent(),0);

	}

	@Test
	public void getToday_open_alerts() {
		int expected = 1234456;
		exceptionRule.setToday_open_alerts(expected);
		assertEquals(expected, exceptionRule.getToday_open_alerts(),0);

	}

	@Test
	public void getTotal_open_alerts() {
		int expected = 1234456;
		exceptionRule.setTotal_open_alerts(expected);
		assertEquals(expected, exceptionRule.getTotal_open_alerts(),0);
				
	}

	@Test
	public void getUpdatedBy() {
		String expected = "Updated By";
		exceptionRule.setUpdatedBy(expected);
		assertEquals(expected, exceptionRule.getUpdatedBy());
		
	}

	@Test
	public void getVersion_id() {
		String expected = "Version ID";
		exceptionRule.setVersion_id(expected);
		assertEquals(expected, exceptionRule.getVersion_id());

	}
}
