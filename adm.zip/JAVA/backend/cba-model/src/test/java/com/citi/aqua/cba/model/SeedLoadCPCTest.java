package com.citi.aqua.cba.model;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.assertEquals;

public class SeedLoadCPCTest {

	SeedLoadCPC seedLoadCPC;
		
	@Before
	public void beforeMethod() {
		seedLoadCPC = new SeedLoadCPC();
	}

	@Test
	public void getCobDate() {
		String expected = "20160913";
		seedLoadCPC.setCobDate(expected);
		assertEquals(expected, seedLoadCPC.getCobDate());				
	}

	@Test
	public void getFlag() {
		String expected = "Y";
		seedLoadCPC.setFlag(expected);
		assertEquals(expected, seedLoadCPC.getFlag());
	}

	@Test
	public void getLoadDate() {
		String expected = "2017-03-17 11:58:00";
		seedLoadCPC.setLoadDate(expected);
		assertEquals(expected, seedLoadCPC.getLoadDate());
	}
	
	@Test
	public void getCreateUser() {
		String expected = "jm27909";
		seedLoadCPC.setLoadDate(expected);
		assertEquals(expected, seedLoadCPC.getLoadDate());
	}
	
	@Test
	public void getLastpdated() {
		String expected = "2017-03-17 11:58:00";
		seedLoadCPC.setLoadDate(expected);
		assertEquals(expected, seedLoadCPC.getLoadDate());
	}
	
	@Test
	public void getLastpdatedUser() {
		String expected = "jm27909";
		seedLoadCPC.setLoadDate(expected);
		assertEquals(expected, seedLoadCPC.getLoadDate());
	}


}
