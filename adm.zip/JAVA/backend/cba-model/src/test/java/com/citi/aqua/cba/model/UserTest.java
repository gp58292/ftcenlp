package com.citi.aqua.cba.model;
import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.Test;

public class UserTest {

	User user;
	
	@Before
	public void setUp() throws Exception {
		user = new User(); 
	}

	@Test
	public void getEmail() {
		String expected = "email";
		user.setEmail(expected);
		assertEquals(expected, user.getEmail());

		}

	@Test
	public void getName() {
		String expected = "name";
		user.setName(expected);
		assertEquals(expected, user.getName());

	}

	@Test
	public void getNewpassword() {
		String expected = "new password";
		user.setNewpassword(expected);
		assertEquals(expected, user.getNewpassword());

	}

	@Test
	public void getPassword() {
		String expected = "password";
		user.setPassword(expected);
		assertEquals(expected, user.getPassword());

	}

	@Test
	public void getSoeid() {
		String expected = "as12345";
		user.setSoeid(expected);
		assertEquals(expected, user.getSoeid());

	}

	@Test
	public void getSsoSessionID() {
		String expected = "SSO session ID";
		user.setSsoSessionID(expected);
		assertEquals(expected, user.getSsoSessionID());

	}

	@Test
	public void getStatusCode() {
		LoginStatusEnum expected = LoginStatusEnum.CBA_1000;
		user.setStatusCode(expected);
		assertEquals(expected, user.getStatusCode());	
	}

	@Test
	public void getStatusMessage() {
		String expected = "status message";
		user.setStatusMessage(expected);
		assertEquals(expected, user.getStatusMessage());

	}



	@Test
	public void isAuthenticated() {
		boolean expected = false;
		user.setAuthenticated(expected);
		assertEquals(expected, user.isAuthenticated());

	}

	@Test
	public void isAuthorized() {
		boolean expected = false;
		user.setIsAuthorized(expected);
		assertEquals(expected, user.getIsAuthorized());

	}
}
