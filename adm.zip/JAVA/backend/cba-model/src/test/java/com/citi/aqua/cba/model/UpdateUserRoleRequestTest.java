package com.citi.aqua.cba.model;
import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.Test;


public class UpdateUserRoleRequestTest {

	UpdateUserRoleRequest updateUserRoleRequest;
	
	@Before
	public void setUp() throws Exception {
		updateUserRoleRequest = new UpdateUserRoleRequest(); 
	}
	
	@Test
	public void getAll_client() {
		int expected = 10;
		updateUserRoleRequest.setAll_client(expected);
		assertEquals(expected, updateUserRoleRequest.getAll_client());		
	}

	@Test
	public void getGpnum() {
		String expected = "Gpnum";
		updateUserRoleRequest.setGpnum(expected);
		assertEquals(expected, updateUserRoleRequest.getGpnum());

	}

	@Test
	public void getRole() {
		String expected = "role";
		updateUserRoleRequest.setRole(expected);
		assertEquals(expected, updateUserRoleRequest.getRole());

	}

	@Test
	public void getSoeid() {
		String expected = "hj12345";
		updateUserRoleRequest.setSoeid(expected);
		assertEquals(expected, updateUserRoleRequest.getSoeid());

	}

	@Test
	public void getUpdatedby() {
		String expected = "updated by";
		updateUserRoleRequest.setUpdatedby(expected);
		assertEquals(expected, updateUserRoleRequest.getUpdatedby());

	}
}
