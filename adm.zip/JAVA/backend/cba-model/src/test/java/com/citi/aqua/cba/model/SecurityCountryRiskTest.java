package com.citi.aqua.cba.model;
import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.Test;

public class SecurityCountryRiskTest {

	SecurityCountryRisk securityCountryRisk;
	
	@Before
	public void setUp() throws Exception {
		securityCountryRisk = new SecurityCountryRisk(); 
	}	
	
	@Test
	public void getAPAC_Emerging_Markets_Lev1() {
		long expected = 123456L;
		securityCountryRisk.setAPAC_Emerging_Markets_Lev1(expected);
		assertEquals(expected,securityCountryRisk.getAPAC_Emerging_Markets_Lev1(),0);
				
	}

	@Test
	public void getAPAC_Emerging_Markets_Lev2() {
		long expected = 123456L;
		securityCountryRisk.setAPAC_Emerging_Markets_Lev2(expected);
		assertEquals(expected,securityCountryRisk.getAPAC_Emerging_Markets_Lev2(),0);

	}

	@Test
	public void getAPAC_Emerging_Markets_Lev3() {
		long expected = 123456L;
		securityCountryRisk.setAPAC_Emerging_Markets_Lev3(expected);
		assertEquals(expected,securityCountryRisk.getAPAC_Emerging_Markets_Lev3(),0);

	}

	@Test
	public void getCob_date() {
		String expected = "cob date";
		securityCountryRisk.setCob_date(expected);
		assertEquals(expected,securityCountryRisk.getCob_date());

	}

	@Test
	public void getDeveloped_Markets() {
		long expected = 123456L;
		securityCountryRisk.setDeveloped_Markets(expected);
		assertEquals(expected,securityCountryRisk.getDeveloped_Markets(),0);
	}

	@Test
	public void getEMEA_Emerging_Markets_Lev1B() {
		long expected = 123456L;
		securityCountryRisk.setEMEA_Emerging_Markets_Lev1B(expected);
		assertEquals(expected,securityCountryRisk.getEMEA_Emerging_Markets_Lev1B(),0);

	}		

	@Test
	public void getEMEA_Emerging_Markets_Lev2() {
		long expected = 123456L;
		securityCountryRisk.setEMEA_Emerging_Markets_Lev2(expected);
		assertEquals(expected,securityCountryRisk.getEMEA_Emerging_Markets_Lev2(),0);

	}

	@Test
	public void getLATAM_Emerging_Markets_Lev2() {
		long expected = 123456L;
		securityCountryRisk.setLATAM_Emerging_Markets_Lev2(expected);
		assertEquals(expected,securityCountryRisk.getLATAM_Emerging_Markets_Lev2(),0);

	}

	@Test
	public void getOther() {
		long expected = 123456L;
		securityCountryRisk.setOther(expected);
		assertEquals(expected,securityCountryRisk.getOther(),0);

	}
}
