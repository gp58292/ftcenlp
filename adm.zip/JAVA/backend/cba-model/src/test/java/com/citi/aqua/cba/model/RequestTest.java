package com.citi.aqua.cba.model;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
 * Created by jm27909 on 8/3/2017.
 */
public class RequestTest {

    Request request;

    @Before
    public void beforeMethod() {
        request = new Request();
    }


    @Test
    public void getId() {
        int expected = 1;
        request.setId(expected);
        assertEquals(expected,request.getId());
    }
    @Test
    public void getSoeid() {
        String expected = "jm27909";
        request.setSoeid(expected);
        assertEquals(expected,request.getSoeid());
    }
    @Test
    public void getUsername() {
        String expected = "Mascarenhas, Justin";
        request.setUserName(expected);
        assertEquals(expected,request.getUserName());
    }
    @Test
    public void getRequestBy() {
        String expected = "Mascarenhas, Justin";
        request.setRequestedBy(expected);
        assertEquals(expected,request.getRequestedBy());
    }
    @Test
    public void getStatus() {
        String expected = "Completed";
        request.setStatus(expected);
        assertEquals(expected,request.getStatus());
    }
    @Test
    public void getSecurityModel() {
        String expected = "MKTPlace Order";
        request.setSecurityModel(expected);
        assertEquals(expected,request.getSecurityModel());
    }
    @Test
    public void getSecurityModelStatus() {
        String expected = "2";
        request.setSecurityModelStatus(expected);
        assertEquals(expected,request.getSecurityModelStatus());
    }
    @Test
    public void getComments() {
        String expected = "Test Comment";
        request.setComments(expected);
        assertEquals(expected,request.getComments());
    }
}
