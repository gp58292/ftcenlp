package com.citi.aqua.cba.model;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.assertEquals;

public class BalanceROATest {

	BalanceROA balanceROA;
	
	@Before
	public void beforeMethod() {

		balanceROA = new BalanceROA(); 
	}

	@Test
	public void getBalance_sheet() {
		long expected = 12345678910L;
		balanceROA.setBalance_sheet(expected);
		assertEquals(expected,balanceROA.getBalance_sheet(),0);
	}

	@Test
	public void getCob_date() {
		String expected = "getCOB";
		balanceROA.setCob_date(expected);
		assertEquals(expected,balanceROA.getCob_date());
	}

	@Test
	public void getPnl() {
		long expected = 12345678910L;
		balanceROA.setPnl(expected);
		assertEquals(expected,balanceROA.getPnl(),0);
	}

	@Test
	public void getRoa() {
		double expected =  10.35;
		balanceROA.setRoa(expected);
		assertEquals(expected,balanceROA.getRoa(),0);
	}

	@Test
	public void getWithout_seclending_balsheet() {
		long expected = 12345678910L;
		balanceROA.setWithout_seclending_balsheet(expected);
		assertEquals(expected,balanceROA.getWithout_seclending_balsheet(),0);		
	}
}
