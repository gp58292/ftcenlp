package com.citi.aqua.cba.model;
import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.Test;



public class UserCoverageTest {

	UserCoverage userCoverage;
	
	@Before
	public void setUp() throws Exception {
		userCoverage = new UserCoverage(); 
	}
  
	@Test
	public void getGpname() {
		String expected = "Gpname";
		userCoverage.setGpname(expected);
		assertEquals(expected, userCoverage.getGpname());

	}

	@Test
	public void getGpnum() {
		String expected = "Gpnum";
		userCoverage.setGpnum(expected);
		assertEquals(expected, userCoverage.getGpnum());
	}

	@Test
	public void getSoeid() {
		String expected = "qw12345";
		userCoverage.setSoeid(expected);
		assertEquals(expected, userCoverage.getSoeid());

	}

	@Test
	public void getSource() {
		String expected = "Source";
		userCoverage.setSource(expected);
		assertEquals(expected, userCoverage.getSource());

	}
}
