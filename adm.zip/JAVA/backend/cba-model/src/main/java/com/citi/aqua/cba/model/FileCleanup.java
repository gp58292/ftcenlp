package com.citi.aqua.cba.model;

/**
 * Created by jm27909 on 8/14/2017.
 */
public class FileCleanup {
}
