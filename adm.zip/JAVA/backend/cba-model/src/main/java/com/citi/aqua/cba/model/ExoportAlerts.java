package com.citi.aqua.cba.model;

public class ExoportAlerts {

	private double exception_id;
	private String cob_date;
	private String priority;
	private double age;
	private String status_name;
	private String client_fund;
	private String region;
	private String datatype;
	private String rule_period;
	private String threshold;
	private double first_value;
	private double second_value;
	private double delta;
	private double delta_percent;
	private String exception_owner_name;

	public String getThreshold() {
		return threshold;
	}

	public void setThreshold(String threshold) {
		this.threshold = threshold;
	}

	public double getException_id() {
		return exception_id;
	}

	public void setException_id(double exception_id) {
		this.exception_id = exception_id;
	}

	public String getCob_date() {
		return cob_date;
	}

	public void setCob_date(String cob_date) {
		this.cob_date = cob_date;
	}

	public String getPriority() {
		return priority;
	}

	public void setPriority(String priority) {
		this.priority = priority;
	}

	public double getAge() {
		return age;
	}

	public void setAge(double age) {
		this.age = age;
	}

	public String getStatus_name() {
		return status_name;
	}

	public void setStatus_name(String status_name) {
		this.status_name = status_name;
	}

	public String getClient_fund() {
		return client_fund;
	}

	public void setClient_fund(String client_fund) {
		this.client_fund = client_fund;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getDatatype() {
		return datatype;
	}

	public void setDatatype(String datatype) {
		this.datatype = datatype;
	}

	public String getRule_period() {
		return rule_period;
	}

	public void setRule_period(String rule_period) {
		this.rule_period = rule_period;
	}

	public double getFirst_value() {
		return first_value;
	}

	public void setFirst_value(double first_value) {
		this.first_value = first_value;
	}

	public double getSecond_value() {
		return second_value;
	}

	public void setSecond_value(double second_value) {
		this.second_value = second_value;
	}

	public double getDelta() {
		return delta;
	}

	public void setDelta(double delta) {
		this.delta = delta;
	}

	public double getDelta_percent() {
		return delta_percent;
	}

	public void setDelta_percent(double delta_percent) {
		this.delta_percent = delta_percent;
	}

	public String getException_owner_name() {
		return exception_owner_name;
	}

	public void setException_owner_name(String exception_owner_name) {
		this.exception_owner_name = exception_owner_name;
	}

}
