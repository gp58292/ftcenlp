package com.citi.aqua.cba.model;

/**
 * Created by jm27909 on 6/29/2017.
 */
public class UserRoleAdmin {
    private String race_role;
    private String cpcDataEntitlements;
    private String dataLoggingEntitlements;
    private String adminEntitlements;
    private int readPermission;
    private int writePermission;

    public String getRace_role() {
        return race_role;
    }

    public void setRace_role(String race_role) {
        this.race_role = race_role;
    }

    public String getCpcDataEntitlements() {
        return cpcDataEntitlements;
    }

    public void setCpcDataEntitlements(String cpcDataEntitlements) {
        this.cpcDataEntitlements = cpcDataEntitlements;
    }

    public String getDataLoggingEntitlements() {
        return dataLoggingEntitlements;
    }

    public void setDataLoggingEntitlements(String dataLoggingEntitlements) {
        this.dataLoggingEntitlements = dataLoggingEntitlements;
    }

    public String getAdminEntitlements() {
        return adminEntitlements;
    }

    public void setAdminEntitlements(String adminEntitlements) {
        this.adminEntitlements = adminEntitlements;
    }

    public int getReadPermission() {
        return readPermission;
    }

    public void setReadPermission(int readPermission) {
        this.readPermission = readPermission;
    }

    public int getWritePermission() {
        return writePermission;
    }

    public void setWritePermission(int writePermission) {
        this.writePermission = writePermission;
    }


}
