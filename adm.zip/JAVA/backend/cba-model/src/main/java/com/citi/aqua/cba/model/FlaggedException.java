package com.citi.aqua.cba.model;

import java.io.Serializable;
import java.util.Arrays;

public class FlaggedException implements Serializable {

	private static final long serialVersionUID = -6280152207444456512L;
	private String rule_id;
	private String rule_group_id;
	private String exception_activity_id;
	private long exception_id;
	private String version_id;
	private String type;
	private String priority;
	private String priority_id;
	private String legal_entity;
	private String client;
	private String region;
	private String fund;
	private String country;
	private String product;
	private String rule_period;
	private String aggregation_level;
	private String aggregation_level_name;
	private String description;
	private String measure;
	private String limit_type;
	private String limit;
	private String is_active;
	private String threshold_type;
	private String create_user;
	private String create_time;
	private String cob_date;
	private String open_date;
	private String status;
	private String status_name;
	private long age;
	private String comment;
	private String file_name;
	private byte[] attachements;
	private String exception_owner;
	private String updatedby;
	private String first_date;
	private String first_value;
	private String second_date;
	private String second_value;
	private String delta;
	private String delta_percent;
	private String exception_owner_name;
	private String client_fund;
	private boolean is_security;

	public String getUpdatedby() {
		return updatedby;
	}

	public void setUpdatedby(String updatedby) {
		this.updatedby = updatedby;
	}

	public String getException_owner_name() {
		return exception_owner_name;
	}

	public void setException_owner_name(String exception_owner_name) {
		this.exception_owner_name = exception_owner_name;
	}

	public String getRule_id() {
		return rule_id;
	}

	public void setRule_id(String rule_id) {
		this.rule_id = rule_id;
	}

	public String getRule_group_id() {
		return rule_group_id;
	}

	public void setRule_group_id(String rule_group_id) {
		this.rule_group_id = rule_group_id;
	}

	public String getException_owner() {
		return exception_owner;
	}

	public void setException_owner(String exception_owner) {
		this.exception_owner = exception_owner;
	}

	public String getException_activity_id() {
		return exception_activity_id;
	}

	public void setException_activity_id(String exception_activity_id) {
		this.exception_activity_id = exception_activity_id;
	}

	public long getException_id() {
		return exception_id;
	}

	public void setException_id(long exception_id) {
		this.exception_id = exception_id;
	}

	public String getVersion_id() {
		return version_id;
	}

	public void setVersion_id(String version_id) {
		this.version_id = version_id;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getPriority() {
		return priority;
	}

	public void setPriority(String priority) {
		this.priority = priority;
	}

	public String getClient_fund() {
		return client_fund;
	}

	public void setClient_fund(String client_fund) {
		this.client_fund = client_fund;
	}

	public String getPriority_id() {
		return priority_id;
	}

	public void setPriority_id(String priority_id) {
		this.priority_id = priority_id;
	}

	public String getLegal_entity() {
		return legal_entity;
	}

	public void setLegal_entity(String legal_entity) {
		this.legal_entity = legal_entity;
	}

	public String getClient() {
		return client;
	}

	public void setClient(String client) {
		this.client = client;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getFund() {
		return fund;
	}

	public void setFund(String fund) {
		this.fund = fund;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getProduct() {
		return product;
	}

	public void setProduct(String product) {
		this.product = product;
	}

	public String getRule_period() {
		return rule_period;
	}

	public void setRule_period(String rule_period) {
		this.rule_period = rule_period;
	}

	public String getAggregation_level() {
		return aggregation_level;
	}

	public void setAggregation_level(String aggregation_level) {
		this.aggregation_level = aggregation_level;
	}

	public String getAggregation_level_name() {
		return aggregation_level_name;
	}

	public void setAggregation_level_name(String aggregation_level_name) {
		this.aggregation_level_name = aggregation_level_name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getMeasure() {
		return measure;
	}

	public void setMeasure(String measure) {
		this.measure = measure;
	}

	public String getLimit_type() {
		return limit_type;
	}

	public void setLimit_type(String limit_type) {
		this.limit_type = limit_type;
	}

	public String getLimit() {
		return limit;
	}

	public void setLimit(String limit) {
		this.limit = limit;
	}

	public String getIs_active() {
		return is_active;
	}

	public void setIs_active(String is_active) {
		this.is_active = is_active;
	}

	public String getThreshold_type() {
		return threshold_type;
	}

	public void setThreshold_type(String threshold_type) {
		this.threshold_type = threshold_type;
	}

	public String getCreate_user() {
		return create_user;
	}

	public void setCreate_user(String create_user) {
		this.create_user = create_user;
	}

	public String getCreate_time() {
		return create_time;
	}

	public void setCreate_time(String create_time) {
		this.create_time = create_time;
	}

	public String getCob_date() {
		return cob_date;
	}

	public void setCob_date(String cob_date) {
		this.cob_date = cob_date;
	}

	public String getOpen_date() {
		return open_date;
	}

	public void setOpen_date(String open_date) {
		this.open_date = open_date;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getStatus_name() {
		return status_name;
	}

	public void setStatus_name(String status_name) {
		this.status_name = status_name;
	}

	public long getAge() {
		return age;
	}

	public void setAge(long age) {
		this.age = age;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public String getFile_name() {
		return file_name;
	}

	public void setFile_name(String file_name) {
		this.file_name = file_name;
	}

	public byte[] getAttachements() {
		return attachements;
	}

	public void setAttachements(byte[] attachements) {
		this.attachements = attachements;
	}

	public String getFirst_date() {
		return first_date;
	}

	public void setFirst_date(String first_date) {
		this.first_date = first_date;
	}

	public String getFirst_value() {
		return first_value;
	}

	public void setFirst_value(String first_value) {
		this.first_value = first_value;
	}

	public String getSecond_date() {
		return second_date;
	}

	public void setSecond_date(String second_date) {
		this.second_date = second_date;
	}

	public String getSecond_value() {
		return second_value;
	}

	public void setSecond_value(String second_value) {
		this.second_value = second_value;
	}

	public String getDelta() {
		return delta;
	}

	public void setDelta(String delta) {
		this.delta = delta;
	}

	public String getDelta_percent() {
		return delta_percent;
	}

	public void setDelta_percent(String delta_percent) {
		this.delta_percent = delta_percent;
	}

	public boolean isIs_security() {
		return is_security;
	}

	public void setIs_security(boolean is_security) {
		this.is_security = is_security;
	}
	
	@Override
	public String toString() {
		return "FlaggedException [rule_id=" + rule_id + ", rule_group_id="
				+ rule_group_id + ", exception_activity_id="
				+ exception_activity_id + ", exception_id=" + exception_id
				+ ", version_id=" + version_id + ", type=" + type
				+ ", priority=" + priority + ", legal_entity=" + legal_entity
				+ ", client=" + client + ", region=" + region + ", fund="
				+ fund + ", country=" + country + ", product=" + product
				+ ", rule_period=" + rule_period + ", aggregation_level="
				+ aggregation_level + ", aggregation_level_name="
				+ aggregation_level_name + ", description=" + description
				+ ", measure=" + measure + ", limit_type=" + limit_type
				+ ", limit=" + limit + ", is_active=" + is_active
				+ ", threshold_type=" + threshold_type + ", create_user="
				+ create_user + ", create_time=" + create_time + ", cob_date="
				+ cob_date + ", open_date=" + open_date + ", status=" + status
				+ ", status_name=" + status_name + ", age=" + age
				+ ", comment=" + comment + ", file_name=" + file_name
				+ ", attachements=" + Arrays.toString(attachements)
				+ ", exception_owner=" + exception_owner + ", updatedby="
				+ updatedby + ", first_date=" + first_date + ", first_value="
				+ first_value + ", second_date=" + second_date
				+ ", second_value=" + second_value + ", delta=" + delta
				+ ", delta_percent=" + delta_percent
				+ ", exception_owner_name=" + exception_owner_name
				+ ", is_security=" + is_security + "]";
	}

}
