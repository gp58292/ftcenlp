package com.citi.aqua.cba.model;
/**
 * @author: jm27909
 *
 * 
 */
public class Admin {

	private String soeid;
	private String friendly_name;
	private String lastUpdateDate;
    private Integer admin;
	private Integer cpcdata;
	private Integer datalogging;
    private Integer accessrequest;
    private Integer batchstatus;


    public String getSoeid() {
		return soeid;
	}

	public void setSoeid(String soeid) {
		this.soeid = soeid;
	}

	public String getFriendly_name() {
		return friendly_name;
	}

	public void setFriendly_name(String friendly_name) {
		this.friendly_name = friendly_name;
	}


    public String getLastUpdateDate() {
        return lastUpdateDate;
    }

    public void setLastUpdateDate(String lastUpdateDate) {
        this.lastUpdateDate = lastUpdateDate;
    }

    public Integer getAdmin() {
        return admin;
    }

    public void setAdmin(Integer admin) {
        this.admin = admin;
    }

    public Integer getCpcdata() {
        return cpcdata;
    }

    public void setCpcdata(Integer cpcdata) {
        this.cpcdata = cpcdata;
    }

    public Integer getDatalogging() {
        return datalogging;
    }

    public void setDatalogging(Integer datalogging) {
        this.datalogging = datalogging;
    }


    public Integer getAccessrequest() {
        return accessrequest;
    }

    public void setAccessrequest(Integer accessrequest) {
        this.accessrequest = accessrequest;
    }

    public Integer getBatchstatus() {
        return batchstatus;
    }

    public void setBatchstatus(Integer batchstatus) {
        this.batchstatus = batchstatus;
    }


}
