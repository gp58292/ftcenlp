package com.citi.aqua.cba.model;

/**
 * @author ak92283
 */
import java.io.Serializable;

public class FeedDelayData implements Serializable {

	private static final long serialVersionUID = 1L;

	private Long batch_delay_id;
	private String area_impacted;
	private String eta_resolution;
	private String inc_mim;
	private String issue;
	private String source_issue;
	private String description;
	private String next_update;
	private String cobdate;


	/**
	 * @return the batch_delay_id
	 */
	public Long getBatch_delay_id() {
		return batch_delay_id;
	}

	/**
	 * @param batch_delay_id
	 *            the batch_delay_id to set
	 */
	public void setBatch_delay_id(Long batch_delay_id) {
		this.batch_delay_id = batch_delay_id;
	}

	/**
	 * @return the eta_resolution
	 */
	public String getEta_resolution() {
		return eta_resolution;
	}

	/**
	 * @param eta_resolution
	 *            the eta_resolution to set
	 */
	public void setEta_resolution(String eta_resolution) {
		this.eta_resolution = eta_resolution;
	}

	/**
	 * @return the mim
	 */
	public String getInc_mim() {
		return inc_mim;
	}

	/**
	 * @param mim
	 *            the mim to set
	 */
	public void setInc_mim(String inc_mim) {
		this.inc_mim = inc_mim;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description
	 *            the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the area_impacted
	 */
	public String getArea_impacted() {
		return area_impacted;
	}

	/**
	 * @param area_impacted
	 *            the area_impacted to set
	 */
	public void setArea_impacted(String area_impacted) {
		this.area_impacted = area_impacted;
	}

	/**
	 * @return the issue
	 */
	public String getIssue() {
		return issue;
	}

	/**
	 * @param issue
	 *            the issue to set
	 */
	public void setIssue(String issue) {
		this.issue = issue;
	}

	/**
	 * @return the next_update
	 */
	public String getNext_update() {
		return next_update;
	}

	/**
	 * @param next_update
	 *            the next_update to set
	 */
	public void setNext_update(String next_update) {
		this.next_update = next_update;
	}

	/**
	 * @return the cobdate
	 */
	public String getCobdate() {
		return cobdate;
	}

	/**
	 * @param cobdate
	 *            the cobdate to set
	 */
	public void setCobdate(String cobdate) {
		this.cobdate = cobdate;
	}

	public String getSource_issue() {
		return source_issue;
	}

	public void setSource_issue(String source_issue) {
		this.source_issue = source_issue;
	}


}
