package com.citi.aqua.cba.model;

import java.io.Serializable;

public class EquityBalance implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String cob_date;
	private String GFCID_fund;
	private String client;
	private String fund;
	private String region;
	private long cash;
	private long lmv;
	private long smv;
	private long netequity;
	private long totalequity;
	private long index_level;

	public String getCob_date() {
		return cob_date;
	}

	public void setCob_date(String cob_date) {
		this.cob_date = cob_date;
	}

	public String getGFCID_fund() {
		return GFCID_fund;
	}

	public void setGFCID_fund(String gFCID_fund) {
		GFCID_fund = gFCID_fund;
	}

	public String getClient() {
		return client;
	}

	public void setClient(String client) {
		this.client = client;
	}

	public String getFund() {
		return fund;
	}

	public void setFund(String fund) {
		this.fund = fund;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public long getCash() {
		return cash;
	}

	public void setCash(long cash) {
		this.cash = cash;
	}

	public long getLmv() {
		return lmv;
	}

	public void setLmv(long lmv) {
		this.lmv = lmv;
	}

	public long getSmv() {
		return smv;
	}

	public void setSmv(long smv) {
		this.smv = smv;
	}

	public long getNetequity() {
		return netequity;
	}

	public void setNetequity(long netequity) {
		this.netequity = netequity;
	}

	public long getTotalequity() {
		return totalequity;
	}

	public void setTotalequity(long totalequity) {
		this.totalequity = totalequity;
	}

	public long getIndex_level() {
		return index_level;
	}

	public void setIndex_level(long index_level) {
		this.index_level = index_level;
	}

}
