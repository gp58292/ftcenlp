package com.citi.aqua.cba.model;

import java.util.Arrays;
import java.util.List;

/**
 * @author gp58292
 *
 */

public class BulkExceptionRequest {

	private String exception_ids;
	private String exception_id_list;
	private String status;
	private String alert_status;
	private String comment;
	private String exception_owner;
	private List<String> selectedExceptionIdList;
	private String updatedby;
	private String file_name;
	private byte[] file_object;

	public String getException_ids() {
		return exception_ids;
	}

	public void setException_ids(String exception_ids) {
		this.exception_ids = exception_ids;
	}

	public String getException_id_list() {
		return exception_id_list;
	}

	public void setException_id_list(String exception_id_list) {
		this.exception_id_list = exception_id_list;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getAlert_status() {
		return alert_status;
	}

	public void setAlert_status(String alert_status) {
		this.alert_status = alert_status;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public String getException_owner() {
		return exception_owner;
	}

	public void setException_owner(String exception_owner) {
		this.exception_owner = exception_owner;
	}

	public List<String> getSelectedExceptionIdList() {
		return selectedExceptionIdList;
	}

	public void setSelectedExceptionIdList(List<String> selectedExceptionIdList) {
		this.selectedExceptionIdList = selectedExceptionIdList;
	}

	public String getUpdatedby() {
		return updatedby;
	}

	public void setUpdatedby(String updatedby) {
		this.updatedby = updatedby;
	}

	public String getFile_name() {
		return file_name;
	}

	public void setFile_name(String file_name) {
		this.file_name = file_name;
	}

	public byte[] getFile_object() {
		return file_object;
	}

	public void setFile_object(byte[] file_object) {
		this.file_object = file_object;
	}

	@Override
	public String toString() {
		return "BulkExceptionRequest [exception_ids=" + exception_ids
				+ ", exception_id_list=" + exception_id_list + ", status="
				+ status + ", comment=" + comment + ", exception_owner="
				+ exception_owner + ", selectedExceptionIdList="
				+ selectedExceptionIdList + ", updatedby=" + updatedby
				+ ", file_name=" + file_name + ", file_object="
				+ Arrays.toString(file_object) + "]";
	}

}
