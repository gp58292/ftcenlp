package com.citi.aqua.cba.model;

import java.io.Serializable;

public class Revenue implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String cob_date;
	private Long pnl;
	private Long cash;
	private Long shorts;
	private Long fee;

	public String getCob_date() {
		return cob_date;
	}

	public void setCob_date(String cob_date) {
		this.cob_date = cob_date;
	}

	public Long getPnl() {
		return pnl;
	}

	public void setPnl(Long pnl) {
		this.pnl = pnl;
	}

	public Long getCash() {
		return cash;
	}

	public void setCash(Long cash) {
		this.cash = cash;
	}

	public Long getShorts() {
		return shorts;
	}

	public void setShorts(Long shorts) {
		this.shorts = shorts;
	}

	public Long getFee() {
		return fee;
	}

	public void setFee(Long fee) {
		this.fee = fee;
	}

}
