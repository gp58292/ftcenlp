package com.citi.aqua.cba.model;

import java.io.Serializable;

/**
 * 
 * @author ak92283
 *
 */
public class BatchEmailConfigForm implements Serializable {

	private static final long serialVersionUID = 1L;
	private String emailTo;
	private String emailFrom;
	private String emailCC;
	private String emailBCC;
	private String emailSubject;
	private String emailUpdate;
	private String notificationType;

	/**
	 * @return the emailTo
	 */
	public String getEmailTo() {
		return emailTo;
	}

	/**
	 * @param emailTo
	 *            the emailTo to set
	 */
	public void setEmailTo(String emailTo) {
		this.emailTo = emailTo;
	}

	/**
	 * @return the emailFrom
	 */
	public String getEmailFrom() {
		return emailFrom;
	}

	/**
	 * @param emailFrom
	 *            the emailFrom to set
	 */
	public void setEmailFrom(String emailFrom) {
		this.emailFrom = emailFrom;
	}

	/**
	 * @return the emailCC
	 */
	public String getEmailCC() {
		return emailCC;
	}

	/**
	 * @param emailCC
	 *            the emailCC to set
	 */
	public void setEmailCC(String emailCC) {
		this.emailCC = emailCC;
	}

	/**
	 * @return the emailBCC
	 */
	public String getEmailBCC() {
		return emailBCC;
	}

	/**
	 * @param emailBCC
	 *            the emailBCC to set
	 */
	public void setEmailBCC(String emailBCC) {
		this.emailBCC = emailBCC;
	}

	/**
	 * @return the emailsubject
	 */
	public String getEmailSubject() {
		return emailSubject;
	}

	/**
	 * @param emailsubject
	 *            the emailsubject to set
	 */
	public void setEmailSubject(String emailSubject) {
		this.emailSubject = emailSubject;
	}

	/**
	 * @return the emailUpdate
	 */
	public String getEmailUpdate() {
		return emailUpdate;
	}

	/**
	 * @param emailUpdate
	 *            the emailUpdate to set
	 */
	public void setEmailUpdate(String emailUpdate) {
		this.emailUpdate = emailUpdate;
	}

	/**
	 * @return the notificationType
	 */
	public String getNotificationType() {
		return notificationType;
	}

	/**
	 * @param notificationType
	 *            the notificationType to set
	 */
	public void setNotificationType(String notificationType) {
		this.notificationType = notificationType;
	}

}
