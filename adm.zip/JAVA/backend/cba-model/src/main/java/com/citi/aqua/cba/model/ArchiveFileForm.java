/**
 * 
 */
package com.citi.aqua.cba.model;

import java.io.Serializable;

/**
 * @author ak92283
 *
 */
public class ArchiveFileForm implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public Long id;
	public String dateFormat;
	public Integer dateSearchParameter;
	public String fileNamePattern;
	public String sourcePath;
	public String archivePath;
	public String purgePath;
	public Integer archiveFlag;
	public Integer archiveDays;
	public Integer deleteFlag;
	public Integer deleteDays;
	public String archive_ExclusionRule;
	public String purging_ExclusionRule;
	public String readyFilePattern;

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the dateFormat
	 */
	public String getDateFormat() {
		return dateFormat;
	}

	/**
	 * @param dateFormat
	 *            the dateFormat to set
	 */
	public void setDateFormat(String dateFormat) {
		this.dateFormat = dateFormat;
	}

	/**
	 * @return the dateSearchParameter
	 */
	public Integer getDateSearchParameter() {
		return dateSearchParameter;
	}

	/**
	 * @param dateSearchParameter
	 *            the dateSearchParameter to set
	 */
	public void setDateSearchParameter(Integer dateSearchParameter) {
		this.dateSearchParameter = dateSearchParameter;
	}

	/**
	 * @return the fileNamePattern
	 */
	public String getFileNamePattern() {
		return fileNamePattern;
	}

	/**
	 * @param fileNamePattern
	 *            the fileNamePattern to set
	 */
	public void setFileNamePattern(String fileNamePattern) {
		this.fileNamePattern = fileNamePattern;
	}

	/**
	 * @return the sourcePath
	 */
	public String getSourcePath() {
		return sourcePath;
	}

	/**
	 * @param sourcePath
	 *            the sourcePath to set
	 */
	public void setSourcePath(String sourcePath) {
		this.sourcePath = sourcePath;
	}

	/**
	 * @return the archivePath
	 */
	public String getArchivePath() {
		return archivePath;
	}

	/**
	 * @param archivePath
	 *            the archivePath to set
	 */
	public void setArchivePath(String archivePath) {
		this.archivePath = archivePath;
	}

	/**
	 * @return the purgePath
	 */
	public String getPurgePath() {
		return purgePath;
	}

	/**
	 * @param purgePath
	 *            the purgePath to set
	 */
	public void setPurgePath(String purgePath) {
		this.purgePath = purgePath;
	}

	/**
	 * @return the archiveFlag
	 */
	public Integer getArchiveFlag() {
		return archiveFlag;
	}

	/**
	 * @param archiveFlag
	 *            the archiveFlag to set
	 */
	public void setArchiveFlag(Integer archiveFlag) {
		this.archiveFlag = archiveFlag;
	}

	/**
	 * @return the archiveDays
	 */
	public Integer getArchiveDays() {
		return archiveDays;
	}

	/**
	 * @param archiveDays
	 *            the archiveDays to set
	 */
	public void setArchiveDays(Integer archiveDays) {
		this.archiveDays = archiveDays;
	}

	/**
	 * @return the deleteFlag
	 */
	public Integer getDeleteFlag() {
		return deleteFlag;
	}

	/**
	 * @param deleteFlag
	 *            the deleteFlag to set
	 */
	public void setDeleteFlag(Integer deleteFlag) {
		this.deleteFlag = deleteFlag;
	}

	/**
	 * @return the deleteDays
	 */
	public Integer getDeleteDays() {
		return deleteDays;
	}

	/**
	 * @param deleteDays
	 *            the deleteDays to set
	 */
	public void setDeleteDays(Integer deleteDays) {
		this.deleteDays = deleteDays;
	}

	/**
	 * @return the archive_ExclusionRule
	 */
	public String getArchive_ExclusionRule() {
		return archive_ExclusionRule;
	}

	/**
	 * @param archive_ExclusionRule
	 *            the archive_ExclusionRule to set
	 */
	public void setArchive_ExclusionRule(String archive_ExclusionRule) {
		this.archive_ExclusionRule = archive_ExclusionRule;
	}

	/**
	 * @return the purging_ExclusionRule
	 */
	public String getPurging_ExclusionRule() {
		return purging_ExclusionRule;
	}

	/**
	 * @param purging_ExclusionRule
	 *            the purging_ExclusionRule to set
	 */
	public void setPurging_ExclusionRule(String purging_ExclusionRule) {
		this.purging_ExclusionRule = purging_ExclusionRule;
	}

	/**
	 * @return the readyFilePattern
	 */
	public String getReadyFilePattern() {
		return readyFilePattern;
	}

	/**
	 * @param readyFilePattern
	 *            the readyFilePattern to set
	 */
	public void setReadyFilePattern(String readyFilePattern) {
		this.readyFilePattern = readyFilePattern;
	}

}