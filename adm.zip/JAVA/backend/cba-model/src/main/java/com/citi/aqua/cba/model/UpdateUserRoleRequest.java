package com.citi.aqua.cba.model;

public class UpdateUserRoleRequest {

	private String soeid;
	private String role;
	private String gpnum;
	private int all_client;
	private String updatedby;

	public String getSoeid() {
		return soeid;
	}

	public void setSoeid(String soeid) {
		this.soeid = soeid;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getGpnum() {
		return gpnum;
	}

	public void setGpnum(String gpnum) {
		this.gpnum = gpnum;
	}

	public String getUpdatedby() {
		return updatedby;
	}

	public void setUpdatedby(String updatedby) {
		this.updatedby = updatedby;
	}

	public int getAll_client() {
		return all_client;
	}

	public void setAll_client(int all_client) {
		this.all_client = all_client;
	}

}
