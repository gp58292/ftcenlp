package com.citi.aqua.cba.model;

public class ExceptionRuleDescription {

}
