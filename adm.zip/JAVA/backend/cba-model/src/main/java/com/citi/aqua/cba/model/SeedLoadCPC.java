package com.citi.aqua.cba.model;
/**
 * @author: jm27909
 *
 * 
 */
import java.io.Serializable;

public class SeedLoadCPC implements Serializable {
	
	private static final long serialVersionUID = 1L;
	private String cobDate;
	private String createUser;
	private String flag;
	private String loadDate;
	private String lastUpdated;
	private String lastUpdatedUser;
	
	public static long getSerialVersionUID() {
		return serialVersionUID;
	}

	public String getCobDate() {
		return cobDate;
	}

	public void setCobDate(String cobDate) {
		this.cobDate = cobDate;
	}
	
	public String getCreateUser() {
		return createUser;
	}

	public void setCreateUser(String createUser) {
		this.createUser = createUser;
	}

	public String getFlag() {
		return flag;
	}

	public void setFlag(String flag) {
		this.flag = flag;
	}

	public String getLoadDate() {
		return loadDate;
	}

	public void setLoadDate(String loadDate) {
		this.loadDate = loadDate;
	}
	
	public String getLastUpdated() {
		return lastUpdated;
	}

	public void setLastUpdated(String lastUpdated) {
		this.lastUpdated = lastUpdated;
	}

	public String getLastUpdatedUser() {
		return lastUpdatedUser;
	}

	public void setLastUpdatedUser(String lastUpdatedUser) {
		this.lastUpdatedUser = lastUpdatedUser;
	}

	@Override
	public String toString() {
		return "SeedLoadCPC [cobDate=" + cobDate + ", createUser=" + createUser + ", flag=" + flag + ", loadDate="
				+ loadDate + ", lastUpdated=" + lastUpdated + ", lastUpdatedUser=" + lastUpdatedUser + "]";
	}

}
