package com.citi.aqua.cba.model;

public class EWSUser {

	private String id;
	private String soeid;
	private String friendly_name;
	private String domain_name;
	private String email;
	private String status;
	private String user_role;
	private String race_role;
	private boolean all_client;
	private boolean manage_alert;
	private boolean manage_alert_rule;
	private boolean add_admin;
	private boolean manage_coverage;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getSoeid() {
		return soeid;
	}

	public void setSoeid(String soeid) {
		this.soeid = soeid;
	}

	public String getFriendly_name() {
		return friendly_name;
	}

	public void setFriendly_name(String friendly_name) {
		this.friendly_name = friendly_name;
	}

	public String getDomain_name() {
		return domain_name;
	}

	public void setDomain_name(String domain_name) {
		this.domain_name = domain_name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getUser_role() {
		return user_role;
	}

	public void setUser_role(String user_role) {
		this.user_role = user_role;
	}

	public String getRace_role() {
		return race_role;
	}

	public void setRace_role(String race_role) {
		this.race_role = race_role;
	}

	public boolean isAll_client() {
		return all_client;
	}

	public void setAll_client(boolean all_client) {
		this.all_client = all_client;
	}

	public boolean isManage_alert() {
		return manage_alert;
	}

	public void setManage_alert(boolean manage_alert) {
		this.manage_alert = manage_alert;
	}

	public boolean isManage_alert_rule() {
		return manage_alert_rule;
	}

	public void setManage_alert_rule(boolean manage_alert_rule) {
		this.manage_alert_rule = manage_alert_rule;
	}

	public boolean isAdd_admin() {
		return add_admin;
	}

	public void setAdd_admin(boolean add_admin) {
		this.add_admin = add_admin;
	}

	public boolean isManage_coverage() {
		return manage_coverage;
	}

	public void setManage_coverage(boolean manage_coverage) {
		this.manage_coverage = manage_coverage;
	}

}
