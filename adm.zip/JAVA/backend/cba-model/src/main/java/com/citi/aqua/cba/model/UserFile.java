package com.citi.aqua.cba.model;

public class UserFile {

	private String file_id;
	private String exception_activity_id;
	private String file_name;
	private byte[] file_object;
	private String create_user;
	private String create_time;

	public String getFile_id() {
		return file_id;
	}

	public void setFile_id(String file_id) {
		this.file_id = file_id;
	}

	public String getException_activity_id() {
		return exception_activity_id;
	}

	public void setException_activity_id(String exception_activity_id) {
		this.exception_activity_id = exception_activity_id;
	}

	public String getFile_name() {
		return file_name;
	}

	public void setFile_name(String file_name) {
		this.file_name = file_name;
	}

	public byte[] getFile_object() {
		return file_object;
	}

	public void setFile_object(byte[] file_object) {
		this.file_object = file_object;
	}

	public String getCreate_user() {
		return create_user;
	}

	public void setCreate_user(String create_user) {
		this.create_user = create_user;
	}

	public String getCreate_time() {
		return create_time;
	}

	public void setCreate_time(String create_time) {
		this.create_time = create_time;
	}

}
