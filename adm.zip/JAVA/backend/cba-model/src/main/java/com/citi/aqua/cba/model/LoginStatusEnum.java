package com.citi.aqua.cba.model;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public enum LoginStatusEnum {
	
	CBA_200("Success"),
	CBA_300("Not Authenticated"),
	CBA_400("Not Authorized in AQUA"),
	CBA_500("Password Expired"),
	CBA_600("Account Locked"),
	CBA_700("Session Invalidated"),
	CBA_800("CITI SSO Service Communication Error"),
	CBA_900("AQUA SSO Service Communication Error"),
	CBA_1000("Force password change requested for user");

	private String statusMsg;
	private static Logger LOGGER = LoggerFactory.getLogger(LoginStatusEnum.class);

	LoginStatusEnum(String statusMsg) {
		this.statusMsg = statusMsg;
	}

	public static void main(String args[]) {
		if (LOGGER.isDebugEnabled())
			for (LoginStatusEnum c : LoginStatusEnum.values()) {
				LOGGER.debug(c + " : " + c.getStatusMsg());
			}
	}

	public String getStatusMsg() {
		return statusMsg;
	}
}