package com.citi.aqua.cba.model;

import java.io.Serializable;

public class SecuritySector implements Serializable {

	private static final long serialVersionUID = 1L;

	private String cob_date;
	private long consumer_discretionary;
	private long consumer_staples;
	private long energy;
	private long financials;
	private long health_care;
	private long industrials;
	private long information_technology;
	private long materials;
	private long Other;
	private long telecommunications;
	private long utilities;

	public String getCob_date() {
		return cob_date;
	}

	public void setCob_date(String cob_date) {
		this.cob_date = cob_date;
	}

	public long getConsumer_discretionary() {
		return consumer_discretionary;
	}

	public void setConsumer_discretionary(long consumer_discretionary) {
		this.consumer_discretionary = consumer_discretionary;
	}

	public long getConsumer_staples() {
		return consumer_staples;
	}

	public void setConsumer_staples(long consumer_staples) {
		this.consumer_staples = consumer_staples;
	}

	public long getEnergy() {
		return energy;
	}

	public void setEnergy(long energy) {
		this.energy = energy;
	}

	public long getFinancials() {
		return financials;
	}

	public void setFinancials(long financials) {
		this.financials = financials;
	}

	public long getHealth_care() {
		return health_care;
	}

	public void setHealth_care(long health_care) {
		this.health_care = health_care;
	}

	public long getIndustrials() {
		return industrials;
	}

	public void setIndustrials(long industrials) {
		this.industrials = industrials;
	}

	public long getInformation_technology() {
		return information_technology;
	}

	public void setInformation_technology(long information_technology) {
		this.information_technology = information_technology;
	}

	public long getMaterials() {
		return materials;
	}

	public void setMaterials(long materials) {
		this.materials = materials;
	}

	public long getOther() {
		return Other;
	}

	public void setOther(long other) {
		Other = other;
	}

	public long getTelecommunications() {
		return telecommunications;
	}

	public void setTelecommunications(long telecommunications) {
		this.telecommunications = telecommunications;
	}

	public long getUtilities() {
		return utilities;
	}

	public void setUtilities(long utilities) {
		this.utilities = utilities;
	}

}
