package com.citi.aqua.cba.model;

/**
 * @author ak92283
 */
import java.io.Serializable;

public class BatchConfigParams implements Serializable {

	private static final long serialVersionUID = 1L;
	private String config_id;
	private String mail_to;
	private String mail_cc;
	private String mail_bcc;
	private String subject;
	private String type;
	private String update_time;
	private String update_type;
	private String mail_from;

	/**
	 * @return the config_id
	 */
	public String getConfig_id() {
		return config_id;
	}

	/**
	 * @param config_id
	 *            the config_id to set
	 */
	public void setConfig_id(String config_id) {
		this.config_id = config_id;
	}

	/**
	 * @return the mail_to
	 */
	public String getMail_to() {
		return mail_to;
	}

	/**
	 * @param mail_to
	 *            the mail_to to set
	 */
	public void setMail_to(String mail_to) {
		this.mail_to = mail_to;
	}

	/**
	 * @return the mail_cc
	 */
	public String getMail_cc() {
		return mail_cc;
	}

	/**
	 * @param mail_cc
	 *            the mail_cc to set
	 */
	public void setMail_cc(String mail_cc) {
		this.mail_cc = mail_cc;
	}

	/**
	 * @return the mail_bcc
	 */
	public String getMail_bcc() {
		return mail_bcc;
	}

	/**
	 * @param mail_bcc
	 *            the mail_bcc to set
	 */
	public void setMail_bcc(String mail_bcc) {
		this.mail_bcc = mail_bcc;
	}

	/**
	 * @return the subject
	 */
	public String getSubject() {
		return subject;
	}

	/**
	 * @param subject
	 *            the subject to set
	 */
	public void setSubject(String subject) {
		this.subject = subject;
	}

	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * @param type
	 *            the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * @return the update_time
	 */
	public String getUpdate_time() {
		return update_time;
	}

	/**
	 * @param update_time
	 *            the update_time to set
	 */
	public void setUpdate_time(String update_time) {
		this.update_time = update_time;
	}

	/**
	 * @return the update_type
	 */
	public String getUpdate_type() {
		return update_type;
	}

	/**
	 * @param update_type
	 *            the update_type to set
	 */
	public void setUpdate_type(String update_type) {
		this.update_type = update_type;
	}

	/**
	 * @return the mail_from
	 */
	public String getMail_from() {
		return mail_from;
	}

	/**
	 * @param mail_from
	 *            the mail_from to set
	 */
	public void setMail_from(String mail_from) {
		this.mail_from = mail_from;
	}

}
