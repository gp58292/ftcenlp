package com.citi.aqua.cba.model;

public class UserCoverage {

	private String soeid;
	private String gpnum;
	private String gpname;
	private String Source;

	public String getSoeid() {
		return soeid;
	}

	public void setSoeid(String soeid) {
		this.soeid = soeid;
	}

	public String getGpnum() {
		return gpnum;
	}

	public void setGpnum(String gpnum) {
		this.gpnum = gpnum;
	}

	public String getGpname() {
		return gpname;
	}

	public void setGpname(String gpname) {
		this.gpname = gpname;
	}

	public String getSource() {
		return Source;
	}

	public void setSource(String source) {
		Source = source;
	}

}
