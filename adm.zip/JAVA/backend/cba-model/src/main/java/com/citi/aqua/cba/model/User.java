package com.citi.aqua.cba.model;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class User implements Serializable {

	private static final long serialVersionUID = 1L;
	private String soeid;
	private String name;
	private String password;
	private String newpassword;
	private String ssoSessionID;
	private LoginStatusEnum statusCode;
	private String statusMessage;
	private String email;
	private boolean isAuthorized;
	@SuppressWarnings("unused")
	private boolean isAuthenticated;
	private List<String> accessList = new ArrayList<>();
	private boolean isCBAAccessible;

	public boolean getIsAuthorized() {
		return isAuthorized;
	}

	public void setIsAuthorized(boolean isAuthorized) {
		this.isAuthorized = isAuthorized;
	}

	public String getSoeid() {
		return soeid;
	}

	public void setSoeid(String soeid) {
		this.soeid = soeid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getNewpassword() {
		return newpassword;
	}

	public void setNewpassword(String newpassword) {
		this.newpassword = newpassword;
	}

	public String getSsoSessionID() {
		return ssoSessionID;
	}

	public void setSsoSessionID(String ssoSessionID) {
		this.ssoSessionID = ssoSessionID;
	}

	public LoginStatusEnum getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(LoginStatusEnum statusCode) {
		this.statusCode = statusCode;
	}

	public String getStatusMessage() {
		return statusMessage;
	}

	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public List<String> getAccessList() {
		return accessList;
	}

	public void setAccessList(List<String> accessList) {
		this.accessList = accessList;
	}

	public boolean isAuthorized() {
		return statusCode.equals(LoginStatusEnum.CBA_200);
	}

	public void setAuthorized(boolean isAuthorized) {
		this.isAuthorized = isAuthorized;
	}

	public boolean isAuthenticated() {
		return statusCode != null && statusCode.equals(LoginStatusEnum.CBA_200);
	}

	public void setAuthenticated(boolean authenticated) {
		this.isAuthenticated = authenticated;
	}



	public boolean isCBAAccessible() {
		return isCBAAccessible;
	}

	public void setCBAAccessible(boolean isCBAAccessible) {
		this.isCBAAccessible = isCBAAccessible;
	}

}
