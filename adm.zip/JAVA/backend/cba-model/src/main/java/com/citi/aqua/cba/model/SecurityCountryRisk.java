package com.citi.aqua.cba.model;

import java.io.Serializable;

public class SecurityCountryRisk implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String cob_date;
	private long APAC_Emerging_Markets_Lev1;
	private long APAC_Emerging_Markets_Lev2;
	private long APAC_Emerging_Markets_Lev3;
	private long Developed_Markets;
	private long EMEA_Emerging_Markets_Lev1B;
	private long EMEA_Emerging_Markets_Lev2;
	private long LATAM_Emerging_Markets_Lev2;
	private long Other;

	public String getCob_date() {
		return cob_date;
	}

	public void setCob_date(String cob_date) {
		this.cob_date = cob_date;
	}

	public Long getAPAC_Emerging_Markets_Lev1() {
		return APAC_Emerging_Markets_Lev1;
	}

	public void setAPAC_Emerging_Markets_Lev1(Long aPAC_Emerging_Markets_Lev1) {
		APAC_Emerging_Markets_Lev1 = aPAC_Emerging_Markets_Lev1;
	}

	public Long getAPAC_Emerging_Markets_Lev2() {
		return APAC_Emerging_Markets_Lev2;
	}

	public void setAPAC_Emerging_Markets_Lev2(Long aPAC_Emerging_Markets_Lev2) {
		APAC_Emerging_Markets_Lev2 = aPAC_Emerging_Markets_Lev2;
	}

	public long getAPAC_Emerging_Markets_Lev3() {
		return APAC_Emerging_Markets_Lev3;
	}

	public void setAPAC_Emerging_Markets_Lev3(long aPAC_Emerging_Markets_Lev3) {
		APAC_Emerging_Markets_Lev3 = aPAC_Emerging_Markets_Lev3;
	}

	public long getDeveloped_Markets() {
		return Developed_Markets;
	}

	public void setDeveloped_Markets(long developed_Markets) {
		Developed_Markets = developed_Markets;
	}

	public long getEMEA_Emerging_Markets_Lev1B() {
		return EMEA_Emerging_Markets_Lev1B;
	}

	public void setEMEA_Emerging_Markets_Lev1B(long eMEA_Emerging_Markets_Lev1B) {
		EMEA_Emerging_Markets_Lev1B = eMEA_Emerging_Markets_Lev1B;
	}

	public long getEMEA_Emerging_Markets_Lev2() {
		return EMEA_Emerging_Markets_Lev2;
	}

	public void setEMEA_Emerging_Markets_Lev2(long eMEA_Emerging_Markets_Lev2) {
		EMEA_Emerging_Markets_Lev2 = eMEA_Emerging_Markets_Lev2;
	}

	public long getLATAM_Emerging_Markets_Lev2() {
		return LATAM_Emerging_Markets_Lev2;
	}

	public void setLATAM_Emerging_Markets_Lev2(long lATAM_Emerging_Markets_Lev2) {
		LATAM_Emerging_Markets_Lev2 = lATAM_Emerging_Markets_Lev2;
	}

	public long getOther() {
		return Other;
	}

	public void setOther(long other) {
		Other = other;
	}

	public void setAPAC_Emerging_Markets_Lev1(long aPAC_Emerging_Markets_Lev1) {
		APAC_Emerging_Markets_Lev1 = aPAC_Emerging_Markets_Lev1;
	}

	public void setAPAC_Emerging_Markets_Lev2(long aPAC_Emerging_Markets_Lev2) {
		APAC_Emerging_Markets_Lev2 = aPAC_Emerging_Markets_Lev2;
	}

}
