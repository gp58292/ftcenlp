package com.citi.aqua.cba.model;

import java.io.Serializable;

public class ExceptionStatusChart implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String date;
	private Integer exceptions;
	private Integer resolved;
	private Integer review;
	private Integer reassigned;
	private Integer open;

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public Integer getExceptions() {
		return exceptions;
	}

	public void setExceptions(Integer exceptions) {
		this.exceptions = exceptions;
	}

	public Integer getResolved() {
		return resolved;
	}

	public void setResolved(Integer resolved) {
		this.resolved = resolved;
	}

	public Integer getReview() {
		return review;
	}

	public void setReview(Integer review) {
		this.review = review;
	}

	public Integer getReassigned() {
		return reassigned;
	}

	public void setReassigned(Integer reassigned) {
		this.reassigned = reassigned;
	}

	public Integer getOpen() {
		return open;
	}

	public void setOpen(Integer open) {
		this.open = open;
	}

}
