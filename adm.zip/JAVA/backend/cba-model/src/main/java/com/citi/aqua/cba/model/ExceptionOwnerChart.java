package com.citi.aqua.cba.model;

import java.io.Serializable;

public class ExceptionOwnerChart implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String client;
	private Integer open;
	private Integer underreview;
	private Integer reassigned;

	public String getClient() {
		return client;
	}

	public void setClient(String client) {
		this.client = client;
	}

	public Integer getOpen() {
		return open;
	}

	public void setOpen(Integer open) {
		this.open = open;
	}

	public Integer getUnderreview() {
		return underreview;
	}

	public void setUnderreview(Integer underreview) {
		this.underreview = underreview;
	}

	public Integer getReassigned() {
		return reassigned;
	}

	public void setReassigned(Integer reassigned) {
		this.reassigned = reassigned;
	}

}
