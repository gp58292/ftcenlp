package com.citi.aqua.cba.model;

/**
 * Created by jm27909 on 8/29/2017.
 */
public class UploadFile {

    private int id;
    private int requestId;
    private String fileName;
    private byte[] fileObject;
    private String loadDate;

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public byte[] getFileObject() {
        return fileObject;
    }

    public void setFileObject(byte[] fileObject) {
        this.fileObject = fileObject;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getLoadDate() {
        return loadDate;
    }

    public void setLoadDate(String loadDate) {
        this.loadDate = loadDate;
    }

    public int getRequestId() {
        return requestId;
    }

    public void setRequestId(int requestId) {
        this.requestId = requestId;
    }
}
