package com.citi.aqua.cba.model;

/**
 * @author ak92283
 */
import java.io.Serializable;
import java.util.List;

public class FeedDelayEmailData implements Serializable {

	private static final long serialVersionUID = 1L;

	private FeedDelayData feedDelayForm;

	private List<FeedDelayDataDetails> cbaDashboardResponseData;
	private List<FeedDelayDataDetails> slDashboardResponseData;
	private List<FeedDelayDataDetails> reportResponseData;
	private List<FeedDelayDataDetails> cadResponseData;
	private List<FeedDelayDataDetails> feedResponseData;
	private BatchEmailConfigForm configForm;

	/**
	 * @return the cbaDashboardResponseData
	 */
	public List<FeedDelayDataDetails> getCbaDashboardResponseData() {
		return cbaDashboardResponseData;
	}

	/**
	 * @param cbaDashboardResponseData
	 *            the cbaDashboardResponseData to set
	 */
	public void setCbaDashboardResponseData(List<FeedDelayDataDetails> cbaDashboardResponseData) {
		this.cbaDashboardResponseData = cbaDashboardResponseData;
	}

	/**
	 * @return the slDashboardResponseData
	 */
	public List<FeedDelayDataDetails> getSlDashboardResponseData() {
		return slDashboardResponseData;
	}

	/**
	 * @param slDashboardResponseData
	 *            the slDashboardResponseData to set
	 */
	public void setSlDashboardResponseData(List<FeedDelayDataDetails> slDashboardResponseData) {
		this.slDashboardResponseData = slDashboardResponseData;
	}

	/**
	 * @return the serialversionuid
	 */
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	/**
	 * @return the feedDelayForm
	 */
	public FeedDelayData getFeedDelayForm() {
		return feedDelayForm;
	}

	/**
	 * @param feedDelayForm
	 *            the feedDelayForm to set
	 */
	public void setFeedDelayForm(FeedDelayData feedDelayForm) {
		this.feedDelayForm = feedDelayForm;
	}

	/**
	 * @return the reportResponseData
	 */
	public List<FeedDelayDataDetails> getReportResponseData() {
		return reportResponseData;
	}

	/**
	 * @param reportResponseData
	 *            the reportResponseData to set
	 */
	public void setReportResponseData(List<FeedDelayDataDetails> reportResponseData) {
		this.reportResponseData = reportResponseData;
	}

	/**
	 * @return the cadResponseData
	 */
	public List<FeedDelayDataDetails> getCadResponseData() {
		return cadResponseData;
	}

	/**
	 * @param cadResponseData
	 *            the cadResponseData to set
	 */
	public void setCadResponseData(List<FeedDelayDataDetails> cadResponseData) {
		this.cadResponseData = cadResponseData;
	}

	/**
	 * @return the feedResponseData
	 */
	public List<FeedDelayDataDetails> getFeedResponseData() {
		return feedResponseData;
	}

	/**
	 * @param feedResponseData
	 *            the feedResponseData to set
	 */
	public void setFeedResponseData(List<FeedDelayDataDetails> feedResponseData) {
		this.feedResponseData = feedResponseData;
	}

	/**
	 * @return the configForm
	 */
	public BatchEmailConfigForm getConfigForm() {
		return configForm;
	}

	/**
	 * @param configForm
	 *            the configForm to set
	 */
	public void setConfigForm(BatchEmailConfigForm configForm) {
		this.configForm = configForm;
	}

}
