package com.citi.aqua.cba.model;


public class Request {

    private int id;
    private String soeid;
    private String userName;
    private String requestedBy;
    private String accessRequested;
    private String receivedOn;
    private String status;
    private String securityModel;
    private String qvAuthorization;
    private String qvAuthorizationStatus;
    private String qvAuthorizationLandingPage;
    private String citiVelocity;
    private String notifiedUser;
    private String securityModelStatus;
    private String lastUpdated;
    private String comments;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getSoeid() {
        return soeid;
    }

    public void setSoeid(String soeid) {
        this.soeid = soeid;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getRequestedBy() {
        return requestedBy;
    }

    public void setRequestedBy(String requestedBy) {
        this.requestedBy = requestedBy;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getSecurityModel() {
        return securityModel;
    }

    public void setSecurityModel(String securityModel) {
        this.securityModel = securityModel;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }


    public String getSecurityModelStatus() {
        return securityModelStatus;
    }

    public void setSecurityModelStatus(String securityModelStatus) {
        this.securityModelStatus = securityModelStatus;
    }


    public String getAccessRequested() {
        return accessRequested;
    }

    public void setAccessRequested(String accessRequested) {
        this.accessRequested = accessRequested;
    }

    public String getReceivedOn() {
        return receivedOn;
    }

    public void setReceivedOn(String receivedOn) {
        this.receivedOn = receivedOn;
    }

    public String getQvAuthorizationLandingPage() {
        return qvAuthorizationLandingPage;
    }

    public void setQvAuthorizationLandingPage(String qvAuthorizationLandingPage) {
        this.qvAuthorizationLandingPage = qvAuthorizationLandingPage;
    }

    public String getCitiVelocity() {
        return citiVelocity;
    }

    public void setCitiVelocity(String citiVelocity) {
        this.citiVelocity = citiVelocity;
    }

    public String getLastUpdated() {
        return lastUpdated;
    }

    public void setLastUpdated(String lastUpdated) {
        this.lastUpdated = lastUpdated;
    }

    public String getNotifiedUser() {
        return notifiedUser;
    }

    public void setNotifiedUser(String notifiedUser) {
        this.notifiedUser = notifiedUser;
    }

    public String getQvAuthorization() {
        return qvAuthorization;
    }

    public void setQvAuthorization(String qvAuthorization) {
        this.qvAuthorization = qvAuthorization;
    }

    public String getQvAuthorizationStatus() {
        return qvAuthorizationStatus;
    }

    public void setQvAuthorizationStatus(String qvAuthorizationStatus) {
        this.qvAuthorizationStatus = qvAuthorizationStatus;
    }

}
