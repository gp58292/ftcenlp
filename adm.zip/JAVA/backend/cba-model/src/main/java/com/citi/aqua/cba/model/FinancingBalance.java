package com.citi.aqua.cba.model;

import java.io.Serializable;

public class FinancingBalance implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String cob_date;
	private String GFCID_fund;
	private String client;
	private String fund;
	private String region;
	private long credit;
	private long debit;
	private long shorts;
	private long others;
	private long index_level;

	public String getCob_date() {
		return cob_date;
	}

	public void setCob_date(String cob_date) {
		this.cob_date = cob_date;
	}

	public String getGFCID_fund() {
		return GFCID_fund;
	}

	public void setGFCID_fund(String gFCID_fund) {
		GFCID_fund = gFCID_fund;
	}

	public String getClient() {
		return client;
	}

	public void setClient(String client) {
		this.client = client;
	}

	public String getFund() {
		return fund;
	}

	public void setFund(String fund) {
		this.fund = fund;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public long getCredit() {
		return credit;
	}

	public void setCredit(long credit) {
		this.credit = credit;
	}

	public long getDebit() {
		return debit;
	}

	public void setDebit(long debit) {
		this.debit = debit;
	}

	public long getShorts() {
		return shorts;
	}

	public void setShorts(long shorts) {
		this.shorts = shorts;
	}

	public long getOthers() {
		return others;
	}

	public void setOthers(long others) {
		this.others = others;
	}

	public long getIndex_level() {
		return index_level;
	}

	public void setIndex_level(long index_level) {
		this.index_level = index_level;
	}

}
