package com.citi.aqua.cba.model;

public class ExceptionRule {

	private Long ExceptionRuleId;
	private String rule_group_id;
	private String ExceptionRuleType;
	private String ExceptionRuleTypeName;
	private String ExceptionPriority;
	private String ExceptionPriorityName;
	private String LegalEntity;
	private String LegalEntityName;
	private String Client;
	private String Region;
	private String RegionName;
	private String Fund;
	private String ClientName;
	private String FundName;
	private String ExceptionRuleDataType;
	private String ExceptionRuleDataTypeName;
	private String ExceptionRuleTimePeriod;
	private String ExceptionRuleTimePeriodName;
	private String ExceptionRuleLimitType;
	private String ExceptionRuleLimitTypeName;
	private String ExceptionRuleThresholdType;
	private String ExceptionRuleThresholdTypeName;
	private String ExceptionRuleLimits;
	private String ExceptionStatus;
	private String ExceptionStatusName;
	private String ExceptionComments;
	private int total_open_alerts;
	private int today_open_alerts;
	private String UpdatedBy;
	private String create_time;
	private String RuleOwner;
	private String version_id;
	private String alert_assignee;
	private String alert_owner;
	private long threshold_dollar;
	private String threshold_dollar_mask;
	private String aggregation_level;
	private String aggregation_level_name;

	public String getAggregation_level_name() {
		return aggregation_level_name;
	}

	public void setAggregation_level_name(String aggregation_level_name) {
		this.aggregation_level_name = aggregation_level_name;
	}

	public String getAggregation_level() {
		return aggregation_level;
	}

	public void setAggregation_level(String aggregation_level) {
		this.aggregation_level = aggregation_level;
	}

	public String getThreshold_dollar_mask() {
		return threshold_dollar_mask;
	}

	public void setThreshold_dollar_mask(String threshold_dollar_mask) {
		this.threshold_dollar_mask = threshold_dollar_mask;
	}

	private long threshold_percent;

	public String getAlert_assignee() {
		return alert_assignee;
	}

	public void setAlert_assignee(String alert_assignee) {
		this.alert_assignee = alert_assignee;
	}

	public String getAlert_owner() {
		return alert_owner;
	}

	public void setAlert_owner(String alert_owner) {
		this.alert_owner = alert_owner;
	}

	public String getVersion_id() {
		return version_id;
	}

	public void setVersion_id(String version_id) {
		this.version_id = version_id;
	}

	public long getThreshold_dollar() {
		return threshold_dollar;
	}

	public void setThreshold_dollar(long threshold_dollar) {
		this.threshold_dollar = threshold_dollar;
	}

	public long getThreshold_percent() {
		return threshold_percent;
	}

	public void setThreshold_percent(long threshold_percent) {
		this.threshold_percent = threshold_percent;
	}

	public Long getExceptionRuleId() {
		return ExceptionRuleId;
	}

	public void setExceptionRuleId(Long exceptionRuleId) {
		ExceptionRuleId = exceptionRuleId;
	}

	public String getRule_group_id() {
		return rule_group_id;
	}

	public void setRule_group_id(String rule_group_id) {
		this.rule_group_id = rule_group_id;
	}

	public String getExceptionRuleType() {
		return ExceptionRuleType;
	}

	public void setExceptionRuleType(String exceptionRuleType) {
		ExceptionRuleType = exceptionRuleType;
	}

	public String getExceptionRuleTypeName() {
		return ExceptionRuleTypeName;
	}

	public void setExceptionRuleTypeName(String exceptionRuleTypeName) {
		ExceptionRuleTypeName = exceptionRuleTypeName;
	}

	public String getExceptionPriority() {
		return ExceptionPriority;
	}

	public void setExceptionPriority(String exceptionPriority) {
		ExceptionPriority = exceptionPriority;
	}

	public String getExceptionPriorityName() {
		return ExceptionPriorityName;
	}

	public void setExceptionPriorityName(String exceptionPriorityName) {
		ExceptionPriorityName = exceptionPriorityName;
	}

	public String getLegalEntity() {
		return LegalEntity;
	}

	public void setLegalEntity(String legalEntity) {
		LegalEntity = legalEntity;
	}

	public String getLegalEntityName() {
		return LegalEntityName;
	}

	public void setLegalEntityName(String legalEntityName) {
		LegalEntityName = legalEntityName;
	}

	public String getClient() {
		return Client;
	}

	public void setClient(String client) {
		Client = client;
	}

	public String getRegion() {
		return Region;
	}

	public void setRegion(String region) {
		Region = region;
	}

	public String getRegionName() {
		return RegionName;
	}

	public void setRegionName(String regionName) {
		RegionName = regionName;
	}

	public String getFund() {
		return Fund;
	}

	public void setFund(String fund) {
		Fund = fund;
	}

	public String getClientName() {
		return ClientName;
	}

	public void setClientName(String clientName) {
		ClientName = clientName;
	}

	public String getFundName() {
		return FundName;
	}

	public void setFundName(String fundName) {
		FundName = fundName;
	}

	public String getExceptionRuleDataType() {
		return ExceptionRuleDataType;
	}

	public void setExceptionRuleDataType(String exceptionRuleDataType) {
		ExceptionRuleDataType = exceptionRuleDataType;
	}

	public String getExceptionRuleDataTypeName() {
		return ExceptionRuleDataTypeName;
	}

	public void setExceptionRuleDataTypeName(String exceptionRuleDataTypeName) {
		ExceptionRuleDataTypeName = exceptionRuleDataTypeName;
	}

	public String getExceptionRuleTimePeriod() {
		return ExceptionRuleTimePeriod;
	}

	public void setExceptionRuleTimePeriod(String exceptionRuleTimePeriod) {
		ExceptionRuleTimePeriod = exceptionRuleTimePeriod;
	}

	public String getExceptionRuleTimePeriodName() {
		return ExceptionRuleTimePeriodName;
	}

	public void setExceptionRuleTimePeriodName(
			String exceptionRuleTimePeriodName) {
		ExceptionRuleTimePeriodName = exceptionRuleTimePeriodName;
	}

	public String getExceptionRuleLimitType() {
		return ExceptionRuleLimitType;
	}

	public void setExceptionRuleLimitType(String exceptionRuleLimitType) {
		ExceptionRuleLimitType = exceptionRuleLimitType;
	}

	public String getExceptionRuleLimitTypeName() {
		return ExceptionRuleLimitTypeName;
	}

	public void setExceptionRuleLimitTypeName(String exceptionRuleLimitTypeName) {
		ExceptionRuleLimitTypeName = exceptionRuleLimitTypeName;
	}

	public String getExceptionRuleThresholdType() {
		return ExceptionRuleThresholdType;
	}

	public void setExceptionRuleThresholdType(String exceptionRuleThresholdType) {
		ExceptionRuleThresholdType = exceptionRuleThresholdType;
	}

	public String getExceptionRuleThresholdTypeName() {
		return ExceptionRuleThresholdTypeName;
	}

	public void setExceptionRuleThresholdTypeName(
			String exceptionRuleThresholdTypeName) {
		ExceptionRuleThresholdTypeName = exceptionRuleThresholdTypeName;
	}

	public String getExceptionRuleLimits() {
		return ExceptionRuleLimits;
	}

	public void setExceptionRuleLimits(String exceptionRuleLimits) {
		ExceptionRuleLimits = exceptionRuleLimits;
	}

	public String getExceptionStatus() {
		return ExceptionStatus;
	}

	public void setExceptionStatus(String exceptionStatus) {
		ExceptionStatus = exceptionStatus;
	}

	public String getExceptionStatusName() {
		return ExceptionStatusName;
	}

	public void setExceptionStatusName(String exceptionStatusName) {
		ExceptionStatusName = exceptionStatusName;
	}

	public String getExceptionComments() {
		return ExceptionComments;
	}

	public void setExceptionComments(String exceptionComments) {
		ExceptionComments = exceptionComments;
	}

	public String getUpdatedBy() {
		return UpdatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		UpdatedBy = updatedBy;
	}

	public int getTotal_open_alerts() {
		return total_open_alerts;
	}

	public void setTotal_open_alerts(int total_open_alerts) {
		this.total_open_alerts = total_open_alerts;
	}

	public int getToday_open_alerts() {
		return today_open_alerts;
	}

	public void setToday_open_alerts(int today_open_alerts) {
		this.today_open_alerts = today_open_alerts;
	}

	public String getCreate_time() {
		return create_time;
	}

	public void setCreate_time(String create_time) {
		this.create_time = create_time;
	}

	public String getRuleOwner() {
		return RuleOwner;
	}

	public void setRuleOwner(String ruleOwner) {
		RuleOwner = ruleOwner;
	}

	@Override
	public String toString() {
		return "ExceptionRule [ExceptionRuleId=" + ExceptionRuleId
				+ ", rule_group_id=" + rule_group_id + ", ExceptionRuleType="
				+ ExceptionRuleType + ", ExceptionRuleTypeName="
				+ ExceptionRuleTypeName + ", ExceptionPriority="
				+ ExceptionPriority + ", ExceptionPriorityName="
				+ ExceptionPriorityName + ", LegalEntity=" + LegalEntity
				+ ", LegalEntityName=" + LegalEntityName + ", Client=" + Client
				+ ", Region=" + Region + ", RegionName=" + RegionName
				+ ", Fund=" + Fund + ", ClientName=" + ClientName
				+ ", FundName=" + FundName + ", ExceptionRuleDataType="
				+ ExceptionRuleDataType + ", ExceptionRuleDataTypeName="
				+ ExceptionRuleDataTypeName + ", ExceptionRuleTimePeriod="
				+ ExceptionRuleTimePeriod + ", ExceptionRuleTimePeriodName="
				+ ExceptionRuleTimePeriodName + ", ExceptionRuleLimitType="
				+ ExceptionRuleLimitType + ", ExceptionRuleLimitTypeName="
				+ ExceptionRuleLimitTypeName + ", ExceptionRuleThresholdType="
				+ ExceptionRuleThresholdType
				+ ", ExceptionRuleThresholdTypeName="
				+ ExceptionRuleThresholdTypeName + ", ExceptionRuleLimits="
				+ ExceptionRuleLimits + ", ExceptionStatus=" + ExceptionStatus
				+ ", ExceptionStatusName=" + ExceptionStatusName
				+ ", ExceptionComments=" + ExceptionComments
				+ ", total_open_alerts=" + total_open_alerts
				+ ", today_open_alerts=" + today_open_alerts + ", UpdatedBy="
				+ UpdatedBy + ", create_time=" + create_time + ", RuleOwner="
				+ RuleOwner + ", version_id=" + version_id
				+ ", alert_assignee=" + alert_assignee + ", alert_owner="
				+ alert_owner + ", threshold_dollar=" + threshold_dollar
				+ ", threshold_dollar_mask=" + threshold_dollar_mask
				+ ", aggregation_level=" + aggregation_level
				+ ", aggregation_level_name=" + aggregation_level_name
				+ ", threshold_percent=" + threshold_percent + "]";
	}

}
