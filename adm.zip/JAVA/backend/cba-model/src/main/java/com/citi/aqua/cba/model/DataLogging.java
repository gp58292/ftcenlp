package com.citi.aqua.cba.model;
/**
 * @author: jm27909
 *
 * 
 */
public class DataLogging {
	
	private String databaseName;
	private String schemaName;
	private String procedureName;
	private String stepName;
	private int recordCount;
	private String logTime;
	private String userName;
	private String errorLine;
	private String errrorMessage;


	public String getDatabaseName() {
		return databaseName;
	}

	public void setDatabaseName(String databaseName) {
		this.databaseName = databaseName;
	}
	
	public String getSchemaName() {
		return schemaName;
	}

	public void setSchemaName(String schemaName) {
		this.schemaName = schemaName;
	}

	public String getProcedureName() {
		return procedureName;
	}

	public void setProcedureName(String procedureName) {
		this.procedureName = procedureName;
	}

	public String getStepName() {
		return stepName;
	}

	public void setStepName(String stepName) {
		this.stepName = stepName;
	}

	public int getRecordCount() {
		return recordCount;
	}

	public void setRecordCount(int recordCount) {
		this.recordCount = recordCount;
	}

	public String getLogTime() {
		return logTime;
	}

	public void setLogTime(String logTime) {
		this.logTime = logTime;
	}
	
	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	public String getErrorLine() {
		return errorLine;
	}

	public void setErrorLine(String errorLine) {
		this.errorLine = errorLine;
	}
	
	public String getErrrorMessage() {
		return errrorMessage;
	}

	public void setErrrorMessage(String errrorMessage) {
		this.errrorMessage = errrorMessage;
	}
		
}
