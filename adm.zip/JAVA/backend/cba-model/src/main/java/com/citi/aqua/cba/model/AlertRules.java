package com.citi.aqua.cba.model;

public class AlertRules {

	private double rule_group_id;
	private String type;
	private String priority;
	private String client;
	private String fund;
	private String region;
	private String data_type;
	private String rule_period;
	private String threshold;
	private double total_open_alerts;
	private double today_open_alerts;
	private String status;
	private String alert_owner;

	public double getRule_group_id() {
		return rule_group_id;
	}

	public void setRule_group_id(double rule_group_id) {
		this.rule_group_id = rule_group_id;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getPriority() {
		return priority;
	}

	public void setPriority(String priority) {
		this.priority = priority;
	}

	public String getClient() {
		return client;
	}

	public void setClient(String client) {
		this.client = client;
	}

	public String getFund() {
		return fund;
	}

	public void setFund(String fund) {
		this.fund = fund;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getData_type() {
		return data_type;
	}

	public void setData_type(String data_type) {
		this.data_type = data_type;
	}

	public String getRule_period() {
		return rule_period;
	}

	public void setRule_period(String rule_period) {
		this.rule_period = rule_period;
	}

	public String getThreshold() {
		return threshold;
	}

	public void setThreshold(String threshold) {
		this.threshold = threshold;
	}

	public double getTotal_open_alerts() {
		return total_open_alerts;
	}

	public void setTotal_open_alerts(double total_open_alerts) {
		this.total_open_alerts = total_open_alerts;
	}

	public double getToday_open_alerts() {
		return today_open_alerts;
	}

	public void setToday_open_alerts(double today_open_alerts) {
		this.today_open_alerts = today_open_alerts;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getAlert_owner() {
		return alert_owner;
	}

	public void setAlert_owner(String alert_owner) {
		this.alert_owner = alert_owner;
	}

}
