package com.citi.aqua.cba.model;

import java.io.Serializable;

public class SecurityMarketCap implements Serializable {

	private static final long serialVersionUID = 1L;

	private String cob_date;
	private long Mega;
	private long BigLarge;
	private long Mid;
	private long Small;
	private long Micro;
	private long Nano;
	private long Other;

	public String getCob_date() {
		return cob_date;
	}

	public void setCob_date(String cob_date) {
		this.cob_date = cob_date;
	}

	public long getMega() {
		return Mega;
	}

	public void setMega(long mega) {
		Mega = mega;
	}

	public long getBigLarge() {
		return BigLarge;
	}

	public void setBigLarge(long bigLarge) {
		BigLarge = bigLarge;
	}

	public long getMid() {
		return Mid;
	}

	public void setMid(long mid) {
		Mid = mid;
	}

	public long getSmall() {
		return Small;
	}

	public void setSmall(long small) {
		Small = small;
	}

	public long getMicro() {
		return Micro;
	}

	public void setMicro(long micro) {
		Micro = micro;
	}

	public long getNano() {
		return Nano;
	}

	public void setNano(long nano) {
		Nano = nano;
	}

	public long getOther() {
		return Other;
	}

	public void setOther(long other) {
		Other = other;
	}

}
