package com.citi.aqua.cba.model;

/**
 * @author gp58292
 *
 */
public class BulkExceptionResponse {

	private int exception_id;
	private String operation_status;
	private int operation_status_value;
	private String status;
	private String exception_owner;
	private String comment;
	private String file_name;
	private String updatedby;

	private boolean isError;
	private String errorMessage;

	public int getException_id() {
		return exception_id;
	}

	public void setException_id(int exception_id) {
		this.exception_id = exception_id;
	}

	public String getOperation_status() {
		return operation_status;
	}

	public void setOperation_status(String operation_status) {
		this.operation_status = operation_status;
	}

	public int getOperation_status_value() {
		return operation_status_value;
	}

	public void setOperation_status_value(int operation_status_value) {
		this.operation_status_value = operation_status_value;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getException_owner() {
		return exception_owner;
	}

	public void setException_owner(String exception_owner) {
		this.exception_owner = exception_owner;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public String getFile_name() {
		return file_name;
	}

	public void setFile_name(String file_name) {
		this.file_name = file_name;
	}

	public String getUpdatedby() {
		return updatedby;
	}

	public void setUpdatedby(String updatedby) {
		this.updatedby = updatedby;
	}

	public boolean isError() {
		return isError;
	}

	public void setError(boolean isError) {
		this.isError = isError;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	@Override
	public String toString() {
		return "BulkExceptionResponse [exception_id=" + exception_id
				+ ", operation_status=" + operation_status
				+ ", operation_status_value=" + operation_status_value
				+ ", status=" + status + ", exception_owner=" + exception_owner
				+ ", comment=" + comment + ", file_name=" + file_name
				+ ", updatedby=" + updatedby + ", isError=" + isError
				+ ", errorMessage=" + errorMessage + "]";
	}

}
