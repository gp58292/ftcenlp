package com.citi.aqua.cba.model;

public class UserRole {

	private String user_role;
	private String race_role;
	private boolean all_client;
	private boolean manage_alert;
	private boolean manage_alert_rule;
	private boolean add_admin;

	public String getUser_role() {
		return user_role;
	}

	public void setUser_role(String user_role) {
		this.user_role = user_role;
	}

	public String getRace_role() {
		return race_role;
	}

	public void setRace_role(String race_role) {
		this.race_role = race_role;
	}

	public boolean isAll_client() {
		return all_client;
	}

	public void setAll_client(boolean all_client) {
		this.all_client = all_client;
	}

	public boolean isManage_alert() {
		return manage_alert;
	}

	public void setManage_alert(boolean manage_alert) {
		this.manage_alert = manage_alert;
	}

	public boolean isManage_alert_rule() {
		return manage_alert_rule;
	}

	public void setManage_alert_rule(boolean manage_alert_rule) {
		this.manage_alert_rule = manage_alert_rule;
	}

	public boolean isAdd_admin() {
		return add_admin;
	}

	public void setAdd_admin(boolean add_admin) {
		this.add_admin = add_admin;
	}

}
