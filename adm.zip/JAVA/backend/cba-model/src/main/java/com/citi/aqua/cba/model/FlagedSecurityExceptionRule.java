package com.citi.aqua.cba.model;

public class FlagedSecurityExceptionRule {

	private String security_attribute;
	private String first_date;
	private String first_value;
	private String second_date;
	private String second_value;
	private String change;
	private String change_percent;
	private String composition_percent;
	private String security_type;
	private boolean change_row;

	public String getSecurity_attribute() {
		return security_attribute;
	}

	public void setSecurity_attribute(String security_attribute) {
		this.security_attribute = security_attribute;
	}

	public String getFirst_date() {
		return first_date;
	}

	public void setFirst_date(String first_date) {
		this.first_date = first_date;
	}

	public String getFirst_value() {
		return first_value;
	}

	public void setFirst_value(String first_value) {
		this.first_value = first_value;
	}

	public String getSecond_date() {
		return second_date;
	}

	public void setSecond_date(String second_date) {
		this.second_date = second_date;
	}

	public String getSecond_value() {
		return second_value;
	}

	public void setSecond_value(String second_value) {
		this.second_value = second_value;
	}

	public String getChange() {
		return change;
	}

	public void setChange(String change) {
		this.change = change;
	}

	public String getChange_percent() {
		return change_percent;
	}

	public void setChange_percent(String change_percent) {
		this.change_percent = change_percent;
	}

	public String getComposition_percent() {
		return composition_percent;
	}

	public void setComposition_percent(String composition_percent) {
		this.composition_percent = composition_percent;
	}

	public String getSecurity_type() {
		return security_type;
	}

	public void setSecurity_type(String security_type) {
		this.security_type = security_type;
	}

	public boolean isChange_row() {
		return change_row;
	}

	public void setChange_row(boolean change_row) {
		this.change_row = change_row;
	}

}
