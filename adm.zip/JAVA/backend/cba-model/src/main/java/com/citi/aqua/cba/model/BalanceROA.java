package com.citi.aqua.cba.model;

import java.io.Serializable;

public class BalanceROA implements Serializable {
	
	private static final long serialVersionUID = 1L;

	private String cob_date;
	private Long balance_sheet;
	private Long without_seclending_balsheet;
	private Long pnl;
	private double roa;

	public String getCob_date() {
		return cob_date;
	}

	public void setCob_date(String cob_date) {
		this.cob_date = cob_date;
	}

	public Long getBalance_sheet() {
		return balance_sheet;
	}

	public void setBalance_sheet(Long balance_sheet) {
		this.balance_sheet = balance_sheet;
	}

	public Long getWithout_seclending_balsheet() {
		return without_seclending_balsheet;
	}

	public void setWithout_seclending_balsheet(Long without_seclending_balsheet) {
		this.without_seclending_balsheet = without_seclending_balsheet;
	}

	public Long getPnl() {
		return pnl;
	}

	public void setPnl(Long pnl) {
		this.pnl = pnl;
	}

	public double getRoa() {
		return roa;
	}

	public void setRoa(double roa) {
		this.roa = roa;
	}

}
