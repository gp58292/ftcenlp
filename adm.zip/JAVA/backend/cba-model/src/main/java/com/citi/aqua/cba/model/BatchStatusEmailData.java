package com.citi.aqua.cba.model;

/**
 * @author ak92283
 */
import java.util.List;

public class BatchStatusEmailData {

	private String cobDate;
	private List<BatchStatusDetails> jobData;
	private BatchEmailConfigForm configForm;

	public String getCobDate() {
		return cobDate;
	}

	public void setCobDate(String cobDate) {
		this.cobDate = cobDate;
	}

	public List<BatchStatusDetails> getJobData() {
		return jobData;
	}

	public void setJobData(List<BatchStatusDetails> jobData) {
		this.jobData = jobData;
	}

	/**
	 * @return the configForm
	 */
	public BatchEmailConfigForm getConfigForm() {
		return configForm;
	}

	/**
	 * @param configForm
	 *            the configForm to set
	 */
	public void setConfigForm(BatchEmailConfigForm configForm) {
		this.configForm = configForm;
	}

}
