package com.citi.aqua.cba.model;

public class ChartFilter {

	private Long cob_date;
	private String client;
	private String fund;
	private String region;
	private String type;
	private String soeid;

	public Long getCob_date() {
		return cob_date;
	}

	public void setCob_date(Long cob_date) {
		this.cob_date = cob_date;
	}

	public String getClient() {
		return client;
	}

	public void setClient(String client) {
		this.client = client;
	}

	public String getFund() {
		return fund;
	}

	public void setFund(String fund) {
		this.fund = fund;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getSoeid() {
		return soeid;
	}

	public void setSoeid(String soeid) {
		this.soeid = soeid;
	}

}
