package com.citi.aqua.cba.model;

public class UpdateUserCoverageRequest {

	private String soeid;
	private String gpnum;
	private String updatedby;

	public String getSoeid() {
		return soeid;
	}

	public void setSoeid(String soeid) {
		this.soeid = soeid;
	}

	public String getGpnum() {
		return gpnum;
	}

	public void setGpnum(String gpnum) {
		this.gpnum = gpnum;
	}

	public String getUpdatedby() {
		return updatedby;
	}

	public void setUpdatedby(String updatedby) {
		this.updatedby = updatedby;
	}

}
