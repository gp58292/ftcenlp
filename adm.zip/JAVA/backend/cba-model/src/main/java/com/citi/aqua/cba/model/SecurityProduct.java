package com.citi.aqua.cba.model;

import java.io.Serializable;

public class SecurityProduct implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String cob_date;
	private long Convertibles;
	private long Corporates;
	private long Equities;
	private long Other;
	private long Preferreds;
	private long Sovereigns;
	private long Warrants;

	public String getCob_date() {
		return cob_date;
	}

	public void setCob_date(String cob_date) {
		this.cob_date = cob_date;
	}

	public long getConvertibles() {
		return Convertibles;
	}

	public void setConvertibles(long convertibles) {
		Convertibles = convertibles;
	}

	public long getCorporates() {
		return Corporates;
	}

	public void setCorporates(long corporates) {
		Corporates = corporates;
	}

	public long getEquities() {
		return Equities;
	}

	public void setEquities(long equities) {
		Equities = equities;
	}

	public long getOther() {
		return Other;
	}

	public void setOther(long other) {
		Other = other;
	}

	public long getPreferreds() {
		return Preferreds;
	}

	public void setPreferreds(long preferreds) {
		Preferreds = preferreds;
	}

	public long getSovereigns() {
		return Sovereigns;
	}

	public void setSovereigns(long sovereigns) {
		Sovereigns = sovereigns;
	}

	public long getWarrants() {
		return Warrants;
	}

	public void setWarrants(long warrants) {
		Warrants = warrants;
	}

}
