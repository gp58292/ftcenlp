package com.citi.aqua.cba.model;

import java.io.Serializable;

public class UserToken implements Serializable {

	private static final long serialVersionUID = 1L;

	private String token;
	private boolean isTokenValid;

	/**
	 * @return the token
	 */
	public String getToken() {
		return token;
	}

	/**
	 * @param token
	 *            the token to set
	 */
	public void setToken(String token) {
		this.token = token;
	}

	/**
	 * @return the isTokenValid
	 */
	public boolean isTokenValid() {
		return isTokenValid;
	}

	/**
	 * @param isTokenValid
	 *            the isTokenValid to set
	 */
	public void setTokenValid(boolean isTokenValid) {
		this.isTokenValid = isTokenValid;
	}

}
