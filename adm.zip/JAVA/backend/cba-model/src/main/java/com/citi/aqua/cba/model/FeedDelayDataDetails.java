package com.citi.aqua.cba.model;

/**
 *@author ak92283 
 */
import java.io.Serializable;

public class FeedDelayDataDetails implements Serializable {

	private static final long serialVersionUID = 1L;
	private String name;
	private String sla;
	private String bau;
	private String eta;
	private String flag;

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name
	 *            the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the sla
	 */
	public String getSla() {
		return sla;
	}

	/**
	 * @param sla
	 *            the sla to set
	 */
	public void setSla(String sla) {
		this.sla = sla;
	}

	/**
	 * @return the bau
	 */
	public String getBau() {
		return bau;
	}

	/**
	 * @param bau
	 *            the bau to set
	 */
	public void setBau(String bau) {
		this.bau = bau;
	}

	/**
	 * @return the eta
	 */
	public String getEta() {
		return eta;
	}

	/**
	 * @param eta
	 *            the eta to set
	 */
	public void setEta(String eta) {
		this.eta = eta;
	}

	/**
	 * @return the flag
	 */
	public String getFlag() {
		return flag;
	}

	/**
	 * @param flag
	 *            the flag to set
	 */
	public void setFlag(String flag) {
		this.flag = flag;
	}

}
