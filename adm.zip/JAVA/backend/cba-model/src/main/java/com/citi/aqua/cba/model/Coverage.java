package com.citi.aqua.cba.model;

import java.io.Serializable;

public class Coverage implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private String soeid;
	private String gpnum;
	private String product;
	private String coverer;
	private String coverage_region;
	private String coverage_subregion;
	private String roletype;
	private String Coverage_team;
	private String Client;
	private String coverage_client;
	private String global_priority;
	private String markets_platinum;
	private String source;

	public String getSoeid() {
		return soeid;
	}

	public void setSoeid(String soeid) {
		this.soeid = soeid;
	}

	public String getGpnum() {
		return gpnum;
	}

	public void setGpnum(String gpnum) {
		this.gpnum = gpnum;
	}

	public String getProduct() {
		return product;
	}

	public void setProduct(String product) {
		this.product = product;
	}

	public String getCoverer() {
		return coverer;
	}

	public void setCoverer(String coverer) {
		this.coverer = coverer;
	}

	public String getCoverage_region() {
		return coverage_region;
	}

	public void setCoverage_region(String coverage_region) {
		this.coverage_region = coverage_region;
	}

	public String getCoverage_subregion() {
		return coverage_subregion;
	}

	public void setCoverage_subregion(String coverage_subregion) {
		this.coverage_subregion = coverage_subregion;
	}

	public String getRoletype() {
		return roletype;
	}

	public void setRoletype(String roletype) {
		this.roletype = roletype;
	}

	public String getCoverage_team() {
		return Coverage_team;
	}

	public void setCoverage_team(String coverage_team) {
		Coverage_team = coverage_team;
	}

	public String getClient() {
		return Client;
	}

	public void setClient(String client) {
		Client = client;
	}

	public String getCoverage_client() {
		return coverage_client;
	}

	public void setCoverage_client(String coverage_client) {
		this.coverage_client = coverage_client;
	}

	public String getGlobal_priority() {
		return global_priority;
	}

	public void setGlobal_priority(String global_priority) {
		this.global_priority = global_priority;
	}

	public String getMarkets_platinum() {
		return markets_platinum;
	}

	public void setMarkets_platinum(String markets_platinum) {
		this.markets_platinum = markets_platinum;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

}
