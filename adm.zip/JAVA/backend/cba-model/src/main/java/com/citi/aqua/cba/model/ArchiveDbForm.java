package com.citi.aqua.cba.model;

import java.io.Serializable;

/**
 * @author ak92283
 *
 */
public class ArchiveDbForm implements Serializable {

	private static final long serialVersionUID = 1L;
	public Long id;
	public String sourceDB;
	public String sourceTable;
	public String destDB;
	public String destTable;
	public String queryColumn;
	public Integer archiveFlag;
	public Integer archiveDays;
	public Integer deleteFlag;
	public Integer deleteDays;
	public Integer desiredBatchSize;
	public String exclusionRule_Archiving;
	public String exclusionRule_Purging;
	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}
	/**
	 * @return the sourceDB
	 */
	public String getSourceDB() {
		return sourceDB;
	}
	/**
	 * @param sourceDB the sourceDB to set
	 */
	public void setSourceDB(String sourceDB) {
		this.sourceDB = sourceDB;
	}
	/**
	 * @return the sourceTable
	 */
	public String getSourceTable() {
		return sourceTable;
	}
	/**
	 * @param sourceTable the sourceTable to set
	 */
	public void setSourceTable(String sourceTable) {
		this.sourceTable = sourceTable;
	}
	/**
	 * @return the destDB
	 */
	public String getDestDB() {
		return destDB;
	}
	/**
	 * @param destDB the destDB to set
	 */
	public void setDestDB(String destDB) {
		this.destDB = destDB;
	}
	/**
	 * @return the destTable
	 */
	public String getDestTable() {
		return destTable;
	}
	/**
	 * @param destTable the destTable to set
	 */
	public void setDestTable(String destTable) {
		this.destTable = destTable;
	}
	/**
	 * @return the queryColumn
	 */
	public String getQueryColumn() {
		return queryColumn;
	}
	/**
	 * @param queryColumn the queryColumn to set
	 */
	public void setQueryColumn(String queryColumn) {
		this.queryColumn = queryColumn;
	}
	/**
	 * @return the archiveFlag
	 */
	public Integer getArchiveFlag() {
		return archiveFlag;
	}
	/**
	 * @param archiveFlag the archiveFlag to set
	 */
	public void setArchiveFlag(Integer archiveFlag) {
		this.archiveFlag = archiveFlag;
	}
	/**
	 * @return the archiveDays
	 */
	public Integer getArchiveDays() {
		return archiveDays;
	}
	/**
	 * @param archiveDays the archiveDays to set
	 */
	public void setArchiveDays(Integer archiveDays) {
		this.archiveDays = archiveDays;
	}
	/**
	 * @return the deleteFlag
	 */
	public Integer getDeleteFlag() {
		return deleteFlag;
	}
	/**
	 * @param deleteFlag the deleteFlag to set
	 */
	public void setDeleteFlag(Integer deleteFlag) {
		this.deleteFlag = deleteFlag;
	}
	/**
	 * @return the deleteDays
	 */
	public Integer getDeleteDays() {
		return deleteDays;
	}
	/**
	 * @param deleteDays the deleteDays to set
	 */
	public void setDeleteDays(Integer deleteDays) {
		this.deleteDays = deleteDays;
	}
	/**
	 * @return the desiredBatchSize
	 */
	public Integer getDesiredBatchSize() {
		return desiredBatchSize;
	}
	/**
	 * @param desiredBatchSize the desiredBatchSize to set
	 */
	public void setDesiredBatchSize(Integer desiredBatchSize) {
		this.desiredBatchSize = desiredBatchSize;
	}
	/**
	 * @return the exclusionRule_Archiving
	 */
	public String getExclusionRule_Archiving() {
		return exclusionRule_Archiving;
	}
	/**
	 * @param exclusionRule_Archiving the exclusionRule_Archiving to set
	 */
	public void setExclusionRule_Archiving(String exclusionRule_Archiving) {
		this.exclusionRule_Archiving = exclusionRule_Archiving;
	}
	/**
	 * @return the exclusionRule_Purging
	 */
	public String getExclusionRule_Purging() {
		return exclusionRule_Purging;
	}
	/**
	 * @param exclusionRule_Purging the exclusionRule_Purging to set
	 */
	public void setExclusionRule_Purging(String exclusionRule_Purging) {
		this.exclusionRule_Purging = exclusionRule_Purging;
	}

}
