package com.citi.aqua.cba.data.domain.cba;

/**
 * Created by jm27909 on 6/29/2017.
 */
public class AquaCoreUserEntitlement {

    private String soeid;
    private String name;
    private String permission_level;

    public String getSoeid() {
        return soeid;
    }

    public void setSoeid(String soeid) {
        this.soeid = soeid;
    }

    public String getPermission_level() {
        return permission_level;
    }

    public void setPermission_level(String permission_level) {
        this.permission_level = permission_level;
    }
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
