package com.citi.aqua.cba.data.mapper.cba;

import java.util.List;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.mapping.StatementType;
import org.springframework.cache.annotation.Cacheable;


import com.citi.aqua.cba.model.BulkExceptionRequest;
import com.citi.aqua.cba.model.BulkExceptionResponse;
import com.citi.aqua.cba.model.ExceptionOwnerChart;
import com.citi.aqua.cba.model.ExceptionStatusChart;
import com.citi.aqua.cba.model.ExoportAlerts;
import com.citi.aqua.cba.model.FlagedSecurityExceptionRule;
import com.citi.aqua.cba.model.FlaggedException;
import com.citi.aqua.cba.model.UserFile;

public interface ExceptionSummaryMapper {

	//@Cacheable(cacheNames="ewsCacheExceptions")
	@Select(value = "{call usp_get_all_flaged_exceptionrule(#{soeid})}")
	@Options(statementType = StatementType.CALLABLE)
	public List<FlaggedException> getAllFlaggedExceptions( @Param("soeid") String soeid);
	
	
	@Select(value = "{call usp_get_flaged_exceptionrule_id(#{exception_id})}")
	@Options(statementType = StatementType.CALLABLE)
	public List<FlaggedException> getFlaggedException(@Param("exception_id") Long exception_id);
	
	
	@Select(value = "{call dbo.usp_exception_activity_update(#{exception_id},#{exception_activity_id},#{status},#{comment},#{exception_owner},#{updatedby},#{exception_activity_id,mode=OUT,jdbcType=VARCHAR}"+")}")
	@Options(statementType = StatementType.CALLABLE)
	public void updateFlaggedExceptions(FlaggedException flaggedException);
	
	@Insert("INSERT into tbl_fact_user_file(exception_activity_id,file_name,file_object,create_user) VALUES(#{exception_activity_id}, #{file_name},#{file_object},#{create_user})")
	public void updateFlaggedExceptionFile(UserFile userFile);

//	@Select("{call usp_exception_activity_insert_file(#{exception_activity_id}, #{file_name},#{file_object},#{create_user})}")
//	public void UpdateFlaggedExceptionFile(UserFile userFile);
	
	@Select("select * from tbl_fact_user_file where exception_activity_id=#{exception_activity_id} AND file_name=#{file_name}")
	public UserFile getFile(@Param("exception_activity_id")Long exception_activity_id,@Param("file_name")String file_name);
	
	@Cacheable("ewsCache")
	@Results({
		@Result(property="date",column="cob_date"),
		@Result(property="exceptions",column="exception"),
		@Result(property="resolved",column="resolved"),
		@Result(property="review",column="under_review"),
		@Result(property="reassigned",column="reassigned"),
		@Result(property="open",column="open"),
	})
	@Select(value="{call usp_get_exception_graphdata_by_status}")
	public List<ExceptionStatusChart> getExceptionStatusChart();
	
	@Cacheable("ewsCache")
	@Results({
		@Result(property="client",column="client"),
		@Result(property="open",column="open"),
		@Result(property="underreview",column="UnderReview"),
		@Result(property="reassigned",column="Re-Assigned"),
	})
	@Select(value="{call usp_get_exception_graphdata_by_client}")
	public List<ExceptionOwnerChart> getExceptionOwnerChart();
	
	
	@Select(value="{call usp_get_flaged_security_exceptionrule_id("+"#{exception_id}"+")}")
	public List<FlagedSecurityExceptionRule> getFlagedSecurityExceptionRule(@Param("exception_id") Long exception_id);
	
	@Cacheable("ewsCache")
	@Select("SELECT lower(soeid)  FROM dbo.[tbl_user]  WHERE status='ACTIVE'  "
			+ " AND race_role<>'view_only' AND (all_client=1  OR soeid IN (  SELECT  DISTINCT a.soeid "
			+ " FROM [dbo].[tbl_user_aqua_coverage_based] a "
			+ " INNER JOIN [dbo].[tbl_exception_rule_clientfund_master]  b  ON a.gp=b.gpnum "
			+ " INNER JOIN [dbo].[tbl_fact_exception] ex  ON ex.client=b.client "
			+ " WHERE ex.exception_id  = #{exception_id}  UNION    SELECT  DISTINCT a.userId "
			+ " FROM CBA.[dbo].[SV_Coverage] a  INNER JOIN [dbo].[tbl_exception_rule_clientfund_master]  b "
			+ " ON a.gpnum=b.gpnum  INNER JOIN [dbo].[tbl_fact_exception] ex  ON ex.client=b.client "
			+ " WHERE ex.exception_id  = #{exception_id}))")
	public List<String> getAssigneeList(@Param("exception_id") Long exception_id);
	
	@Select(value="{call usp_get_exception_user_assignment_list(#{exception_id,mode=IN},#{soeid,mode=IN})}")
	@Options(statementType = StatementType.CALLABLE)
	public boolean isUserUnderCoverage(@Param("exception_id") Long exception_id,@Param("soeid") String soeid); 
	
/*	@Select(value="{#{returnVal}=call usp_get_exception_user_assignment_list(#{exception_id,mode=IN},#{soeid,mode=IN})}") 
    @Options(statementType = StatementType.CALLABLE)
    public boolean isUserUnderCoverage(@Param("exception_id") Long exception_id,@Param("soeid") String soeid); */

	
	@Select(value="{call usp_get_all_flaged_exceptionrule_export(#{soeid}, #{search_id}, #{search_text})}")
	@Options(statementType = StatementType.CALLABLE)
	public List<ExoportAlerts> exportAlertRules(@Param("soeid") String soeid,@Param("search_id") int search_id,@Param("search_text") String search_text);
	
	@Select(value = "{call dbo.usp_exception_activity_update_bulk_master(#{exception_id_list},#{status},#{comment},#{exception_owner},#{updatedby},#{file_name},#{file_object})}")
	@Options(statementType = StatementType.CALLABLE)
	public List<BulkExceptionResponse> bulkUpdateFlaggedExceptions(BulkExceptionRequest bulkExceptionRequest);
}
