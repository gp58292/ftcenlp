package com.citi.aqua.cba.data.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.citi.aqua.cba.data.cyberarc.CyberArcFactory;
import com.jolbox.bonecp.BoneCPDataSource;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.DependsOn;

@Configuration
public class DataSourceConfig {

	@Autowired
	CyberArcFactory cyberArcFactory;

	@Bean("ewsDataSource")
	@DependsOn("cyberArc")
	public BoneCPDataSource createEwsDataSource(@Value("${ews.datasource.driverClassName}") final String driverClass,
			@Value("${ews.datasource.url}") final String ewsUrl,
			@Qualifier("cyberArc") CyberArcFactory cyberArcFactory) {
		BoneCPDataSource dataSource = new BoneCPDataSource();
		dataSource.setDriverClass(driverClass);
		dataSource.setJdbcUrl(ewsUrl);
		dataSource.setUser(cyberArcFactory.getNonCoreUsername());
		dataSource.setPassword(cyberArcFactory.getNonCorePwd());
		return dataSource;
	}

	@Bean("cbaDataSource")
	@DependsOn("cyberArc")
	public BoneCPDataSource createCbaDataSource(@Value("${cba.datasource.driverClassName}") final String driverClass,
			@Value("${cba.datasource.url}") final String cbaUrl,
			@Qualifier("cyberArc") CyberArcFactory cyberArcFactory) {
		BoneCPDataSource dataSource = new BoneCPDataSource();
		dataSource.setDriverClass(driverClass);
		dataSource.setJdbcUrl(cbaUrl);
		dataSource.setUser(cyberArcFactory.getNonCoreUsername());
		dataSource.setPassword(cyberArcFactory.getNonCorePwd());
		return dataSource;
	}

	@Bean("futureDataSource")
	@DependsOn("cyberArc")
	public BoneCPDataSource createFuturesDataSource(
			@Value("${future.datasource.driverClassName}") final String driverClass,
			@Value("${future.datasource.url}") final String cbaUrl,
			@Qualifier("cyberArc") CyberArcFactory cyberArcFactory) {
		BoneCPDataSource dataSource = new BoneCPDataSource();
		dataSource.setDriverClass(driverClass);
		dataSource.setJdbcUrl(cbaUrl);
		dataSource.setUser(cyberArcFactory.getNonCoreUsername());
		dataSource.setPassword(cyberArcFactory.getNonCorePwd());
		return dataSource;
	}

	@Bean("pnlDataSource")
	@DependsOn("cyberArc")
	public BoneCPDataSource createPnlDataSource(@Value("${pnl.datasource.driverClassName}") final String driverClass,
			@Value("${pnl.datasource.url}") final String cbaUrl,
			@Qualifier("cyberArc") CyberArcFactory cyberArcFactory) {
		BoneCPDataSource dataSource = new BoneCPDataSource();
		dataSource.setDriverClass(driverClass);
		dataSource.setJdbcUrl(cbaUrl);
		dataSource.setUser(cyberArcFactory.getNonCoreUsername());
		dataSource.setPassword(cyberArcFactory.getNonCorePwd());
		return dataSource;
	}

	@Bean("emtDataSource")
	@DependsOn("cyberArc")
	public BoneCPDataSource createEMTDataSource(@Value("${emt.datasource.driverClassName}") final String driveClass,
			@Value("${emt.datasource.url}") final String ewsUrl,
			@Qualifier("cyberArc") CyberArcFactory cyberArcFactory) {
		BoneCPDataSource cpd = new BoneCPDataSource();
		cpd.setDriverClass(driveClass);
		cpd.setJdbcUrl(ewsUrl);
		cpd.setUser(cyberArcFactory.getCoreUsername());
		cpd.setPassword(cyberArcFactory.getCorePwd());
		return cpd;
	}
}
