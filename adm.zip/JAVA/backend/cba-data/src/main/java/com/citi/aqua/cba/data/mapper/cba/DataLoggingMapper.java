package com.citi.aqua.cba.data.mapper.cba;
/**
 * @author: jm27909
 *
 * 
 */
import java.util.List;

import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.mapping.StatementType;

import com.citi.aqua.cba.model.DataLogging;


public interface DataLoggingMapper {

	@Select(value = "{call CBA.audit.usp_data_logging("+"#{cbaProc},"+"#{raceProc},"+"#{futureProc},"+"#{slProc},"+" #{numberOfRows}"+")}")
	@Options(statementType = StatementType.CALLABLE)
	public List<DataLogging> searchDBAndStoreProcedure(@Param("cbaProc")String cbaProc,
			@Param("raceProc")String raceProc,
			@Param("futureProc")String futureProc,
			@Param("slProc")String slProc,
			@Param("numberOfRows") int numberOfRows);

	@Select(value = "{call CBA.audit.usp_data_logging_db_only("+"#{cbaDB},"+"#{raceDB},"+"#{futureDB},"+"#{slDB},"+" #{numberOfRows}"+")}")
	@Options(statementType = StatementType.CALLABLE)
	public List<DataLogging> searchDB(@Param("cbaDB")String cbaDB,
			@Param("raceDB")String raceDB,
			@Param("futureDB")String futureDB,
			@Param("slDB")String slDB,
			@Param("numberOfRows") int numberOfRows);

	@Select(
			"SELECT name FROM [CBA].[sys].[procedures] where name LIKE #{cbaquery}\n" +
			"UNION \n" +
			"SELECT name FROM [RACE].[sys].[procedures] where name LIKE #{racequery}\n" +
			"UNION\n" +
			"SELECT name FROM FUTURE.[sys].[procedures] where name LIKE #{futurequery}\n" +
			"UNION \n" +
			"SELECT name FROM SL.[sys].[procedures] where name LIKE #{slquery}\n" +

			"")
	public List<String> filterProcList(@Param("cbaquery")String cbaquery,@Param("racequery")String racequery,@Param("futurequery")String futurequery,@Param("slquery")String slquery);

}
