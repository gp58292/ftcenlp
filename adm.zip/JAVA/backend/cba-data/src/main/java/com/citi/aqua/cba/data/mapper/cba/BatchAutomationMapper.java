package com.citi.aqua.cba.data.mapper.cba;

import java.util.List;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.mapping.StatementType;

import com.citi.aqua.cba.model.BatchConfigParams;
import com.citi.aqua.cba.model.FeedDelayData;
import com.citi.aqua.cba.model.FeedDelayDataDetails;

public interface BatchAutomationMapper {

	// Get list of delay sources
	@Select("select feed_source from [CBA].batch.[tbl_batch_feed_stream] where feed_source is not null")
	public List<String> getDelaySources();

	// insert feed delay information
	@Insert("INSERT INTO [CBA].[batch].[tbl_batch_delay] ( issue, source_issue, area_impacted, eta_resolution, inc_mim, next_update, description, updated_by, update_time,cobdate) "
			+ "VALUES (#{issue},#{source_issue},#{area_impacted},#{eta_resolution},#{inc_mim},#{next_update},#{description},'AK92283',null,#{cobdate})")
	public Boolean insertFeedDelayData(FeedDelayData delayData);

	@Select("select feed_name from [CBA].batch.tbl_batch_feed_stream where feed_source = #{feedSource}")
	public String findJobName(@Param("feedSource") String feedSource);

	@Select("select batch_id from [CBA].batch.[tbl_batch_feed_stream] where feed_source = #{feed_source}")
	public Integer getJobId(@Param("feed_source") String feedSource);

	@Select("select eta from  [CBA].batch.[tbl_batch_delay] where batch_Delay_id in (select max(batch_delay_id) from [CBA].batch.[tbl_batch_delay])")
	public String findEtaByMaxBatchDelayId();

	@Select("update CBA.Batch.tbl_batch_master set expected_completion='00:00:00' ")
	public void updateETAEntries();

	@Select("{call CBA.Batch.usp_calculate_time( #{jobid, javaType=Integer, jdbcType=INTEGER, mode=IN},#{expected_arrival, javaType=String, jdbcType=TIME, mode=IN} )}")
	@Options(statementType = StatementType.CALLABLE)
	public void provideFeedDelayInfo(@Param("jobid") Integer jobid, @Param("expected_arrival") String expected_arrival);

	@Select("{call CBA.Batch.usp_extract_batch_details()}")
	@Options(statementType = StatementType.CALLABLE)
	public void updateDelayInformationForETA();

	@Select("{call CBA.Batch.usp_get_batch_deliverydetail(#{type})}")
	@Options(statementType = StatementType.CALLABLE)
	public List<FeedDelayDataDetails> getDelayInformationForETA(@Param("type") String type);

	@Select(value = "{call CBA.dbo.usp_batch_get_COB_date()}")
	@Options(statementType = StatementType.CALLABLE)
	public String getCOBDate();

	@Select("select  calendarId from CBA.dbo.Process_Date order by 1 desc")
	public List<Long> getCOBDateList();

	// insert email config information
	@Insert("INSERT INTO [CBA].[Batch].[tbl_email_config]  ( mail_to, mail_from, mail_cc, mail_bcc, subject, type,update_time,update_type ) "
			+ "VALUES (#{mail_to},#{mail_from},#{mail_cc},#{mail_bcc},#{subject},#{type},null,#{update_type})")
	public Boolean insertBatchConfigData(BatchConfigParams configParams);

	@Select("select * from [CBA]. [Batch].[tbl_email_config] where config_id in (select max(config_id) from [CBA].[Batch].[tbl_email_config] group by type)")
	public List<BatchConfigParams> getEmailConfigList();

	@Select("select * from [CBA].[batch].[tbl_batch_delay] order by batch_delay_id desc")
	public List<FeedDelayData> getDelayList();
	
	@Select("select * from [CBA].[batch].[tbl_batch_delay] where cobdate=#{cobdate} order by batch_delay_id desc")
	public List<FeedDelayData> getDelayListForCobDate(@Param("cobdate") String cobdate);

	@Select("select * from cba.[Batch].[tbl_email_config] u1 where u1.config_id = (select max(config_id) from  cba.[Batch].[tbl_email_config] u2 where u2.type='DN' );")
	public BatchConfigParams getDNConfig();

	@Select("select * from cba.[Batch].[tbl_email_config] u1 where u1.config_id = (select max(config_id) from  cba.[Batch].[tbl_email_config] u2 where u2.type='UN' );")
	public BatchConfigParams getUNConfig();
	
	@Select("select * from cba.[Batch].[tbl_email_config] u1 where u1.config_id = (select max(config_id) from  cba.[Batch].[tbl_email_config] u2 where u2.type='BS' );")
	public BatchConfigParams getBSConfig();

}
