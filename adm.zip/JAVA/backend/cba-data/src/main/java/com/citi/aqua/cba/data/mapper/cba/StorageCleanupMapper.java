package com.citi.aqua.cba.data.mapper.cba;

/**
 * Created by jm27909 on 8/15/2017.
 */
public interface StorageCleanupMapper {

}
