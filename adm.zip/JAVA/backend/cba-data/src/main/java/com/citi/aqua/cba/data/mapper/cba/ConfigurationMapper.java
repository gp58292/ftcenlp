package com.citi.aqua.cba.data.mapper.cba;

import java.util.List;

import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.apache.ibatis.mapping.StatementType;

import com.citi.aqua.cba.model.ArchiveDbForm;
import com.citi.aqua.cba.model.ArchiveFileForm;

public interface ConfigurationMapper {

	@Select("{call CBA.[archive].[usp_get_archive_file_config]()}")
	@Options(statementType = StatementType.CALLABLE)
	public List<ArchiveFileForm> getArchiveFiles();

	@Select("{call CBA.[archive].[usp_get_archive_db_config]()}")
	@Options(statementType = StatementType.CALLABLE)
	public List<ArchiveDbForm> getArchiveDb();

	@Update("UPDATE cba.archive.tbl_config_archive_file SET dateFormat= #{dateFormat}, dateSearchParameter= #{dateSearchParameter}, "
			+ "fileNamePattern= #{fileNamePattern}, sourcePath= #{sourcePath}, archivePath= #{archivePath}, purgePath= #{purgePath}, "
			+ "archiveFlag= #{archiveFlag}, archiveDays= #{archiveDays}, deleteFlag= #{deleteFlag}, deleteDays = #{deleteDays},"
			+ "archive_ExclusionRule= #{archive_ExclusionRule}, purging_ExclusionRule= #{purging_ExclusionRule}, readyFilePattern = #{readyFilePattern} WHERE id = #{id} ")
	public Boolean updateArchiveFile(final ArchiveFileForm archiveFileForm);

	@Update("UPDATE cba.archive.tbl_config_archive_db SET sourceDB = #{sourceDB}, "
			+ "sourceTable = #{sourceTable},destDB = #{destDB},destTable = #{destTable},"
			+ "queryColumn = #{queryColumn},archiveFlag = #{archiveFlag},archiveDays = #{archiveDays},"
			+ "deleteFlag = #{deleteFlag},deleteDays = #{deleteDays},desiredBatchSize = #{desiredBatchSize},"
			+ "exclusionRule_Archiving = #{exclusionRule_Archiving},exclusionRule_Purging = #{exclusionRule_Purging} WHERE id = #{id} ")
	public Boolean updateArchiveDb(final ArchiveDbForm archiveDbForm);

	@Select(value = "{call CBA.[archive].[usp_insert_into_archive_file_config] (#{dateFormat},#{dateSearchParameter},#{fileNamePattern},#{sourcePath},#{archivePath},#{purgePath},#{archiveFlag},#{archiveDays},#{deleteFlag},#{deleteDays},#{archive_ExclusionRule},#{purging_ExclusionRule},#{readyFilePattern}) }")
	@Options(statementType = StatementType.CALLABLE)
	public void insertFileArchiveRecord(final ArchiveFileForm archiveFileForm);

	@Select(value = "{call CBA.[archive].usp_insert_into_archive_DB_config(#{sourceDB},#{sourceTable},#{destDB},#{destTable},#{queryColumn},#{archiveFlag},#{archiveDays},#{deleteFlag},#{deleteDays},#{desiredBatchSize}, #{exclusionRule_Archiving},#{exclusionRule_Purging})}")
	@Options(statementType = StatementType.CALLABLE)
	public void insertDbArchiveRecord(final ArchiveDbForm archiveDbForm);

}
