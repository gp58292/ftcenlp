package com.citi.aqua.cba.data.mapper;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;

/**
 * Created by ag52020 on 1/4/2016.
 */
@Configuration
@ImportResource({
	//"classpath:application-context-datasource-race.xml",
	"classpath:application-context-datasource-pnl.xml",
	"classpath:application-context-datasource-cba.xml",
	//"classpath:application-context-datasource-future.xml",
	//"classpath:application-context-datasource-sl.xml"
	})
public class DBConfiguration  {
}
