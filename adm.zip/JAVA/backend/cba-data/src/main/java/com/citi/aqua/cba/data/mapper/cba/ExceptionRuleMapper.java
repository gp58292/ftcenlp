package com.citi.aqua.cba.data.mapper.cba;

import java.util.List;

import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.mapping.StatementType;

import com.citi.aqua.cba.model.AlertRules;
import com.citi.aqua.cba.model.DropDownModel;
import com.citi.aqua.cba.model.ExceptionMasters;
import com.citi.aqua.cba.model.ExceptionRule;
import com.citi.aqua.cba.model.FlaggedException;
import com.citi.aqua.cba.model.MasterData;

public interface ExceptionRuleMapper {

	@Results({ @Result(property = "value", column = "client_id"), @Result(property = "text", column = "client"), })
	@Select("select distinct client_id, client from tbl_exception_rule_clientfund_master order by client")
	// @Options(useCache=true)
	public List<DropDownModel> getClientListByEntity();

	@Select("{call usp_get_client_fund_region_filter_by_soeid(#{soeid})}")
	@Options(statementType = StatementType.CALLABLE)
	public List<MasterData> getMasters(@Param("soeid") String soeid);

	@Results({ @Result(property = "value", column = "fund_id"), @Result(property = "text", column = "fund"), })
	@Select("select distinct fund_id,fund from tbl_exception_rule_clientfund_master WHERE  client_id =#{client}")
	
	public List<DropDownModel> getFundListByClientEntity(@Param("client") String client);

	@Results({ @Result(property = "value", column = "entity_id"), @Result(property = "text", column = "entity"), })
	@Select("select distinct entity_id,entity from tbl_exception_rule_clientfund_master WHERE  client_id =#{client} AND fund_id=#{fund}")
	public List<DropDownModel> getLegalEntities(@Param("client") String client, @Param("fund") String fund);

	@Results({ @Result(property = "value", column = "region_id"), @Result(property = "text", column = "region"), })
	@Select("select distinct region_id, region from tbl_exception_rule_clientfund_master  WHERE  client_id =#{client} AND fund_id=#{fund} AND entity_id=#{entity}")
	public List<DropDownModel> getRegions(@Param("client") String client, @Param("fund") String fund,
			@Param("entity") String entity);

	@Results({ @Result(property = "value", column = "value"), @Result(property = "text", column = "name"),
			@Result(property = "type", column = "type"), })
	@Select("select name,value,type from tbl_dim_exception_rule_master where  is_active=1")
	public List<ExceptionMasters> getMasterList();

	@Results({ @Result(property = "value", column = "value"), @Result(property = "text", column = "name"), })
	@Select("select name,value from tbl_dim_exception_rule_master where type=#{type} and is_active=1")
	public List<DropDownModel> getMaster(String type);

	@Results({ @Result(property = "value", column = "datatype_id"),
			@Result(property = "text", column = "exception_rule_datatype"), })
	@Select("select datatype_id,exception_rule_datatype from tbl_dim_exception_rule_datatype where is_active=1")
	public List<DropDownModel> getMeasures();

	@Select(value = "{call usp_exception_rule_insert(" + "0, " + "#{ExceptionRuleType}, " + "#{ExceptionPriority}, "
			+ "#{LegalEntity}, " + "#{Client}, " + "#{region}," + "#{fund}, " + "country, " + "product, "
			+ "#{ExceptionRuleTimePeriod}, " + "#{aggregation_level} , " + "#{ExceptionComments}, "
			+ "#{ExceptionRuleDataType}, " + "#{threshold_dollar}," + "#{threshold_percent}," + "#{ExceptionStatus},"
			+ "#{RuleOwner}," + "#{RuleOwner},#{alert_assignee})}")
	@Options(statementType = StatementType.CALLABLE)
	public void AddExceptionRule(ExceptionRule exceptionRule);

	@Select(value = "{call usp_exception_rule_insert(" + "#{ExceptionRuleId}," + "#{ExceptionRuleType}, "
			+ "#{ExceptionPriority}, " + "#{LegalEntity}, " + "#{Client}, " + "#{region}, " + "#{fund}, " + "country, "
			+ "product, " + "#{ExceptionRuleTimePeriod}, " + "#{aggregation_level} , " + "#{ExceptionComments}, "
			+ "#{ExceptionRuleDataType}, " + "#{threshold_dollar}," + "#{threshold_percent}," + "#{ExceptionStatus},"
			+ "#{RuleOwner}," + "#{RuleOwner},#{alert_assignee})}")
	@Options(statementType = StatementType.CALLABLE)
	public void UpdateExceptionRule(ExceptionRule exceptionRule);

	@Results({ @Result(property = "ExceptionRuleId", column = "rule_id"),
			@Result(property = "rule_group_id", column = "rule_group_id"),
			@Result(property = "ExceptionRuleType", column = "type"),
			@Result(property = "ExceptionPriority", column = "priority"),
			@Result(property = "LegalEntity", column = "legal_entity"), @Result(property = "Client", column = "client"),
			@Result(property = "Region", column = "region"), @Result(property = "RegionName", column = "region_name"),
			@Result(property = "Fund", column = "fund"),
			@Result(property = "ExceptionRuleTimePeriod", column = "rule_period"),
			@Result(property = "ExceptionComments", column = "description"),
			@Result(property = "ExceptionRuleDataType", column = "measure"),
			@Result(property = "ExceptionRuleLimits", column = "limit"),
			@Result(property = "ExceptionStatus", column = "is_active"),
			@Result(property = "UpdatedBy", column = "create_user"),


	})
	@Select(value = "{call usp_get_allexceptionrule(" + "#{soeid}" + ")}")
	@Options(statementType = StatementType.CALLABLE)
	public List<ExceptionRule> GetAllExceptionRules(@Param("soeid") String soeid);

	@Results({ @Result(property = "ExceptionRuleId", column = "rule_id"),
			@Result(property = "rule_group_id", column = "rule_group_id"),
			// @Result(property="value",column="version_id"),
			@Result(property = "ExceptionRuleType", column = "type"),
			@Result(property = "ExceptionRuleTypeName", column = "type_name"),
			@Result(property = "ExceptionPriority", column = "priority"),
			@Result(property = "ExceptionPriorityName", column = "priority_name"),
			@Result(property = "LegalEntity", column = "entity_id"),
			@Result(property = "LegalEntityName", column = "legal_entity"),
			@Result(property = "Client", column = "client_id"), @Result(property = "ClientName", column = "client"),
			@Result(property = "RegionName", column = "region"), @Result(property = "Region", column = "region_id"),
			@Result(property = "Fund", column = "fund_id"), @Result(property = "FundName", column = "fund"),
			@Result(property = "ExceptionRuleTimePeriod", column = "rule_period"),
			@Result(property = "ExceptionRuleTimePeriodName", column = "rule_period_name"),
			@Result(property = "ExceptionComments", column = "description"),
			@Result(property = "ExceptionRuleDataType", column = "measure"),
			@Result(property = "ExceptionRuleDataTypeName", column = "measure_name"),
			@Result(property = "ExceptionRuleLimits", column = "limit"),
			@Result(property = "ExceptionStatus", column = "is_active"),
			@Result(property = "ExceptionStatusName", column = "is_active_Name"),
			@Result(property = "UpdatedBy", column = "create_user"),
		

	})
	@Select(value = "{call usp_get_exceptionrule_id(" + "#{id}" + ")}")
	@Options(statementType = StatementType.CALLABLE)
	public List<ExceptionRule> GetExceptionRule(@Param("id") Long id);

	@Results({ @Result(property = "rule_id", column = "rule_id"),
			@Result(property = "exception_id", column = "exception_id"),
			@Result(property = "exception_activity_id", column = "exception_activity_id"),
			@Result(property = "version_id", column = "version_id"), @Result(property = "type", column = "type"),
			@Result(property = "client", column = "client"), @Result(property = "region", column = "region"),
			@Result(property = "cob_date", column = "cob_date"), @Result(property = "open_date", column = "open_date"),
			@Result(property = "age", column = "age"),
			@Result(property = "first_date", column = "first_date"),
			@Result(property = "first_value", column = "first_value"),
			@Result(property = "second_date", column = "second_date"),
			@Result(property = "second_value", column = "second_value"),
			@Result(property = "delta", column = "delta"), })
	@Select(value = "{call usp_get_all_flaged_open_exception(#{id},#{soeid})}")
	@Options(statementType = StatementType.CALLABLE)
	public List<FlaggedException> getAlerts(@Param("id") Long id,@Param("soeid") String soeid);

	@Results({ @Result(property = "value", column = "soeid"), @Result(property = "text", column = "friendly_name"), })
	@Select("SELECT soeid,friendly_name FROM dbo.[tbl_user] where status= 'Active'") // WHERE soeid
																// LIKE '%' +
																// #{term} + '%'
																// OR
																// friendly_name
																// LIKE '%' +
																// #{term} +
																// '%'")
	public List<DropDownModel> getUsers();

	@Select("SELECT friendly_name FROM dbo.[tbl_user] WHERE soeid LIKE '%' + #{term} + '%' OR friendly_name LIKE '%' + #{term} + '%'")
	public List<String> getUser(@Param("term") String term);
	
	@Results({ @Result(property = "value", column = "soeid"), @Result(property = "text", column = "friendly_name"), })
	@Select(value="{call usp_get_rule_user_assignment_list(#{rule_type_id},#{client_id})}")
	public List<DropDownModel> usp_get_rule_user_assignment_list(@Param("rule_type_id") Long rule_type_id ,@Param("client_id") Long client_id );	
	
	
	@Select(
			" SELECT DISTINCT rule_group_id 	FROM tbl_dim_exception_rule 	" +
			" 	WHERE 	type 			=   #{type}  							" +
			"	AND 	client 			= 	#{client}                           " +  
			"	AND 	fund 			= 	#{fund }                            " +
			"	AND 	legal_entity 	= 	#{legal_entity}                     " +  		
			"	AND 	region 			= 	#{region}                           " +  		
			"	AND 	aggregation_level = #{aggregation_level } 				" +
			"	AND 	measure 		= 	#{exception_rule_datatype}          " +
			"	AND 	rule_period 	= 	#{rule_period } 					" +
			"	AND 	is_latest 	= 	'Y'					" 	
			)
	
	public List<Integer> getExceptionRuleByModel(
			@Param("type") String type,
			@Param("priority") String priority,
			@Param("legal_entity") String legal_entity,
			@Param("client") String client,
			@Param("region") String region,
			@Param("fund") String fund,
			@Param("rule_period") String rule_period,
			@Param("aggregation_level") String aggregation_level,
			@Param("exception_rule_datatype") String exception_rule_datatype,
			@Param("threshold_dollar") Long threshold_dollar);	
	
	@Select(value="{call usp_get_allexceptionrule_export(#{soeid}, #{search_text})}")
	@Options(statementType = StatementType.CALLABLE)
	public List<AlertRules> exportAlertRules(@Param("soeid") String soeid,@Param("search_text") String search_text);

}
