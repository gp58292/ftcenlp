package com.citi.aqua.cba.data.cyberarc;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javapasswordsdk.PSDKPassword;
import javapasswordsdk.PSDKPasswordRequest;
import javapasswordsdk.exceptions.PSDKException;

@Component
public class CyberArcFactory {

	private static Logger log = LoggerFactory.getLogger(CyberArcFactory.class);

	private String coreUsername;
	private String corePwd;

	private String nonCoreUsername;
	private String nonCorePwd;

	/**
	 * @return the coreUsername
	 */
	public String getCoreUsername() {
		return coreUsername;
	}

	/**
	 * @param coreUsername
	 *            the coreUsername to set
	 */
	public void setCoreUsername(String coreUsername) {
		this.coreUsername = coreUsername;
	}

	/**
	 * @return the corePwd
	 */
	public String getCorePwd() {
		return corePwd;
	}

	/**
	 * @param corePwd
	 *            the corePwd to set
	 */
	public void setCorePwd(String corePwd) {
		this.corePwd = corePwd;
	}

	/**
	 * @return the nonCoreUsername
	 */
	public String getNonCoreUsername() {
		return nonCoreUsername;
	}

	/**
	 * @param nonCoreUsername
	 *            the nonCoreUsername to set
	 */
	public void setNonCoreUsername(String nonCoreUsername) {
		this.nonCoreUsername = nonCoreUsername;
	}

	/**
	 * @return the nonCorePwd
	 */
	public String getNonCorePwd() {
		return nonCorePwd;
	}

	/**
	 * @param nonCorePwd
	 *            the nonCorePwd to set
	 */
	public void setNonCorePwd(String nonCorePwd) {
		this.nonCorePwd = nonCorePwd;
	}

	@Value("${" + CyberArcProperties.CYBERARC_DISABLED + "}")
	private String cyberArcDisabled;

	@Value("${" + CyberArcProperties.CYBERARC_AUTHDB_APPID_KEY + "}")
	private String cyberArcCoreAppId;

	@Value("${" + CyberArcProperties.CYBERARC_AUTHDB_SAFE_KEY + "}")
	private String cyberArcCoreSafe;

	@Value("${" + CyberArcProperties.CYBERARC_AUTHDB_OBJECT_KEY + "}")
	private String cyberArcCoreObject;

	@Value("${" + CyberArcProperties.CYBERARC_AUTHDB_REASON_KEY + "}")
	private String cyberArcCoreReason;

	@Value("${" + CyberArcProperties.CYBERARC_EWS_APPID_KEY + "}")
	private String cyberArcEwsAppId;

	@Value("${" + CyberArcProperties.CYBERARC_EWS_SAFE_KEY + "}")
	private String cyberArcEwsSafe;

	@Value("${" + CyberArcProperties.CYBERARC_EWS_OBJECT_KEY + "}")
	private String cyberArcEwsObject;

	@Value("${" + CyberArcProperties.CYBERARC_EWS_REASON_KEY + "}")
	private String cyberArcEwsReason;

	@Value("${" + CyberArcProperties.CORE_JDBC_USERNAME + "}")
	private String coreUserWithoutCyberArc;

	@Value("${" + CyberArcProperties.CORE_JDBC_PWD + "}")
	private String corePwdWithoutCyberArc;

	@Value("${" + CyberArcProperties.NC_JDBC_USERNAME + "}")
	private String nonCoreUserWithoutCyberArc;

	@Value("${" + CyberArcProperties.NC_JDBC_PWD + "}")
	private String nonCorePwdWithoutCyberArc;

	@Value("${" + CyberArcProperties.CYBERARC_USERNAME + "}")
	private String cyberArcUser;

	public void init() throws PSDKException, InterruptedException {
		try {
			if ("true".equalsIgnoreCase(cyberArcDisabled)) {
				initWithoutCyberArc();
			} else {
				nonCorePwd = getPassword(cyberArcEwsAppId, cyberArcEwsSafe, cyberArcEwsObject, cyberArcEwsReason);
				nonCoreUsername = cyberArcUser;
				log.info("CyberArc: Retreived for EWS : ");
				corePwd = getPassword(cyberArcCoreAppId, cyberArcCoreSafe, cyberArcCoreObject, cyberArcCoreReason);
				coreUsername = cyberArcUser;
				log.info("CyberArc: Retreived for CORE : ");
			}
		} catch (Exception e) {
			log.error("Exception while retreiving vault value: ", e);
		}

	}

	private void initWithoutCyberArc() {
		nonCoreUsername = nonCoreUserWithoutCyberArc;
		nonCorePwd = nonCorePwdWithoutCyberArc;
		coreUsername = coreUserWithoutCyberArc;
		corePwd = corePwdWithoutCyberArc;
	}

	public String getPassword(String appId, String safe, String object, String reason)
			throws InterruptedException, PSDKException {
		log.info("CyberArkFactory -> Fetch password with query [Safe=" + safe + ";Object=" + object
				+ "] for application [" + appId + "]. Fetch reason: [" + reason + "]");
		try {
			PSDKPasswordRequest passRequest = new PSDKPasswordRequest();
			PSDKPassword password = null;
			passRequest.setAppID(appId);
			passRequest.setSafe(safe);
			passRequest.setObject(object);
			passRequest.setReason(reason);
			passRequest.setFailRequestOnPasswordChange(false);
			boolean passRetrieved = false;
			int retryIntervalms = 3000;

			while (!passRetrieved) {
				// Sending the request to get the password
				password = javapasswordsdk.PasswordSDK.getPassword(passRequest);
				if (password.getAttribute("PasswordChangeInProcess").equals("true")) {
					Thread.sleep(retryIntervalms);
				} else {
					passRetrieved = true;
				}
			}
			return password.getContent();
		} catch (Exception e) {
			log.error("CyberArkFactory-getPassword() :: Exception ::" + e, e);
			return "Error with password generation";
		}
	}

}
