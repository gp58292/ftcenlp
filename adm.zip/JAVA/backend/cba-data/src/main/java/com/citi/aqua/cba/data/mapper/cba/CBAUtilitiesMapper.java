package com.citi.aqua.cba.data.mapper.cba;

import java.util.List;
import java.util.Map;

import com.citi.aqua.cba.data.domain.cba.AquaCoreUserAdmin;
import com.citi.aqua.cba.data.domain.cba.AquaCoreUserEntitlement;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;


public interface CBAUtilitiesMapper {

    @Select(" SELECT"+
            " soeid = LTRIM(RTRIM(soeid)),"+
            " displayName = friendly_name,"+
            " email = LTRIM(RTRIM(email))"+
            " FROM"+
            " [RACE].[dbo].[view_admin_get_all_user] (NOLOCK)"+
            " WHERE soeid = #{soeid}")
    public AquaCoreUserAdmin getUserListEntitlement(@Param("soeid")String soeid);

    @Select("SELECT LTRIM(soeid) \"soeid\", RTRIM(friendly_name) \"name\", LTRIM(permission_level) \"permission_level\" FROM [CBA].[dbo].[admin_emt_user_entitlements] where soeid=#{soeid}")
    public List<AquaCoreUserEntitlement> getEntitlements(@Param("soeid")String soeid);

    @Select("INSERT INTO [CBA].[dbo].[tbl_cba_app_user_log] (soeid,activity,user_name,create_time)  VALUES (#{soeid},#{action},#{fullName},#{create_time})")
    public void insertUserActionDetails( Map<String, Object> map);

}
