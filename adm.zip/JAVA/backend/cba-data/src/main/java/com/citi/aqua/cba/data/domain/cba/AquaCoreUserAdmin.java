package com.citi.aqua.cba.data.domain.cba;

/**
 * Created by jm27909 on 6/29/2017.
 */
public class AquaCoreUserAdmin {
    private String soeid;
    private String displayName;
    private String role;
    //private String status;
    private String email;
    private String cpcDataEntitlements;
    private String dataLoggingEntitlements;
    private String adminEntitlements;
    private String cbaAccessCode;

    public String getSoeid() {
        return soeid;
    }

    public void setSoeid(String soeid) {
        this.soeid = soeid;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

/*
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
*/

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getCpcDataEntitlements() {
        return cpcDataEntitlements;
    }

    public void setCpcDataEntitlements(String cpcDataEntitlements) {
        this.cpcDataEntitlements = cpcDataEntitlements;
    }

    public String getDataLoggingEntitlements() {
        return dataLoggingEntitlements;
    }

    public void setDataLoggingEntitlements(String dataLoggingEntitlements) {
        this.dataLoggingEntitlements = dataLoggingEntitlements;
    }

    public String getAdminEntitlements() {
        return adminEntitlements;
    }

    public void setAdminEntitlements(String adminEntitlements) {
        this.adminEntitlements = adminEntitlements;
    }

    public String getCbaAccessCode() {
        return cbaAccessCode;
    }

    public void setCbaAccessCode(String cbaAccessCode) {
        this.cbaAccessCode = cbaAccessCode;
    }


}
