package com.citi.aqua.cba.data.mapper.cba;

import com.citi.aqua.cba.model.Request;
import com.citi.aqua.cba.model.UploadFile;
import org.apache.ibatis.annotations.*;

import java.util.List;

/**
 * Created by jm27909 on 7/21/2017.
 */
public interface RequestMapper {

    //get all requests
    @Select("SELECT id, soeid,user_name as userName,requested_by as requestedBy,access_requested as accessRequested," +
            " received_on as receivedOn,status,security_model as securityModel,security_model_status as securityModelStatus," +
            "qv_authorization as qvAuthorization,qv_authorization_status as qvAuthorizationStatus," +
            "qv_authorization_landing_page as qvAuthorizationLandingPage," +
            " citi_velocity as citiVelocity,notified_user as notifiedUser,last_updated as lastUpdated,comments" +
            "  FROM [CBA].[dbo].[admin_request_page] ")
    public List<Request> getRequestList();

    //insert request
    @Insert("INSERT INTO [CBA].[dbo].[admin_request_page] " +
            "(soeid, user_name, requested_by,access_requested,received_on, status, security_model,security_model_status," +
            "qv_authorization,qv_authorization_status,qv_authorization_landing_page,citi_velocity,notified_user,comments) "
            + "VALUES (#{soeid},#{userName},#{requestedBy},#{accessRequested},#{receivedOn},#{status},#{securityModel}," +
            "#{securityModelStatus},#{qvAuthorization},#{qvAuthorizationStatus},#{qvAuthorizationLandingPage}," +
            "#{citiVelocity},#{notifiedUser},#{comments})")
    public void insertRequest(Request request);

    //delete request
    @Delete("DELETE FROM [CBA].[dbo].[admin_request_page]"
            + " WHERE id =#{id}")
    public void deleteRequest(@Param("id")int id);

    //edit request
    @Update("UPDATE [CBA].[dbo].[admin_request_page] " +
            "SET status = #{status},requested_by = #{requestedBy},access_requested = #{accessRequested}," +
            "security_model = #{securityModel},security_model_status = #{securityModelStatus}," +
            "qv_authorization = #{qvAuthorization},qv_authorization_status = #{qvAuthorizationStatus}," +
            "qv_authorization_landing_page = #{qvAuthorizationLandingPage}," +
            "citi_velocity = #{citiVelocity},notified_user = #{notifiedUser},last_updated = GETDATE(),comments = #{comments} " +
            "WHERE id = #{id}")
    public void editRequest(Request request);

    //upload file
    @Update("INSERT INTO [CBA].[dbo].[admin_request_page_attachments] (request_id,file_name,file_object) VALUES(#{requestId},#{fileName},#{fileObject})")
    public void upload(UploadFile file);

    @Select("SELECT id,request_id as requestId," +
            "file_name as fileName,file_object as fileObject,load_date as loadDate FROM [CBA].[dbo].[admin_request_page_attachments] " +
            "WHERE request_id=#{requestId} AND file_name=#{fileName}")
    UploadFile getFile(@Param("requestId") int requestId,@Param("fileName") String fileName);

    @Select("SELECT request_id as requestId," +
            "file_name as fileName FROM [CBA].[dbo].[admin_request_page_attachments] WHERE request_id=#{requestId}")
    List<UploadFile> getRequestFileList(@Param("requestId") int requestId);
}
