package com.citi.aqua.cba.data.mapper.pnl;
/**
 * @author: jm27909
 *
 * 
 */
import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import com.citi.aqua.cba.model.SeedLoadCPC;

public interface SeedLoadCPCMapper  {
	
	//retrieve all records from this table 
	@Select("SELECT * FROM [PNL].[dbo].[seed_load_cpc_new]")
	public List<SeedLoadCPC> getSeedLoadCPC();
	
	//insert a record into the table with the following values
	@Insert("INSERT INTO [PNL].[dbo].[seed_load_cpc_new] (cobDate,createUser,flag,lastUpdatedUser) "
			+ "VALUES (#{cobDate},#{createUser},#{flag},#{lastUpdatedUser})")
	public void insertSeedLoadCPC(SeedLoadCPC seedLoadCPC);
	
	//retrieve all records from table where the flag is equal to some value 
	@Select("SELECT * "
			+ "FROM [PNL].[dbo].[seed_load_cpc_new]"
			+ " WHERE flag = #{flag}")
	public List<SeedLoadCPC> findByFlag(@Param("flag") String flag);

	//retrieve all records from table where the cob date is equal to some value
	@Select("SELECT * "
			+ "FROM [PNL].[dbo].[seed_load_cpc_new]"
			+ " WHERE cobDate = #{cobDate}")
	public List<SeedLoadCPC> findByCobDate(@Param("cobDate") String cobDate);


	//delete a record in the table by cobDate
	@Delete("DELETE FROM [PNL].[dbo].[seed_load_cpc_new]"
			+ " WHERE (cobDate =#{cobDate} AND loadDate =#{loadDate})")
	public void deleteSeedLoadCPC(@Param("cobDate")String cobDate, @Param("loadDate")String loadDate);

	//update a record in the table by cobDate 
	@Update("UPDATE [PNL].[dbo].[seed_load_cpc_new]"
			+ "SET cobDate = #{cobDate}, flag = #{flag} "
			+ "WHERE cobDate = #{cobDate}")
	public void updateByCobDate(SeedLoadCPC seedLoadCPC);

}
