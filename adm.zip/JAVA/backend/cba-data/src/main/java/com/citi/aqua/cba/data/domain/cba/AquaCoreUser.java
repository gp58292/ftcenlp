package com.citi.aqua.cba.data.domain.cba;

public class AquaCoreUser {
	private String soeId;
	private String displayName;
	private String role;
	private String status;
	private String email;
	private String access;
	private String cbaAccessCode;

	public String getSoeId() {
		return soeId;
	}

	public void setSoeId(String soeId) {
		this.soeId = soeId;
	}

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAccess() {
		return access;
	}

	public void setAccess(String access) {
		this.access = access;
	}

	public String getCbaAccessCode() {
		return cbaAccessCode;
	}

	public void setCbaAccessCode(String cbaAccessCode) {
		this.cbaAccessCode = cbaAccessCode;
	}
	
	@Override
	public String toString() {
		return "AquaCoreUser{" + "soeId='" + soeId + '\'' + ", displayName='"
				+ displayName + '\'' + ", role='" + role + '\'' + ", status='"
				+ status + '\'' + ", email='" + email + '\'' + ", access='"
				+ access + '\'' + '}';
	}

}