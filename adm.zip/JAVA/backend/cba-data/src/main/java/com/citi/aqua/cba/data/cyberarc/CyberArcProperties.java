package com.citi.aqua.cba.data.cyberarc;

public class CyberArcProperties {

	public static final String CYBERARC_DISABLED = "cyberarc.disabled";

	public static final String CORE_USER = "ews.datasource.username";
	public static final String CYBERARC_EWS_APPID_KEY = "cyberark.appId";
	public static final String CYBERARC_EWS_SAFE_KEY = "cyberark.safe";
	public static final String CYBERARC_EWS_OBJECT_KEY = "cyberark.object";
	public static final String CYBERARC_EWS_REASON_KEY = "cyberark.reason";

	public static final String EWS_USER = "emt.datasource.username";
	public static final String CYBERARC_AUTHDB_APPID_KEY = "cyberark.appId_core";
	public static final String CYBERARC_AUTHDB_SAFE_KEY = "cyberark.safe_core";
	public static final String CYBERARC_AUTHDB_OBJECT_KEY = "cyberark.object_core";
	public static final String CYBERARC_AUTHDB_REASON_KEY = "cyberark.reason_core";

	public static final String CYBERARC_CORE_USERNAME = "emt.datasource.username";
	public static final String CYBERARC_EWS_USERNAME = "ews.datasource.username";

	public static final String NC_JDBC_USERNAME = "nc.jdbc.username";
	public static final String CORE_JDBC_USERNAME = "emt.jdbc.username";

	public static final String CORE_JDBC_PWD = "emt.jdbc.pwd";
	public static final String NC_JDBC_PWD = "nc.jdbc.pwd";

	public static final String CYBERARC_USERNAME = "cyberarc.username";

}
