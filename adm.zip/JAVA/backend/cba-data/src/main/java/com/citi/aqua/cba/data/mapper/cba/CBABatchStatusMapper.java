package com.citi.aqua.cba.data.mapper.cba;

import java.util.List;

import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.mapping.StatementType;

import com.citi.aqua.cba.model.BatchStatusDetails;

public interface CBABatchStatusMapper {

	@Select(value = "{call CBA.audit.usp_get_batch_status_detail(#{cobDate})}")
	@Options(statementType = StatementType.CALLABLE)
	public List<BatchStatusDetails> getBatchStatusDetails(@Param("cobDate") String cobDate);

	@Select(value = "{call CBA.dbo.usp_batch_get_COB_date()}")
	@Options(statementType = StatementType.CALLABLE)
	public String getCOBDate();

	@Select(value = "{call CBA.dbo.usp_batch_derive_COB_date(#{cobDate})}")
	@Options(statementType = StatementType.CALLABLE)
	public String deriveCobDate(@Param("cobDate") String cobDate);

}
