package com.citi.aqua.cba.data.mapper.cba;

import java.util.List;

import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.mapping.StatementType;
import org.springframework.cache.annotation.Cacheable;

import com.citi.aqua.cba.model.BalanceROA;
import com.citi.aqua.cba.model.EquityBalance;
import com.citi.aqua.cba.model.FinancingBalance;
import com.citi.aqua.cba.model.MasterData;
import com.citi.aqua.cba.model.Revenue;
import com.citi.aqua.cba.model.SecurityCountryRisk;
import com.citi.aqua.cba.model.SecurityMarketCap;
import com.citi.aqua.cba.model.SecurityProduct;
import com.citi.aqua.cba.model.SecuritySector;

/**
 * @author: aw11769	
 *
 * 
 */ 


public interface ClientOverviewMapper {
	
	@Cacheable(value="ewsCache")
	@Select("{call usp_get_client_fund_region_filter_by_soeid(#{soeid})}")
	@Options(statementType = StatementType.CALLABLE)
	public List<MasterData> getMasters(@Param("soeid")String soeid);
	
//	@Cacheable(value="ewsCache")
	@Select("select  top 30 cob_date from tbl_race_process_date where type='D' order by 1 desc")
    public List<Long> getCOBDateList();
	
//	@Cacheable(value="ewsCache")
	@Select("SELECT DISTINCT TOP 13 cob_date FROM tbl_race_process_date where type='M' ORDER BY 1 DESC")
    public List<Long> getMonthlyCOBDateList();
	
	@Cacheable(value="ewsCache",keyGenerator="customKeyGenerator")	
	@Select(value = "{call usp_data_clientoverview_financingbalance_graph("+"#{cob_date},"+"#{client},"+"#{fund},"+"#{region},"+"#{type},"+"#{soeid}"+")}")
	@Options(statementType = StatementType.CALLABLE)
	public List<FinancingBalance> getFinancingBalanceDetails(@Param("cob_date")Long cob_date,
			@Param("client")String client,
			@Param("fund")String fund,
			@Param("region")String region,
			@Param("type")String type,
			@Param("soeid")String soeid);
	
	@Cacheable(value="ewsCache",keyGenerator="customKeyGenerator")
	@Select(value = "{call usp_data_clientoverview_equitybalance_graph("+"#{cob_date},"+"#{client},"+"#{fund},"+"#{region},"+"#{type},"+"#{soeid}"+")}")
	@Options(statementType = StatementType.CALLABLE)
	public List<EquityBalance> getEquityBalanceDetails(@Param("cob_date")Long cob_date,
			@Param("client")String client,
			@Param("fund")String fund,
			@Param("region")String region,
			@Param("type")String type,
			@Param("soeid")String soeid);
	
	@Cacheable(value="ewsCache",keyGenerator="customKeyGenerator")
	@Select(value = "{call usp_data_clientoverview_balsheet_roa_graph("+"#{cob_date},"+"#{client},"+"#{fund},"+"#{region},"+"#{type},"+"#{soeid}"+")}")
	@Options(statementType = StatementType.CALLABLE)
	public List<BalanceROA> getBalanceSheetROA(@Param("cob_date")Long cob_date,
			@Param("client")String client,
			@Param("fund")String fund,
			@Param("region")String region,
			@Param("type")String type,
			@Param("soeid")String soeid);
	
	@Cacheable(value="ewsCache",keyGenerator="customKeyGenerator")
	@Select(value = "{call usp_data_clientoverview_revenue_graph("+"#{cob_date},"+"#{client},"+"#{fund},"+"#{region},"+"#{type},"+"#{soeid}"+")}")
	@Options(statementType = StatementType.CALLABLE)
	public List<Revenue> getRevenue(@Param("cob_date")Long cob_date,
			@Param("client")String client,
			@Param("fund")String fund,
			@Param("region")String region,
			@Param("type")String type,
			@Param("soeid")String soeid);
	
	@Cacheable(value="ewsCache",keyGenerator="customKeyGenerator")
	@Select(value = "{call usp_data_clientoverview_gmv_security_countryrisk_graph("+"#{cob_date},"+"#{client},"+"#{fund},"+"#{region},"+"#{type},"+"#{soeid}"+")}")
	@Options(statementType = StatementType.CALLABLE)
	public List<SecurityCountryRisk> getSecurityCountryRisk(@Param("cob_date")Long cob_date,
			@Param("client")String client,
			@Param("fund")String fund,
			@Param("region")String region,
			@Param("type")String type,
			@Param("soeid")String soeid);
	
	
	@Cacheable(value="ewsCache",keyGenerator="customKeyGenerator")
	@Select(value = "{call usp_data_clientoverview_gmv_security_product_graph("+"#{cob_date},"+"#{client},"+"#{fund},"+"#{region},"+"#{type},"+"#{soeid}"+")}")
	@Options(statementType = StatementType.CALLABLE)
	public List<SecurityProduct> getSecurityProduct(@Param("cob_date")Long cob_date,
			@Param("client")String client,
			@Param("fund")String fund,
			@Param("region")String region,
			@Param("type")String type,
			@Param("soeid")String soeid);
	
	@Cacheable(value="ewsCache",keyGenerator="customKeyGenerator")
	@Select(value = "{call usp_data_clientoverview_gmv_security_sector_graph("+"#{cob_date},"+"#{client},"+"#{fund},"+"#{region},"+"#{type},"+"#{soeid}"+")}")
	@Options(statementType = StatementType.CALLABLE)
	public List<SecuritySector> getSecuritySector(@Param("cob_date")Long cob_date,
			@Param("client")String client,
			@Param("fund")String fund,
			@Param("region")String region,
			@Param("type")String type,
			@Param("soeid")String soeid);
	
	@Cacheable(value="ewsCache",keyGenerator="customKeyGenerator")
	@Select(value = "{call usp_data_clientoverview_gmv_security_marketcap_graph("+"#{cob_date},"+"#{client},"+"#{fund},"+"#{region},"+"#{type},"+"#{soeid}"+")}")
	@Options(statementType = StatementType.CALLABLE)
	public List<SecurityMarketCap> getSecurityMarketCap(@Param("cob_date")Long cob_date,
			@Param("client")String client,
			@Param("fund")String fund,
			@Param("region")String region,
			@Param("type")String type,
			@Param("soeid")String soeid);
}
