package com.citi.aqua.cba.data.mapper.cba;

import java.util.List;

import com.citi.aqua.cba.model.*;
import org.apache.ibatis.annotations.*;
import org.apache.ibatis.mapping.StatementType;


/**
 * @author: aw11769	
 *
 * 
 */ 
public interface AdminMapper {

	@Select("select * from view_admin_get_all_user")
	public List<EWSUser> getEWSUsers();
	
	@Select("select * from view_admin_get_all_user where soeid = #{id}")
	public EWSUser getEWSUser(@Param("id") String id);

	@Select(value = "{call usp_get_user_coverage_by_soeid(#{id})}")
	@Options(statementType = StatementType.CALLABLE)
	public List<UserCoverage> getUserCoverage(@Param("id") String id);	

	@Results({
		@Result(property="value",column="gpnum"),
		@Result(property="text",column="gpname"),
	})
	@Select("select  * from tbl_gp_client")
    public List<DropDownModel> getClientCoverageList();
	
	@Select(value = "{call usp_admin_edit_user("+"#{soeid},"+"#{role},"+"#{gpnum},#{all_client},"+"#{updatedby}"+")}")
	@Options(statementType = StatementType.CALLABLE)
	public void updateUserRole(@Param("soeid") String soeid, @Param("role") String role, @Param("gpnum") String gpnum,@Param("all_client") int all_client,@Param("updatedby") String updatedby);	

	@Select(value = "{call usp_admin_update_user_aqua_coverage_based("+"#{soeid},"+"#{gpnum},"+"#{updatedby}"+")}")
	@Options(statementType = StatementType.CALLABLE)
	public void  updateUserCoverage(@Param("soeid") String soeid, @Param("gpnum") String gpnum,@Param("updatedby") String updatedby);	
	
//	@Select("Select * from tbl_user_update_history where soeid =#{soeid}")
	@Select("{call usp_get_user_update_history_by_soeid(#{soeid})}")
	public List<UserHistory> getUserHistory(@Param("soeid") String soeid);

//	@Select("SELECT distinct(a.soeid),b.friendly_name" +
//			"  FROM [CBA].[dbo].[admin_tbl_user_entitlements] a" +
//			"  LEFT JOIN [RACE].[dbo].[view_admin_get_all_user] b" +
//			"  ON b.soeid = a.soeid "
//			)


//	@Select("SELECT DISTINCT(soeid),friendly_name,permission_level,lastUpdatedDate FROM CBA.dbo.admin_emt_user_entitlements")

	@Select("{call CBA.dbo.admin_transpose_user_entitlements()}")
	@Options(statementType = StatementType.CALLABLE)
	public List<Admin> getAdminList();

	//insert admin with given permissions
	@Insert("INSERT INTO [CBA].[dbo].[admin_tbl_user_entitlements] (soeid,readPermission,writePermission,entitlement) "
			+ "VALUES (#{soeid},#{readPermission},#{writePermission},#{entitlement})")
	public void insertAdmin(Admin admin);

	//delete admin by soeid
	@Delete("DELETE FROM [CBA].[dbo].[admin_tbl_user_entitlements]"
			+ " WHERE (soeid =#{soeid} AND entitlement =#{entitlement})")
	public void deleteAdmin(@Param("soeid")String soeid,@Param("entitlement")String entitlement);

	//edit admin record permission by soeid
	@Update("UPDATE [CBA].[dbo].[admin_tbl_user_entitlements] SET readPermission = #{readPermission}, writePermission = #{writePermission} WHERE soeid = #{soeid} AND entitlement = #{entitlement}")
	public void editAdminPermission(Admin admin);



	// Update statement
	@Select("{" +
			"call CBA.dbo.admin_update_user_entitlements_temp( #{soeid, javaType=String, jdbcType=VARCHAR, mode=IN},#{admin, javaType=String, jdbcType=INTEGER, mode=IN} )}")
	@Options(statementType = StatementType.CALLABLE)
	public void editUserPermission(Admin admin);

}
