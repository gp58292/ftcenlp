package com.citi.aqua.cba.cache;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;

public class CacheConfigTest {

	  @Test
	  public void ehCacheCacheManager() throws Exception {
	      assertNotNull("Need to fix these test case...");
	  }

//    private static final String CACHE_ID = "ewsCache";
//    private static final String CACHE_MANAGER_NAME = "TestCacheManager";
//    private static final String CACHE_ENTRY_KEY = "[hello :-)]";
//
//    @SuppressWarnings("unused")
//	private Ehcache cache;
//
//    @Autowired
//    private CacheConfig cacheConfig;
//    private File cacheDirectory;
//
//
//    @Before
//    public void setUp() throws Exception {
//
//        cacheConfig.setShared(false);
//        cache = (Ehcache) cacheConfig.cacheManager().getCache(CACHE_ID).getNativeCache();
//
//        cacheDirectory = File.createTempFile("folder"
//                + System.currentTimeMillis(), "k");
//
//        if (!cacheDirectory.delete()) {
//            throw new RuntimeException("Could not delete temp file: "
//                    + cacheDirectory.getAbsolutePath());
//        }
//
//        if (!cacheDirectory.mkdir()) {
//            throw new RuntimeException("Could not create temp directory: "
//                    + cacheDirectory.getAbsolutePath());
//        }
//    }
//
//
//    @Test
//    public void ehCacheCacheManager() throws Exception {
//        assertNotNull(cacheConfig.ehCacheCacheManager());
//    }
//
//    @Test
//    public void setShared() throws Exception {
//        cacheConfig.setShared(false);
//        assertNotNull(cacheConfig.ehCacheCacheManager());
//    }
//
//    @SuppressWarnings("deprecation")
//	@Test
//    public void cacheManager() throws Exception {
//
//       // assertThat(CacheManager.getInstance().getName(), is("__DEFAULT__"));
//        CacheManager.getInstance().shutdown();
//
//        String diskStorePath = cacheDirectory.getAbsolutePath();
//
//        CacheConfiguration oneCache = new CacheConfiguration();
//        oneCache.setName(CACHE_ID);
//        oneCache.setMaxEntriesLocalHeap(1);
//        oneCache.setTimeToLiveSeconds(100000L);
//        oneCache.setOverflowToDisk(true);
//        oneCache.setEternal(true);
//
//        CacheConfiguration defaultCacheConfiguration;
//        defaultCacheConfiguration = new CacheConfiguration();
//        defaultCacheConfiguration.setEternal(true);
//        defaultCacheConfiguration.setMaxEntriesLocalHeap(1);
//        defaultCacheConfiguration.setOverflowToDisk(true);
//        defaultCacheConfiguration.setTimeToLiveSeconds(100000L);
//
//        Configuration configuration = new Configuration();
//        configuration.setName(CACHE_MANAGER_NAME);
//        configuration.setDefaultCacheConfiguration(defaultCacheConfiguration);
//        configuration.addCache(oneCache);
//
//        DiskStoreConfiguration diskStoreConfiguration;
//        diskStoreConfiguration = new DiskStoreConfiguration();
//        diskStoreConfiguration.setPath(diskStorePath);
//
//        configuration.addDiskStore(diskStoreConfiguration);
//
//        CacheManager manager = CacheManager.create(configuration);
//
//        assertThat(manager.getName(), is("TestCacheManager"));
//        File cacheFile = null;
//        for (File file : cacheDirectory.listFiles()) {
//            if (file.getName().indexOf(".data") > 0) {
//                assertThat(file.getName(),
//                        is("ews%0043ache.data"));
//                cacheFile = file;
//            }
//        }
//        assertNotNull(cacheFile);
//        assertThat(cacheFile.length(), is(0L));
//
//        String cachedElement = "one entry";
//        Element element = new Element(CACHE_ENTRY_KEY, cachedElement);
//        Cache cache = manager.getCache(CACHE_ID);
//        cache.put(element);
//
//        Element fromCacheElement = cache.get(CACHE_ENTRY_KEY);
//        String fromCacheObject = (String) fromCacheElement.getValue();
//
//        assertThat(fromCacheObject, is(cachedElement));
//        addRandomElements(cache);
//
//        Thread.sleep(TimeUnit.SECONDS.toMillis(2));
//
//        assertTrue(cacheFile.length() > 1);
//    }
//
//    @After
//    public void tearDown() {
//        if (cacheDirectory != null) {
//            cacheDirectory.delete();
//        }
//    }
//
//    /**
//     * Adds random elements to the cache.
//     *
//     * @param cache the cache.
//     */
//    private void addRandomElements(final Cache cache) {
//        for (int i = 0; i <= 20000; i++) {
//            Element element = new Element("a_" + i, "ab_" + i);
//            cache.put(element);
//        }
//    }

}