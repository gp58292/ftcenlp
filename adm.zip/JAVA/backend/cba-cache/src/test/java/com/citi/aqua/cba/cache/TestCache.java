package com.citi.aqua.cba.cache;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;

/**
 *  Set the system property -Dnet.sf.ehcache.disabled=true to disable Ehcache
 */

/**
 *  This test case covers basic cache functionality to ensure that linked libraries perfom cached operations as designed
 */
public class TestCache {
	
	 @Test
	  public void ehCacheCacheManager() throws Exception {
	      assertNotNull("Need to fix these test case...");
	  }


//    private static final String CACHE_ID = "ewsCache";
//    private static final String CACHE_MANAGER_NAME = "TestCacheManager";
//    private Ehcache cache;
//
//    @SuppressWarnings("deprecation")
//	@Before
//    public void setUp() {
//        CacheConfiguration oneCache = new CacheConfiguration();
//        oneCache.setName(CACHE_ID);
//        oneCache.setMaxEntriesLocalHeap(1);
//        oneCache.setTimeToLiveSeconds(100000L);
//        oneCache.setOverflowToDisk(true);
//        oneCache.setEternal(true);
//
//        CacheConfiguration defaultCacheConfiguration;
//        defaultCacheConfiguration = new CacheConfiguration();
//        defaultCacheConfiguration.setEternal(true);
//        defaultCacheConfiguration.setMaxEntriesLocalHeap(1);
//        defaultCacheConfiguration.setOverflowToDisk(true);
//        defaultCacheConfiguration.setTimeToLiveSeconds(100000L);
//
//        Configuration configuration = new Configuration();
//        configuration.setName(CACHE_MANAGER_NAME);
//        configuration.setDefaultCacheConfiguration(defaultCacheConfiguration);
//        configuration.addCache(oneCache);
//
//        CacheManager manager = CacheManager.create(configuration);
//        cache = manager.getCache(CACHE_ID);
//        assertNotNull(cache);
//    }
//
//    @Test
//    public void shouldDemonstrateCopiesAreEqual() {
//        for (int i = 0; i < 100; i++) {
//            Element element = new Element(i,i);
//            cache.put(element);
//            assertEquals(element, cache.get(i));
//        }
//    }
//
//    @Test
//    public void shouldRemoveItemOnDemand() {
//        Element element = new Element(0,0);
//        cache.put(element);
//        assertNotNull(cache.get(0));
//        cache.remove(0);
//        Object o = cache.get(0);
//        assertNull(o);
//    }
//
//    @Test
//    public void shouldFlushAllItemsOnDemand() {
//        for (int i = 0; i < 5; i++) {
//            Element element = new Element(i,i);
//            cache.put(element);
//        }
//        assertNotNull(cache.get(0));
//        assertNotNull(cache.get(4));
//        cache.removeAll();
//        assertNull(cache.get(0));
//        assertNull(cache.get(4));
//    }
//
//    @Test
//    public void shouldAcceptAKeyBiggerThan250() {
//        char[] keyChar = new char[1024];
//        Arrays.fill(keyChar, 'X');
//        String key = new String(keyChar);
//        String value = "value";
//        cache.put(new Element(key, value));
//        assertEquals(value, (cache.get(key)).getObjectValue());
//    }




}
