package com.citi.aqua.cba.commons.exception;

public interface ExceptionMessageDescriptor {

	public String getMessageCode();
	public String getMessageDescription();
}
