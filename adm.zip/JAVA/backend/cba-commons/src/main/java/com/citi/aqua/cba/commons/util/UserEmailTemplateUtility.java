package com.citi.aqua.cba.commons.util;

/**
 * @author ak92283
 */
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.citi.aqua.cba.model.FeedDelayDataDetails;
import com.citi.aqua.cba.model.FeedDelayEmailData;

@Component
public class UserEmailTemplateUtility {

	private static final Logger LOGGER = LoggerFactory.getLogger(UserEmailTemplateUtility.class);

	public String formHtmlText(final String cid, final FeedDelayEmailData emailData) {

		LOGGER.debug("DownstreamEmailTemplateUtility::formHtmlText()::starts");
		StringBuilder stringBuffer = new StringBuilder();
		stringBuffer.append(fomatImageAndstyles(cid));
		stringBuffer.append(fomatTablecontents(emailData));
		stringBuffer.append(createGridHeader("CBA Dashboard"));
		stringBuffer.append(createGridItemsFromList(emailData.getCbaDashboardResponseData()));
		stringBuffer.append(createGridHeader("Stock Loan Dashboard"));
		stringBuffer.append(createGridItemsFromList(emailData.getSlDashboardResponseData()));
		stringBuffer.append(createGridHeader("Client Alert Dashboard"));
		stringBuffer.append(createGridItemsFromList(emailData.getCadResponseData()));
		stringBuffer.append(createGridHeader("Reports"));
		stringBuffer.append(createGridItemsFromList(emailData.getReportResponseData()));
		stringBuffer.append(createFooterContents());
		return stringBuffer.toString();
	}

	private StringBuilder fomatImageAndstyles(final String contentId) {
		LOGGER.debug("DownstreamEmailTemplateUtility::fomatImageAndstyles()::starts");

		StringBuilder sb = new StringBuilder();
		sb.append("<!DOCTYPE> <html><head>");
		sb.append("<style>table {    font-family: arial, sans-serif;    border-collapse: collapse;    width:60%;}");
		sb.append("td{ border: 1px solid #dddddd;text-align: left;padding:6px;font-family: Calibri;}");
		sb.append(
				"td.labels {border: 1px solid #dddddd;text-align:left;padding:6px;font-family:'Calibri';font-weight: normal;}");
		sb.append(
				".row >td{		padding:12px 12px;		border-color:#BFBFBF;	border-style: solid;		border-width: 1px;		}");
		sb.append(
				"table.MsoNormalTable {width:100%;font-size:10.0pt;font-family:\"Calibri\";border-color:#BFBFBF;padding:12px 12px;border-style: solid;");
		sb.append(
				"border-width: 1px;border-top-color: #BFBFBF;border-collapse:collapse;}.header > th{padding:12px 12px;font-weight: bold;");
		sb.append(
				"background-color: #D9D9D9;border-color:#BFBFBF;border-style: solid;border-width: 1px;}.row >  td{padding:12px 12px;");
		sb.append("border-color:#BFBFBF;border-style: solid;border-width: 1px;}</style>");
		sb.append("</head><body><table>");
		sb.append("<tr><td colspan='2'><img src=\"cid:" + contentId + "\"/>");
		sb.append("</td></tr>");

		return sb;
	}

	private StringBuilder fomatTablecontents(final FeedDelayEmailData emailData) {

		LOGGER.debug("DownstreamEmailTemplateUtility::fomatTablecontents()::starts");
		String mim = "";
		if (null != emailData.getFeedDelayForm().getInc_mim()) {
			mim = emailData.getFeedDelayForm().getInc_mim();
		}
		StringBuilder sb = new StringBuilder();
		sb.append(
				"<tr><td  colspan='2' style=\"color:#11aaec; font-family:'Arial'; font-weight: bold;\">Aqua CBA -Production Support Notification</td></tr>");
		sb.append(
				"<tr><td class=\"labels\" style=\"background-color:#eec3c7;\">Source of Issue:</td> <td style=\"background-color:#eec3c7; font-family:'Arial'; font-weight: bold; color:#FF0000;\">");
		sb.append(emailData.getFeedDelayForm().getSource_issue());
		sb.append(
				"</td></tr>  <tr>    <td class=\"labels\">Areas Impacted:</td>    <td  style=\"font-family:'Calibri'; font-weight: bold; color:#11aaec;\">");
		sb.append(emailData.getFeedDelayForm().getArea_impacted());
		sb.append("</td>  </tr><tr><td class=\"labels\">ETA for Resolution</td>    <td >");
		sb.append(emailData.getFeedDelayForm().getEta_resolution());
		sb.append(" hours  ");
		sb.append("</td>   </tr>  <tr>    <td class=\"labels\">ServiceNow/MIM:</td><td  style=\"font-weight: bold;\">");
		sb.append(mim);
		sb.append("</td>  </tr>   <tr>    <td class=\"labels\">Next Update:</td>    <td  >");
		sb.append(emailData.getFeedDelayForm().getNext_update());
		sb.append(" hours  ");
		sb.append("</td>  </tr>  <tr>    <td class=\"labels\">Summary Description:</td>    <td >");
		sb.append(emailData.getFeedDelayForm().getDescription());
		sb.append("</td>  </tr><tr><td class=\\\"labels\\\" rowspan='4'>Impact:</td>");

		return sb;
	}

	private StringBuilder createGridHeader(String dashboardType) {
		LOGGER.debug("DownstreamEmailTemplateUtility::createGridHeader()::starts");
		StringBuilder sb = new StringBuilder();
		if (!dashboardType.equals("CBA Dashboard")) {
			sb.append("<tr>");
		}
		sb.append(
				"<td><TABLE class=MsoNormalTable ><TR class=\"header\"><TH align=\"left\" style='color:white;  width:30%;border:solid #BFBFBF 1.0pt;background:SteelBlue;padding:0in 5.4pt 0in 5.4pt;height:22.5pt;border-collapse:collapse;'>");
		sb.append(dashboardType);
		sb.append(
				"</TD><TH align=\"left\" style='color:white;  width:20%;border:solid #BFBFBF 1.0pt;background:SteelBlue;padding:0in 5.4pt 0in 5.4pt;height:22.5pt;border-collapse:collapse;'>BAU</TD>");
		sb.append(
				"<TH align=\"left\" style='color:white;  width:20%;border:solid #BFBFBF 1.0pt;background:SteelBlue;padding:0in 5.4pt 0in 5.4pt;height:22.5pt;border-collapse:collapse;'>SLA</TD>");
		sb.append(
				"<TH align=\"left\" style='color:white;  width:30%;border:solid #BFBFBF 1.0pt;background:SteelBlue;padding:0in 5.4pt 0in 5.4pt;height:22.5pt;border-collapse:collapse;'>ETA/Status</TD></TR>");

		return sb;

	}

	private StringBuilder createGridItemsFromList(List<FeedDelayDataDetails> feedList) {
		LOGGER.debug("DownstreamEmailTemplateUtility::createGridItemsFromList()::starts");
		StringBuilder sb = new StringBuilder();
		for (FeedDelayDataDetails data : feedList) {
			sb.append("<TR class=\"row\">");
			sb.append(
					"<TD align=\"left\" style='width:30%;border:solid #BFBFBF 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:22.5pt;border-collapse:collapse;'>");
			sb.append(data.getName());
			sb.append(
					"</TD><TD align=\"left\" style='width:20%;border:solid #BFBFBF 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:22.5pt;border-collapse:collapse;'>");
			sb.append(data.getBau());
			sb.append(
					"</TD><TD align=\"left\" style='width:20%;border:solid #BFBFBF 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:22.5pt;border-collapse:collapse;'>");
			sb.append(data.getSla());
			sb.append("</TD>");
			if (data.getEta().equals("Available") || data.getEta().equals("Available in Second Refresh")) {
				sb.append(
						"<TD align=\"left\" style='width:30%;border:solid #BFBFBF 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:22.5pt;border-collapse:collapse;background:#30a43b;'>");
				sb.append(data.getEta());
			} else {
				sb.append(
						"<TD align=\"left\" style='width:30%;border:solid #BFBFBF 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:22.5pt;border-collapse:collapse; background:#f6ca0a;'>");
				sb.append(data.getEta());
			}
			sb.append("</TD>");
			sb.append("</TR>");

		}
		sb.append("</TABLE></td></tr>");
		return sb;
	}

	private StringBuilder createFooterContents() {

		LOGGER.debug("DownstreamEmailTemplateUtility::createFooterContents()::starts");
		StringBuilder sb = new StringBuilder();
		sb.append(
				"<tr><td colspan='2' style=\"color:#8D9092; font-family:'Calibri';font-size:11.0pt; font-weight: normal;\">");
		sb.append("<br/>BCC: *GT Global AQUA CBA Prime Dashboard Status FYI;</br> <br/>");
		sb.append(
				" *GT Global AQUA Futures MIS;</br> <br/>*GT GLOBAL AQUA StockLoan Daily APAC P&L Sequel;</br> <br/>");
		sb.append(
				" *GT GLOBAL AQUA StockLoan Daily NAM P&L Sequel Report;</br> <br/> *GT GLOBAL AQUA StockLoan Daily EMEA P&L Sequel Report");
		sb.append(
				"</td></tr></table></BR><P style = \"font-size:12.0pt;font-family:'Calibri';\">CBA Build Team</P></body></html>");
		return sb;
	}

}
