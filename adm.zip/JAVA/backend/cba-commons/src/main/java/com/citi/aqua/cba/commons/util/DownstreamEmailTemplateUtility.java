package com.citi.aqua.cba.commons.util;

/**
 * @author ak92283
 */
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.citi.aqua.cba.model.FeedDelayDataDetails;
import com.citi.aqua.cba.model.FeedDelayEmailData;

@Component
public class DownstreamEmailTemplateUtility {

	private static final Logger LOGGER = LoggerFactory.getLogger(DownstreamEmailTemplateUtility.class);

	public String formHtmlText(final String cid, final FeedDelayEmailData emailData) {

		LOGGER.debug("DownstreamEmailTemplateUtility::formHtmlText()::starts");
		StringBuffer stringBuffer = new StringBuffer();
		stringBuffer.append(fomatImageAndstyles(cid));
		stringBuffer.append(fomatTablecontents(emailData));
		stringBuffer.append(createGridHeader());
		stringBuffer.append(createGridItems(emailData));
		stringBuffer.append(createFooterContents());
		return stringBuffer.toString();
	}

	private StringBuffer fomatImageAndstyles(final String contentId) {
		LOGGER.debug("DownstreamEmailTemplateUtility::fomatImageAndstyles()::starts");

		StringBuffer sb = new StringBuffer();
		sb.append("<!DOCTYPE> <html><head>");
		sb.append("<style>table {    font-family: arial, sans-serif;    border-collapse: collapse;    width: 60%;}");
		sb.append("td{ border: 1px solid #dddddd;text-align: left;padding:6px;width:80%;font-family: Calibri;}");
		sb.append(
				"td.labels {border: 1px solid #dddddd;text-align:left;padding: 6px;	width:20%;font-family:'Calibri';font-weight: normal;}");
		sb.append(
				".row >td{		padding:12px 12px;		border-color:#BFBFBF;	border-style: solid;		border-width: 1px;		}");
		sb.append(
				"table.MsoNormalTable {width:100%;font-size:10.0pt;font-family:\"Calibri\";border-color:#BFBFBF;padding:12px 12px;border-style: solid;");
		sb.append(
				"border-width: 1px;border-top-color: #BFBFBF;border-collapse:collapse;}.header > th{padding:12px 12px;font-weight: bold;");
		sb.append(
				"background-color: #D9D9D9;border-color:#BFBFBF;border-style: solid;border-width: 1px;}.row >  td{padding:12px 12px;");
		sb.append("border-color:#BFBFBF;border-style: solid;border-width: 1px;}</style>");
		sb.append("</head><body><table>");
		sb.append("<tr><td colspan=\"2\"><img src=\"cid:" + contentId + "\"/>");
		sb.append("</td></tr>");

		return sb;
	}

	private StringBuffer fomatTablecontents(final FeedDelayEmailData emailData) {

		LOGGER.debug("DownstreamEmailTemplateUtility::fomatTablecontents()::starts");
		String mim = "";
		if (null != emailData.getFeedDelayForm().getInc_mim()) {
			mim = emailData.getFeedDelayForm().getInc_mim();
		}
		StringBuffer sb = new StringBuffer();
		sb.append(
				"<tr><td  colspan=\"2\" style=\"color:#11aaec; font-family:'Arial'; font-weight: bold;\">Aqua CBA -Production Support Notification</td></tr>");
		sb.append(
				"<tr><td class=\"labels\" style=\"background-color:#eec3c7;\">Source of Issue:</td> <td style=\"background-color:#eec3c7; font-family:'Arial'; font-weight: bold; color:#FF0000;\">");
		sb.append(emailData.getFeedDelayForm().getSource_issue());
		sb.append(
				"</td></tr>  <tr>    <td class=\"labels\">Areas Impacted:</td>    <td  style=\"font-family:'Calibri'; font-weight: bold; color:#11aaec;\">");
		sb.append(emailData.getFeedDelayForm().getArea_impacted());
		sb.append("</td>  </tr><tr><td class=\"labels\">ETA for Resolution</td>    <td >");
		sb.append(emailData.getFeedDelayForm().getEta_resolution());
		sb.append(" hours  ");
		sb.append("</td>   </tr>  <tr>    <td class=\"labels\">ServiceNow/MIM:</td><td  style=\"font-weight: bold;\">");
		sb.append(mim);
		sb.append("</td>  </tr>   <tr>    <td class=\"labels\">Next Update:</td>    <td  >");
		sb.append(emailData.getFeedDelayForm().getNext_update());
		sb.append(" hours  ");
		sb.append("</td>  </tr>  <tr>    <td class=\"labels\">Summary Description:</td>    <td >");
		sb.append(emailData.getFeedDelayForm().getDescription());
		sb.append("</td>  </tr><tr>");

		return sb;
	}

	private StringBuffer createGridHeader() {

		LOGGER.debug("DownstreamEmailTemplateUtility::createGridHeader()::starts");

		StringBuffer sb = new StringBuffer();
		sb.append(
				"<td class=\"labels\" rowspan=\"1\">Impact:</td><td ><TABLE class=MsoNormalTable ><TR class=\"header\"><TH align=\"left\" style='color:white;  width:30%;border:solid #BFBFBF 1.0pt;background:SteelBlue;padding:0in 5.4pt 0in 5.4pt;height:22.5pt;border-collapse:collapse;'>Dashboard Data</TD>");
		sb.append(
				"<TH align=\"left\" style='color:white;  width:20%;border:solid #BFBFBF 1.0pt;background:SteelBlue;padding:0in 5.4pt 0in 5.4pt;height:22.5pt;border-collapse:collapse;'>BAU</TD>");
		sb.append(
				"<TH align=\"left\" style='color:white;  width:20%;border:solid #BFBFBF 1.0pt;background:SteelBlue;padding:0in 5.4pt 0in 5.4pt;height:22.5pt;border-collapse:collapse;'>SLA</TD>");
		sb.append(
				"<TH align=\"left\" style='color:white;  width:30%;border:solid #BFBFBF 1.0pt;background:SteelBlue;padding:0in 5.4pt 0in 5.4pt;height:22.5pt;border-collapse:collapse;'>ETA/Status</TD></TR>");

		return sb;

	}

	private StringBuffer createGridItems(final FeedDelayEmailData emailData) {

		LOGGER.debug("DownstreamEmailTemplateUtility::fomatTablecontents()::starts");
		StringBuffer sb = new StringBuffer();
		List<FeedDelayDataDetails> feedDeataList = emailData.getFeedResponseData();
		for (FeedDelayDataDetails data : feedDeataList) {
			sb.append("<TR class=\"row\">");
			sb.append(
					"<TD align=\"left\" style='width:30%;border:solid #BFBFBF 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:22.5pt;border-collapse:collapse;'>");
			sb.append(data.getName());
			sb.append(
					"</TD><TD align=\"left\" style='width:20%;border:solid #BFBFBF 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:22.5pt;border-collapse:collapse;'>");
			sb.append(data.getBau()); 
			sb.append(
					"</TD><TD align=\"left\" style='width:20%;border:solid #BFBFBF 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:22.5pt;border-collapse:collapse;'>");
			sb.append(data.getSla());
			sb.append("</TD>");
			if (data.getEta().equals("Available") || data.getEta().equals("Available in Second Refresh")) {
				sb.append(
						"<TD align=\"left\" style='width:30%;border:solid #BFBFBF 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:22.5pt;border-collapse:collapse;background:#30a43b;'>");
				sb.append(data.getEta());
				sb.append("</TD>");
			} else {
				sb.append(
						"<TD align=\"left\" style='width:30%;border:solid #BFBFBF 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:22.5pt;border-collapse:collapse; background:#f6ca0a;'>");
				sb.append(data.getEta());
				sb.append("</TD>");
			}
			sb.append("</TR>");

		}
		return sb;
	}

	private StringBuffer createFooterContents() {

		LOGGER.debug("DownstreamEmailTemplateUtility::createFooterContents()::starts");
		StringBuffer sb = new StringBuffer();
		sb.append(
				"</TABLE></td></tr><tr><td colspan=\"5\" style=\"color:#8D9092; font-family:'Calibri';font-size:11.0pt; font-weight: normal;\">");
		sb.append(
				"BCC: *GT CN AQUA Secured Finance Dev; *GT GLOBAL AQUA S&U Build Team; *GT GLOBAL AQUA TRS Build Team; *GT IN Pune AQUA Recon & Control Team");
		sb.append(
				"</td></tr></table></BR><P style = \"font-size:12.0pt;font-family:'Calibri';\">CBA Build Team</body></P></html>");
		return sb;
	}

}
