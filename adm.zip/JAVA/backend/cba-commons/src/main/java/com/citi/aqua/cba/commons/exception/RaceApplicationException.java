package com.citi.aqua.cba.commons.exception;

import java.text.MessageFormat;
import java.util.Locale;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * This is the Common ApplicationException to use across the application.
 * 
 * @author mk35063
 *
 */
public class RaceApplicationException extends RaceException {

	private static final long serialVersionUID = 1L;

	private Object[] replaceOption;

	private ExceptionMessageDescriptor messageDescriptor;

	private String cause;

	private Locale default_Locale = Locale.US;

	private static final Logger LOGGER = LoggerFactory.getLogger(RaceApplicationException.class);

	/**
	 * Creates Application Exception which can be accessed as RaceException
	 * 
	 * @param exception
	 *            : Pass Throwable or RaceApplicationException. Passing
	 *            RaceApplicationException
	 * @param messageDescriptor
	 *            : ExceptionMessageDescriptor to capture the MessageCode and
	 *            Default Message (If any resource bundle could not be located
	 *            the default message will be used)
	 * @param replaceOption
	 *            : Variable arguments to pass the values to be replaced during
	 *            interpolation
	 */
	public RaceApplicationException(Throwable exception,
			ExceptionMessageDescriptor messageDescriptor,
			Object... replaceOption) {
		super(exception);
		this.cause = exception.getCause().getMessage();
		this.replaceOption = replaceOption;
		this.messageDescriptor = messageDescriptor;
	}

	public String getInterpolatedMessage(Locale locale) {
		ResourceBundle bundle = ResourceBundle.getBundle("i18n.race-message-bundle", locale);
		return constructInterpolatedMessages(bundle);
	}

	private String constructInterpolatedMessages(ResourceBundle bundle) {
		String message = "";
		try {
			message = bundle.getString(messageDescriptor.getMessageCode());
			if (replaceOption != null && replaceOption.length > 0) {
				message = MessageFormat.format(message, replaceOption);
			}
		} catch (MissingResourceException ex) {
			// If description not found for this code in bundle, set default
			// description
			LOGGER.error("No message found for code: "
					+ messageDescriptor.getMessageCode()
					+ ", setting default message desciption");
			message = messageDescriptor.getMessageDescription();
		}

		// If description returned from bundle is empty, set default
		if (message.isEmpty()) {
			message = messageDescriptor.getMessageDescription();
		}
		return message;
	}

	public String getDefaultInterpolatedMessage() {
		return getInterpolatedMessage(default_Locale);
	}

	public Object[] getReplaceOption() {
		return replaceOption;
	}

	public String getCauseMessage() {
		return this.cause;
	}

	public String getExceptionCode() {
		String errorCode = (messageDescriptor != null) ? messageDescriptor.getMessageCode() : "UNKNOWN";
		return errorCode;
	}
}
