package com.citi.aqua.cba.commons.exception;

/**
 * This is the Common Enum Class to store all application Exception messages .
 * We will be using code-message combination to store the messages. We will use
 * prefix letter in code to indicate which layer is using this messsage. e.g For
 * service code will start with "S" , for Controller its "C" etc, also for each
 * Screen we will reserver range for message like exception summary will start
 * with 1001 - 1100 and exception rule will start with 2001 On Client browser we
 * will get the code information to identify which error has occurred. Finally
 * these enum will be overwritten by bundle string RaceMessageBunddle.Properties
 * 
 * @author mk35063
 *
 */

public enum RestExceptionMessage implements ExceptionMessageDescriptor {

	// Exception Summary ESXXX
	FAILED_ALERT_SUMMARY_LIST("ES001", "Failed to retrieve Alert Summary List data. "), 
	FAILED_ALERT_SUMMARY_STATUS_CHART_DATA("ES002", "Failed to retrieve Top 5 Client Chart data."), 
	FAILED_ALERT_SUMMARY_TOP_CLIENT_CHART_DATA("ES003", "Failed to retrieve Top 5 Client Chart data."), 
	FAILED_ALERT_SUMMARY_ALERT_USER_DATA("ES004", "Failed to retrieve Alert user data."), 
	FAILED_ALERT_SUMMARY_ALERT_USER_LIST("ES005", "Failed to retrieve user list data."), 
	FAILED_ALERT_SUMMARY_ALERT_DATA("ES006", "Failed to retrieve Alert data for given selected ALERT#  {0}"), 
	FAILED_ALERT_SUMMARY_ASSIGNEE_LIST("ES007", "Failed to retrieve Assignee List data."), 
	FAILED_ALERT_SUMMARY_SECURITY_RULE("ES008", "Failed to retrieve security rule for selected ALERT# : {0}"), 
	FAILED_ALERT_SUMMARY_DOWNLOAD_FILE("ES009", "Failed to download selected File : {0}"),

	// Exception Rule  ERXXX
	FAILED_ALERT_RULE_LIST("ER001", "Failed to retrieve alert Rule list data."), 
	FAILED_ALERT_RULE_ALERT_DATA("ER002", "Failed to retrieve alert data."), 
	FAILED_ALERT_RULE_OPEN_ALERTS("ER003", "Failed to retrieve open alerts data."), 
	FAILED_ALERT_RULE_CLIENT_LIST("ER004", "Failed to retrieve clients data."), 
	FAILED_ALERT_RULE_FUND_LIST("ER005", "Failed to retrieve client funds data."), 
	FAILED_ALERT_RULE_LEGAL_ENTITIES("ER006", "Failed to retrieve client fund legal entities data."), 
	FAILED_ALERT_RULE_REGION_LIST("ER007", "Failed to retrieve regions data."), 
	FAILED_ALERT_RULE_MASTER_LIST("ER008", "Failed to retrieve alert rule master list data."), 
	FAILED_ALERT_RULE_MASTER_DATA_BY_TYPE("ER009", "Failed to retrieve alert rule master data for selected type."), 
	FAILED_ALERT_RULE_USER_DATA("ER010", "Failed to retrieve users data for alert rule type."), 

	
	// Client Overview COXXX
	FAILED_CLIENT_OVERVIEW_CLIENT_LIST("CO001", "Failed to retrieve clients data."), 
	FAILED_CLIENT_OVERVIEW_FUND_LIST("CO002", "Failed to retrieve client funds data."), 
	FAILED_CLIENT_OVERVIEW_REGION_LIST("CO003", "Failed to retrieve client fund regions data."), 
	FAILED_CLIENT_OVERVIEW_COB_DATES("CO004", "Failed to retrieve COB dates data."), 
	FAILED_CLIENT_OVERVIEW_MONTHLY_COB_DATES("CO005", "Failed to retrieve monthly COB dates data."), 
	FAILED_CLIENT_OVERVIEW_FINANCE_BALANCE_CHART("CO006", "Failed to retrieve financing balance chart data."), 
	FAILED_CLIENT_OVERVIEW_EQUITY_BALANCE_CHART("CO007", "Failed to retrieve equity balance chart data."),
	FAILED_CLIENT_OVERVIEW_BALANCESHEET_RAO_CHART("CO008", "Failed to retrieve Balance Sheet and ROA chart data."),
	FAILED_CLIENT_OVERVIEW_PB_REVENUE_CHART("CO009", "Failed to retrieve PB Revenue chart data."),
	FAILED_CLIENT_OVERVIEW_COUNTRY_RISK_CHART("CO010", "Failed to retrieve GMV by Country of Risk chart data."), 
	FAILED_CLIENT_OVERVIEW_PRODUCT_CHART("CO011", "Failed to retrieve GMV by product chart data."),
	FAILED_CLIENT_OVERVIEW_SECTOR_CHART("CO012", "Failed to retrieve GMV by sector chart data."),
	FAILED_CLIENT_OVERVIEW_MARKET_CAP_CHART("CO013", "Failed to retrieve GMV by market cap chart data."),	
	
	// Client Coverage CCXXX
	FAILED_CLIENT_COVERAGE_DATA("CC001", "Failed to clients coverage data."), 
	FAILED_CLIENT_COVERAGE_USER_DATA("CC002", "Failed to retrieve users data."), 
	
	// Admin AXXX
	FAILED_ADMIN_USERS_DATA("A001", "Failed to retrieve users data."), 
	FAILED_ADMIN_USER_COVERAGE_DATA("A002", "Failed to retrieve user coverage data."),
	FAILED_ADMIN_USER_DATA("A003", "Failed to retrieve user data."),
	FAILED_ADMIN_COVERAGE_LIST("A004", "Failed to retrieve client coverage list data."),
	FAILED_ADMIN_USER_HISTORY("A005", "Failed to retrieve user history data."),
	FAILED_ADMIN_USER_COVERAGE_HISTORY("A006", "Failed to retrieve user coverage history data.");
	
	private String messageCode;
	private String messageDescription;

	private RestExceptionMessage(String messageCode, String messageDescription) {
		this.messageCode = messageCode;
		this.messageDescription = messageDescription;
	}

	public String getMessageCode() {
		return messageCode;
	}

	public String getMessageDescription() {
		return messageDescription;
	}

}
