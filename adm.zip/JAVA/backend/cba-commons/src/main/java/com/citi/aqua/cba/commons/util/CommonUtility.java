package com.citi.aqua.cba.commons.util;

/**
 * @author ak92283
 */
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class CommonUtility {

	private static final Logger LOGGER = LoggerFactory.getLogger(CommonUtility.class);

	public String generateContentId(final String prefix) {
		LOGGER.debug("CommonUtility::generateContentId()::starts");
		return String.format("%s-%s", prefix, UUID.randomUUID());
	}

}
