package com.citi.services.client.cues.hessian.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service("propertyReader")
public class PropertyReader {

	@Value("${cert.path:''}")
	private String certPath;
	
	public String getCertPath() {
		return certPath;
	}
	
}
