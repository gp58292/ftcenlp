package com.citi.services.client.cues.hessian.service;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Date;
import java.util.HashMap;
import java.util.Optional;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;

import com.citi.gpf.common.ent.client.EntClientImpl;
import com.citi.gpf.common.ent.vo.ClientCoverage;

public class HessianService {

	@Autowired
	private DataSource dataSource;
	
	private EntClientImpl entClient	= new EntClientImpl();

	public static void main(String[] args) {
		System.out.println("############### Cues Main Application Started ###############");
		HessianService baltest = new HessianService();
		baltest.insertBatch();
		System.out.println("############### Cues Main Application Stopped ###############");
	}

	public void insertBatch() {
		JdbcTemplate jdbcTemplate;
		ApplicationContext context = new ClassPathXmlApplicationContext("CuesClientContext.xml");
		try {
			PropertyReader readerService = (PropertyReader) context.getBean("propertyReader");
			System.setProperty("javax.net.ssl.trustStore", readerService.getCertPath());
			
			dataSource = (DataSource) context.getBean("dataSource");
			jdbcTemplate = new JdbcTemplate(dataSource);
			
			HashMap<String, String> param = new HashMap<>();
			param.put("realm", "PB");	//mandatory field
			
			final ClientCoverage[] list = entClient.getClientCoverage(param);
			
			if(list.length > 0) {
				System.out.println("CUES data recieved from Hessian service, Number of records:: " + list.length);	
			} else {
				System.out.println("CUES data not recieved from Hessian service, No records to update");
				throw new Exception("Exception: CUES data not recieved from Hessian service, No records to update");
			}
			
			String truncateQuery = "delete from dbo.tbl_stg_client_coverage_from_cues";			
			System.out.println("Clear data from Table: tbl_stg_client_coverage_from_cues");
			jdbcTemplate.execute(truncateQuery);
			
			String cobDateQuery = "SELECT MAX(calendarid) FROM dbo.process_date";
			System.out.println("Get COB Date from Table: process_date");
			int cobDate = jdbcTemplate.queryForInt(cobDateQuery);
			System.out.println("Retrieved COB Date: " + cobDate);
			
			String sql = "INSERT INTO dbo.tbl_stg_client_coverage_from_cues "
					+ "("
			           + "relation_pfId			 	 ,"
			           + "relation                   ,"
			           + "investmentmanager_pfId     ,"
			           + "investmentmanager          ,"
			           + "region                     ,"
			           + "bizarea                    ,"
			           + "organization               ,"
			           + "topaccount                 ,"
			           + "modified_user              ,"
			           + "modified_date              ,"
			           + "coverage_soeid             ,"
			           + "coverage_firstname         ,"
			           + "coverage_lastname          ,"
			           + "coverage_company           ,"
			           + "coverage_phone             ,"
			           + "coverage_email             ,"
			           + "coverage_region            ,"
			           + "coverage_timezone          ,"
			           + "coverage_country           ,"
			           + "coverage_internalind       ,"
			           + "coverage_attributes        ,"
			           + "primary_soeid              ,"
			           + "primary_firstname          ,"
			           + "primary_lastname           ,"
			           + "Primary_company            ,"
			           + "Primary_phone              ,"
			           + "Primary_email              ,"
			           + "Primary_region             ,"
			           + "Primary_timezone           ,"
			           + "Primary_country            ,"
			           + "Primary_internalind        ,"
			           + "Primary_attributes         ,"
			           + "Secondary_soeid            ,"
			           + "Secondary_firstname        ,"
			           + "Secondary_lastname         ,"
			           + "Secondary_company          ,"
			           + "Secondary_phone            ,"
			           + "Secondary_email            ,"
			           + "Secondary_region           ,"
			           + "Secondary_timezone         ,"
			           + "Secondary_country          ,"
			           + "Secondary_internalind      ,"
			           + "Secondary_attributes       ,"
			           + "teamlead_soeid             ,"
			           + "teamlead_firstname         ,"
			           + "teamlead_lastname          ,"
			           + "teamlead_company           ,"
			           + "teamlead_phone             ,"
			           + "teamlead_email             ,"
			           + "teamlead_region            ,"
			           + "teamlead_timezone          ,"
			           + "teamlead_country           ,"
			           + "teamlead_internalind       ,"
			           + "teamlead_attributes        ,"
			           + "distributionalias          ,"
			           + "distributionemail          ,"
			           + "cob_date                   "
					+ ") "
					+ "VALUES ("
					+ "?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, "
					+ "?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, "
					+ "?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, "
					+ "?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, "
					+ "?, ?, ?, ?, ?"
					+ ")";

			System.out.println("Updating Table:: tbl_stg_client_coverage_from_cues");

			int[] arr = jdbcTemplate.batchUpdate(sql, new BatchPreparedStatementSetter() {
				public void setValues(PreparedStatement ps, int i) throws SQLException {
					ClientCoverage feed = list[i];

                    ps.setLong(1, 	 	feed.getRelpfId());
                    ps.setString(2,  	Optional.ofNullable(feed.getRelation()).orElse(""));
                    ps.setLong(3, 		feed.getImpfId());
                    ps.setString(4, 	Optional.ofNullable(feed.getIm()).orElse(""));
                    ps.setString(5, 	Optional.ofNullable(feed.getRegion()).orElse(""));
                    ps.setString(6, 	"Prime Brokerage");
                    ps.setString(7,  	Optional.ofNullable(feed.getOrganization()).orElse(""));
                    ps.setString(8, 	Optional.ofNullable(feed.getTopAcct()).orElse(""));
                    ps.setString(9,  	Optional.ofNullable(feed.getModUser()).orElse(""));
                    
                    if(feed.getModDate() != null) {
                    	ps.setDate(10, new java.sql.Date(feed.getModDate().getTime()));
                    } else {
                    	ps.setDate(10, new java.sql.Date(new Date().getTime()));
                    }
                    
                    if(feed.getCoverage() != null) {
	                    ps.setString(11,  Optional.ofNullable(feed.getCoverage().getUserId()).orElse(""));
						ps.setString(12,  Optional.ofNullable(feed.getCoverage().getFirstName()).orElse(""));
	                    ps.setString(13,  Optional.ofNullable(feed.getCoverage().getLastName()).orElse(""));
	                    ps.setString(14,  Optional.ofNullable(feed.getCoverage().getCompany()).orElse(""));
	                    ps.setString(15,  Optional.ofNullable(feed.getCoverage().getPhone()).orElse(""));
	                    ps.setString(16,  Optional.ofNullable(feed.getCoverage().getEmailAddr()).orElse(""));
	                    ps.setString(17,  Optional.ofNullable(feed.getCoverage().getRegion()).orElse(""));
	                    ps.setString(18,  Optional.ofNullable(feed.getCoverage().getTimezone()).orElse(""));
	                    ps.setString(19,  Optional.ofNullable(feed.getCoverage().getCountry()).orElse(""));
	                    ps.setString(20,  Optional.ofNullable(feed.getCoverage().getInternalInd()).orElse(""));
	                    ps.setString(21, "");
                    } else {
	                    ps.setString(11, "");
						ps.setString(12, "");
	                    ps.setString(13, "");
	                    ps.setString(14, "");
						ps.setString(15, "");
	                    ps.setString(16, "");
	                    ps.setString(17, "");
						ps.setString(18, "");
	                    ps.setString(19, "");
	                    ps.setString(20, "");
						ps.setString(21, "");
                    }
                    
                    if(feed.getPrimaryCoverage() != null) {
	                    ps.setString(22, Optional.ofNullable(feed.getPrimaryCoverage().getUserId()).orElse(""));
						ps.setString(23, Optional.ofNullable(feed.getPrimaryCoverage().getFirstName()).orElse(""));
	                    ps.setString(24, Optional.ofNullable(feed.getPrimaryCoverage().getLastName()).orElse(""));
	                    ps.setString(25, Optional.ofNullable(feed.getPrimaryCoverage().getCompany()).orElse(""));
	                    ps.setString(26, Optional.ofNullable(feed.getPrimaryCoverage().getPhone()).orElse(""));
	                    ps.setString(27, Optional.ofNullable(feed.getPrimaryCoverage().getEmailAddr()).orElse(""));
	                    ps.setString(28, Optional.ofNullable(feed.getPrimaryCoverage().getRegion()).orElse(""));
	                    ps.setString(29, Optional.ofNullable(feed.getPrimaryCoverage().getTimezone()).orElse(""));
	                    ps.setString(30, Optional.ofNullable(feed.getPrimaryCoverage().getCountry()).orElse(""));
	                    ps.setString(31, Optional.ofNullable(feed.getPrimaryCoverage().getInternalInd()).orElse(""));
	                    ps.setString(32, "");
                    } else {
						ps.setString(22, "");
	                    ps.setString(23, "");
	                    ps.setString(24, "");
						ps.setString(25, "");
	                    ps.setString(26, "");
	                    ps.setString(27, "");
						ps.setString(28, "");
	                    ps.setString(29, "");
	                    ps.setString(30, "");
						ps.setString(31, "");  
                        ps.setString(32, "");               	
                    }
                    
                    if(feed.getSecondaryCoverage() != null) {
	                    ps.setString(33, Optional.ofNullable(feed.getSecondaryCoverage().getUserId()).orElse(""));
						ps.setString(34, Optional.ofNullable(feed.getSecondaryCoverage().getFirstName()).orElse(""));
	                    ps.setString(35, Optional.ofNullable(feed.getSecondaryCoverage().getLastName()).orElse(""));
	                    ps.setString(36, Optional.ofNullable(feed.getSecondaryCoverage().getCompany()).orElse(""));
	                    ps.setString(37, Optional.ofNullable(feed.getSecondaryCoverage().getPhone()).orElse(""));
	                    ps.setString(38, Optional.ofNullable(feed.getSecondaryCoverage().getEmailAddr()).orElse(""));
	                    ps.setString(39, Optional.ofNullable(feed.getSecondaryCoverage().getRegion()).orElse(""));
	                    ps.setString(40, Optional.ofNullable(feed.getSecondaryCoverage().getTimezone()).orElse(""));
	                    ps.setString(41, Optional.ofNullable(feed.getSecondaryCoverage().getCountry()).orElse(""));
	                    ps.setString(42, Optional.ofNullable(feed.getSecondaryCoverage().getInternalInd()).orElse(""));
	                    ps.setString(43, "");
                    } else {
						ps.setString(33, "");
	                    ps.setString(34, "");
	                    ps.setString(35, "");
						ps.setString(36, "");
	                    ps.setString(37, "");
	                    ps.setString(38, "");
						ps.setString(39, "");
	                    ps.setString(40, "");
	                    ps.setString(41, "");
						ps.setString(42, "");  
                        ps.setString(43, "");
                    }
                    
                    if(feed.getTeamlead() != null ) {
	                    ps.setString(44, Optional.ofNullable(feed.getTeamlead().getUserId()).orElse(""));
	                    ps.setString(45, Optional.ofNullable(feed.getTeamlead().getFirstName()).orElse(""));
	                    ps.setString(46, Optional.ofNullable(feed.getTeamlead().getLastName()).orElse(""));
	                    ps.setString(47, Optional.ofNullable(feed.getTeamlead().getCompany()).orElse(""));
	                    ps.setString(48, Optional.ofNullable(feed.getTeamlead().getPhone()).orElse(""));
	                    ps.setString(49, Optional.ofNullable(feed.getTeamlead().getEmailAddr()).orElse(""));
	                    ps.setString(50, Optional.ofNullable(feed.getTeamlead().getRegion()).orElse(""));
	                    ps.setString(51, Optional.ofNullable(feed.getTeamlead().getTimezone()).orElse(""));
	                    ps.setString(52, Optional.ofNullable(feed.getTeamlead().getCountry()).orElse(""));
	                    ps.setString(53, Optional.ofNullable(feed.getTeamlead().getInternalInd()).orElse(""));
	                    ps.setString(54, "");
                    } else {
	                    ps.setString(44, "");
	                    ps.setString(45, "");
	                    ps.setString(46, "");
	                    ps.setString(47, "");
	                    ps.setString(48, "");
	                    ps.setString(49, "");
	                    ps.setString(50, "");
	                    ps.setString(51, "");
	                    ps.setString(52, "");
	                    ps.setString(53, "");
	                    ps.setString(54, "");
                    }
                    
                    ps.setString(55, Optional.ofNullable(feed.getDistributionEmail()).orElse(""));
                    ps.setString(56, Optional.ofNullable(feed.getDistributionEmail()).orElse(""));
                    ps.setInt(57, cobDate);
				}
				public int getBatchSize() {
					return list.length;
				}
			});

			if (arr.length > 0) {
				System.out.println("Number of Rows:: "+ arr.length +" updated successfully");
			} else {
				System.out.println("No records to update");
			}
		} catch (Exception e) {
			System.out.println("Exception occured: feed Not Completed");
			e.printStackTrace();
		} finally {
			System.out.println("############### Cues Main Application Stopped ###############");
			((ClassPathXmlApplicationContext) context).close();
			System.exit(0);
		}
	}
}
