package com.citi.services.client.datalend;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.citi.sbl.rates.api.marketdata.DatalendVariancePB.DatalendVariance;
import com.citi.services.client.datalend.configuration.DatalendConfiguration;
import com.citi.services.client.datalend.service.DatalendService;

public class DatalendMainApplication {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(DatalendMainApplication.class);
	
	public static void main(String[] args) {
		
		LOGGER.info("############### Datalend Main Application Started ###############");
		System.out.println("############### Datalend Main Application Started ###############");
		ApplicationContext context = new AnnotationConfigApplicationContext(DatalendConfiguration.class);
		
		try {
			DatalendService service = context.getBean(DatalendService.class);
			List<DatalendVariance> datalendVarianceList = service.getAllDatalendVar();
			
			if(datalendVarianceList != null && !datalendVarianceList.isEmpty()) {
				
				java.sql.Date sysDate = service.getSysDate();
				LOGGER.info("System Date {}: ", sysDate);
				int cobDate = service.findCobDate();
				LOGGER.info("COB Date is {}: ", cobDate);
				service.deleteDatalendVariance(cobDate);
				LOGGER.info("Inserting data into Table: stock_loan.tbl_datalend_equilend_rate for COB Date {}: And System Date {}:", cobDate, sysDate);
				service.insertDatalendVariance(datalendVarianceList, cobDate, sysDate);
				
				System.out.println("Feed recieved from Datalend service and data loaded for cobdate: " + cobDate);
				
			} else {
				LOGGER.error("Feed not recieved from Datalend service");
				System.out.println("Feed not recieved from Datalend service");
				throw new Exception("Exception: Feed not recieved from Datalend service");
			}
		} catch (Exception e) {
			LOGGER.error("Exception occured: feed Not Completed " + e);
			System.out.println(" #### Batch Failed : Exception occured: feed Not Completed ####");
			e.printStackTrace();
		} finally {
			System.out.println("############### Datalend Main Application Stopped ###############");
			LOGGER.info("############### Datalend Main Application Stopped ###############");
			((AnnotationConfigApplicationContext) context).close();
			System.exit(0);
		}
		
	}
}
