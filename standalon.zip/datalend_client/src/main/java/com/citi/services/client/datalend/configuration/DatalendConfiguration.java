package com.citi.services.client.datalend.configuration;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.sql.DataSource;

import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;
import org.jasypt.encryption.pbe.config.EnvironmentStringPBEConfig;
import org.jasypt.spring31.properties.EncryptablePropertySourcesPlaceholderConfigurer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.http.converter.protobuf.ProtobufHttpMessageConverter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.web.client.RestTemplate;

@Configuration
@ComponentScan(basePackages = "com.citi")
public class DatalendConfiguration {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(DatalendConfiguration.class);
	
    @Bean
    RestTemplate restTemplate(ProtobufHttpMessageConverter hmc) {
        return new RestTemplate(Arrays.asList(hmc));
    }

    @Bean
    ProtobufHttpMessageConverter protobufHttpMessageConverter() {
        return new ProtobufHttpMessageConverter();
    }
    
    @Bean
    public DataSource dataSource(@Value("${jdbc.driverClassName}") String driverClassName,  @Value("${jdbc.url}") String url,
            @Value("${jdbc.username}") String username,   @Value("${jdbc.password}") String password) {
        DriverManagerDataSource dataSource = new DriverManagerDataSource();
        dataSource.setDriverClassName(driverClassName);
        dataSource.setUrl(url);
        dataSource.setUsername(username);
        dataSource.setPassword(password);
        return dataSource;
    }
 
    @Bean
    public JdbcTemplate jdbcTemplate(DataSource dataSource) {
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        jdbcTemplate.setResultsMapCaseInsensitive(true);
        return jdbcTemplate;
    }
    
    @Bean
    public EnvironmentStringPBEConfig encryptorConfig() {
    	EnvironmentStringPBEConfig encryptorConfig = new EnvironmentStringPBEConfig();
    	encryptorConfig.setAlgorithm("PBEWithMD5AndDES");
    	encryptorConfig.setPasswordEnvName("APP_ENCRYPTION_PASSWORD");
    	return encryptorConfig;
    }
    
    @Bean
    public StandardPBEStringEncryptor encryptor(EnvironmentStringPBEConfig encryptorConfig) {
    	StandardPBEStringEncryptor encryptor = new StandardPBEStringEncryptor();
    	encryptor.setConfig(encryptorConfig);
    	return encryptor;
    }
    
    @Bean
    public EncryptablePropertySourcesPlaceholderConfigurer configureProperty(StandardPBEStringEncryptor encryptor) {
    	EncryptablePropertySourcesPlaceholderConfigurer configureProperty = new EncryptablePropertySourcesPlaceholderConfigurer(encryptor);
    	String proprtyFileName = System.getProperty("config_location") + "/application_" + System.getProperty("app_env") + ".properties";
    	LOGGER.info("Property file configured : {}", proprtyFileName);
    	File f = new File(proprtyFileName);
    	List<Resource> resources = new ArrayList<>();
    	resources.add(new FileSystemResource(f));
    	configureProperty.setLocations(resources.toArray(new Resource[resources.size()]));
    	configureProperty.setIgnoreUnresolvablePlaceholders(true);
    	return configureProperty;
    }
    
}
