package com.citi.services.client.datalend.service.impl;

import java.net.URI;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.citi.sbl.rates.api.marketdata.DatalendVariancePB;
import com.citi.sbl.rates.api.marketdata.DatalendVariancePB.DatalendVariance;
import com.citi.services.client.datalend.data.jdbc.DatalendDao;
import com.citi.services.client.datalend.service.DatalendService;

@Service("DatalendService")
public class DatalendServiceImpl implements DatalendService {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(DatalendServiceImpl.class);

	@Autowired
	private RestTemplate restTemplate;
	
	@Autowired
	private DatalendDao datalendDao;

	@Value("${datalend.remote.service.url}")
	private URI requestURI;
	
	@Override
    public List<DatalendVariancePB.DatalendVariance> getAllDatalendVar() {
		LOGGER.info("Inside DatalendServiceImpl:: getAllDatalendVar");
        DatalendVariancePB.GetAllDatalendVarianceDataRequest getRateRequest = buildGetFullDatalendVar().build();
        LOGGER.info("path: {}", requestURI);
        ResponseEntity<DatalendVariancePB.GetDatalendVarianceDataResponse> entity = restTemplate.postForEntity(requestURI, getRateRequest, DatalendVariancePB.GetDatalendVarianceDataResponse.class);
        DatalendVariancePB.GetDatalendVarianceDataResponse response = entity.getBody();
        LOGGER.info("response  count i.e. Records Found ==> ");
        LOGGER.info(" Records Found " +response.getResultListList().size());
        return response.getResultListList();
    }

    private DatalendVariancePB.GetAllDatalendVarianceDataRequest.Builder buildGetFullDatalendVar() {
        DatalendVariancePB.GetAllDatalendVarianceDataRequest.Builder requestBuilder = DatalendVariancePB.GetAllDatalendVarianceDataRequest.newBuilder();
        requestBuilder.setRequestingApp("StockLoan - Datalend Client Application");
        requestBuilder.setRequester("Datalend Client Autosys Job");
        return requestBuilder;
    }
    
    @Override
    public int findCobDate() {
		 LOGGER.info("Inside DatalendServiceImpl:: findCobDate");
		return datalendDao.findCobDate();
	}
	
    @Override
    public void deleteDatalendVariance(int cobDate) {
    	 LOGGER.info("Inside DatalendServiceImpl:: deleteDatalendVariance");
    	datalendDao.deleteDatalendVariance(cobDate);
	}
    
    @Override
    public java.sql.Date getSysDate() throws ParseException {
    	 LOGGER.info("Inside DatalendServiceImpl:: getSysDate");
		SimpleDateFormat sm = new SimpleDateFormat("yyyy-MM-dd");
		String strDate = sm.format(new Date());
		return new java.sql.Date(sm.parse(strDate).getTime());
	}

	@Override
	public void insertDatalendVariance(List<DatalendVariance> datalendVarianceList, int cobDate, java.sql.Date sysDate) {
		 LOGGER.info("Inside DatalendServiceImpl:: insertDatalendVariance");
		datalendDao.insertDatalendVariance(datalendVarianceList, cobDate, sysDate);
	}


}
