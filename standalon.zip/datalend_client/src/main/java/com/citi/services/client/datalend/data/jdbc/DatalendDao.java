package com.citi.services.client.datalend.data.jdbc;

import java.sql.Date;
import java.util.List;

import com.citi.sbl.rates.api.marketdata.DatalendVariancePB.DatalendVariance;

public interface DatalendDao {

	public int findCobDate();

	public void deleteDatalendVariance(int cobDate);

	public void insertDatalendVariance(List<DatalendVariance> datalendVarianceList, int cobDate, Date sysDate);

}
