package com.citi.services.client.datalend.data.jdbc.impl;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.citi.sbl.rates.api.marketdata.DatalendVariancePB;
import com.citi.services.client.datalend.data.jdbc.DatalendDao;

@Repository("DatalendDao")
public class DatalendDaoImpl implements DatalendDao {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(DatalendDaoImpl.class);

	@Autowired
	JdbcTemplate jdbcTemplate;
	
    @Override
    public int findCobDate() {
    	LOGGER.info("Inside findCobDate");
		String cobDateQuery = "SELECT MAX(calendarid) FROM CBA.dbo.process_date";
		LOGGER.info("Get COB Date from Table: process_date");
		return  jdbcTemplate.queryForObject(cobDateQuery, Integer.class);
	}
	
    @Override
    public void deleteDatalendVariance(int cobDate) {
		String truncateQuery = "delete from stock_loan.tbl_datalend_equilend_rate where cobdate = " + cobDate;			
		LOGGER.info("Clear data from Table: stock_loan.tbl_datalend_equilend_rate for cobdate: {}", cobDate);
		jdbcTemplate.execute(truncateQuery);
	}
    
    @Override
	public void insertDatalendVariance(final List<DatalendVariancePB.DatalendVariance> datalendVarianceList, int cobDate, java.sql.Date sysDate ) {
    	LOGGER.info("Inside insertDatalendVariance");
		
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append("INSERT INTO SL.[stock_loan].[tbl_datalend_equilend_rate] (fii, smcp, InventoryValue, InventoryQty, LoanValue, LoanQty, citiLenderBorrowValue, citiLenderBorrowQty, utilization, netAvailabilityQty, netAvailabilityValue, activeLendableQty, activeLendableValue, activeUtilization, avgCashOnlyRebate1Day, avgCashOnlyRebate5Day, avgCashOnlyRebate10Day, avgCashOnlyRebate30Day, avgCashOnlyRebate90Day, avgCashOnlyRebateAllDay, avgNonCashOnlyFee1Day, avgNonCashOnlyFee5Day, avgNonCashOnlyFee10Day, avgNonCashOnlyFee30Day, avgNonCashOnlyFee90Day, avgNonCashOnlyFeeAllDay, cashOnlyCollateralValue1Day, cashOnlyCollateralValue5Day, cashOnlyCollateralValue10Day, cashOnlyCollateralValue30Day, cashOnlyCollateralValue90Day, cashOnlyCollateralValueAllDay, nonCashOnlyCollateralValue1Day, nonCashOnlyCollateralValue5Day, nonCashOnlyCollateralValue10Day, nonCashOnlyCollateralValue30Day, nonCashOnlyCollateralValue90Day, nonCashOnlyCollateralValueAllDay, avgFee1Day, avgFee5Day, avgFee10Day, avgFee30Day, avgFee90Day, avgFeeAllDay, citiAvgCashOnlyRebate1Day, citiAavgCashOnlyRebate5Day, citiAavgCashOnlyRebate10Day, citiAvgCashOnlyRebate30Day, citiAvgCashOnlyRebate90Day, citiAvgCashOnlyRebateAllDay, citiAvgNonCashOnlyFee1Day, citiAvgNonCashOnlyFee5Day, citiAvgNonCashOnlyFee10Day, citiAvgNonCashOnlyFee30Day, citiAvgNonCashOnlyFee90Day, citiAvgNonCashOnlyFeeAllDay, citiCashOnlyCollateralValue1Day, citiCOnlyCollateralValue5Day, citiCashOnlyCollateralValue10Day, citiCashOnlyCollateralValue30Day, citiCashOnlyCollateralValue90Day, citiCashOnlyCollateralValueAllDay, citiNonCashOnlyCollateralValue1Day, citiNonCashOnlyCollateralValue5Day, citiNonCashOnlyCollateralValue10Day, citiNonCashOnlyCollateralValue30Day, citiNonCashOnlyCollateralValue90Day, citiNonCashOnlyCollateralValueAllDay, citiAvgFee1Day, citiAvgFee5Day, citiAvgFee10Day, citiAvgFee30Day, citiAvgFee90Day, citiAvgFeeAllDay, citiLenderMarketShare, citiBrokerMarketShare, borrowerCount, lenderCount, lenderInventoryCount, brokerToBrokerValue, brokerToBrokerQty, brokerToBrokerCashOnlyRebate, brokerToBrokerNonCashOnlyFee, brokerToBrokerFee, citiBrokerBorrowValue, citiBrokerBorrowQty, citiBrokerBorrowCashOnlyRebate, citiBrokerBorrowNonCashOnlyFee, citiBrokerBorrowFee, loadDate, CBALoaddate, cobdate) ");
		stringBuilder.append(
				" VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
		String sql = stringBuilder.toString();
		
		LOGGER.info("sql query formed: {}", sql);
		LOGGER.info("############## Updating Table: SL.[stock_loan].[tbl_datalend_equilend_rate] ##############");
		
		int[] arr =  jdbcTemplate.batchUpdate(sql, new BatchPreparedStatementSetter() {

			@Override
			public void setValues(PreparedStatement ps, int i) throws SQLException {
					
				DatalendVariancePB.DatalendVariance respSecurity = datalendVarianceList.get(i);
				ps.setDouble(1, respSecurity.getFii());
				ps.setString(2, Optional.ofNullable(respSecurity.getSmcp()).orElse(""));
				ps.setDouble(3, respSecurity.getInventoryValue());
				ps.setDouble(4, respSecurity.getInventoryQty());
				ps.setDouble(5, respSecurity.getLoanValue());
				ps.setDouble(6, respSecurity.getLoanQty());
				ps.setDouble(7, respSecurity.getCitiLenderBorrowValue());
				ps.setDouble(8, respSecurity.getCitiLenderBorrowQty());
				ps.setDouble(9, respSecurity.getUtilization());
				ps.setDouble(10, respSecurity.getNetAvailabilityQty());
				ps.setDouble(11, respSecurity.getNetAvailabilityValue());
				ps.setDouble(12, respSecurity.getActiveLendableQty());
				ps.setDouble(13, respSecurity.getActiveLendableValue());
				ps.setDouble(14, respSecurity.getActiveUtilization());
				ps.setDouble(15, respSecurity.getAvgCashOnlyRebate1Day());
				ps.setDouble(16, respSecurity.getAvgCashOnlyRebate5Day());
				ps.setDouble(17, respSecurity.getAvgCashOnlyRebate10Day());
				ps.setDouble(18, respSecurity.getAvgCashOnlyRebate30Day());
				ps.setDouble(19, respSecurity.getAvgCashOnlyRebate90Day());
				ps.setDouble(20, respSecurity.getAvgCashOnlyRebateAllDay());
				ps.setDouble(21, respSecurity.getAvgNonCashOnlyFee1Day());
				ps.setDouble(22, respSecurity.getAvgNonCashOnlyFee5Day());
				ps.setDouble(23, respSecurity.getAvgNonCashOnlyFee10Day());
				ps.setDouble(24, respSecurity.getAvgNonCashOnlyFee30Day());
				ps.setDouble(25, respSecurity.getAvgNonCashOnlyFee90Day());
				ps.setDouble(26, respSecurity.getAvgNonCashOnlyFeeAllDay());
				ps.setDouble(27, respSecurity.getCashOnlyCollateralValue1Day());
				ps.setDouble(28, respSecurity.getCashOnlyCollateralValue5Day());
				ps.setDouble(29, respSecurity.getCashOnlyCollateralValue10Day());
				ps.setDouble(30, respSecurity.getCashOnlyCollateralValue30Day());
				ps.setDouble(31, respSecurity.getCitiCashOnlyCollateralValue90Day());
				ps.setDouble(32, respSecurity.getCitiCashOnlyCollateralValueAllDay());
				ps.setDouble(33, respSecurity.getCitiNonCashOnlyCollateralValue1Day());
				ps.setDouble(34, respSecurity.getCitiNonCashOnlyCollateralValue5Day());
				ps.setDouble(35, respSecurity.getNonCashOnlyCollateralValue10Day());
				ps.setDouble(36, respSecurity.getNonCashOnlyCollateralValue30Day());
				ps.setDouble(37, respSecurity.getNonCashOnlyCollateralValue90Day());
				ps.setDouble(38, respSecurity.getNonCashOnlyCollateralValueAllDay());
				ps.setDouble(39, respSecurity.getAvgFee1Day());
				ps.setDouble(40, respSecurity.getAvgFee5Day());
				ps.setDouble(41, respSecurity.getAvgFee10Day());
				ps.setDouble(42, respSecurity.getAvgFee30Day());
				ps.setDouble(43, respSecurity.getAvgFee90Day());
				ps.setDouble(44, respSecurity.getAvgFeeAllDay());
				ps.setDouble(45, respSecurity.getCitiAvgCashOnlyRebate1Day());
				ps.setDouble(46, respSecurity.getAvgCashOnlyRebate5Day());
				ps.setDouble(47, respSecurity.getAvgCashOnlyRebate10Day());
				ps.setDouble(48, respSecurity.getCitiAvgCashOnlyRebate30Day());
				ps.setDouble(49, respSecurity.getCitiAvgCashOnlyRebate90Day());
				ps.setDouble(50, respSecurity.getCitiAvgCashOnlyRebateAllDay());
				ps.setDouble(51, respSecurity.getCitiAvgNonCashOnlyFee1Day());
				ps.setDouble(52, respSecurity.getCitiAvgNonCashOnlyFee5Day());
				ps.setDouble(53, respSecurity.getCitiAvgNonCashOnlyFee10Day());
				ps.setDouble(54, respSecurity.getCitiAvgNonCashOnlyFee30Day());
				ps.setDouble(55, respSecurity.getCitiAvgNonCashOnlyFee90Day());
				ps.setDouble(56, respSecurity.getCitiAvgNonCashOnlyFeeAllDay());
				ps.setDouble(57, respSecurity.getCitiCashOnlyCollateralValue1Day());
				ps.setDouble(58, respSecurity.getCitiCOnlyCollateralValue5Day());
				ps.setDouble(59, respSecurity.getCitiCashOnlyCollateralValue10Day());
				ps.setDouble(60, respSecurity.getCitiCashOnlyCollateralValue30Day());
				ps.setDouble(61, respSecurity.getCitiCashOnlyCollateralValue90Day());
				ps.setDouble(62, respSecurity.getCitiCashOnlyCollateralValueAllDay());
				ps.setDouble(63, respSecurity.getCitiNonCashOnlyCollateralValue1Day());
				ps.setDouble(64, respSecurity.getCitiNonCashOnlyCollateralValue5Day());
				ps.setDouble(65, respSecurity.getCitiNonCashOnlyCollateralValue10Day());
				ps.setDouble(66, respSecurity.getCitiNonCashOnlyCollateralValue30Day());
				ps.setDouble(67, respSecurity.getCitiNonCashOnlyCollateralValue90Day());
				ps.setDouble(68, respSecurity.getCitiNonCashOnlyCollateralValueAllDay());
				ps.setDouble(69, respSecurity.getCitiAvgFee1Day());
				ps.setDouble(70, respSecurity.getCitiAvgFee5Day());
				ps.setDouble(71, respSecurity.getCitiAvgFee10Day());
				ps.setDouble(72, respSecurity.getCitiAvgFee30Day());
				ps.setDouble(73, respSecurity.getCitiAvgFee90Day());
				ps.setDouble(74, respSecurity.getCitiAvgFeeAllDay());
				ps.setDouble(75, respSecurity.getCitiLenderMarketShare());
				ps.setDouble(76, respSecurity.getCitiBrokerMarketShare());
				ps.setDouble(77, respSecurity.getBorrowerCount());
				ps.setDouble(78, respSecurity.getLenderCount());
				ps.setDouble(79, respSecurity.getLenderInventoryCount());
				ps.setDouble(80, respSecurity.getBrokerToBrokerValue());
				ps.setDouble(81, respSecurity.getBrokerToBrokerQty());
				ps.setDouble(82, respSecurity.getBrokerToBrokerCashOnlyRebate());
				ps.setDouble(83, respSecurity.getBrokerToBrokerNonCashOnlyFee());
				ps.setDouble(84, respSecurity.getBrokerToBrokerFee());
				ps.setDouble(85, respSecurity.getCitiBrokerBorrowValue());
				ps.setDouble(86, respSecurity.getCitiBrokerBorrowQty());
				ps.setDouble(87, respSecurity.getCitiBrokerBorrowCashOnlyRebate());
				ps.setDouble(88, respSecurity.getCitiBrokerBorrowNonCashOnlyFee());
				ps.setDouble(89, respSecurity.getCitiBrokerBorrowFee());
				ps.setInt(90, respSecurity.getLoadDate());
				ps.setDate(91, sysDate);
				ps.setInt(92, cobDate);
			}
			@Override
			public int getBatchSize() {
				return datalendVarianceList.size();
			}
		  });
		
		if (arr.length > 0) {
			LOGGER.info("########### Rows are updated successfully #########");
		} else {
			LOGGER.info("No records to update");
		}
	}
	
}
