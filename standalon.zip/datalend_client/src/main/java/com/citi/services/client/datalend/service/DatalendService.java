package com.citi.services.client.datalend.service;

import java.sql.Date;
import java.text.ParseException;
import java.util.List;

import com.citi.sbl.rates.api.marketdata.DatalendVariancePB.DatalendVariance;

public interface DatalendService {

	public List<DatalendVariance> getAllDatalendVar();

	public int findCobDate();
	
	public void deleteDatalendVariance(int cobDate);

	public Date getSysDate() throws ParseException;

	public void insertDatalendVariance(List<DatalendVariance> datalendVarianceList, int cobDate, Date sysDate);

}
