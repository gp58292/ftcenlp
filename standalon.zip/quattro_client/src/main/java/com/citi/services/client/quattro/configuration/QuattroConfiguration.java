package com.citi.services.client.quattro.configuration;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;
import org.jasypt.encryption.pbe.config.EnvironmentStringPBEConfig;
import org.jasypt.spring31.properties.EncryptablePropertySourcesPlaceholderConfigurer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

@Configuration
@ComponentScan(basePackages = "com.citi")
public class QuattroConfiguration {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(QuattroConfiguration.class);
	
    @Bean
    public DataSource azDataSource(@Value("${jdbc.driverClassName}") String driverClassName,  @Value("${jdbc.az.url}") String url,
            @Value("${jdbc.username}") String username,   @Value("${jdbc.password}") String password) {
        DriverManagerDataSource dataSource = new DriverManagerDataSource();
        dataSource.setDriverClassName(driverClassName);
        dataSource.setUrl(url);
        dataSource.setUsername(username);
        dataSource.setPassword(password);
        return dataSource;
    }
 
    @Bean
    public JdbcTemplate azJdbcTemplate(DataSource azDataSource) {
        JdbcTemplate jdbcTemplate = new JdbcTemplate(azDataSource);
        jdbcTemplate.setResultsMapCaseInsensitive(true);
        return jdbcTemplate;
    }
    
    @Bean
    public DataSource lzDataSource(@Value("${jdbc.driverClassName}") String driverClassName,  @Value("${jdbc.lz.url}") String url,
            @Value("${jdbc.username}") String username,   @Value("${jdbc.password}") String password) {
        DriverManagerDataSource dataSource = new DriverManagerDataSource();
        dataSource.setDriverClassName(driverClassName);
        dataSource.setUrl(url);
        dataSource.setUsername(username);
        dataSource.setPassword(password);
        return dataSource;
    }
 
    @Bean
    public JdbcTemplate lzJdbcTemplate(DataSource lzDataSource) {
        JdbcTemplate jdbcTemplate = new JdbcTemplate(lzDataSource);
        jdbcTemplate.setResultsMapCaseInsensitive(true);
        return jdbcTemplate;
    }
    
    @Bean
    public EnvironmentStringPBEConfig encryptorConfig() {
    	EnvironmentStringPBEConfig encryptorConfig = new EnvironmentStringPBEConfig();
    	encryptorConfig.setAlgorithm("PBEWithMD5AndDES");
    	encryptorConfig.setPasswordSysPropertyName("APP_ENCRYPTION_PASSWORD");
    	return encryptorConfig;
    }
    
    @Bean
    public StandardPBEStringEncryptor encryptor(EnvironmentStringPBEConfig encryptorConfig) {
    	StandardPBEStringEncryptor encryptor = new StandardPBEStringEncryptor();
    	encryptor.setConfig(encryptorConfig);
    	return encryptor;
    }
    
    @Bean
    public static EncryptablePropertySourcesPlaceholderConfigurer configureProperty(StandardPBEStringEncryptor encryptor) {
    	EncryptablePropertySourcesPlaceholderConfigurer configureProperty = new EncryptablePropertySourcesPlaceholderConfigurer(encryptor);
    	String proprtyFileName = System.getProperty("config_location") + "/application_" + System.getProperty("app_env") + ".properties";
    	LOGGER.info("Property file configured : {}", proprtyFileName);
    	File f = new File(proprtyFileName);
    	List<Resource> resources = new ArrayList<>();
    	resources.add(new FileSystemResource(f));
    	configureProperty.setLocations(resources.toArray(new Resource[resources.size()]));
    	configureProperty.setIgnoreUnresolvablePlaceholders(true);
    	return configureProperty;
    }
    
}
