package com.citi.services.client.quattro.dto;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.List;

public class AgreementQuattro {

	private int agreementId;

	private Date cobDate;

	private String countryOfRisk;

	private String currency;

	private String extension;

	private Long gfcId;

	private int lvid;

	private String lvidName;

	private String mnemonic;

	private String nettingPortfolio;

	private String obligor;

	private String postingFirmAccount;

	private String productType;

	private String region;

	private String reportingLvid;

	private String reportingLvidName;
	
	private String resolvedBusinessUnit;

	private String securityAgreement;

	private String shelf;

	private String source;

	private String uinid;

	private String underlyingBusinessUnit;
	
	private Double value;

	private List<BigDecimal> underlyingExposure;

	private List<Integer> underlyingExposureProfileDays;
	
	private List<Integer> underlyingepe;

	public int getAgreementId() {
		return agreementId;
	}

	public void setAgreementId(int agreementId) {
		this.agreementId = agreementId;
	}

	public Date getCobDate() {
		return cobDate;
	}

	public void setCobDate(Date cobDate) {
		this.cobDate = cobDate;
	}

	public String getCountryOfRisk() {
		return countryOfRisk;
	}

	public void setCountryOfRisk(String countryOfRisk) {
		this.countryOfRisk = countryOfRisk;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getExtension() {
		return extension;
	}

	public void setExtension(String extension) {
		this.extension = extension;
	}

	public Long getGfcId() {
		return gfcId;
	}

	public void setGfcId(Long gfcId) {
		this.gfcId = gfcId;
	}

	public int getLvid() {
		return lvid;
	}

	public void setLvid(int lvid) {
		this.lvid = lvid;
	}

	public String getLvidName() {
		return lvidName;
	}

	public void setLvidName(String lvidName) {
		this.lvidName = lvidName;
	}

	public String getMnemonic() {
		return mnemonic;
	}

	public void setMnemonic(String mnemonic) {
		this.mnemonic = mnemonic;
	}

	public String getNettingPortfolio() {
		return nettingPortfolio;
	}

	public void setNettingPortfolio(String nettingPortfolio) {
		this.nettingPortfolio = nettingPortfolio;
	}

	public String getObligor() {
		return obligor;
	}

	public void setObligor(String obligor) {
		this.obligor = obligor;
	}

	public String getPostingFirmAccount() {
		return postingFirmAccount;
	}

	public void setPostingFirmAccount(String postingFirmAccount) {
		this.postingFirmAccount = postingFirmAccount;
	}

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getReportingLvid() {
		return reportingLvid;
	}

	public void setReportingLvid(String reportingLvid) {
		this.reportingLvid = reportingLvid;
	}

	public String getReportingLvidName() {
		return reportingLvidName;
	}

	public void setReportingLvidName(String reportingLvidName) {
		this.reportingLvidName = reportingLvidName;
	}

	public String getResolvedBusinessUnit() {
		return resolvedBusinessUnit;
	}

	public void setResolvedBusinessUnit(String resolvedBusinessUnit) {
		this.resolvedBusinessUnit = resolvedBusinessUnit;
	}

	public String getSecurityAgreement() {
		return securityAgreement;
	}

	public void setSecurityAgreement(String securityAgreement) {
		this.securityAgreement = securityAgreement;
	}

	public String getShelf() {
		return shelf;
	}

	public void setShelf(String shelf) {
		this.shelf = shelf;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getUinid() {
		return uinid;
	}

	public void setUinid(String uinid) {
		this.uinid = uinid;
	}

	public String getUnderlyingBusinessUnit() {
		return underlyingBusinessUnit;
	}

	public void setUnderlyingBusinessUnit(String underlyingBusinessUnit) {
		this.underlyingBusinessUnit = underlyingBusinessUnit;
	}

	public Double getValue() {
		return value;
	}

	public void setValue(Double value) {
		this.value = value;
	}

	public List<BigDecimal> getUnderlyingExposure() {
		return underlyingExposure;
	}

	public void setUnderlyingExposure(List<BigDecimal> underlyingExposure) {
		this.underlyingExposure = underlyingExposure;
	}

	public List<Integer> getUnderlyingExposureProfileDays() {
		return underlyingExposureProfileDays;
	}

	public void setUnderlyingExposureProfileDays(List<Integer> underlyingExposureProfileDays) {
		this.underlyingExposureProfileDays = underlyingExposureProfileDays;
	}

	public List<Integer> getUnderlyingepe() {
		return underlyingepe;
	}

	public void setUnderlyingepe(List<Integer> underlyingepe) {
		this.underlyingepe = underlyingepe;
	}
	
}
