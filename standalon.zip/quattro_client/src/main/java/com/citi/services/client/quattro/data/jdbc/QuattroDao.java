package com.citi.services.client.quattro.data.jdbc;

import java.util.List;

import com.citi.services.client.quattro.model.AgreementQuattroEntity;

public interface QuattroDao {

	public String findCobDate();

	public int insertQuattroFeed(List<AgreementQuattroEntity> agreementQuattroEntityList);

}
