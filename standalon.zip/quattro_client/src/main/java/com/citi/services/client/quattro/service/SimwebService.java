package com.citi.services.client.quattro.service;

import java.util.List;

import com.citi.services.client.quattro.dto.QuattroResponse;
import com.citi.services.client.quattro.model.AgreementQuattroEntity;

public interface SimwebService {

	public QuattroResponse fetchFinconFeed(String oAuthToken, String cobDate) throws Exception;

	public void fetchCobDate(String oAuthToken);
	public void updateFinconFeed(List<AgreementQuattroEntity> agreementQuattroEntityList);

}
