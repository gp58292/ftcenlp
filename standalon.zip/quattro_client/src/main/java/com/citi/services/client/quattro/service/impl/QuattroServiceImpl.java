package com.citi.services.client.quattro.service.impl;

import java.io.IOException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.citi.services.client.quattro.data.jdbc.QuattroDao;
import com.citi.services.client.quattro.dto.QuattroResponse;
import com.citi.services.client.quattro.model.AgreementQuattroEntity;
import com.citi.services.client.quattro.service.QuattroService;
import com.citi.services.client.quattro.util.JsonUtil;

@Service("QuattroService")
public class QuattroServiceImpl implements QuattroService {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(QuattroServiceImpl.class);
	
	@Autowired
	private QuattroDao quattroDao;
	
    @Override
    public String findCobDate() {
		 LOGGER.debug("Inside QuattroServiceImpl:: findCobDate");
	     return quattroDao.findCobDate();
	}

	@Override
	public List<AgreementQuattroEntity> convertDummyJsonToListOfObject() throws IOException {
//		String beginning = "[";
// 		String end = "]";
//		List<AgreementQuattroEntity> agreementQuattroEntityList = new ArrayList<>();
//		ObjectMapper objectMapper = new ObjectMapper();
//		InputStream inputStream = TypeReference.class.getResourceAsStream("/json/quattro_sample_data_format.json");
//		List<InputStream> streams = Arrays.asList(new ByteArrayInputStream(beginning.getBytes()), inputStream, new ByteArrayInputStream(end.getBytes()));
//		InputStream modifiedStream = new SequenceInputStream(Collections.enumeration(streams));
//		List<AgreementQuattro> agreementQuattroDTOList = objectMapper.readValue(modifiedStream,	new TypeReference<List<AgreementQuattro>>() {});
//		try {
//			agreementQuattroEntityList = JsonUtil.convertObject(agreementQuattroDTOList);
//		} catch(Exception e) {
//			LOGGER.error("Exception occured :"+ e);
//		} finally {
//			modifiedStream.close();
//		}
//		return agreementQuattroEntityList;
		return null;
	}

	@Override
	public List<AgreementQuattroEntity> convertJsonToListOfObject(QuattroResponse feed) throws IOException {
		return JsonUtil.convertObject(feed);
	}

	@Override
	public int insertQuattroFeed(List<AgreementQuattroEntity> agreementQuattroEntityList) {
		 LOGGER.debug("Inside QuattroServiceImpl:: insertQuattroFeed");
		return quattroDao.insertQuattroFeed(agreementQuattroEntityList);
	}

}
