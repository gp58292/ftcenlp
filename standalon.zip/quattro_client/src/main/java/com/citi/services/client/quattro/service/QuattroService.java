package com.citi.services.client.quattro.service;

import java.io.IOException;
import java.util.List;

import com.citi.services.client.quattro.dto.QuattroResponse;
import com.citi.services.client.quattro.model.AgreementQuattroEntity;

public interface QuattroService {

	public String findCobDate();
	
	public List<AgreementQuattroEntity> convertJsonToListOfObject(QuattroResponse feed) throws IOException;

	public List<AgreementQuattroEntity> convertDummyJsonToListOfObject() throws IOException;
	
	public int insertQuattroFeed(List<AgreementQuattroEntity> agreementQuattroEntityList);
	
}
