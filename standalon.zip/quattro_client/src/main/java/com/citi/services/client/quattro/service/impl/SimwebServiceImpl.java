package com.citi.services.client.quattro.service.impl;

import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.util.List;

import org.apache.http.client.utils.URIBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.citi.services.client.quattro.configuration.QuattroConfiguration;
import com.citi.services.client.quattro.dto.QuattroResponse;
import com.citi.services.client.quattro.model.AgreementQuattroEntity;
import com.citi.services.client.quattro.service.QuattroService;
import com.citi.services.client.quattro.service.SimwebService;
import com.citi.services.client.quattro.util.HttpUtil;
import com.citi.services.client.quattro.util.JsonUtil;

@Service
public class SimwebServiceImpl implements SimwebService {

	private static final Logger LOGGER = LoggerFactory.getLogger(SimwebServiceImpl.class);

	@Value("${simweb.url.scheme}")
	private String scheme;

	@Value("${simweb.url.host}")
	private String host;

	@Value("${simweb.url.port}")
	private String port;

	@Value("${simweb.finconFeed.api.uri}")
	private String finconFeedApiUri;

	@Value("${simweb.cobDate.api.uri}")
	private String cobDateApiUri;

	@Value("${simweb.finconFeed.page}")
	private String page;

	@Value("${simweb.finconFeed.pagesize}")
	private String pageSize;

	@Value("${simweb.finconFeed.reportingFrequency}")
	private String reportingFrequency;

	@Value("${simweb.finconFeed.underlyingee}")
	private String underlyingee;

	@Override
	public QuattroResponse fetchFinconFeed(String oAuthToken, String cobDate) throws Exception {
		ApplicationContext context = new AnnotationConfigApplicationContext(QuattroConfiguration.class);
		QuattroService service = context.getBean(QuattroService.class);
		QuattroResponse feed = null;
		try {
			URIBuilder builder = new URIBuilder();
			builder.setScheme(scheme);
			builder.setHost(host);
			builder.setPort(Integer.parseInt(port));
			builder.setPath(finconFeedApiUri);
			builder.setParameter("date", "2018-04-20");
			builder.setParameter("underlyingee", underlyingee);
			builder.setParameter("page", page);
			builder.setParameter("n", pageSize);
			builder.setParameter("reportingFrequency", reportingFrequency);

			// String url
			// ="https://simpliciti.uat.nam.nsroot.net/api/counterparty/v2/FinconFeed?date=2018-04-20&underlyingee=true&page=1&n=100&reportingFrequency=ALL&nextPage=13";
			String url = builder.build().toURL().toString();
			LOGGER.info("Fincon Feed URL: {}", url);
			RestTemplate restTemplate = new RestTemplate(HttpUtil.trustAllCerts());
			ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.GET,
					HttpUtil.appendHeaderWithOAuthToken(oAuthToken), String.class);
			feed = JsonUtil.mapToObject(response);
			List<AgreementQuattroEntity> agreementQuattroEntityList = service.convertJsonToListOfObject(feed);

			LOGGER.info("No of records" + agreementQuattroEntityList);
			if (agreementQuattroEntityList != null && !agreementQuattroEntityList.isEmpty()) {
				updateFinconFeed(agreementQuattroEntityList);
			} else {
				LOGGER.info("Fincon feed recieved from Sibweb service, No records to update");
				throw new Exception("Exception: CUES data not recieved from Sibweb service, No records to update");
			}
			do {

				url = builder.getScheme() + "://" + builder.getHost() + ":" + builder.getPort();
				response = restTemplate.exchange(url + feed.getNext().getHref(), HttpMethod.GET,
						HttpUtil.appendHeaderWithOAuthToken(oAuthToken), String.class);
				LOGGER.info("Fincon Feed URL: {}", url + feed.getNext().getHref());
				feed = JsonUtil.mapToObject(response);
				agreementQuattroEntityList = service.convertJsonToListOfObject(feed);

				LOGGER.info("No of records" + agreementQuattroEntityList.size());

				if (!agreementQuattroEntityList.isEmpty()) {
					updateFinconFeed(agreementQuattroEntityList);
				}
			} while (feed.getNext().getHref() != null);
		} catch (MalformedURLException | URISyntaxException e) {
			LOGGER.info("Exception occured", e.getMessage());
		}
		return feed;
	}

	@Override
	public void fetchCobDate(String oAuthToken) {
		try {
			URIBuilder builder = new URIBuilder();
			builder.setScheme(scheme);
			builder.setHost(host);
			builder.setPort(Integer.parseInt(port));
			builder.setPath(cobDateApiUri);

			String url = builder.build().toURL().toString();
			LOGGER.info("Cob Date URL: {}", url);

			RestTemplate restTemplate = new RestTemplate(HttpUtil.trustAllCerts());
			ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.GET,
					HttpUtil.appendHeaderWithOAuthToken(oAuthToken), String.class);
			LOGGER.info("####### Response from SIMWEB:: cobDate is {} ####### ", response);
		} catch (MalformedURLException | URISyntaxException e) {
			LOGGER.info("Exception occured", e.getMessage());
		}
	}

	@Override
	public void updateFinconFeed(List<AgreementQuattroEntity> agreementQuattroEntityList) {
		ApplicationContext context = new AnnotationConfigApplicationContext(QuattroConfiguration.class);
		QuattroService service = context.getBean(QuattroService.class);
		int recordsUpdated = service.insertQuattroFeed(agreementQuattroEntityList);
		if (recordsUpdated > 0) {
			LOGGER.info("Number of Rows:: {} inserted successfully", recordsUpdated);
		} else {
			LOGGER.info("No records to insert");
		}

	}

}
