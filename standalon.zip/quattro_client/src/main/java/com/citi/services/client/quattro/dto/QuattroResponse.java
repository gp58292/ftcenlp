package com.citi.services.client.quattro.dto;

import java.util.List;

public class QuattroResponse {

	private List<Feed> Feeds;
	private Next Next;
	public List<Feed> getFeeds() {
		return Feeds;
	}
	public void setFeeds(List<Feed> feeds) {
		Feeds = feeds;
	}
	public Next getNext() {
		return Next;
	}
	public void setNext(Next next) {
		Next = next;
	}
	
	
	
	
	
}
