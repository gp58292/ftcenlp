package com.citi.services.client.quattro.service.impl;

import java.net.MalformedURLException;
import java.net.URISyntaxException;

import org.apache.http.client.utils.URIBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.citi.services.client.quattro.dto.OAuthAccessTokenResponse;
import com.citi.services.client.quattro.service.OAuthAccessTokenService;
import com.citi.services.client.quattro.util.HttpUtil;

@Service
public class OAuthAccessTokenServiceImpl implements OAuthAccessTokenService {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(OAuthAccessTokenServiceImpl.class);
	
	@Value("${oAuth.url.scheme}")
	private String scheme;
	
	@Value("${oAuth.url.host}")
	private String host;
	
	@Value("${oAuth.token.api.uri}")
	private String oAuthTokenApiUri;
	
	@Value("${oAuth.client.grant.type}")
	private String clientGrantType;
	
	@Value("${oAuth.client.id}")
	private String clientId;
	
	@Value("${oAuth.client.secret}")
	private String clientSecret;
	
	@Value("${access.token.flag}")
	private Boolean isAccessTokenNeeded;
	
	@Value("${oAuth.scope}")
	private String scope;
	
	@Override
	public OAuthAccessTokenResponse fetchOAuthAccessToken() {
		LOGGER.debug("OAuthAccessTokenServiceImpl:: fetchOAuthAccessToken");
		OAuthAccessTokenResponse response = null;
		try {
			URIBuilder builder = new URIBuilder();
			builder.setScheme(scheme);
			builder.setHost(host);
			builder.setPath(oAuthTokenApiUri);
			builder.addParameter("client_id", clientId);
			builder.addParameter("client_secret", clientSecret);
			builder.addParameter("grant_type", clientGrantType);
			builder.addParameter("scope", scope);
			String url = builder.build().toURL().toString();
			LOGGER.info("oAuth URL: {}", url);

			RestTemplate restTemplate = new RestTemplate(HttpUtil.trustAllCerts());
			response = restTemplate.postForObject(url, HttpUtil.appendHeader(), OAuthAccessTokenResponse.class);
		} catch (MalformedURLException | URISyntaxException e) {
			LOGGER.info("Exception occured", e.getMessage());
		}
		return response;
	}

}
