package com.citi.services.client.quattro.service;

import com.citi.services.client.quattro.dto.OAuthAccessTokenResponse;

public interface OAuthAccessTokenService {

	public OAuthAccessTokenResponse fetchOAuthAccessToken();

}
