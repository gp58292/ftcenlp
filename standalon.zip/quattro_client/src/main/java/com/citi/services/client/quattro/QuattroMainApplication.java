package com.citi.services.client.quattro;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.citi.services.client.quattro.configuration.QuattroConfiguration;
import com.citi.services.client.quattro.dto.OAuthAccessTokenResponse;
import com.citi.services.client.quattro.dto.QuattroResponse;
import com.citi.services.client.quattro.service.OAuthAccessTokenService;
import com.citi.services.client.quattro.service.QuattroService;
import com.citi.services.client.quattro.service.SimwebService;
import com.citi.services.client.quattro.service.impl.OAuthAccessTokenServiceImpl;
import com.citi.services.client.quattro.service.impl.SimwebServiceImpl;

public class QuattroMainApplication {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(QuattroMainApplication.class);
	
	public static void main(String[] args) {
		LOGGER.info("############### Quattro Main Application Started ###############");
		ApplicationContext context = new AnnotationConfigApplicationContext(QuattroConfiguration.class);
		try {
			QuattroService service = context.getBean(QuattroService.class);
			OAuthAccessTokenService oAuthAccessTokenService = context.getBean(OAuthAccessTokenServiceImpl.class);
			OAuthAccessTokenResponse oAuthAccessTokenResponse = oAuthAccessTokenService.fetchOAuthAccessToken();
			LOGGER.info("OAuth Access Token : " + oAuthAccessTokenResponse.getAccessToken());
			
			String cobDate = service.findCobDate();
			 cobDate=null;
			LOGGER.info("COB Date is {}: ", cobDate); 
			SimwebService simwebService = context.getBean(SimwebServiceImpl.class);
			
			QuattroResponse feed = simwebService.fetchFinconFeed(oAuthAccessTokenResponse.getAccessToken(), cobDate);
			LOGGER.info("QuattroResponse {}: ", feed); 
			
		} catch (Exception e) {
			LOGGER.error("Exception occured: feed Not Completed " + e);
		} finally {
			LOGGER.info("############### Quattro Main Application Stopped ###############");
			((AnnotationConfigApplicationContext) context).close();
			System.exit(0);
		}
	}
	
}
