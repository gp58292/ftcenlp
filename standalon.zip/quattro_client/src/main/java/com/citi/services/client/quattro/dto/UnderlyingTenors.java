package com.citi.services.client.quattro.dto;

import java.util.List;

public class UnderlyingTenors {
	private String unit;
	private List<Integer> value;
	public String getUnit() {
		return unit;
	}
	public void setUnit(String unit) {
		this.unit = unit;
	}
	public List<Integer> getValue() {
		return value;
	}
	public void setValue(List<Integer> value) {
		this.value = value;
	}
	
	
	

}
