package com.citi.services.client.quattro.util;
import java.util.ArrayList;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.http.ResponseEntity;
import com.citi.services.client.quattro.dto.Feed;
import com.citi.services.client.quattro.dto.QuattroResponse;
import com.citi.services.client.quattro.model.AgreementQuattroEntity;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public final class JsonUtil {
	private static final Logger LOGGER = LoggerFactory.getLogger(JsonUtil.class);

	private JsonUtil() {
	}

	public static List<AgreementQuattroEntity> convertObject(QuattroResponse response) {
		LOGGER.debug("JsonUtil::convertObject");
		List<AgreementQuattroEntity> agreementQuattroEntityList = new ArrayList<>();

		for (Feed agreementQuattro : response.getFeeds()) {			
				AgreementQuattroEntity common = new AgreementQuattroEntity();
				String[] ignoreProperties = new String[2];
				ignoreProperties[0] = "lvid";				
				BeanUtils.copyProperties(agreementQuattro, common, ignoreProperties);

				if (agreementQuattro.getUnderlyingTenors() != null) {
					int count = agreementQuattro.getUnderlyingTenors().getValue().size();
					for (int i = 0; i < count; i++) {
						AgreementQuattroEntity agreementQuattroObj = new AgreementQuattroEntity();
						BeanUtils.copyProperties(common, agreementQuattroObj);
						agreementQuattroObj.setUnit(agreementQuattro.getUnderlyingTenors().getUnit());
						agreementQuattroObj
								.setUnderlyingTenor(agreementQuattro.getUnderlyingTenors().getValue().get(i));
						if (agreementQuattro.getUnderlyingepe() != null) {
							agreementQuattroObj.setUnderlyingepe(agreementQuattro.getUnderlyingepe().get(i));
						} else if (agreementQuattro.getUnderlyingene() != null) {
							agreementQuattroObj.setUnderlyingene(agreementQuattro.getUnderlyingene().get(i));
						}

						agreementQuattroEntityList.add(agreementQuattroObj);
					}
				} else {
					AgreementQuattroEntity agreementQuattroObj = new AgreementQuattroEntity();
					BeanUtils.copyProperties(common, agreementQuattroObj,ignoreProperties);
					agreementQuattroEntityList.add(agreementQuattroObj);
				}
		}
		return agreementQuattroEntityList;
	}

	public static QuattroResponse mapToObject(ResponseEntity<String> response) throws Exception {
		QuattroResponse quattroResponse = null;
		Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd'T'HH:mm:ss").create();
		quattroResponse = gson.fromJson(response.getBody(), QuattroResponse.class);
		return quattroResponse;
	}
}
