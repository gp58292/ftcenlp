package com.citi.services.client.quattro.data.jdbc.impl;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.citi.services.client.quattro.data.jdbc.QuattroDao;
import com.citi.services.client.quattro.model.AgreementQuattroEntity;

@Repository("QuattroDao")
public class QuattroDaoImpl implements QuattroDao {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(QuattroDaoImpl.class);

	@Autowired
	JdbcTemplate azJdbcTemplate;
	
	@Autowired
	JdbcTemplate lzJdbcTemplate;
	
    @Override
    public String findCobDate() {
    	LOGGER.info("QuattroDaoImpl:: findCobDate");
		String cobDateQuery = "SELECT TOP 1 File_Load_Date FROM deriv_az.ref.Calendar_Derivatives (NOLOCK) WHERE CONVERT(DATE, bus_date) = CONVERT(DATE,GETDATE()) AND Project='Agreement'";
		List<Date> dateList = azJdbcTemplate.query(cobDateQuery, new RowMapper<Date>() {
			public Date mapRow(ResultSet rs, int rownumber)
					throws SQLException {
				return rs.getDate(1);
			}
		});
		Date date = dateList.get(0);
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		final String dateStr = dateFormat.format(date);
		LOGGER.info("COB Date from Table: deriv_az.ref.Calendar_Derivatives:: {}", dateStr);
		return dateStr;
	}
	
	@Override
	public int insertQuattroFeed(List<AgreementQuattroEntity> agreementQuattroEntityList) {
		LOGGER.info("QuattroDaoImpl:: insertQuattroFeed");
		String sql = " INSERT INTO quattro.forward_mtm_v1("
				+ "agreementId, cobDate, countryOfRisk, currency, extension, gfcId, lvid, lvidName, mnemonic,"
				+ "nettingPortfolio, obligor, postingFirmAccount, productType, region, reportingLvid, reportingLvidName,"
				+ "resolvedBusinessUnit, securityAgreement, shelf, source, uinid, underlyingBusinessUnit, value, underlyingTenor, unit, underlyingepe,underlyingene, seq_id"
				+ ") "
				+ "VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?, ?, ?,?,?)";
		
		LOGGER.info("Updating Table:: quattro.forward_mtm");
		
		int[] arr = lzJdbcTemplate.batchUpdate(sql, new BatchPreparedStatementSetter() {
			public void setValues(PreparedStatement ps, int i) throws SQLException {
				AgreementQuattroEntity feed = agreementQuattroEntityList.get(i);
				ps.setLong(1,  feed.getAgreementId().isEmpty()?0:Long.parseLong(feed.getAgreementId()));
				ps.setDate(2,  feed.getCobDate());
				ps.setString(3,  feed.getCountryOfRisk());
				ps.setString(4,  feed.getCurrency());
				ps.setString(5,  feed.getExtension());
				ps.setLong(6,  feed.getGfcId());
				ps.setLong(7,  feed.getLvid());
				ps.setString(8,  feed.getLvidName());
				ps.setString(9,  feed.getMnemonic());
				ps.setString(10, feed.getNettingPortfolio());
				ps.setString(11, feed.getObligor());
				ps.setString(12, feed.getPostingFirmAccount());
				ps.setString(13,feed.getProductType());
				ps.setString(14,feed.getRegion());
				ps.setString(15,feed.getReportingLvid());
				ps.setString(16,feed.getReportingLvidName());
				ps.setString(17,feed.getResolvedBusinessUnit());
				ps.setString(18,feed.getSecurityAgreement());
				ps.setString(19,feed.getShelf());
				ps.setString(20,feed.getSource());
				ps.setString(21,feed.getUinid());
				ps.setString(22,feed.getUnderlyingBusinessUnit());
				ps.setDouble(23,feed.getValue());
				ps.setDouble(24,feed.getUnderlyingTenor());
				ps.setString(25,feed.getUnit());
				ps.setBigDecimal(26,feed.getUnderlyingepe());
				ps.setBigDecimal(27,feed.getUnderlyingene());
				
				
				ps.setLong(28,  i++);
			}
			public int getBatchSize() {
				return agreementQuattroEntityList.size();
			}
		});
		return arr.length ;
	}
}
