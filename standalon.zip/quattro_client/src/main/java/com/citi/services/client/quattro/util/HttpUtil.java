package com.citi.services.client.quattro.util;

import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

import javax.net.ssl.SSLContext;

import org.apache.http.client.config.CookieSpecs;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustStrategy;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.util.LinkedMultiValueMap;

public final class HttpUtil {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(HttpUtil.class);
	
	private HttpUtil() {}
	
	public static HttpEntity<LinkedMultiValueMap<String, String>> appendHeader() {
		HttpHeaders headers = new HttpHeaders();
		headers.add("Accept", "application/json");
		headers.add("Content-Type", "application/x-www-form-urlencoded");
		
		LinkedMultiValueMap<String, String> body = new LinkedMultiValueMap<>();
		return new HttpEntity<>(body, headers);
	}
	
	public static HttpEntity<LinkedMultiValueMap<String, String>> appendHeaderWithOAuthToken(String authorization) {
		HttpHeaders headers = new HttpHeaders();
		headers.add("Accept", "application/json");
		headers.add("Authorization", "Bearer " +authorization);
		headers.add("Content-Type", "application/x-www-form-urlencoded");
		
		LinkedMultiValueMap<String, String> body = new LinkedMultiValueMap<>();
		return new HttpEntity<>(body, headers);
	}
	
	public static HttpComponentsClientHttpRequestFactory trustAllCerts() {
		final HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory();
		try {
			  TrustStrategy acceptingTrustStrategy = new TrustStrategy() {
			        @Override
			        public boolean isTrusted(X509Certificate[] x509Certificates, String s) throws CertificateException {
			            return true;
			        }
			    };
			    SSLContext sslContext = org.apache.http.ssl.SSLContexts.custom().loadTrustMaterial(null, acceptingTrustStrategy).build();
			    SSLConnectionSocketFactory csf = new SSLConnectionSocketFactory(sslContext, new NoopHostnameVerifier());
			    CloseableHttpClient httpClient = HttpClients.custom().setDefaultRequestConfig(RequestConfig.custom()
	                    .setCookieSpec(CookieSpecs.STANDARD).build()).setSSLSocketFactory(csf).build();
			    requestFactory.setHttpClient(httpClient);
		} catch (NoSuchAlgorithmException | KeyStoreException | KeyManagementException e) {
			LOGGER.error(e.getMessage());
		}
		return requestFactory;
	}

}
