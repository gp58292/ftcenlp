package com.citi.prime.services.optimizer.service;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.citi.prime.services.optimizer.service.api.AutomationDataService;
import com.citi.prime.services.optimizer.service.api.AutomationEnviroment;
import com.citi.prime.services.optimizer.service.impl.AutomationDataServiceFactory;
import com.citi.prime.services.optimizer.service.vo.AutomationLenderDetail;


public class TargetBalanceService {

	@Autowired
	private DataSource dataSource;

	private List<AutomationLenderDetail> details;

	public static void main(String[] args) {
		TargetBalanceService baltest = new TargetBalanceService();
		baltest.insertBatch();
	}

	public void insertBatch() {
		JdbcTemplate jdbcTemplate;
		ApplicationContext context = new ClassPathXmlApplicationContext("Spring-Datasource.xml");
		try {
			AutomationDataService service = AutomationDataServiceFactory.getInstance(AutomationEnviroment.PROD);
			details = service.getLenderDetails("optimizer_admin", "optimizer_admin");
			
			if(details != null) {
				System.out.println("#### Starting Batch Update.. ####");
				dataSource = (DataSource) context.getBean("dataSource");
				jdbcTemplate = new JdbcTemplate(dataSource);

				String selectDateSql = "SELECT MAX(calendarId) as date FROM DBO.PROCESS_DATE";
				List<Integer> dateList = jdbcTemplate.query(selectDateSql, new RowMapper<Integer>() {
					public Integer mapRow(ResultSet rs, int rownumber)
							throws SQLException {
						return rs.getInt(1);
					}
				});

				Integer dateInt = dateList.get(0);
				DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
				Date date = dateFormat.parse(dateInt.toString());
				final String dateValue = dateFormat.format(date);
				System.out.println("COB  Date:" + date);
				String truncateQuery = "delete from sl.stock_loan.tbl_target_balance where cob_date='"
						+ dateValue + "'";

				String sql = "INSERT INTO sl.stock_loan.tbl_target_balance "
						+ "(cob_date, CustMnemonic, Region,TargetBalance) VALUES (?, ?, ?, ?)";

				System.out.println("Clear data from Table for COB  Date:" + date);
				jdbcTemplate.execute(truncateQuery);

				System.out.println("Updating Table for COB  Date:" + date);

				int[] arr = jdbcTemplate.batchUpdate(sql, new BatchPreparedStatementSetter() {
					public void setValues(PreparedStatement ps, int i) throws SQLException {
						AutomationLenderDetail feed = details.get(i);
						ps.setString(1, dateValue);
						ps.setString(2, Optional.ofNullable(feed.getCustomerMnemonic()).orElse(""));
						ps.setString(3, Optional.ofNullable(feed.getRegion()).orElse(""));
						ps.setDouble(4, feed.getTargetBalance());
					}
					public int getBatchSize() {
						return details.size();
					}
				});

				if (arr.length > 0) {
					System.out.println("#### Rows are updated successfully !! ####");
				} else {
					System.out.println("No records to update");
				}
			} else {
				System.out.println("No records to update");
			}
			
		} catch (Exception e) {
			System.out.println(" #### Batch Failed : Exception occured: feed Not Completed ####");
			 e.printStackTrace();
		} finally {
			((ClassPathXmlApplicationContext) context).close();
			System.out.println("#### Batch process completed ####");
			System.exit(0);
		}
	}
	
}
