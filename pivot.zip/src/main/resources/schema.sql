CREATE TABLE trade
  (
     product VARCHAR(255),
     portfolio VARCHAR(255),
     book VARCHAR(255),
     tradeId int,
     submitterId int,
     submitterDealId int,
     dealType VARCHAR(255),
     bidType VARCHAR(255),
     currentValue int,
     previousValue int,
     pl1 int,
     pl2 int,
     gainDx int,
     sxPx int,
     x99Out int,
     batch int
  );