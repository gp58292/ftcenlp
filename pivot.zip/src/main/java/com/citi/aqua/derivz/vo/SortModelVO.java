package com.citi.aqua.derivz.vo;

import java.io.Serializable;
import java.util.Objects;

public class SortModelVO implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String colId;
    private String sort;

    public SortModelVO() {}

    public SortModelVO(String colId, String sort) {
        this.colId = colId;
        this.sort = sort;
    }

    public String getColId() {
        return colId;
    }

    public void setColId(String colId) {
        this.colId = colId;
    }

    public String getSort() {
        return sort;
    }

    public void setSort(String sort) {
        this.sort = sort;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        SortModelVO sortModelVO = (SortModelVO) o;
        return Objects.equals(colId, sortModelVO.colId) &&
                Objects.equals(sort, sortModelVO.sort);
    }

    @Override
    public int hashCode() {

        return Objects.hash(colId, sort);
    }

    @Override
    public String toString() {
        return "SortModel{" +
                "colId='" + colId + '\'' +
                ", sort='" + sort + '\'' +
                '}';
    }
}
