package com.citi.aqua.derivz.web.controller;

import static org.springframework.web.bind.annotation.RequestMethod.POST;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.citi.aqua.derivz.data.jdbc.SearchDAO;
import com.citi.aqua.derivz.web.utils.DerivzNonListSearchRestRequest;
import com.citi.aqua.derivz.web.utils.DerivzRestResponse;

@RestController
public class SearchController {
	
	private static final Logger log = LoggerFactory.getLogger(SearchController.class);

	 @Autowired
    private SearchDAO searchDAO;


    @RequestMapping(method = POST, value = "/getTabs")
    @ResponseBody
    public DerivzRestResponse getData(@RequestBody DerivzNonListSearchRestRequest request) {
    	log.info("SearchController:: /getTabs request called");
        return searchDAO.getData(request);
    }
}