package com.citi.aqua.derivz.data.jdbc;

import com.citi.aqua.derivz.web.utils.DerivzNonListSearchRestRequest;
import com.citi.aqua.derivz.web.utils.DerivzRestResponse;

public interface SearchDAO {

	DerivzRestResponse getData(DerivzNonListSearchRestRequest request);

}
