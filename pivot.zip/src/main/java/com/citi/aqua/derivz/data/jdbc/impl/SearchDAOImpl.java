package com.citi.aqua.derivz.data.jdbc.impl;

import static com.citi.aqua.derivz.web.utils.ResponseBuilder.build;
import static java.lang.String.format;
import static java.util.stream.Collectors.toMap;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.citi.aqua.derivz.data.jdbc.SearchDAO;
import com.citi.aqua.derivz.vo.ColumnVO;
import com.citi.aqua.derivz.web.utils.DerivzNonListSearchRestRequest;
import com.citi.aqua.derivz.web.utils.DerivzRestResponse;
import com.citi.aqua.derivz.web.utils.QueryBuilder;

@Repository
public class SearchDAOImpl implements SearchDAO {
	
	private static final Logger log = LoggerFactory.getLogger(SearchDAOImpl.class);

	@Autowired
	private JdbcTemplate template;
	
	@Autowired
	private QueryBuilder queryBuilder;
	
	private String tableName = "trade";

	@Override
	public DerivzRestResponse getData(DerivzNonListSearchRestRequest request) {
		log.info("SearchDao:: getData: called");
		// first obtain the pivot values from the DB for the requested pivot columns
		Map<String, List<String>> pivotValues = getPivotValues(request.getPivotCols());

		// generate sql
		String sql = queryBuilder.createSql(request, this.tableName, pivotValues);

		// query db for rows
		List<Map<String, Object>> rows = template.queryForList(sql);

		// create response with our results
		return build(request, rows, pivotValues);
	}

	private Map<String, List<String>> getPivotValues(List<ColumnVO> pivotCols) {
		return pivotCols.stream().map(ColumnVO::getField)
				.collect(toMap(pivotCol -> pivotCol, this::getPivotValues, (a, b) -> a, LinkedHashMap::new));
	}

	private List<String> getPivotValues(String pivotColumn) {
		String sql = "SELECT DISTINCT %s FROM " + this.tableName;
		return template.queryForList(format(sql, pivotColumn), String.class);
	}
}