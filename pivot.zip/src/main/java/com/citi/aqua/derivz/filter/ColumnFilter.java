package com.citi.aqua.derivz.filter;

import java.util.List;

public class ColumnFilter extends AbstractColumnFilter {
	
	private static final long serialVersionUID = 1L;
	
	private List<String> values;

    public ColumnFilter() {}

    public ColumnFilter(List<String> values) {
        this.values = values;
    }

    public List<String> getValues() {
        return values;
    }
}
