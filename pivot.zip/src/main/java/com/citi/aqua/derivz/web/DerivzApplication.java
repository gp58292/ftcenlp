package com.citi.aqua.derivz.web;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

import com.citi.aqua.derivz.web.utils.TradeDataLoader;
import com.ulisesbocchio.jasyptspringboot.annotation.EnableEncryptableProperties;

@SpringBootApplication
@ComponentScan({ "com.citi.aqua" })
@EnableAutoConfiguration
@EnableEncryptableProperties
public class DerivzApplication implements ApplicationRunner {
	
	public static final Logger log = LoggerFactory.getLogger(DerivzApplication.class);
	
	@Autowired
	private TradeDataLoader dataLoader;

	public static void main(String[] args) {
		SpringApplication.run(DerivzApplication.class, args);
	}

	@Override
	public void run(ApplicationArguments args) throws Exception {
		log.info("Data loading into H2 Cache...");
		dataLoader.loadTradeData();
		log.info("Data successfully loaded into H2 Cache.");
	}
}
