package com.citi.aqua.derivz.model;

public interface DBConstants {

	String SCHEMA_CEFT = "ceft";
	String SCHEMA_DZ = "dz";
	String SCHEMA_AZ = "deriv_az";
	String SCHEMA_DERIVZ_REF = "ref";
	String SCHEMA_VOYAGER = "voyager";
	String SCHEMA_ETL = "etl";

	String IP_INPUT_PARAMETERS = "input_variable_ceft_max";
	String POSTINGS_INPUT_PARAMETERS = "input_postings";
	String BOX_INPUT_PARAMETERS = "input_box";
	String IP_INPUT_RATING_VARIABLE = "input_rating_variable";

	// Below are dimensional or fact names
	String DIM_AGREEMENT = "dim_agreement"; // dimensional or fact

	// Below are table names, schema=DBConstants.schemaCEFT
	String TBL_DISTINCT_DATA = "tbl_distinct_data";
	String TBL_USER_SEARCH_SAVED_LIST = "tbl_user_search_saved_list";
	String TBL_STATIC_COMPONENT = "tbl_static_component";
	String TBL_CUSTOM_FIELD = "tbl_custom_fields";
	String TBL_META_DATA = "table_metadata";
	String TBL_BATCH_PROCESS_AUDIT = "tbl_batch_process_audit";
	String TBL_USER = "tbl_user";
	String TBL_EMT_DASHBOARD_ENTITLEMENT = "tbl_emt_dashboard_entitlement";
	String TBL_CEFT_APP_USER_LOG = "tbl_ceft_app_user_log";
	
	String TBL_RATING_RANKING = "tbl_static_rating_rankings";

	// Below are procedure names
	String USP_DERIV_MAC_DATA_RETRIEVAL = "usp_deriv_mac_data_retrieval_parent";
	String USP_DERIV_MAC_DATA_RETRIEVAL_RATING = "usp_deriv_mac_data_retrieval_parent_rating";
	String SP_GET_FACT_BOX = "sp_get_fact_box";
	String SP_GET_FACT_POSTING = "sp_get_fact_posting";
	String USP_GET_CAPACITY_DATA = "usp_get_capacity_data";
	String USP_DERIV_VOYAGER_DATASET_RETRIEVAL = "usp_deriv_mac_data_retrieval_parent_fact_posting";
	String USP_GET_USER_AUTHENTICATION = "usp_get_user_authentication";
	String SP_PERSIST_CEFT_BOOKMARK_TO_VOYAGER= "sp_persist_ceft_bookmark_to_voyager";
	String SP_GET_CURRENT_DATASETID= "sp_get_current_datasetid_based_of_ceft_link_click";
	String USP_GET_USAGE_SUMMARY_DETAILS = "usp_get_usage_summary_details";
	String USP_DERIV_COLLATERAL_LOOKUP_RETRIEVAL = "usp_ceft_collateral_type_lookup_reg";
	String USP_GET_FWD_MTM_DATA = "sp_get_forward_mtm_data_set";
	String USP_GET_MTM_DATA = "usp_get_mtm";
	String USP_GET_GSST_DATA="usp_get_gsst_data_set";
	String USP_GET_FRTB_DATA="usp_get_frtb";
	String SP_GET_AGREEMENT_DETAIL_DATA = "sp_get_agreement_detail_data";
	String SP_GET_CSA_TYPE_DATA_HEADER = "sp_get_csa_type_data_header";
	String SP_GET_CSA_TYPE_DATA_THRESHOLD = "sp_get_csa_type_data_threshold";
	String SP_GET_CSA_TYPE_DATA_SCHEDULE_THRESHOLD= "sp_get_csa_type_data_schedule_threshold";
	String SP_GET_CSA_TYPE_DATA_CREDIT_THRESHOLD = "sp_get_csa_type_data_credit_threshold";
	String SP_GET_CSA_TYPE_DATA_PUBLIC_RATING = "sp_get_csa_type_data_public_rating";
	String SP_GET_CSA_TYPE_DATA_HAIRCUT_SCHEDULE = "sp_get_csa_type_data_haircut_schedule";
	String SP_GET_CSA_TYPE_DATA_COLL_CASH = "sp_get_csa_type_data_coll_cash";
	String SP_GET_CSA_TYPE_DATA_COV_PROD = "sp_get_csa_type_data_cov_prod";
	String SP_DAILY_BATCH_STATUS_AQUA_CEFT= "sp_daily_batch_status_aqua_ceft";
	String DASHBOARD_TYPE_CEFT = "Collateral Exposure Forecasting Tool";
	String DASHBOARD_TYPE_VOYAGER = "Voyager Visualization Tool";
	
	String NULL_VALUE_CHECK="<NULL>";
	String CALL_PROC = "{CALL ";
	String PROC_ONE_ARG = " (?)}";
	String PROC_TWO_ARG = " (?,?)}";
	
	//DB Column Fields
	String COUNTERPARTY_CUSTODIAN_REQUIRED = "Counterparty Custodian Required";
	String AGREEMENT_ID = "Agreement ID";
	String AGREEMENT_ID_1 = "agreement_id";
	String AGREEMENT_KEY = "agreement_key";	
	String BUSINESS_DATE = "Business Date";
	String CLEARING_AGREEMENT = "Clearing Agreement";
	String CONSENT_TO_SUBSTITUTION = "Consent to Substitution";
	String COUNTERPARTY_NAME = "Counterparty Name";
	String CP_MARGIN_TYPE = "CP Margin Type";
	String CSA_DESCRIPTION = "CSA Description";
	String CSA_STATUS = "CSA Status";
	String CSA_DESCRIPTION_1 = "csa_description";
	String CSA_STATUS_1 = "csa_status";
	String CUSTOMER_NAME = "Customer Name";
	String GFCID_TYPE = "GFCID Type";
	String GFCID = "GFCID";
	String GOVERNING_LAW = "Governing Law";
	String INCORPORATED_COUNTRY = "Incorporated Country";
	String INTER_COMPANY_AGREEMENT = "Inter Company Agreement";
	String MANDATORY_MARK_FREQUENCY = "Mandatory Mark Frequency";
	String MASTER_AGREEMENT_STATUS = "Master Agreement Status";
	String MASTER_AGREEMENT = "Master Agreement";
	String MGD_SEG_LEVEL5_DESC = "Mgd Seg Level5 Desc";
	String PARTY_CUSTODIAN_REQUIRED = "Party Custodian Required";
	String PARTY_LEGAL_ENTITY = "Party Legal Entity";
	String PLEDGOR = "Pledgor";
	String RIGHT_OF_REUSE = "Right of Reuse";
	String SA_TRIGGER_EVENT = "SA Trigger Event";
	String TRIGGER_EVENT = "Trigger Event";
	String PARTY_GFCID = "party_gfcid";
	String COV_PROD_PARENT_INSTR_CODE = "cov_prod_parent_instr_code";
	String COUNTER_PARTY_GFCID = "counter_party_gfcid";
	
	//Batch status screen
	String DATA_EXIST = "Data_Exist";
	String BUSINESS_DATE_CEFT_UI = "Business_Date_CEFT_UI";
	String BUSINESS_DATE_IN_DATABASE = "Business_Date_in_Database";
	String SLA = "SLA";
	String BAU = "BAU";
	String SOURCE_DATA = "Source_Data";
	
}