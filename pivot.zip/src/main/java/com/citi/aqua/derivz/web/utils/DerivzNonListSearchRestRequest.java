package com.citi.aqua.derivz.web.utils;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import com.citi.aqua.derivz.filter.AbstractColumnFilter;
import com.citi.aqua.derivz.vo.ColumnVO;
import com.citi.aqua.derivz.vo.SortModelVO;

import static java.util.Collections.emptyList;
import static java.util.Collections.emptyMap;

public class DerivzNonListSearchRestRequest implements Serializable {

	private static final long serialVersionUID = 1L;

	private int startRow;
    
    private int endRow;

    // row group columns
    private List<ColumnVO> rowGroupCols;

    // value columns
    private List<ColumnVO> valueCols;

    // pivot columns
    private List<ColumnVO> pivotCols;

    // true if pivot mode is one, otherwise false
    private boolean pivotMode;

    // what groups the user is viewing
    private List<String> groupKeys;

    // if filtering, what the filter model is
    private Map<String, AbstractColumnFilter> filterModel;

    // if sorting, what the sort model is
    private List<SortModelVO> sortModelVO;

    public DerivzNonListSearchRestRequest() {
        this.rowGroupCols = emptyList();
        this.valueCols = emptyList();
        this.pivotCols = emptyList();
        this.groupKeys = emptyList();
        this.filterModel = emptyMap();
        this.sortModelVO = emptyList();
    }

    public int getStartRow() {
        return startRow;
    }

    public void setStartRow(int startRow) {
        this.startRow = startRow;
    }

    public int getEndRow() {
        return endRow;
    }

    public void setEndRow(int endRow) {
        this.endRow = endRow;
    }

    public List<ColumnVO> getRowGroupCols() {
        return rowGroupCols;
    }

    public void setRowGroupCols(List<ColumnVO> rowGroupCols) {
        this.rowGroupCols = rowGroupCols;
    }

    public List<ColumnVO> getValueCols() {
        return valueCols;
    }

    public void setValueCols(List<ColumnVO> valueCols) {
        this.valueCols = valueCols;
    }

    public List<ColumnVO> getPivotCols() {
        return pivotCols;
    }

    public void setPivotCols(List<ColumnVO> pivotCols) {
        this.pivotCols = pivotCols;
    }

    public boolean isPivotMode() {
        return pivotMode;
    }

    public void setPivotMode(boolean pivotMode) {
        this.pivotMode = pivotMode;
    }

    public List<String> getGroupKeys() {
        return groupKeys;
    }

    public void setGroupKeys(List<String> groupKeys) {
        this.groupKeys = groupKeys;
    }

    public Map<String, AbstractColumnFilter> getFilterModel() {
        return filterModel;
    }

    public void setFilterModel(Map<String, AbstractColumnFilter> filterModel) {
        this.filterModel = filterModel;
    }

    public List<SortModelVO> getSortModel() {
        return sortModelVO;
    }

    public void setSortModel(List<SortModelVO> sortModelVO) {
        this.sortModelVO = sortModelVO;
    }
}