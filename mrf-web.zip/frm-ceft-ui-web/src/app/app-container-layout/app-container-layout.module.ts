import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppContainerLayoutComponent } from '@aqua/app-container-layout/app-container-layout.component';
import { MaterialModule } from '@aqua/material.module';
import { AppContainerRoutingModule } from '@aqua/app-container-layout/app-container-routing.module';
import { BookmarksManagerModule } from '@bookmarks-manager/bookmarks-manager.module';

@NgModule({
  declarations: [
    AppContainerLayoutComponent,
  ],
  imports: [
    CommonModule,
    HttpClientModule,
    MaterialModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    AppContainerRoutingModule,
    BookmarksManagerModule,
  ],
  exports: [
    AppContainerLayoutComponent
  ],
})
export class AppContainerLayoutModule {
}
