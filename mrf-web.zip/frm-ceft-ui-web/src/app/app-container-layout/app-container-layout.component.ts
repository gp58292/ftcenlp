import { Component } from '@angular/core';

@Component({
  selector: 'app-container-layout',
  templateUrl: './app-container-layout.component.html',
  styleUrls: ['./app-container-layout.component.scss'],
})
/**
 * Main Application container with the AQUA brand footer and header.
 */
export class AppContainerLayoutComponent {

}
