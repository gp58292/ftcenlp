import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { PipeModule } from '@aqua/aqua-component/pipes';
import { AquaComponentModule } from '@aqua/components/aqua-component.module';
import { BookmarksManagerComponent } from './bookmarks-manager.component';

@NgModule({
  declarations: [
    BookmarksManagerComponent
  ],

  providers: [
   
  ],

  imports: [
    CommonModule,
    PipeModule,
    AquaComponentModule
  ],

  exports: [
    BookmarksManagerComponent
  ]
})
export class BookmarksManagerModule {}
