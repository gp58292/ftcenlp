import { NumericExcelStyleRule } from '@aqua/aqua-component/aqua-grid';
import { NumberRenderer, DeleteRenderer, DateRenderer, HyperlinkRenderer, UsedInChartRenderer } from '@aqua/aqua-component/aqua-grid/inline-cell-renderer';
import { ColumnDefaultGrid, GridUtils } from '@aqua/aqua-component/aqua-grid/utils';

export const BOOKMARK_MANAGER_GRID_DEFINATION: ColumnDefaultGrid[] = [
  {
    headerName: 'ID',
    cellRendererFramework: HyperlinkRenderer,
    tooltipValueGetter: GridUtils.tooltip,
    field: 'key',
    width: 10
  },
  {
    headerName: 'Bookmark Name',
    cellRendererFramework: HyperlinkRenderer,
    tooltipValueGetter: GridUtils.tooltip,
    field: 'name',
    width: 30
  },
  {
    headerName: 'Description',
    field: 'type',
    tooltipValueGetter: GridUtils.tooltip,
    width: 20
  },
  {
    headerName: 'Created/Last Updated On',
    field: 'updatedTime',
    cellRendererFramework: DateRenderer,
    width: 30
  },
  {
    headerName: 'Used in Charts',
    field: 'chartFlag',
    cellRendererFramework:UsedInChartRenderer,
    width: 5
  },
  {
    headerName: 'Delete',
    cellRendererFramework: DeleteRenderer,
    width: 5
  }
];
