import { HTTP_INTERCEPTORS } from "@angular/common/http";
import { HttpDataRequestInterceptor } from "./http-data-request-interceptor";
import { HttpDataResponseInterceptor } from "./http-data-response-interceptor";

export * from "./http-data-request-interceptor";
export * from "./error-handler.service";
export * from "./global-error-handler";

/** Http interceptor providers in outside-in order */
export const httpInterceptorProviders = [
	{
		provide: HTTP_INTERCEPTORS,
		useClass: HttpDataRequestInterceptor,
		multi: true
	},
	{
		provide: HTTP_INTERCEPTORS,
		useClass: HttpDataResponseInterceptor,
		multi: true
	}
];
