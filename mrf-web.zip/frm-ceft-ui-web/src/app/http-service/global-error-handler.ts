import { HttpErrorResponse } from "@angular/common/http";
import { ErrorHandler, Injectable, Injector } from "@angular/core";
import { ErrorHandlerService } from "./error-handler.service";

// export interface LoggingErrorHandlerOptions {
//     rethrowError: boolean;
//     unwrapError: boolean;
// }

// export const LOGGING_ERROR_HANDLER_OPTIONS: LoggingErrorHandlerOptions = {
//     rethrowError: false,
//     unwrapError: false
// };

@Injectable()
export class GlobalErrorHandler implements ErrorHandler {
	// CAUTION: The core implementation of the ErrorHandler class accepts a boolean
	// parameter, `rethrowError`; however, this is not part of the interface for the  class.
	// /@Inject( LOGGING_ERROR_HANDLER_OPTIONS ) private options: LoggingErrorHandlerOptions
	private errorHandlerService: ErrorHandlerService;
	constructor(private injector: Injector) {
		console.debug("GlobalErrorHandler::constructor::");
	}

	public handleError(error: any): void {
		// We are tracking UI error here for Server response error we have Http error handler. Send to the error-logging service.
		if (!(error instanceof HttpErrorResponse)) {
			// console.debug("GlobalErrorHandler::handleError::",error);
			try {
				if (!this.errorHandlerService) {
					this.errorHandlerService = this.injector.get(ErrorHandlerService);
				}

				// this.errorHandlerService.handle( this.options.unwrapError?this.findOriginalError(error):error);
				this.errorHandlerService.handle(error);
			} catch (loggingError) {
				console.group("ErrorHandler");
				console.warn(
					"Error when trying to log error to",
					this.errorHandlerService
				);
				console.error(loggingError);
				console.groupEnd();
			}

			// if (this.options.rethrowError) {
			//     throw (error);
			// }
		}
	}

	// To find the underlying error in the given Wrapped error.
	private findOriginalError(error: any): any {
		while (error && error.originalError) {
			error = error.originalError;
		}
		return error;
	}
}

// Collection of providers used for this service at the module level.
// Notice that we are overriding the CORE ErrorHandler with our own class definition.
// --
// CAUTION: These are at the BOTTOM of the file so that we don't have to worry about
// creating futureRef() and hoisting behavior.
export const LOGGING_ERROR_HANDLER_PROVIDERS = [
	// {
	//     provide: LOGGING_ERROR_HANDLER_OPTIONS,
	//     useValue: LOGGING_ERROR_HANDLER_OPTIONS
	// },
	{
		provide: ErrorHandler,
		useClass: GlobalErrorHandler
	}
];
