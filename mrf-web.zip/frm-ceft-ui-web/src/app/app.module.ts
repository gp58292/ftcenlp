import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AquaGridModule } from "@aqua/aqua-component/aqua-grid";
import { ErrorHandlerService, httpInterceptorProviders, LOGGING_ERROR_HANDLER_PROVIDERS } from '@aqua/http-service';
import { UrlConfig, VizNotificationService } from '@aqua/services';
import { BookmarksManagerModule } from '@bookmarks-manager/bookmarks-manager.module';
import { FRMAuthModule, FRMCommunicationModule } from '@citi-icg-163206/frm-framework-npm-commons';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FiltersModule } from './filters/filters.module';
import { MaterialModule } from './material.module';
import { FrmCommunicationHandlerService } from '@service/frm-communication-handler.service';
import { LocalAtmosphereHandlerService } from '@service/local-atmosphere-handler.service';
import { UIGuideModule } from './ui-guide';
import { AppContainerLayoutModule } from '@aqua/app-container-layout/app-container-layout.module';


@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    MaterialModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    AppRoutingModule,
    FRMAuthModule.forRoot({ clientId: 'frm-ceft-client', clientSecret: 'secret' }),
    FRMCommunicationModule,
    AquaGridModule,
    BookmarksManagerModule,
    FiltersModule,
    UIGuideModule,
    AppContainerLayoutModule,
  ],
  providers: [
    UrlConfig,
    VizNotificationService,
    ErrorHandlerService,
    httpInterceptorProviders,
    // LOGGING_ERROR_HANDLER_PROVIDERS,
    FrmCommunicationHandlerService,
    LocalAtmosphereHandlerService
  ],
  bootstrap: [AppComponent],
})
export class AppModule {
  constructor (
    private frmCommunicationHandlerService: FrmCommunicationHandlerService,
    // private localAtmosphereHandlerService: LocalAtmosphereHandlerService
  ) {
    frmCommunicationHandlerService.start();
  }
}
