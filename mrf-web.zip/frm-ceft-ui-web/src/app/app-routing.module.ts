import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { UIGuideComponent } from '@aqua/ui-guide/ui-guide.component';

const appRoutes: Routes = [
  {
    path: 'ui-guide',
    component: UIGuideComponent,
    pathMatch: 'full',
  },
];

@NgModule({
  imports: [RouterModule.forRoot(appRoutes)],
  exports: [RouterModule]
})
export class AppRoutingModule {

}
