import { CeftDataSetType } from './dataset-type.enum';

export class DataSet {
  public soeid: string;
  public bookmarkId: number;
  public type: CeftDataSetType;
}
