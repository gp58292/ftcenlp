import { DataStatus } from './data-status-enum';
import { DataSet } from './dataset.model';

export class CeftDataSetStatus {
  public webSocketUuid: string;
  public status: DataStatus;
  public total: number;
  public loaded: number;
  public dataSet: DataSet;

  public ready: boolean = false;
  public timestamp: string;
}
