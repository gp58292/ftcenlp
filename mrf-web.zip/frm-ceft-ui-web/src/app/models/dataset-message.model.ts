import { DataStatus } from './data-status-enum';
import { DataSet } from './dataset.model';

export class CeftDataSetMessage {
  public uuid: string;
  public statusCode: DataStatus;
  public totalItems: number;
  public loadedItems: number;
  public dataSet: DataSet;
}
