export interface EnvironmentVersion {
	envName: string;
	buildVersion: string;
}

