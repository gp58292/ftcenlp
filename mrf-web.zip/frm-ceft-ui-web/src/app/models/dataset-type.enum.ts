export enum CeftDataSetType {
  LISTED = 'Listed',
  CURRENT_POSTING = 'Current Postings',
  BOX = 'Box',
  CAPACITY = 'Capacity',
  FMTM = 'Forward MTM',
  HMTM = 'MTM',
  GSST = 'GSST',
  FRTB = 'FRTB'
}
