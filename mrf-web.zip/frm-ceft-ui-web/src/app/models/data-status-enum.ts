export enum DataStatus {
  COMPLETED = 'COMPLETED',
  LOADING = 'LOADING',
  READY = 'READY'
}
