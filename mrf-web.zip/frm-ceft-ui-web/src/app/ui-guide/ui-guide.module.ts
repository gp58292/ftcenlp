import { NgModule } from '@angular/core';
import { UIGuideComponent } from '@aqua/ui-guide/ui-guide.component';
import { RouterModule } from '@angular/router';

/**
 * Authorisation module.
 */
@NgModule({
  declarations: [
    UIGuideComponent,
  ],
  imports: [
    RouterModule,
  ],
  providers: [
  ],
})
export class UIGuideModule {
}
