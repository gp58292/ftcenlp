import { Component, OnInit } from "@angular/core";

@Component({
	selector: "derivz-data-finder",
	templateUrl: "./data-finder.component.html",
	styleUrls: ["./data-finder.component.scss"]
})
export class DataFinderComponent implements OnInit {
	public ngOnInit() {
		console.debug("DataFinderComponent::ngOnInit");
	}
}
