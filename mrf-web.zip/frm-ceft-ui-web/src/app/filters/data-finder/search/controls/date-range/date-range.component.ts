import { Component, Input } from '@angular/core';
import { AbstractControl, FormGroup } from '@angular/forms';
import { SearchField } from '@aqua/filters/models/search-field';

@Component({
  selector: 'derivz-date-range',
  templateUrl: './date-range.component.html',
  styleUrls: ['./date-range.component.scss'],
})
export class DateRangeComponent {
  @Input('field') public field: SearchField;

  @Input()
  set form (formItem: FormGroup) {
    this.control = formItem.controls[`${this.field.fieldName}_${this.field.key}_${this.field.whoHasFlag}`];
  }

  public control: AbstractControl;

  public getErrorMessage () {
    if (this.control.hasError('validateDateRange')) {
      return 'Please enter valid range';
    }

    return '';
  }
}
