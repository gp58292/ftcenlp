import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { FreeFormTextComponent } from "./free-form-text.component";

describe("FreeFormTextComponent", () => {
	let component: FreeFormTextComponent;
	let fixture: ComponentFixture<FreeFormTextComponent>;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			declarations: [FreeFormTextComponent]
		}).compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(FreeFormTextComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});
});
