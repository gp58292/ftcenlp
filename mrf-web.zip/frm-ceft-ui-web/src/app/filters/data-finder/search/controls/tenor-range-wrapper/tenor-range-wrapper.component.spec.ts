import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { TenorRangeComponent } from "./tenor-range-wrapper.component";

describe("TenorRangeComponent", () => {
	let component: TenorRangeComponent;
	let fixture: ComponentFixture<TenorRangeComponent>;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			declarations: [TenorRangeComponent]
		}).compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(TenorRangeComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});
});
