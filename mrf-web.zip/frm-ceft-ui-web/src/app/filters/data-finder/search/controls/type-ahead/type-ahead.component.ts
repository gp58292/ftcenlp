import { Component, Input } from '@angular/core';
import { AbstractControl, FormGroup } from '@angular/forms';
import { Options } from '@aqua/aqua-component/models';
import { SearchService } from '@aqua/filters/data-finder/search/search.service';
import { SearchField } from '@aqua/filters/models/search-field';
import { of, Subject } from 'rxjs';
import { debounceTime, filter, switchMap } from 'rxjs/operators';

@Component({
  selector: 'derivz-type-ahead',
  templateUrl: './type-ahead.component.html',
  styleUrls: ['./type-ahead.component.scss'],
})
export class TypeAheadComponent {
  @Input('field') public field: SearchField;

  @Input()
  set form (formItem: FormGroup) {
    this.control = formItem.controls[`${this.field.fieldName}_${this.field.key}_${this.field.whoHasFlag}`];
  }

  public control: AbstractControl;

  public isPasting = false;

  public filterText$ = new Subject<string>();

  public options$ = this.filterText$.pipe(
    filter(() => !this.isPasting),
    debounceTime(200),
    switchMap(term => (term != null && term !== '') ? this.searchService.getTypeAheadData(this.field, term) : of([])),
  );

  public pasteProcessedData: { FOUND: Options[]; NOT_FOUND: Options[] };

  constructor (private searchService: SearchService) {
  }

  public filterText (text: string) {
    this.filterText$.next(text);
  }

  public pastedValues (pasteValues: string[]): void {
    this.isPasting = true;
    this.searchService
      .getTypeAheadDataByPastedValue(this.field, pasteValues)
      .subscribe(data => {
        this.isPasting = false;
        this.pasteProcessedData = data;
      });
  }
}
