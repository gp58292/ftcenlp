import { ChangeDetectorRef, Component, Input, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { RatingRankingModel } from '@aqua/aqua-component/dropdown-range';
import { SearchService } from '@aqua/filters/data-finder/search/search.service';
import { SearchField } from '@aqua/filters/models/search-field';

@Component({
  selector: 'ceft-rating-ranking',
  templateUrl: './rating-ranking.component.html',
  styleUrls: ['./rating-ranking.component.scss'],
  // changeDetection:ChangeDetectionStrategy.OnPush
})
export class RatingRankingComponent implements OnInit {
  @Input('field') public field: SearchField;
  @Input() public form: FormGroup;
  public ratingRanking: RatingRankingModel[];

  public data: string[] = [];

  constructor (private searchService: SearchService, private changeDetection: ChangeDetectorRef) {
  }

  public ngOnInit () {
    console.debug('RatingRankingComponent::ngOnInit');
    this.loadReferenceData();
  }

  public loadReferenceData () {
    console.debug('RatingRankingComponent::loadReferenceData', this.field);
    this.searchService.getRatingRankings().subscribe((data: RatingRankingModel[]) => {
        this.ratingRanking = data;
        console.debug('RatingRankingComponent::loadReferenceData', this.ratingRanking);
        this.changeDetection.detectChanges();
      });
  }
}
