import { TitleCasePipe, UpperCasePipe } from '@angular/common';
import { Component, Input } from '@angular/core';
import {
  IncludeExcludeListModel,
  IncludeExcludeModel,
  OPERATOR,
  RangeValue,
  RangeWrapperModel,
  RatingRangeListModel,
  RatingRangeListWrapperModel,
  TenorRangeModel,
} from '@aqua/aqua-component/models';
import { ComponentType, SearchField } from '@aqua/filters/models';
import { FiltersService } from '@aqua/filters/services/filters.service';
import { map } from 'rxjs/operators';
import { WhoCanWhoHas } from '@aqua/filters/filters.types';

@Component({
  selector: 'derivz-filter-display',
  templateUrl: './filter-display.component.html',
  styleUrls: ['./filter-display.component.scss'],
})
export class FilterDisplayComponent {
  public static titleCasePipe: TitleCasePipe = new TitleCasePipe();
  public static upperCasePipe: UpperCasePipe = new UpperCasePipe();

  public static prepareNumberRange (field: SearchField) {
    const range: RangeValue<number> = field.value;
    let outStr;
    if (range.start) {
      outStr = `<label>From </label>${range.start}`;
      outStr += range.end ? `<label> till </label> ${range.end}` : '<label> and all highest</label>';
    }
    else {
      outStr = `<label>All before </label> ${range.end}`;
    }

    return outStr;
  }

  public static prepareDateRange (field: SearchField) {
    const range: RangeValue<Date> = field.value;
    let outStr;

    if (range.start) {
      outStr = `<label>From </label>${range.start}`;
      outStr += range.end ? `<label> till </label> ${range.end}` : '<label> till max date</label>';
    }
    else {
      outStr = `<label>Before </label> ${range.end} <label>date</label>`;
    }

    return outStr;
  }

  public static prepareIncludeExclude (field: SearchField) {
    const includeExclude: IncludeExcludeModel = field.value;
    let outStr = '';
    if (includeExclude.value && includeExclude.value.length > 0) {
      const str = includeExclude.value.map(f => f.value).join('; ');
      outStr += `<section><label class="toggle-label blue">${FilterDisplayComponent.formatData(includeExclude.operation, true) }</label>${str}</section>`;
    }
    if (includeExclude.butNotValue && includeExclude.butNotValue.length > 0) {
      const str = includeExclude.butNotValue.map(f => f.value).join('; ');
      outStr += `<section><label class="toggle-label grey">BUT NOT</label>${str}</section>`;
    }

    return outStr;
  }

  public static prepareRatingRangeList (field: SearchField) {
    const ratingRangeWrapper: RatingRangeListWrapperModel = field.value;
    let outStr1 = '';
    let outStr2 = '';

    if (ratingRangeWrapper.inValueList) {
      outStr1 = FilterDisplayComponent.prepareInValueOrNotInValue(outStr1, ratingRangeWrapper.inValueList);
    }
    if (ratingRangeWrapper.notInValueList) {
      outStr2 = FilterDisplayComponent.prepareInValueOrNotInValue(outStr2, ratingRangeWrapper.notInValueList);
    }

    return (outStr1 || '') + (outStr2 || '');
  }

  public static prepareTerm (field: SearchField) {
    let outStr = '';
    const tenorRangeList: RangeWrapperModel<any> = field.value;
    if (tenorRangeList) {
      const tenorRangeInValue: TenorRangeModel<any> = tenorRangeList.inValue;
      const tenorRangeNotInValue: TenorRangeModel<any> = tenorRangeList.notInValue;
      if (tenorRangeInValue) {
        outStr = outStr + '<section>';
        if (tenorRangeInValue.rangeValue && (tenorRangeInValue.rangeValue.start || tenorRangeInValue.rangeValue.end)) {
          outStr = outStr + '<label class="toggle-label blue">IN</label> ';
          // outStr = outStr + ' Range: ';
          if (tenorRangeInValue.rangeValue.start) {
            outStr = outStr + tenorRangeInValue.rangeValue.start + '<label> &le; </label>';
          }
          if (tenorRangeInValue.rangeValue.start) {
            outStr = outStr + '<label> &ge; </label>' + tenorRangeInValue.rangeValue.end;
          }
          // outStr = outStr + '; ';
        }
        if (tenorRangeInValue.period && (tenorRangeInValue.period.key || tenorRangeInValue.period.value)) {
          outStr = outStr + ' ' + tenorRangeInValue.period.value;
        }
        outStr = outStr + '</section>';
      }
      // term not in values
      if (tenorRangeNotInValue) {
        outStr = outStr + '<section>';
        if (tenorRangeNotInValue.rangeValue && (tenorRangeNotInValue.rangeValue.start || tenorRangeNotInValue.rangeValue.end)) {
          outStr = outStr + '<label class="toggle-label grey">NOT IN</label>';
          // outStr = outStr + ' Range: ';
          if (tenorRangeNotInValue.rangeValue.start) {
            outStr = outStr + tenorRangeNotInValue.rangeValue.start + '<label> &le; </label>';
          }
          if (tenorRangeNotInValue.rangeValue.end) {
            outStr = outStr + '<label> &ge; </label>' + tenorRangeNotInValue.rangeValue.end;
          }
          // outStr = outStr + '; ';
        }
        if (tenorRangeNotInValue.period && (tenorRangeNotInValue.period.key || tenorRangeNotInValue.period.value)) {
          outStr = outStr + ' ' + tenorRangeNotInValue.period.value;
        }
        outStr = outStr + '</section>';
      }

    }

    return outStr;
  }

  public static prepareMultiIncludeExclude (field: SearchField) {
    const includeExcludeList: IncludeExcludeListModel = field.value;
    let outStr = '';
    if (includeExcludeList) {
      if (
        includeExcludeList.valueList &&
        includeExcludeList.valueList.length > 0
      ) {
        includeExcludeList.valueList.forEach(element => {
          const includeExclude: IncludeExcludeModel = element;
          if (includeExclude.value && includeExclude.value.length > 0) {
            const str = includeExclude.value.map(f => f.value).join('; ');
            outStr =
              outStr +
              '<section><label class="toggle-label blue">' +
              FilterDisplayComponent.formatData(includeExclude.operation, true) +
              '</label>' +
              str +
              '</section>';
          }
          if (
            includeExclude.butNotValue &&
            includeExclude.butNotValue.length > 0
          ) {
            const str = includeExclude.butNotValue
              .map(f => f.value)
              .join('; ');
            outStr =
              outStr +
              '<section><label class="toggle-label grey">BUT NOT</label>' +
              str +
              '</section>';
          }
        });
      }
    }

    return outStr;
  }


  public static prepareInValueOrNotInValue (outStr: string, ratingRange: RatingRangeListModel): string {
    let operationForList: string = '';
    for (const rangeModel of ratingRange.valueList) {
      if (rangeModel.agencyName || rangeModel.period || rangeModel.value) {
        operationForList = '';
      }
      if (rangeModel.operation === OPERATOR.AND && (rangeModel.agencyName || rangeModel.period || rangeModel.value)) {
        operationForList = operationForList + '<label class=\'toggle-label blue\'>AND</label><br/>';
        break;
      }
      if (rangeModel.operation === OPERATOR.OR && (rangeModel.agencyName || rangeModel.period || rangeModel.value)) {
        operationForList = operationForList + '<label class=\'toggle-label blue\'>OR</label>';
        break;
      }
      if (rangeModel.operation === OPERATOR.BUT_NOT && (rangeModel.agencyName || rangeModel.period || rangeModel.value)) {
        operationForList = operationForList + '<label class=\'toggle-label grey\'> BUT NOT</label>';
        break;
      }
      operationForList = operationForList !== '' ? operationForList : '';
    }
    outStr = (outStr !== undefined ? outStr : '') + operationForList;

    outStr = outStr + '<table><thead><tr>' +
      '<th>Agency Name</th>' +
      '<th>Period</th>' +
      '<th colspan="4">Range</th>' +
      '</tr></thead><tbody>';
    for (const rangeModel of ratingRange.valueList) {
      if (rangeModel.agencyName || rangeModel.period || rangeModel.value) {
        outStr = outStr + '<tr><td>';

        if (rangeModel.agencyName) {
          outStr = outStr + FilterDisplayComponent.formatData(rangeModel.agencyName, true);
        }
        outStr = outStr + '</td><td>';
        if (rangeModel.period) {
          outStr = outStr + FilterDisplayComponent.formatData(rangeModel.period, true);
        }

        outStr = outStr + '</td>';
        if (rangeModel.value && (rangeModel.value.start || rangeModel.value.end)) {
          if (rangeModel.value.start) {
            outStr = outStr + '<td>' + rangeModel.value.start.value + '</td><td><label>&le;</label></td>';
          } else {
            outStr = outStr + '<td colspan="2"></td>';
          }

          if (rangeModel.value.end) {
            outStr = outStr + '<td><label>&ge;</label></td><td>' + rangeModel.value.end.value + '</td>';
          } else {
            outStr = outStr + '<td colspan="2"></td>';
          }
        } else {
          outStr = outStr + '<td colspan="4"></td>';
        }
        outStr = outStr + '</tr>';
      }
    }
    outStr = outStr + '</tbody></table>';
    return outStr;
  }

  public static formatData (
    rec: string,
    isUpcase: boolean = false,
    skipCaseFormatting: boolean = false,
  ): string {
    return skipCaseFormatting
      ? rec.toString()
      : isUpcase
        ? FilterDisplayComponent.upperCasePipe.transform(rec.toString())
        : FilterDisplayComponent.titleCasePipe.transform(rec.toString());
  }
  
  public static prepareCriteria (data): any {
    const displayCriteria = new Map<string, Set<string>>();
    data.forEach(fieldItem => {
      const renderValue = new Set<any>();

      switch (fieldItem.componentType) {
        case ComponentType.FREE_FORM_TEXT:
          renderValue.add(fieldItem.value);
          break;
        case ComponentType.DROPDOWN:
        case ComponentType.TYPEAHEAD_TEXTBOX:
          fieldItem.value.forEach(valueItem => renderValue.add(valueItem.value));
          break;
        case ComponentType.NUMERIC_RANGE_FILTER:
          renderValue.add(FilterDisplayComponent.prepareNumberRange(fieldItem));
          break;
        case ComponentType.DATE_RANGE_FILTER:
          renderValue.add(FilterDisplayComponent.prepareDateRange(fieldItem));
          break;
        case ComponentType.INCLUDE_EXCLUDE:
          renderValue.add(FilterDisplayComponent.prepareIncludeExclude(fieldItem));
          break;
        case ComponentType.RATING_RANGE:
          renderValue.add(FilterDisplayComponent.prepareRatingRangeList(fieldItem));
          break;
        case ComponentType.TENOR_RANGE:
          renderValue.add(FilterDisplayComponent.prepareTerm(fieldItem));
          break;
        case ComponentType.MULTI_INCLUDE_EXCLUDE:
          renderValue.add(FilterDisplayComponent.prepareMultiIncludeExclude(fieldItem));
          break;
      }

      displayCriteria.set(fieldItem.name, renderValue);
    });

    return displayCriteria;
  }
  
  @Input('whoHas') public whoHasFlag: WhoCanWhoHas = WhoCanWhoHas.CAN;

  public criterias$ = this.filterService.listenFiltersList$().pipe(
    map((data: SearchField[]) => data.filter(field => field.whoHasFlag.toString() === this.whoHasFlag.toString())),
    map((data: SearchField[]) => data.filter(field => !!field.value)),
    map((data: SearchField[]) => FilterDisplayComponent.prepareCriteria(data)),
  );
 
  constructor (private filterService: FiltersService) {
  }
}
