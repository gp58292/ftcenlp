import { NumericExcelStyleRule } from "@aqua/aqua-component/aqua-grid";
import { NumberRenderer } from "@aqua/aqua-component/aqua-grid/inline-cell-renderer";
import { ColumnDefaultGrid } from "@aqua/aqua-component/aqua-grid/utils";

export const AC_HAIRCUT_SCHEDULES_GRID_DEFINATION: ColumnDefaultGrid[] = [
  {
    headerName: "Type",
    field: "achType"
  },
  {
    headerName: "Min Term",
    field: "achMinTerm"
  },
  {
    headerName: "Max Term",
    field: "achMaxTerm"
  },
  {
    headerName: "Haircut%",
    field: "achHaicutPercentage",
    cellRendererFramework: NumberRenderer,
    cellClassRules: NumericExcelStyleRule
  },
  {
    headerName: "Issue Rating",
    field: "achRating",
    minWidth: 250
  },
  {
    headerName: "Issuer Rating",
    field: "achIssuerRating",
    minWidth: 250
  },
  {
    headerName: "Collateral Applied",
    field: "achCollateralApplied"
  },
  {
    headerName: "Collateral Party",
    field: "collateralParty"
  },
  {
    headerName: "Ranking",
    field: "achRanking"
  }
];
