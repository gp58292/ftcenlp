import {
  Component,
  EventEmitter,
  Input,
  OnDestroy,
  OnInit,
  Output,
  ViewChild,
  ViewChildren,
  QueryList,
  AfterViewInit
} from '@angular/core';
import { MatDialog, MatTabChangeEvent } from '@angular/material';
import { AquaGrid } from '@aqua/aqua-component/aqua-grid';
import { ColumnsDefinationGrid } from '@aqua/aqua-component/aqua-grid/model';
import { ColumnDefaultGrid, GridUtils } from '@aqua/aqua-component/aqua-grid/utils';
import { IncludeExcludeListModel, IncludeExcludeModel } from '@aqua/aqua-component/models';
import { BookmarkService } from '@aqua/filters/data-finder/bookmark';
import { BookmarkRequest } from '@aqua/filters/data-finder/bookmark/bookmark-request.model';
import { AggrementPopinComponent } from '@aqua/filters/data-finder/search/search-result/filter-popin/aggrement-popin.component';
import { SearchService } from '@aqua/filters/data-finder/search/search.service';
import { WhoCanWhoHas } from '@aqua/filters/filters.types';
import { Agreement, ComponentType, FieldNames, SearchResultColumns, SearchResultModel } from '@aqua/filters/models';
import { AgreementOptimalRank } from '@aqua/filters/models/agreement-optimal-rank';
import { SearchResultDataSetBookmark } from '@aqua/filters/models/search-bookmark-model';
import { SearchField } from '@aqua/filters/models/search-field';
import { FilterCancelService, GridNotificationService, SearchResultColumnService, TabsSearchService } from '@aqua/filters/services';
import { FiltersService } from '@aqua/filters/services/filters.service';
import { SearchPlusBookmarkService } from '@aqua/filters/services/search-plus-bookmark.service';
import { TabsInfo } from '@aqua/models';
import { VizNotificationService } from '@aqua/services';
import { AuthenticationService } from '@citi-icg-163206/frm-framework-npm-commons';
import { GridOptions } from 'ag-grid-community';
import { combineLatest, Observable, Subject } from 'rxjs';
import { debounceTime, filter, map, shareReplay, takeUntil } from 'rxjs/operators';

import { SearchResultDataSource } from './server-grid-api/search-result.server.datasource';

@Component({
  selector: 'ceft-search-result',
  templateUrl: './search-result.component.html',
  styleUrls: ['./search-result.component.scss']
})
export class SearchResultComponent implements OnInit, OnDestroy, AfterViewInit {
  @Input()
  set filtersExpanded(_filterExpanded: boolean) {
    this.gridHeight = _filterExpanded ? 41.1 : 77.8;
  }

  set isFilterd(isFilterdData: boolean) {
    console.debug('SearchResultComponent::isFilterd::', isFilterdData, this.activeTabName, this.isActualPostingCTNExist);
    this._isFilterd = isFilterdData;
    // TODO: Use observable and handle in searchPlus bookmark.
    // if (this.activeTabName === 'Current Postings' && this.isActualPostingCTNExist) {
    //   this.getData(this.tabsSearchService.activeTabInfo.tabId);
    // }
  }

  get isFilterd(): boolean {
    return this._isFilterd;
  }
  @ViewChild('listedAgGrid')
  private set listedAgGrid(listedAgGrid: AquaGrid) {
    console.debug('SearchResultComponent::listedAgGrid::', listedAgGrid);
    if (listedAgGrid) {
      this._listedAgGrid = listedAgGrid;
    }
  }

  private get listedAgGrid() {
    return this._listedAgGrid;
  }

  public get searchStatus$(): Observable<boolean> {
    return this.searchService.searchingStatus$;
  }

  public get isListedEmpty(): boolean {
    return this._isListedEmpty;
  }

  private static checkCollatralType(criteria: SearchField[], withContractualEligibilityOnly: boolean = true): any {
    return criteria.filter(
      field =>
        (withContractualEligibilityOnly ? field.whoHasFlag === WhoCanWhoHas.CAN : field.whoHasFlag === WhoCanWhoHas.HAS) &&
        field.componentType === ComponentType.MULTI_INCLUDE_EXCLUDE &&
        field.value
    ).length;
  }

  public readonly gridOptions: GridOptions = {
    maxBlocksInCache: 10,
    // suppressMultiSort: false,
    // sortingOrder: ['asc', 'desc'],
    rowModelType: 'serverSide',
    blockLoadDebounceMillis: 1000,
    defaultColDef: {
      sortable: true,
      filter: true
    }
  };

  public gotResult: boolean = false;
  public resultTabSelectedIndex: number = 0;

  @Output() public selectedAquaRows: EventEmitter<any[]> = new EventEmitter<any[]>();

  @Input() public resultsExpanded: boolean = false;
  public gridHeight: number = 41.1;

  public searchCriteria: SearchField[];
  public searchingStatus: boolean = false;

  public searchColumnsList: ColumnsDefinationGrid[];

  public _isFilterd: boolean = false;
  public isCTNExist: boolean = false;

  // New variables
  public tabsList: TabsInfo[];
  public resultColumnsList: ColumnsDefinationGrid[];
  public finalColumnsList: ColumnsDefinationGrid[];
  public resultsDataSource = [[]];
  public resultDataSource = undefined;
  public listedTabResultDataSource = undefined;
  public activeTabName: string;
  public isActualPostingCTNExist: boolean = false;

  private alive: Subject<void> = new Subject();
  private userId: string;
  // private firstTabName: string;

  private _selectedRows: any[];

  private smcColumns: SearchResultColumns[] = [];

  // Hold List ag grid reference
  private _listedAgGrid: AquaGrid;
  private _isListedEmpty: boolean = false;

  private _maxRecordLimit: number = 10000;
  private _resultTables: QueryList<AquaGrid>;

  @ViewChildren(AquaGrid) private set resultTables(grids: QueryList<AquaGrid>) {
    console.debug('SearchResultComponent::resultTables::SET::', grids.length, grids);
    this._resultTables = grids;
    // Initialize data source and this will be common accross tabs
    this.initializeGridsDataSource();
  }

  constructor(
    private authService: AuthenticationService,
    private searchService: SearchService,
    private filtersService: FiltersService,
    private vizNotification: VizNotificationService,
    private filterCancelService: FilterCancelService,
    private searchResultColumnService: SearchResultColumnService,
    public dialog: MatDialog,
    private bookmarkService: BookmarkService,
    private searchPlusBookmarkService: SearchPlusBookmarkService,
    private tabsSearchService: TabsSearchService,
    private gridNotificationService: GridNotificationService
  ) {
    this.authService
      .subscribeUserDetails()
      .pipe(takeUntil(this.alive))
      .subscribe(user => {
        this.userId = user.soeid;
      });
  }

  public spinnerCancelled(event: Event, name?: string) {
    console.debug('SearchResultComponent::spinnerCancelled::', event, name);
    this.filterCancelService.cancelSubject();
  }

  public ngOnInit() {
    console.debug('SearchResultComponent::ngOnInit::');

    this.getAllTabs();

    this.listenResultDataChange();
    this.listenCriteriaChange();
    this.searchResultColumnService.loadResultColumns();
    this.getTabColumns(this.tabsSearchService.activeTabInfo.tabId);
    this.listenForClearData();
  }

  public ngAfterViewInit() {
    console.debug('SearchResultComponent::ngAfterViewInit::', this._resultTables.length);
  }

  public ngOnDestroy() {
    console.debug('SearchResultComponent::ngOnDestroy');
    this.alive.next();
    this.alive.complete();
    this.alive.unsubscribe();
  }

  public getLastResultAgreementKeys(): number[] {
    const selectedRows = this.getSelectedRows();
    if (selectedRows && selectedRows.length > 0) {
      this._selectedRows = selectedRows;
    } else {
      this._selectedRows = this.listedTabResultDataSource;
      // this.resultsDataSource[this.firstTabName];
    }
    return this._selectedRows && this._selectedRows.map(result => result.agreement_key);
  }

  public getLastResultAgreementKeysAndOptimalRank(): AgreementOptimalRank[] {
    const selectedRows = this.getSelectedRows();
    if (selectedRows && selectedRows.length > 0) {
      this._selectedRows = selectedRows;
    } else {
      this._selectedRows = this.listedTabResultDataSource;
      // this.resultsDataSource[this.firstTabName];
    }

    return (
      this._selectedRows &&
      this._selectedRows.map(result => ({
        agreementKey: result.agreement_key,
        optimalRank: result.optimal_rank
      }))
    );
  }

  public onFiltered(event: MouseEvent): void {
    const element: any = event.target || event.srcElement || event.currentTarget;
    const isDisabled: any = element.getAttribute('disabled');

    console.debug('SearchResultComponent::onFiltered::', this.isFilterd, isDisabled);
    if (isDisabled) {
      return;
    }
    this.isFilterd = !this.isFilterd;
    this.searchService.onFilterFlagChange(this.isFilterd);
  }

  public onSelectedRows(_selectedRows: Agreement[]): void {
    this._selectedRows = _selectedRows;
  }

  public tabChanged(tabChangeEvent: MatTabChangeEvent): void {
    console.debug('SearchResultComponent::tabChanged Tab Changed: ', tabChangeEvent, tabChangeEvent.tab.textLabel);
    const activeTabName = tabChangeEvent.tab.textLabel;
    const activetabInfo: TabsInfo = this.tabsList.find(item => item.tabName === activeTabName);
    // if (!this.firstTabName) {
    //   this.firstTabName = activetabInfo.tabId
    // }
    // this.searchingStatus = false;
    this.resultDataSource = undefined;
    this.getTabColumns(activetabInfo.tabName);
    // if (this.activeTabName !== 'Listed') {
    //   setTimeout(() => {
    //     this.getData(activetabInfo.tabId);
    //   }, 200);
    // }

    this.tabsSearchService.setTabInfo(activetabInfo);
    // if (this.activeTabName === "Listed") {
    // 	this.searchingStatus = true;
    // 	// setTimeout(() => {
    // 	// 	this.searchingStatus = false;
    // 	// }, 500);
    // }
  }

  public getTabColumns(tabName: string): void {
    console.debug('SearchResultComponent::getTabColumns:: ');
    this.searchResultColumnService
      .getColumnsListByTab(tabName)
      .pipe(takeUntil(this.alive))
      .subscribe((columns: SearchResultColumns[]) => {
        console.debug('SearchResultComponent::getTabColumns::', columns.filter(p => p.isDefaultDisplay && p.tabName === 'Listed'));
        let finalColumns = [...columns];
        if (tabName === 'Current Postings' || tabName === 'Box') {
          finalColumns = GridUtils.mergeColumnsIfNotExistOtherwiseIgnore(this.smcColumns, finalColumns);
        }
        this.resultColumnsList = GridUtils.buildColumns2(finalColumns);
        if (tabName === 'Listed') {
          this.resultColumnsList.push(ColumnDefaultGrid.checkbox);
        }
        console.debug('SearchResultComponent::getTabColumns:: Result Column::', tabName, this.resultColumnsList.length);
      });
  }

  public getAllTabs(): void {
    // console.debug("SearchResultComponent::getAllTabs:: ");
    this.searchResultColumnService
      .getTabList()
      .pipe(takeUntil(this.alive))
      .subscribe(tabs => {
        console.debug('SearchResultComponent::getAllTabs:: ', tabs);
        this.tabsList = tabs;
      });
  }

  public getVoyagerTabs(): void {
    console.debug('SearchResultComponent::getVoyagerTabs:: ');
    this.searchResultColumnService
      .getVoyagerTabList()
      .pipe(takeUntil(this.alive))
      .subscribe(columns => {
        console.debug('SearchResultComponent::getVoyagerTabs::', columns);
      });
  }

  public onSelectedAggrement($event) {
    console.debug('SearchResult::onSelectedAggrement:: ', $event);
    const selectedAggrement = $event.data[FieldNames.AGREEMENT_KEY];
    const selectedAggrementId = $event.data[FieldNames.AGREEMENT_ID];

    if ($event.colDef.field === 'agreement_id') {
      // aggrement popin start
      const dialogRef = this.dialog.open(AggrementPopinComponent, {
        width: '95%',
        maxWidth: '95%',
        height: '90%',
        data: {
          name: selectedAggrement,
          aggrementId: selectedAggrementId
        }
      });
      console.debug('SearchResult::onSelectedAggrement:: ', selectedAggrement);
      dialogRef.afterClosed().subscribe(result => {
        console.debug('SearchResult::afterClosed:: ');
      });
    }
  }
  private getSelectedRows(): any[] {
    if (this.listedAgGrid && this.listedAgGrid.gridApi) {
      this._selectedRows = this.listedAgGrid.gridApi.getSelectedRows();
    }
    return this._selectedRows;
  }

  private listenForClearData(): void {
    combineLatest(this.tabsSearchService.startSearch$(), this.tabsSearchService.activeTabInfo$())
      .pipe(
        filter(([isStarted, activeTabInfo]: any) => isStarted),
        map(([isStarted, activeTabInfo]: any) => [isStarted, activeTabInfo, this.filtersService.filterListWithValues]),
        filter(([isStarted, activeTabInfo, criteria]: any) => criteria.length > 0),
        shareReplay(1)
      )
      .subscribe((data: any) => {
        console.debug('SearchResultDataSource::listenForClearData::');
        this.clearActiveGrid();
      });
  }

  // Clear existing data from grid when user search or open new tab, so use won't see any stale data
  // this may need to improve, when we load all grids data simultaneously
  private clearActiveGrid() {
    const aquaGrid: AquaGrid = this._resultTables.find((grid: AquaGrid) => {
      console.debug(
        'SearchResultDataSource::clearActiveGrid::',
        grid.gridId,
        this.tabsSearchService.activeTabInfo.tabId,
        this.tabsSearchService.activeTabInfo
      );
      return grid.gridId === this.tabsSearchService.activeTabInfo.tabId;
    });
    if (aquaGrid) {
      console.debug('SearchResultDataSource::clearActiveGrid::', aquaGrid.gridId);
      if (aquaGrid.gridApi) {
        aquaGrid.gridApi.setServerSideDatasource(
          new SearchResultDataSource(this.gridNotificationService, this.searchPlusBookmarkService, this.tabsSearchService, aquaGrid.gridId)
        );
      } else {
        aquaGrid.serverDataSource = new SearchResultDataSource(
          this.gridNotificationService,
          this.searchPlusBookmarkService,
          this.tabsSearchService,
          aquaGrid.gridId
        );
      }
    }
  }

  // Create seperate server side datasource instance of each grid wise, assign unique id(which is optional, but good as multi grids are here)
  private initializeGridsDataSource() {
    // this._resultTables.forEach((grid: AquaGrid) => {
    //   if (!grid.serverDataSource) {
    //     grid.serverDataSource = new SearchResultDataSource(
    //       this.gridNotificationService,
    //       this.searchPlusBookmarkService,
    //       this.tabsSearchService,
    //       grid.gridId
    //     );
    //   }
    // });
  }

  private listenCriteriaChange(): void {
    // listen current search criteria
    this.filtersService
      .listenFiltersList$()
      .pipe(
        takeUntil(this.alive),
        debounceTime(500),
        map((data: SearchField[]) => data && data.filter(field => !!field.value))
      )
      .subscribe((data: SearchField[]) => {
        if (data.length > 0) {
          this.searchCriteria = data;
          this.prepareColumnList();
          this.isActualPostingCTNExist = SearchResultComponent.checkCollatralType(data, false);
          this.isCTNExist = SearchResultComponent.checkCollatralType(data) > 0;
          console.debug('SearchResultComponent::listenCriteriaChange::', this.isActualPostingCTNExist, this.isCTNExist);
          this.searchService.onFilterFlagChange(this.isActualPostingCTNExist);
        }
      });
  }

  private prepareColumnList(): void {
    const smsSearchField = this.searchCriteria.filter(p => p.logicalGroupName === 'SMC Attributes');

    const smcColumns: SearchResultColumns[] = [];
    let count = 1000;
    for (const searchField of smsSearchField) {
      const src: SearchResultColumns = new SearchResultColumns();
      src.fieldName = searchField.fieldName;
      src.displayName = searchField.name;
      src.isDefaultDisplay = true;
      src.fieldType = searchField.dataType.toUpperCase();
      src.fieldOrder = count++;
      smcColumns.push(src);
    }
    this.smcColumns = smcColumns;
    // console.debug(
    // 	"SearchResultComponent::preapreColumnList::",
    // 	smsSearchField,
    // 	smcColumns
    // );
  }

  // private updateCeftTabsDataSource(count, criteria) {
  //   const searchResultDataSource:SearchResultDataSource=new  SearchResultDataSource({});
  // }

  private listenResultDataChange() {
    console.debug('SearchResultComponent::listenResultDataChange');
    this.searchPlusBookmarkService.searchResultObervable$
      .pipe(takeUntil(this.alive))
      .subscribe((searchBookmarkModel: SearchResultDataSetBookmark) => {
        console.debug(
          'SearchResultComponent::listenResultDataChange::Got new result::',
          searchBookmarkModel,
          // this.firstTabName,
          this.resultTabSelectedIndex,
          this.tabsSearchService.activeTabInfo,
          this.tabsSearchService.isFirstTabActive,
          this.gotResult
        );
        const result: SearchResultModel = searchBookmarkModel.searchResult;
        // clear existing data from array
        // this.resultsDataSource = [[]];
        this.gotResult = result && result.listOfRecords && result.listOfRecords.length > 0;

        // if (this.resultTabSelectedIndex !== 0) {
        //   this.resultTabSelectedIndex = 0;
        // }
        if (this.tabsSearchService.isFirstTabActive) {
          this._isListedEmpty = this.gotResult;
        }
        if (this.listedTabResultDataSource !== undefined) {
          this.listedTabResultDataSource = undefined;
        }
        if (this.gotResult) {
          this.setFilter();
          // this.resultsDataSource[this.firstTabName] = result.listOfRecords;
          this.listedTabResultDataSource = result.listOfRecords;

          if (result.count > this._maxRecordLimit) {
            this.showRecordWarning(result.count);
          }
        } else if (result !== null) {
          // this.resultsDataSource[this.firstTabName] = [];
          this.listedTabResultDataSource = [];
        }
      });
  }

  private showRecordWarning(count: number): void {
    this.vizNotification.showWarning(
      `**NOTIFICATION** User query returned ${count} records , only ${this._maxRecordLimit} records are displayed in the listed tab.`,
      'Dismiss',
      { duration: 60000 }
    );
  }

  private setFilter(): void {
    console.debug('SearchResultComponent::setFilter::', this.isActualPostingCTNExist);
    this._isFilterd = this.isActualPostingCTNExist;
    this.searchService.onFilterFlagChange(this.isActualPostingCTNExist);
  }

  private getCollaterTypeSearchCriteria(): string[] {
    const collateralTypeNames: Set<string> = new Set();
    const collateralTypeNameFields: SearchField[] = this.searchCriteria.filter(
      field => field.fieldName === 'collateral_type_name' && field.value
    );
    collateralTypeNameFields.forEach(field => {
      const fieldIncludeExcludeValue: IncludeExcludeListModel = field.value;
      if (fieldIncludeExcludeValue) {
        fieldIncludeExcludeValue.valueList.forEach((valueCTN: IncludeExcludeModel) => {
          if (valueCTN.value) {
            valueCTN.value.forEach(element => collateralTypeNames.add(element.value));
          }
        });
      }
    });
    return Array.from(collateralTypeNames.values());
  }

  // ---------------------------------------------------------------------------------------------------------------------
  private getData(tabName: string) {
    console.debug('SearchResultComponent::getData::', this.isActualPostingCTNExist, this._isFilterd, this.searchCriteria);
    const agreementKeys = this.getLastResultAgreementKeys();
    const agreementOptimalRanks: AgreementOptimalRank[] = this.getLastResultAgreementKeysAndOptimalRank();
    console.debug('SearchResultComponent::getData::Agreement Keys::', agreementKeys);
    const bookmarkRequest: BookmarkRequest = new BookmarkRequest();
    bookmarkRequest.userId = this.userId;
    // bookmarkRequest.datasetType = tabName;
    bookmarkRequest.bookmarkId = this.bookmarkService.getSelectedBookmarkKey();

    // this.searchService
    //   .getTabsData(bookmarkRequest)
    //   .pipe(takeUntil(this.alive))
    //   .subscribe(agreements => {
    //     console.debug('SearchResultComponent::getData::', agreements);
    //     if (agreements) {
    //       this.vizNotification.showMessage(tabName + ' fetched successfully');
    //       // @todo What The Field is `listOfRecords?` Which the Model is belong to?
    //       this.resultDataSource = agreements.listOfRecords;
    //       if (tabName === 'GSST') {
    //         this.showGSSTTabMessage(tabName, this.resultDataSource.length);
    //       }
    //     }
    //   });
  }

  private showGSSTTabMessage(tabName: string, resultLength: number) {
    // this.resultsDataSource[tabName].length
    if (this.getCollaterTypeSearchCriteria().length === 0 && resultLength > 0) {
      this.vizNotification.showWarning(
        'GSST exposure is not calculated as collateral type name is not selected in contractual eligibility',
        'Dismiss',
        { duration: 60000 }
      );
    } else {
      this.vizNotification.showMessage('GSST Data fetched successfully');
    }
  }

  // private mergeDefaultAndSMCColumns(): void {
  // 	console.debug("SearchResultComponent::mergeDefaultAndSMCColumns::");
  // 	this.finalColumnsList = [...this.resultColumnsList];
  // 	console.debug(
  // 		"SearchResultComponent::mergeDefaultAndSMCColumns:: Final Column::",
  // 		this.finalColumnsList.length
  // 	);
  // }
}
