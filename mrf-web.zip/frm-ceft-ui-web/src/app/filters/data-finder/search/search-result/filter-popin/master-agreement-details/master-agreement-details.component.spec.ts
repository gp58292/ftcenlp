import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { MasterAgreementDetailsComponent } from "./master-agreement-details.component";

describe("MasterAgreementDetailsComponent", () => {
	let component: MasterAgreementDetailsComponent;
	let fixture: ComponentFixture<MasterAgreementDetailsComponent>;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			declarations: [MasterAgreementDetailsComponent]
		}).compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(MasterAgreementDetailsComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});
});
