import { SearchResultModel } from '@aqua/filters/models';
import { SearchResultDataSetBookmark } from '@aqua/filters/models/search-bookmark-model';
import { FiltersService, GridNotificationService, TabsSearchService } from '@aqua/filters/services';
import { SearchPlusBookmarkService } from '@aqua/filters/services/search-plus-bookmark.service';
import { CeftDataSetStatus } from '@aqua/models';
import { IServerSideDatasource, IServerSideGetRowsParams } from 'ag-grid-community';
import { combineLatest, Subject } from 'rxjs';
import { filter, map, shareReplay, takeUntil, tap } from 'rxjs/operators';

export class SearchResultDataSource implements IServerSideDatasource {
  private _alive$: Subject<void> = new Subject();

  private _params: IServerSideGetRowsParams;
  private _lastRow: number = 10;
  private _dataSourceId: string;

  constructor(
    private gridNotificationService: GridNotificationService,
    private searchPlusBookmarkService: SearchPlusBookmarkService,
    private tabsSearchService: TabsSearchService,
    private dataSourceId?: string
  ) {
    this._dataSourceId = dataSourceId;
    console.debug('SearchResultDataSource::constructor::', dataSourceId);

    this.listenResults();
    this.listenForLastrow();
  }
  public getRows(params: IServerSideGetRowsParams): void {
    console.debug('SearchResultDataSource::getRows::', params);
    this.gridNotificationService.updateRowsParam(params.request);
    this._params = params; // For holding
  }
  public destroy?(): void {
    console.debug('SearchResultDataSource::destroy::');
    this._alive$.next();
    this._alive$.complete();
    this._alive$.unsubscribe();
  }

  private listenResults(): void {
    this.searchPlusBookmarkService.searchResultObervable$
      .pipe(
        filter((searchBookmarkModel: SearchResultDataSetBookmark) => this._dataSourceId === this.tabsSearchService.activeTabInfo.tabId),
        takeUntil(this._alive$)
      )
      .subscribe(
        (searchBookmarkModel: SearchResultDataSetBookmark) => {
          console.debug('SearchResultDataSource::listenResults::', searchBookmarkModel, this._params);
          const searchResult: SearchResultModel = searchBookmarkModel.searchResult;
          if (this._params) {
            // Check if its last row or not for smooth scrolling
            const lastRow = this._params.request.endRow > this._lastRow ? -1 : this._lastRow;

            this._params.successCallback(searchResult.listOfRecords as any, lastRow);
          }
        },
        error => {
          if (this._params) {
            this._params.failCallback();
          }
          console.debug('SearchResultDataSource::listenResults::error::', error);
        }
      );
  }

  private listenForLastrow(): void {
    this.searchPlusBookmarkService.searchResultDataReadyObervable$
      .pipe(
        filter((ceftDataSetStatus: CeftDataSetStatus) => this._dataSourceId === this.tabsSearchService.activeTabInfo.tabId),
        takeUntil(this._alive$)
      )
      .subscribe(
        (ceftDataSetStatus: CeftDataSetStatus) => {
          console.debug('SearchResultDataSource::listenForLastrow::', ceftDataSetStatus);
          this._lastRow = ceftDataSetStatus.total;
        },
        error => {
          console.debug('SearchResultDataSource::listenForLastrow::error::', error);
        }
      );
  }
}
