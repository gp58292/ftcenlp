import { NumericExcelStyleRule } from "@aqua/aqua-component/aqua-grid";
import { NumberRenderer } from "@aqua/aqua-component/aqua-grid/inline-cell-renderer";
import { ColumnDefaultGrid } from "@aqua/aqua-component/aqua-grid/utils";

export const PARTY_THRESHOLD_GRID_DEFINATION: ColumnDefaultGrid[] = [
  {
    headerName: "Type",
    field: "type"
  },
  {
    headerName: "Basis",
    field: "basis"
  },
  {
    headerName: "Currency",
    field: "currency"
  },
  {
    headerName: "Amount",
    field: "amount",
    cellRendererFramework: NumberRenderer,
    cellClassRules: NumericExcelStyleRule
  }
];
