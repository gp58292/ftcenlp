import { IServerSideGetRowsParams, IServerSideGetRowsRequest, RowNode } from 'ag-grid-community';

export class SearchResultRowsParams implements IServerSideGetRowsParams {
  public request: IServerSideGetRowsRequest;
  public parentNode: RowNode;
  public successCallback(rowsThisPage: any[], lastRow: number): void {
    throw new Error('Method not implemented.');
  }
  public failCallback(): void {
    throw new Error('Method not implemented.');
  }
}

// interface IServerSideGetRowsRequest {

//   // row group columns
//   rowGroupCols: ColumnVO[];

//   // value columns
//   valueCols: ColumnVO[];

//   // pivot columns
//   pivotCols: ColumnVO[];

//   // true if pivot mode is one, otherwise false
//   pivotMode: boolean;

//   // what groups the user is viewing
//   groupKeys: string[];

//   // if filtering, what the filter model is
//   filterModel: any;

//   // if sorting, what the sort model is
//   sortModel: any;
// }

// export interface ColumnVO {
//   id: string;
//   displayName: string;
//   field: string;
//   aggFunc: string;
// }
