import { NumericExcelStyleRule } from "@aqua/aqua-component/aqua-grid";
import { NumberRenderer } from "@aqua/aqua-component/aqua-grid/inline-cell-renderer";
import { ColumnDefaultGrid } from "@aqua/aqua-component/aqua-grid/utils";

export const COVERED_PRODUCTS_GRID_DEFINATION: ColumnDefaultGrid[] = [
  {
    headerName: "Include/Exclude",
    field: "includeExclude"
  },
  {
    headerName: "Code",
    field: "instrumentCode",
    cellRendererFramework: NumberRenderer,
    cellClassRules: NumericExcelStyleRule
  },
  {
    headerName: "Parent Instr Code",
    field: "parentInstrCode",
    cellRendererFramework: NumberRenderer,
    cellClassRules: NumericExcelStyleRule
  },
  {
    headerName: "Type",
    field: "covProdType"
  },
  {
    headerName: "Name",
    field: "instrumentName"
  }
];
