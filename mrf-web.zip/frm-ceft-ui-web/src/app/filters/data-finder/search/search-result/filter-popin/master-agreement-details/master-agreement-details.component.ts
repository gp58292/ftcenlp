import { ChangeDetectionStrategy, Component, Input } from "@angular/core";
import { ColumnDefaultGrid } from "@aqua/aqua-component/aqua-grid/utils";
import { GridOptions } from "ag-grid-community";

import { COVERED_BRANCHES_GRID_DEFINATION } from "./grid-column-defination/covered-branches.grid-definations";
import { COVERED_PRODUCTS_GRID_DEFINATION } from "./grid-column-defination/covered-products.grid-definations";

@Component({
	selector: "ceft-master-agreement-details",
	templateUrl: "./master-agreement-details.component.html",
	styleUrls: ["./master-agreement-details.component.scss"],
	changeDetection: ChangeDetectionStrategy.OnPush
})
export class MasterAgreementDetailsComponent {
	public gridOptions: GridOptions = {
		sideBar: null,
		enableRangeSelection: true,
		statusBar: {
			statusPanels: [
				{ statusPanel: "agFilteredRowCountComponent" },
				{ statusPanel: "agSelectedRowCountComponent" },
				{
					statusPanel: "agAggregationComponent",
					statusPanelParams: {
						// possible values are: 'count', 'sum', 'min', 'max', 'avg'
						aggFuncs: ["count", "min", "max", "avg"]
					}
				}
			]
		},
		suppressHorizontalScroll: false,
		pagination: false,
		rowHeight: 30,
		rowBuffer: 10,
		defaultColDef: {
			sortable: true,
			resizable: true,
			filter: true
		}
	};

	public coveredBranchesColDef: ColumnDefaultGrid[] = COVERED_BRANCHES_GRID_DEFINATION;
	public coveredProductsColDef: ColumnDefaultGrid[] = COVERED_PRODUCTS_GRID_DEFINATION;

	@Input()
	public agreementDetails: any;

	public getData(data: string): string {
		return data ? data : "N/A";
	}
}
