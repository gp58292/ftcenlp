import { ColumnDefaultGrid } from "@aqua/aqua-component/aqua-grid/utils";

export const PUBLIC_RATING_GRID_DEFINATION: ColumnDefaultGrid[] = [
  {
    headerName: "Date",
    field: "ratingDate"
  },
  {
    headerName: "Agency",
    field: "agency"
  },
  {
    headerName: "Rating",
    field: "rating"
  }
];
