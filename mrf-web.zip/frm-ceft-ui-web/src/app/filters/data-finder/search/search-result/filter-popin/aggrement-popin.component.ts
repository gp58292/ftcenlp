import { ChangeDetectionStrategy, ChangeDetectorRef, Component, Inject, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialog, MatDialogRef } from '@angular/material';
import { SearchService } from '@aqua/filters/data-finder/search/search.service';
import { Agreement } from '@aqua/filters/models';
import { VizNotificationService } from '@aqua/services';

import { CsaAgreementDetailsComponent } from './csa-agreement-details/csa-agreement-details.component';
import { CSADetails } from './csa-details-model';

@Component({
  selector: 'ceft-aggrement-popin',
  templateUrl: './aggrement-popin.component.html',
  styleUrls: ['./aggrement-popin.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AggrementPopinComponent implements OnInit {
  public agreementDetailsList: Agreement;
  public spinnerStatus: boolean = true;

  @ViewChild(CsaAgreementDetailsComponent)
  public csaAgrermentDetailsComponent: CsaAgreementDetailsComponent;
  private tabList: Map<string, CSADetails> = new Map<string, CSADetails>();

  constructor (
    private searchService: SearchService,
    private vizNotification: VizNotificationService,
    public dialogRef: MatDialogRef<AggrementPopinComponent>,
    private dialogConfirmation: MatDialog,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private _changeDetectorRef: ChangeDetectorRef,
  ) {
    dialogRef.disableClose = true;
  }

  public ngOnInit () {
    this.getAgreementDetails();
  }

  public aggrementTabChanged ($event) {
    console.debug('AggrementPopinComponent::aggrementTabChanged', $event.index);
    const _currentTabkey = this.data.aggrementId + this.agreementDetailsList.csaTypeDescList[$event.index - 1].csa_description;

    let tabDetails = this.tabList.get(_currentTabkey);
    // console.debug(
    // 	"AggrementPopinComponent::aggrementTabChanged",
    // 	$event.index,
    // 	_currentTabkey,
    // 	tabDetails
    // );
    if (!tabDetails) {
      tabDetails = new CSADetails(
        this.data.aggrementId,
        this.agreementDetailsList.csaTypeDescList[$event.index - 1].csa_description,
        this.agreementDetailsList.csaTypeDescList[$event.index - 1].csa_status,
      );
      this.tabList.set(_currentTabkey, tabDetails);
    }
  }

  public getCurrentCSA (listofcsatype) {
    const _currentTabKey = this.data.aggrementId + listofcsatype;
    // console.debug("AggrementPopinComponent::getCurrentCSA::", _currentTabKey);
    return this.tabList.get(_currentTabKey);
  }

  public onCancel (): void {
    this.dialogRef.close();
  }

  private getAgreementDetails () {
    console.debug('AggrementPopinComponent::getBOXData');
    this.searchService.getAgreementDetails(this.data.name).subscribe((agreement: any) => {
      if (agreement) {
        this.vizNotification.showMessage('Agreement details fetched successfully');
        console.debug('AggrementPopinComponent::getAgreementDetails::', agreement);
        this.agreementDetailsList = agreement;
        this.spinnerStatus = false;
        this._changeDetectorRef.markForCheck();
      }
    });
  }
}
