import { NumericExcelStyleRule } from "@aqua/aqua-component/aqua-grid";
import { NumberRenderer } from "@aqua/aqua-component/aqua-grid/inline-cell-renderer";
import { ColumnDefaultGrid } from "@aqua/aqua-component/aqua-grid/utils";

export const AC_COVERED_GRID_DEFINATION: ColumnDefaultGrid[] = [
  {
    headerName: "Include/Exclude",
    field: "includeExclude"
  },
  {
    headerName: "Code",
    field: "instrumentCode"
  },
  {
    headerName: "Instr Code",
    field: "parentInstrCode"
  },
  {
    headerName: "Type",
    field: "covProdType",
    cellRendererFramework: NumberRenderer,
    cellClassRules: NumericExcelStyleRule
  },
  {
    headerName: "Name",
    field: "instrumentName"
  }
];
