import { NumericExcelStyleRule } from "@aqua/aqua-component/aqua-grid";
import { NumberRenderer } from "@aqua/aqua-component/aqua-grid/inline-cell-renderer";
import { ColumnDefaultGrid } from "@aqua/aqua-component/aqua-grid/utils";

export const COVERED_BRANCHES_GRID_DEFINATION: ColumnDefaultGrid[] = [
  {
    headerName: "GFCID",
    field: "partyGfcId"
  },
  {
    headerName: "Branch Name",
    field: "partyBranchName"
  },
  {
    headerName: "Location",
    field: "partyLocation"
  },
  {
    headerName: "Funding Index",
    field: "fundingIndex",
    cellRendererFramework: NumberRenderer,
    cellClassRules: NumericExcelStyleRule
  }
];
