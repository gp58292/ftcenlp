import { NumericExcelStyleRule } from "@aqua/aqua-component/aqua-grid";
import { NumberRenderer } from "@aqua/aqua-component/aqua-grid/inline-cell-renderer";
import { ColumnDefaultGrid } from "@aqua/aqua-component/aqua-grid/utils";

export const AC_CASH_GRID_DEFINATION: ColumnDefaultGrid[] = [
	{
		headerName: "Currency",
		field: "accCurrency"
	},
	{
		headerName: "Interest Index",
		field: "accInterestMatrix"
	},
	{
		headerName: "Interest Spread",
		field: "accInterestSpread"
	},
	{
		headerName: "Compounding",
		field: "accCompounding"
	},
	{
		headerName: "Payment Frequency",
		field: "accPaymentFrequency"
	},
	{
		headerName: "Reset Frequency",
		field: "accResetFrequency"
	},
	{
		headerName: "Ranking",
		field: "accRanking"
	}
];
