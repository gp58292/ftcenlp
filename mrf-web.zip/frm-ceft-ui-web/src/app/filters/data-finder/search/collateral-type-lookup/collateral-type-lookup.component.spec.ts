import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { CollateralTypeLookupComponent } from "./collateral-type-lookup.component";

describe("CollateralTypeLookupComponent", () => {
	let component: CollateralTypeLookupComponent;
	let fixture: ComponentFixture<CollateralTypeLookupComponent>;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			declarations: [CollateralTypeLookupComponent]
		}).compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(CollateralTypeLookupComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});
});
