import { Component } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { MatDialog } from '@angular/material';
import { ConfirmationDialogComponent } from '@aqua/filters/data-finder/confirmation-dialog/confirmation-dialog.component';
import { SearchService } from '@aqua/filters/data-finder/search/search.service';
import { WhoCanWhoHas } from '@aqua/filters/filters.types';
import { SearchField } from '@aqua/filters/models';
import { DataTreeStorageService, FiltersService, TabsSearchService } from '@aqua/filters/services';
import { SearchPlusBookmarkService } from '@aqua/filters/services/search-plus-bookmark.service';
import { Observable } from 'rxjs';
import { debounceTime, filter, map, shareReplay, tap } from 'rxjs/operators';

import { BookmarkService } from '../bookmark';

@Component({
  selector: 'aqua-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.scss']
})
export class SearchComponent {
  public isFiltersViewMode$ = this.filtersService.listenFiltersViewMode$().pipe(shareReplay());

  public fields$: Observable<SearchField[]> = this.filtersService.listenFiltersList$().pipe(
    debounceTime(200),
    tap(fields => {
      if (fields.length === 0 && this.form) {
        this.form.reset();
      }

      this.form = SearchService.toFormGroup(fields, this.form);
    }),
    shareReplay()
  );

  public fieldsWhoHas$: Observable<SearchField[]> = this.fields$.pipe(
    map(fields => fields.filter(field => field.whoHasFlag)),
    shareReplay()
  );

  public fieldsWhoCan$: Observable<SearchField[]> = this.fields$.pipe(
    map(fields => fields.filter(field => !field.whoHasFlag)),
    shareReplay()
  );

  public form: FormGroup;

  public readonly WhoCanWhoHas = WhoCanWhoHas;

  constructor(
    private dataStorageTreeService: DataTreeStorageService,
    private dialog: MatDialog,
    private filtersService: FiltersService,
    private tabsSearchService: TabsSearchService
  ) {}

  // DON"T DO: Never enable track by using trackByKey, it causes problem while removing item
  public trackByKey(item) {
    return item.key;
  }

  public onDeleteField(field: any) {
    console.debug('SearchComponent::onDeleteField');
    this.dataStorageTreeService.updateNode(field, 'filter', false);
  }

  public doSearch() {
    console.debug('SearchComponent::doSearch');
    const critieria = this.filtersService.filtersList.filter(field => !!field.value);

    if (critieria && critieria.length > 0) {
      // Always update the bookmark even the criteria list is empty.
      // @todo It seems it doesn't update bookmark for empty criterias anymore. Does it?
      // this.bookmarkService.onSearchCreateOrModifyBookmark(this.filtersService.filtersList);
      this.tabsSearchService.setStartSearch(true);
    }
  }

  public openConfirmationDialog() {
    console.debug('SearchComponent::openConfirmationDialog ::for Reset ');
    this.confirmActionViaDialog('Are you sure you want to reset ?', () => {
      // Reset All filters
      this.form.reset();
    });
  }

  public onResetContractualEligibilityFilters() {
    this.confirmActionViaDialog('Are you sure you want to reset Contractual Eligibility Filters ?', () => {
      for (const name in this.form.controls) {
        // Reset 'WhoCan' filters
        if (SearchService.testFieldNameByWhoCanFlag(name)) {
          this.form.controls[name].reset();
        }
      }
    });
  }

  public onResetActualPostingsFilters() {
    this.confirmActionViaDialog('Are you sure you want to reset Actual Postings Filters ?', () => {
      for (const name in this.form.controls) {
        // Reset 'WhoHas' filters
        if (SearchService.testFieldNameByWhoHasFlag(name)) {
          this.form.controls[name].reset();
        }
      }
    });
  }

  private confirmActionViaDialog(message: string, callback: () => void) {
    this.dialog
      .open(ConfirmationDialogComponent, {
        data: { confirmationMessage: message },
        disableClose: false
      })
      .afterClosed()
      .pipe(filter(result => !!result))
      .subscribe(() => callback());
  }
}
