import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { RatingRankingModel } from '@aqua/components/dropdown-range';
import { Agreement, RatingRanking, SearchBookmarkRequest, UserDataset } from '@aqua/filters/models';
import { SearchResultDataSetBookmark } from '@aqua/filters/models/search-bookmark-model';
import { SearchField } from '@aqua/filters/models/search-field';
import { FilterCancelService, FiltersUrlConfig } from '@aqua/filters/services';
import { VizNotificationService } from '@aqua/services';
import { LocalAtmosphereHandlerService } from '@aqua/services/local-atmosphere-handler.service';
import { AuthenticationService } from '@citi-icg-163206/frm-framework-npm-commons';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { distinctUntilChanged, finalize, map, publishReplay, refCount, share, takeUntil } from 'rxjs/operators';

@Injectable()
export class SearchService {
  public static addOrReplaceControl(form: FormGroup, name: string, value: any) {
    if (!!form.get(name)) {
      console.debug('SearchService::addOrReplaceControl::: Setting existing control::', name, form.get(name));
      // form.setControl(name, new FormControl(value))
      form.removeControl(name);
      // form.get(name).setValue(value);
      form.addControl(name, new FormControl(value));
    } else {
      console.debug('SearchService::addOrReplaceControl::: Adding existing control::', name, form.get(name));
      form.addControl(name, new FormControl(value));
    }
  }

  public static toFormGroup(fields: SearchField[], form: FormGroup) {
    console.debug('SearchService::toFormGroup:::...');
    if (!form) {
      const group: any = {};
      console.debug('SearchService::toFormGroup::: Adding New Form Controls again.');
      fields.forEach(field => {
        group[field.fieldName + '_' + field.key + '_' + field.whoHasFlag] = new FormControl(field.value);
        console.debug('#### SearchService::toFormGroup : other ::' + field.fieldName + '-' + field.key);
      });
      return new FormGroup(group);
    }

    // This include exclude will be removed, when include exclude component updated
    Object.keys(form.controls).forEach(key => {
      const item = fields.find((f: SearchField) => {
        return key === f.fieldName + '_' + f.key + '_' + f.whoHasFlag;
      });

      if (!item) {
        form.removeControl(key);
        console.debug('SearchService::toFormGroup::Not found removing control named [' + key + '] = ', item);
      }
    });
    fields.forEach(field => {
      SearchService.addOrReplaceControl(form, field.fieldName + '_' + field.key + '_' + field.whoHasFlag, field.value);
    });

    return form;
  }

  /**
   * Field name is based on pattern {fieldName}_{key}_{whoHasFlag(0|1)} (defined by this.toFormGroup()).
   */
  public static testFieldNameByWhoCanFlag(fieldName: string) {
    // return /_0$/.test(fieldName);
    return fieldName.endsWith('_0');
  }

  /**
   * Field name is based on pattern {fieldName}_{key}_{whoHasFlag(0|1)} (defined by this.toFormGroup()).
   */
  public static testFieldNameByWhoHasFlag(fieldName: string) {
    // return /_1$/.test(fieldName);
    return fieldName.endsWith('_1');
  }
  private userId: string;
  private refDataCallCount: number = 0;
  private searchResultChange: BehaviorSubject<Agreement[]> = new BehaviorSubject(null);
  private searchStarted: BehaviorSubject<boolean> = new BehaviorSubject(false);
  private filterFlagChanged: BehaviorSubject<boolean> = new BehaviorSubject(false);

  constructor(
    private http: HttpClient,
    private urlConfig: FiltersUrlConfig,
    private vizNotification: VizNotificationService,
    private localAtmosphereHandlerService: LocalAtmosphereHandlerService,
    private filterCancelService: FilterCancelService,
    private authenticationService: AuthenticationService
  ) {
    this.authenticationService.subscribeUserDetails().subscribe(user => {
      this.userId = user.soeid;
    });
    console.debug('SearchService::constructor:: Loading Search Service ..................................');
  }

  public getReferenceData(field: SearchField): Observable<any> {
    console.debug('SearchService::getReferenceData ' + this.refDataCallCount++);
    const requestUrl: string = this.urlConfig.EP_GET_REFERENCE_DATA + field.key;
    console.debug('SearchService::getReferenceData' + requestUrl);
    return this.http.get(requestUrl).pipe(
      publishReplay(1),
      refCount(),
      share()
    );
  }

  public getTypeAheadData(field: SearchField, valueLike: string): Observable<any> {
    const requestUrl: string = this.urlConfig.EP_GET_TYPEAHEAD_DATA + field.key + '/' + valueLike;
    console.debug('SearchService::getTypeAheadData' + requestUrl);
    if (valueLike) {
      return this.http.get(requestUrl).pipe(
        publishReplay(1),
        refCount()
      );
    }
    return of([]);
  }

  public getTypeAheadDataByPastedValue(field: SearchField, valueLike: string[]): Observable<any> {
    const requestUrl: string = this.urlConfig.EP_GET_TYPEAHEAD_DATA_BY_PASTED_VALUES + field.key;
    console.debug('SearchService::getTypeAheadDataByPastedValue::' + requestUrl);
    if (valueLike && valueLike.length > 0) {
      return this.http.post(requestUrl, valueLike);
    }
  }

  public lookupCollateralType(criteria) {
    console.debug('SearchService::searchCriteria');
    this.searchStarted.next(true);
    return this.http.post(this.urlConfig.EP_SEARCH_COLLATERAL_TYPE, { userId: this.userId, criteria }).pipe(
      takeUntil(this.filterCancelService.getSubject()),
      distinctUntilChanged(),
      finalize(() => this.searchStarted.next(false))
    );
  }

  public exportSearchResult(source: string, criteria: SearchField[], agreementKeys: number[]): Observable<any> {
    console.debug('SearchService::exportSearchResult');
    return this.http
      .post(this.urlConfig.EP_RESULT_EXPORT, { source, criteria, agreementKeys }, { responseType: 'blob' })
      .pipe(takeUntil(this.filterCancelService.getSubject()));
  }

  public getCollateralTypeLookupColums() {
    const requestUrl: string = this.urlConfig.EP_SEARCH_COLLATERAL_TYPE;
    console.debug('SearchService::getCollateralTypeLookupColums' + requestUrl);
    return this.http.get(requestUrl).pipe(
      publishReplay(1),
      refCount(),
      share()
    );
  }

  public clearSearchResult(): void {
    this.setSearchResult(null);
  }

  public setSearchResult(newSearchResult) {
    this.searchResultChange.next(newSearchResult);
  }

  public searchResultChangeNotification(): Observable<any[]> {
    return this.searchResultChange.asObservable();
  }

  public get searchingStatus$(): Observable<boolean> {
    return this.searchStarted.asObservable();
  }

  // ============= used in integration ==========
  // Gets the datasetId given the soeid and datasetTypeName
  public getDatasetId(soeid: string, datasetTypeName: string): Observable<any> {
    const requestUrl = this.urlConfig.EP_FINDER_DATASETID;
    console.debug('BookmarkService:: getDatasetId' + requestUrl);
    return this.http.post(requestUrl, { soeid, datasetTypeName });
  }

  public getUserDataset(): Observable<UserDataset[]> {
    const requestUrl: string = this.urlConfig.EP_GET_USER_DATASET;
    console.debug('BookmarkService:: getDatasetId' + requestUrl);
    return this.http.get(requestUrl).pipe(map((data: UserDataset[]) => data));
  }

  // -------------------------------------------------------------------------------------
  public getTabsData(bookmarkRequest: SearchBookmarkRequest): Observable<SearchResultDataSetBookmark | any> {
    console.debug('SearchPlusBookmarkService::getTabsData::');
    this.searchStarted.next(true);
    bookmarkRequest.atmosphereResourceUuid = this.localAtmosphereHandlerService.getConnectionUuid();
    return this.http.post(this.urlConfig.EP_BOOKMARK_SEARCH_TABS, bookmarkRequest).pipe(
      takeUntil(this.filterCancelService.getSubject()),
      distinctUntilChanged(),
      finalize(() => this.searchStarted.next(false))
    );
    // TODO ^ Finally block will be replaced once we create subscribe functionality.
  }

  public requestDataset(bookmarkRequest: SearchBookmarkRequest): Observable<any> {
    console.debug('SearchPlusBookmarkService::requestDataset::');
    // const url = this.urlConfig.EP_REQUEST_DATASET + '/' + bookmarkId + '/' + type + '/requestDataSet';
    // let params = { "socket": uuid, "soeid": "mk35063" };
    return this.http.post(this.urlConfig.EP_REQUEST_DATASET, bookmarkRequest).pipe(
      finalize(() => this.searchStarted.next(false))
    );

    // TODO ^ Finally block will be replaced once we create subscribe functionality.
  }


  public filterFlagChangeNotification(): Observable<boolean> {
    return this.filterFlagChanged.asObservable();
  }

  public onFilterFlagChange(flag: boolean) {
    console.debug('SearchService::onFilterFlagChange::');
    this.filterFlagChanged.next(flag);
  }

  public getAgreementDetails(agreementKeys: number[]): Observable<Agreement[] | any> {
    console.debug('SearchService::getAgreementDetails');
    return this.http
      .get(this.urlConfig.EP_GET_AGREEMENT_DETAILS + '/' + agreementKeys)
      .pipe(finalize(() => this.searchStarted.next(false)));
  }

  public getAgreementCSADetails(ageementId: number, csaType: string): Observable<Agreement[] | any> {
    console.debug('SearchService::getAgreementDetails');
    const url = this.urlConfig.EP_GET_CSA_TYPE_DETAILS + '/' + ageementId + '/' + csaType;
    return this.http.get(url).pipe(finalize(() => this.searchStarted.next(false)));
  }

  public getRatingRankings(): Observable<RatingRanking[] | RatingRankingModel[] | any> {
    console.debug('SearchService::getResultColumns');
    return this.http.get(this.urlConfig.EP_GET_REFERENCE_RATING_RANKINGS);
  }
}
