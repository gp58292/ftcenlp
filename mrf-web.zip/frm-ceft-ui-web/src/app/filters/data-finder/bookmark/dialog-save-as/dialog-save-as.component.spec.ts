import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { DialogSaveAsComponent } from "./dialog-save-as.component";

describe("DialogSaveAsComponent", () => {
	let component: DialogSaveAsComponent;
	let fixture: ComponentFixture<DialogSaveAsComponent>;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			declarations: [DialogSaveAsComponent]
		}).compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(DialogSaveAsComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});
});
