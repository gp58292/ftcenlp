import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { MatDialog } from '@angular/material';
import { SearchService } from '@aqua/filters/data-finder/search/search.service';
import { Bookmark, SearchField } from '@aqua/filters/models';
import { DataTreeStorageService, FiltersUrlConfig } from '@aqua/filters/services';
import { VizNotificationService } from '@aqua/services';
import { CommonUtils } from '@aqua/util';
import { AuthenticationService } from '@citi-icg-163206/frm-framework-npm-commons';
import * as lodash from 'lodash';
import { BehaviorSubject, Observable } from 'rxjs';
import { distinctUntilChanged, map, mergeMap, shareReplay, take, tap } from 'rxjs/operators';

import { BookmarkRequest } from './bookmark-request.model';
import { ChartConfirmationDialogComponent } from './chart-confirmation-dialog/chart-confirmation-dialog.component';

const defalutSettingsName = 'default';

// TODO: Work in progress to improve API, still all functionality not tested or either not completed.
@Injectable()
export class BookmarkService {
  public get activeBookmark() {
    return this._activeBookmark$.value;
  }
  public bookmarksList: Bookmark[];
  private bookmarkList$: BehaviorSubject<Bookmark[]> = new BehaviorSubject(null);

  private userId: string;
  private userId$ = this.authService.subscribeUserDetails().pipe(
    map(user => user.soeid),
    tap(userId => (this.userId = userId))
  );

  private _selectedBookmarkKey: number;

  // TO DO : If possilbe wrap or move SearFiled inside bookmark model as criteria Will be better while handling
  //  private selectedBookmarkCriteria: SearchField[];

  private _activeBookmark$ = new BehaviorSubject<Bookmark>(undefined);

  constructor(
    private http: HttpClient,
    private urlConfig: FiltersUrlConfig,
    private authService: AuthenticationService,
    private vizNotification: VizNotificationService,
    private dataStorageTreeService: DataTreeStorageService,
    private searchService: SearchService,
    private dialog: MatDialog
  ) {
    this.loadAllBookmarks();
  }

  public get selectedBookmarkKey() {
    return this._selectedBookmarkKey;
  }
  public set selectedBookmarkKey(key: number) {
    this._selectedBookmarkKey = key;
    this.setActiveBookmark(key);
  }

  public activeBookmark$() {
    return this._activeBookmark$.asObservable().pipe(
      distinctUntilChanged(),
      shareReplay(1)
    );
  }

  public setActiveBookmark(bookmarkKey: number) {
    this._activeBookmark$.next(this.bookmarkList$.value.find(bookmark => bookmark.key === bookmarkKey));
  }

  // Load selected bookmark from rest service
  public loadBookmark(id: number) {
    console.debug('BookmarkService:: loadBookmark');
    // this.selectedBookmarkKey = id;
    if (id > 0) {
      this.getBookmark(this.userId, id).subscribe((fields: SearchField[]) => {
        console.debug('BookmarkService:: loadBookmark :: ', fields);
        if (fields) {
          // this.selectedBookmarkCriteria = fields;
          this.dataStorageTreeService.setFiltersBasedOfBookmark(fields);
        }
      });
    }
  }

  // Load all bookmarks
  public loadAllBookmarks(isReloadBookmark: boolean = true): void {
    console.debug('BookmarkService:: loadAllBookmarks::', isReloadBookmark);
    this.getBookmarks().subscribe((bookmarks: Bookmark[]) => {
      console.debug('BookmarkService:: loadAllBookmarks :: this.selectedCriteria', bookmarks);
      this.bookmarksList = bookmarks || [];
      this.informBookmarkListListener();
    });
  }

  // public isCurrentBookmarkModified(data: SearchField[]): boolean {
  //   const props: string[] = ['filtered', 'distinctRequired', 'key', 'filterOnlyFlag'];
  //   const isObjectEqual = lodash.isEqual(
  //     CommonUtils.omitFalsyAndProps(this.selectedBookmarkCriteria || [], props, true),
  //     CommonUtils.omitFalsyAndProps(data, props, true)
  //   );

  //   return !isObjectEqual;
  // }

  // // On search bookmark creation and updation handling
  // public onSearchCreateOrModifyBookmark(data: SearchField[]) {
  //   console.debug('BookmarkService:: createOrModifyBookmark ', this.selectedBookmarkKey, this.bookmarksList);

  //   console.debug(
  //     'BookmarkService:: createOrModifyBookmark ',
  //     this.selectedBookmarkKey,
  //     !this.isAnyBookmarkExist(),
  //     this.isDefaultBookmarkSelected(),
  //     this.isCurrentBookmarkModified(data),
  //     this.isModifiedBookmarkTemporary()
  //   );
  //   const ADD: string = 'add';
  //   const UPDATE: string = 'update';

  //   if (!this.isAnyBookmarkExist() || (!this.isDefaultBookmarkExist() && this.selectedBookmarkKey === -1)) {
  //     const bookmarkRequest: BookmarkRequest = new BookmarkRequest();
  //     bookmarkRequest.bookmarkData = data;
  //     bookmarkRequest.bookmarkName = defalutSettingsName;
  //     bookmarkRequest.userId = this.userId;
  //     // this.wrapperAddBookmark(bookmarkRequest);
  //     this.find(bookmarkRequest, ADD);
  //   } else {
  //     if (this.isDefaultBookmarkSelected() || this.selectedBookmarkKey === -1) {
  //       // As we already checked, current selected bookmark is default, that means we can use same selected bookmark key which is pointing to default
  //       // And Even in selected default case, if bookmark modifed, we want to override it anyway.
  //       const bookmarkRequest: BookmarkRequest = new BookmarkRequest();
  //       bookmarkRequest.bookmarkData = data;
  //       bookmarkRequest.bookmarkId = this.getDefaultBookmarkKey();
  //       bookmarkRequest.isSilent = true;
  //       bookmarkRequest.userId = this.userId;
  //       // this.wrapperUpdateBookmark(bookmarkRequest);
  //       this.find(bookmarkRequest, UPDATE);
  //       this.selectedBookmarkKey = this.getDefaultBookmarkKey();
  //     } else {
  //       // Now we need to check bookmark is modified or not
  //       if (this.isCurrentBookmarkModified(data)) {
  //         // const bookmarkRequest: BookmarkRequest = new BookmarkRequest();
  //         // bookmarkRequest.addSearchCriteria(data);
  //         // bookmarkRequest.bookmarkId = this.getDefaultBookmarkKey();
  //         // bookmarkRequest.isSilent = true;
  //         // this.wrapperUpdateBookmark(bookmarkRequest);
  //         // this.selectedBookmarkKey = this.getDefaultBookmarkKey();
  //         // Disabling temporary bookmark creation, as voyager integration has problems
  //         // DON"T REMOVE THIS COMMENTED CODE
  //         // If modifed bookmark is temporary, then simply update it
  //         if (this.isModifiedBookmarkTemporary()) {
  //           const bookmarkRequest: BookmarkRequest = new BookmarkRequest();
  //           bookmarkRequest.bookmarkData = data;
  //           bookmarkRequest.bookmarkId = this.selectedBookmarkKey;
  //           bookmarkRequest.isSilent = true;
  //           bookmarkRequest.userId = this.userId;
  //           // this.wrapperUpdateBookmark(bookmarkRequest);
  //           this.find(bookmarkRequest, UPDATE);
  //         } else {
  //           const tempBookmark = this.getCorrespondingTempBookmark(this.selectedBookmarkKey);
  //           console.debug('BookmarkService:: createOrModifyBookmark::tempBookmark:: ', tempBookmark);
  //           if (tempBookmark) {
  //             const bookmarkRequest: BookmarkRequest = new BookmarkRequest();
  //             bookmarkRequest.bookmarkData = data;
  //             bookmarkRequest.bookmarkId = tempBookmark.key;
  //             bookmarkRequest.isSilent = true;
  //             bookmarkRequest.userId = this.userId;
  //             // this.wrapperUpdateBookmark(bookmarkRequest);
  //             this.find(bookmarkRequest, UPDATE);
  //             this.updateBookmarkKeyAndNotifyListener(tempBookmark.key);
  //           } else {
  //             // If modified bookmark is not temporary, then create new temporary bookmark.
  //             const bookmark = this.getBookmarkByKey(this.selectedBookmarkKey);
  //             const bookmarkRequest: BookmarkRequest = new BookmarkRequest();
  //             bookmarkRequest.bookmarkData = data;
  //             bookmarkRequest.parentBookmarkId = this.selectedBookmarkKey;
  //             bookmarkRequest.bookmarkName = bookmark.name + '_temp';
  //             bookmarkRequest.userId = this.userId;
  //             // this.wrapperAddBookmark(bookmarkRequest);
  //             this.find(bookmarkRequest, ADD);
  //           }
  //         }
  //       } else {
  //         const bookmarkRequest: BookmarkRequest = new BookmarkRequest();
  //         bookmarkRequest.bookmarkData = data;
  //         bookmarkRequest.bookmarkId = this.selectedBookmarkKey;
  //         bookmarkRequest.isSilent = true;
  //         bookmarkRequest.userId = this.userId;
  //         // If bookmark is not modifed, then simply update it
  //         // this.wrapperUpdateBookmark(bookmarkRequest);
  //         this.find(bookmarkRequest, UPDATE);
  //       }
  //     }
  //   }
  // }

  public getBookmarkListNotification(): Observable<Bookmark[]> {
    return this.bookmarkList$.asObservable();
  }

  // =================== apis for add , delete , up date and retrive bookmark starts ===========================

  public updateSelectedBookmarkKey(key: number): void {
    this.selectedBookmarkKey = key;
  }

  public getSelectedBookmarkKey(): number {
    return this.selectedBookmarkKey;
  }

  public getBookmarks() {
    const requestUrl: string = this.urlConfig.EP_BOOKMARK + '/' + this.userId;
    console.debug('BookmarkService:: getBookmarks ' + requestUrl);
    // Boomarks service require to specify userId. Pipe http service to userId$ here.
    return this.userId$.pipe(
      take(1),
      mergeMap(userId => this.http.get(`${this.urlConfig.EP_BOOKMARK}/${userId}`))
    );
  }

  public getBookmark(userId: string, bookmarkId: number): Observable<SearchField[] | any> {
    if (bookmarkId && bookmarkId != null) {
      const requestUrl: string = this.urlConfig.EP_BOOKMARK + '/' + userId + '/' + bookmarkId;
      console.debug('BookmarkService:: getBookmark' + requestUrl);
      return this.http.get(requestUrl).pipe(shareReplay(1));
    }
  }

  public updateBookmark(bookmarkRequest: BookmarkRequest): Observable<Bookmark | any> {
    console.debug('BookmarkService::updateBookmark', bookmarkRequest);
    bookmarkRequest.userId = this.userId;
    return this.http.put(this.urlConfig.EP_BOOKMARK, bookmarkRequest);
  }

  public updateOriginalAndDeleteTemporaryBookmark(bookmarkRequest: BookmarkRequest): void {
    bookmarkRequest.userId = this.userId;
    console.debug('BookmarkService::updateOriginalAndDeleteTemporaryBookmark', bookmarkRequest);
    this.http.put(this.urlConfig.EP_BOOKMARK_REPLACE, bookmarkRequest).subscribe(
      (data: Bookmark) => {
        const newBbookmark = data;
        let bookmarkFound = this.bookmarksList.findIndex((bookmark: Bookmark) => bookmark.key === bookmarkRequest.bookmarkId);
        if (bookmarkFound !== -1) {
          this.bookmarksList.splice(bookmarkFound, 1);
          bookmarkFound = this.bookmarksList.findIndex((bookmark: Bookmark) => bookmark.key === newBbookmark.key);
          this.bookmarksList[bookmarkFound] = newBbookmark;
          this.sortBookmarkList();
          // this.selectedBookmarkCriteria = bookmarkRequest.searchCriteria;
          this.updateBookmarkKeyAndNotifyListener(newBbookmark.key);
        }
        this.vizNotification.showMessage('Successfully updated original bookmark and deleted temporary.');
      },
      error => {
        this.vizNotification.showError('There is error while doing save on temporary functionality, Please contact AQUA CEFT Build Team.');
      }
    );
  }

  public wrapperUpdateBookmark(bookmarkRequest: BookmarkRequest) {
    this.updateBookmark(bookmarkRequest).subscribe((bookmark: Bookmark) => {
      if (bookmark) {
        if (!bookmarkRequest.isSilent) {
          this.vizNotification.showMessage('Successfully saved bookmark.');
        }

        const bookmarkFound = this.bookmarksList.findIndex(bookmarkItem => bookmarkItem.key === bookmarkRequest.bookmarkId);
        if (bookmarkFound !== -1) {
          this.bookmarksList[bookmarkFound] = bookmark;
          this.sortBookmarkList();
          this.updateBookmarkKeyAndNotifyListener(bookmark.key);
          // this.selectedBookmarkCriteria = bookmarkRequest.searchCriteria;
        }
      }
    });
  }

  public updateBookmarkInUI(bookmark: Bookmark) {
    const bookmarkFound = this.bookmarksList.findIndex(bookmarkItem => bookmarkItem.key === bookmark.key);
    if (bookmarkFound !== -1) {
      this.bookmarksList[bookmarkFound] = bookmark;
      this.sortBookmarkList();
      this.updateBookmarkKeyAndNotifyListener(bookmark.key);

      // TODO: Need to find to set selected bookmark crtieria once updation or additing bookmark in CEFT done while searching
      // this.selectedBookmarkCriteria = bookmarkRequest.searchCriteria;
    }
  }

  public addBookmarkInUI(bookmark: Bookmark) {
    if (bookmark) {
      this.vizNotification.showMessage('Successfully created new bookmark.');
    }
    this.bookmarksList.push(bookmark);
    this.sortBookmarkList();
    this.informBookmarkListListener();
    this.updateBookmarkKeyAndNotifyListener(bookmark.key);

    // TODO: Need to find to set selected bookmark crtieria once updation or additing bookmark in CEFT done while searching
    // this.selectedBookmarkCriteria = bookmarkRequest.searchCriteria;
    console.debug('BookmarkService::wrapperAddBookmark', this.bookmarksList);
  }

  public deleteBookmark(bookmarkId: number): void {
    const requestUrl: string = this.urlConfig.EP_BOOKMARK + '/' + this.userId + '/' + bookmarkId;
    console.debug('BookmarkService:: deleteBookmark ' + requestUrl);
    this.http.delete(requestUrl).subscribe((response: boolean | string[]) => {
      console.debug('BookmarkComponent::deleteBookmark::', response);
      if (response && response instanceof Array) {
        this.alertUserIfChartExist(response);
      } else if (response) {
        this.vizNotification.showMessage('Bookmark deleted successfully');
        const isTemporary: boolean = this.isCurrentBookmarkTemporary();
        const bookmark: Bookmark = this.getSelectedBookmark();
        // Remove successfully deleted bookmark from data base along with UI as well
        this.bookmarksList.splice(this.bookmarksList.indexOf(bookmark), 1);
        const tempBookmark: Bookmark = this.getCorrespondingTempBookmark(bookmark.key);
        if (tempBookmark) {
          this.bookmarksList.splice(this.bookmarksList.indexOf(tempBookmark), 1);
        }
        this.sortBookmarkList();
        if (isTemporary) {
          this.updateBookmarkKeyAndNotifyListener(bookmark.parentId);
        } else {
          this.updateBookmarkKeyAndNotifyListener(this.bookmarksList && this.bookmarksList.length > 0 ? this.bookmarksList[0].key : -1);
        }
        this.bookmarkList$.next(this.bookmarksList);
      }
    });
  }

  // Add Bookmark to database
  public addBookmark(bookmarkRequest: BookmarkRequest): Observable<Bookmark | any> {
    bookmarkRequest.userId = this.userId;
    console.debug('BookmarkService::addBookmark', bookmarkRequest);
    return this.http.post(this.urlConfig.EP_BOOKMARK, bookmarkRequest);
  }

  public wrapperAddBookmark(bookmarkRequest: BookmarkRequest) {
    this.addBookmark(bookmarkRequest).subscribe((bookmark: Bookmark) => {
      if (bookmark) {
        if (!bookmarkRequest.isSilent) {
          this.vizNotification.showMessage('Successfully created new bookmark.');
        }
        this.bookmarksList.push(bookmark);
        this.sortBookmarkList();
        if (bookmarkRequest.isReload || this.bookmarksList.length < 2) {
          this.informBookmarkListListener();
        } else {
          this.updateBookmarkKeyAndNotifyListener(bookmark.key);
        }

        // this.selectedBookmarkCriteria = bookmarkRequest.searchCriteria;
        console.debug('BookmarkService::wrapperAddBookmark', this.bookmarksList);
        // this.currentBookmarkData = response.responseData;
      }
    });
  }

  // Delete all temporary bookmark for specific user id
  public deleteAllTemporaryBookmarkByUserId(): Observable<boolean | any> {
    const url: string = this.urlConfig.EP_BOOKMARK_DELETE_ALL_TEMPORARY + '/' + this.userId;
    console.debug('BookmarkService::deleteAllTemporaryBookmarkByUserId::', url);
    return this.http.delete(url);
  }

  public deleteTempBookmarkWrapper(): void {
    this.deleteAllTemporaryBookmarkByUserId().subscribe((response: boolean) => {
      if (response) {
        this.vizNotification.showMessage('All your temporary bookmark removed successfully.');
        const bookmark = this.getSelectedBookmark();
        const isTemporary = this.isCurrentBookmarkTemporary();
        console.debug('BookmarkService::deleteTempBookmarkWrapper::', isTemporary, bookmark.parentId);
        this.removeTemporaryBookmarkFromUI();
        if (isTemporary) {
          this.updateBookmarkKeyAndNotifyListener(bookmark.parentId);
        }
        this.bookmarkList$.next(this.bookmarksList);
      }
    });
  }

  // Delete all temporary bookmark for specific user id
  public restoreAllBookmarkByUserId(): void {
    const url: string = this.urlConfig.EP_BOOKMARK_RESTORE_ALL_DELETED + '/' + this.userId;
    console.debug('BookmarkService::restoreAllBookmarkByUserId::', url);
    this.http.get(url).subscribe((bookmarks: Bookmark[]) => {
      if (bookmarks) {
        this.vizNotification.showMessage('All your recently deleted bookmark restored successfully.');
        this.restoreBookmarkInUI(bookmarks);
      }
    });
  }

  // get default bookmark if selected
  public getDefaultBookmarkIfSelected(): Bookmark {
    const selectedBookmark: Bookmark = this.getSelectedBookmark();
    return selectedBookmark && selectedBookmark.name === defalutSettingsName ? selectedBookmark : undefined;
  }

  public getSelectedBookmark(): Bookmark {
    return this.getBookmarkByKey(this.selectedBookmarkKey);
  }

  public isBookmarkNameExist(name: string): boolean {
    const bookmarkFound: Bookmark = this.bookmarksList.find(bookmark => bookmark.name === name);
    return !!bookmarkFound;
  }

  // Find is any temporary bookmark exist
  public isAnyTemporaryBookmarkExist(): boolean {
    return this.bookmarksList.filter(bookmark => !!bookmark.parentId).length > 0;
  }

  // Find is any temporary bookmark exist
  public isCurrentBookmarkTemporary(): boolean {
    const bookmarkFound: Bookmark = this.getBookmarkByKey(this.selectedBookmarkKey);
    return bookmarkFound && !!bookmarkFound.parentId;
  }

  // =================== apis for add , delete , up date and retrive bookmark Ends ===========================

  // Small interal API to know states of bookmark

  // Get default bookmark id
  // private getDefaultBookmarkKey(): number {
  //   const deafultBookmark: Bookmark = this.bookmarksList.find(bookmark => bookmark.name && bookmark.name === defalutSettingsName);
  //   if (deafultBookmark) {
  //     return deafultBookmark.key;
  //   }
  //   return -1;
  // }

  // Get corresponding temporary bookmark of givin parent id
  private getCorrespondingTempBookmark(key: number): Bookmark {
    const correspondingBookmark: Bookmark = this.bookmarksList.find(bookmark => bookmark.parentId && bookmark.parentId === key);
    return correspondingBookmark;
  }

  // // Find is bookmark list is empty
  // private isAnyBookmarkExist(): boolean {
  //   return this.bookmarksList ? this.bookmarksList.length > 0 : false;
  // }

  // // is Currently default bookmark selected
  // private isModifiedBookmarkTemporary(): boolean {
  //   const selectedBookmark: Bookmark = this.getBookmarkByKey(this.selectedBookmarkKey);
  //   console.debug('BookmarkService::isModifiedBookmarkTemporary', selectedBookmark, selectedBookmark && selectedBookmark.parentId);
  //   return !!(selectedBookmark && selectedBookmark.parentId);
  // }

  // // is Currently default bookmark selected
  // private isDefaultBookmarkSelected(): boolean {
  //   const selectedBookmark: Bookmark = this.getBookmarkByKey(this.selectedBookmarkKey);
  //   return selectedBookmark && selectedBookmark.name === defalutSettingsName;
  // }

  // // is Currently default bookmark selected
  // private isDefaultBookmarkExist(): boolean {
  //   const correspondingBookmark: Bookmark = this.bookmarksList.find(bookmark => bookmark && bookmark.name === defalutSettingsName);
  //   return !!correspondingBookmark;
  // }

  // Get bookmark by bookmark key
  private getBookmarkByKey(id: number): Bookmark {
    return this.bookmarksList.find(bookmark => bookmark.key === id);
  }

  // Sort bookmark list by updated timestamp
  private sortBookmarkList(): void {
    this.bookmarksList = this.bookmarksList.sort((a: Bookmark, b: Bookmark) => {
      if (a.updatedTime === b.updatedTime) {
        return 0;
      } else if (a.updatedTime < b.updatedTime) {
        return 1;
      } else {
        return -1;
      }
    });
  }

  private informBookmarkListListener(): void {
    this.bookmarkList$.next(this.bookmarksList);
    if (this.bookmarksList[0]) {
      this.selectedBookmarkKey = this.bookmarksList[0].key;
    }
  }

  private updateBookmarkKeyAndNotifyListener(key: number): void {
    this.selectedBookmarkKey = key;
  }

  // Remove temporary bookmark from UI
  private removeTemporaryBookmarkFromUI(): void {
    this.bookmarksList = this.bookmarksList.filter((bookmark: Bookmark) => !bookmark.parentId);
    this.sortBookmarkList();
  }

  // Restore bookmark in UI
  private restoreBookmarkInUI(restoreBookmakrs: Bookmark[]): void {
    this.bookmarksList = this.bookmarksList.concat(restoreBookmakrs);
    this.informBookmarkListListener();
  }

  private alertUserIfChartExist(listOfCharts: string[]): void {
    console.debug('BookmarkService::alertUserIfChartExist::', listOfCharts);
    const dialogRef = this.dialog.open(ChartConfirmationDialogComponent, {
      panelClass: 'confirm-dailog-container',
      data: listOfCharts
    });

    dialogRef.afterClosed().subscribe((action: any) => {
      console.debug('BookmarkService::alertUserIfChartExist::Subscribe::', action);
    });
  }
}
