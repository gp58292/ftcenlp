import { ChangeDetectionStrategy, Component, EventEmitter, Output, ViewEncapsulation } from '@angular/core';
import { MatDialog, MatSelectChange } from '@angular/material';
import { ConfirmationDialogComponent } from '@aqua/filters/data-finder/confirmation-dialog/confirmation-dialog.component';
import { SearchService } from '@aqua/filters/data-finder/search/search.service';
import { Bookmark } from '@aqua/filters/models';
import { SearchResultDataSetBookmark } from '@aqua/filters/models/search-bookmark-model';
import { TabsSearchService } from '@aqua/filters/services';
import { FiltersService } from '@aqua/filters/services/filters.service';
import { SearchPlusBookmarkService } from '@aqua/filters/services/search-plus-bookmark.service';
import { DialogSaveAsComponent } from 'app/filters/data-finder/bookmark/dialog-save-as/dialog-save-as.component';
import { DataTreeStorageService } from 'app/filters/services/datatree-storage.service';
import { VizNotificationService } from 'app/services/viz-notification.service';
import { Subject } from 'rxjs';
import { filter, map, shareReplay, takeUntil } from 'rxjs/operators';

import { BookmarkRequest } from './bookmark-request.model';
import { BookmarkService } from './bookmark.service';

@Component({
  selector: 'bookmark-panel',
  templateUrl: './bookmark.component.html',
  styleUrls: ['./bookmark.component.scss'],
  encapsulation: ViewEncapsulation.Emulated,
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class BookmarkComponent {
  public get selectedBookmarkKey() {
    const key: number = this.bookmarkService.getSelectedBookmarkKey();
    if (this._selectedBookmarkKey !== key) {
      // @todo: WHY DO THE GETTER SET A VALUE?!!
      this._selectedBookmarkKey = key;
    }
    return this._selectedBookmarkKey;
  }

  public set selectedBookmarkKey(key: number) {
    this.bookmarkService.updateSelectedBookmarkKey(key);
  }

  @Output() public change = new EventEmitter<any>();

  public readonly bookmarks$ = this.bookmarkService.getBookmarkListNotification().pipe(
    map(bookmarks => {
      if (bookmarks) {
        if (bookmarks.length > 0) {
          console.debug('BookmarkComponent::getBookmarkListNotification : ');

          this.bookmarkService.loadBookmark(this.selectedBookmarkKey !== undefined ? this.selectedBookmarkKey : bookmarks[0].key);
        } else {
          this.clearBookmarkState();
        }

        return bookmarks;
      }

      return [];
    }),
    shareReplay(1)
  );

  private _selectedBookmarkKey: number = -1;
  private alive: Subject<void> = new Subject();

  constructor(
    private bookmarkService: BookmarkService,
    private vizNotification: VizNotificationService,
    private dialog: MatDialog,
    private searchService: SearchService,
    private dataStorageTreeService: DataTreeStorageService,
    private filtersService: FiltersService,
    private searchPlusBookmark: SearchPlusBookmarkService,
    private tabsSearchService: TabsSearchService
  ) {
    console.debug('BookmarkComponent::constructor');
    this.listenSearchResult();
  }

  public openConfirmationDialog() {
    const isTemporary: boolean = this.bookmarkService.isCurrentBookmarkTemporary();
    this.dialog
      .open(ConfirmationDialogComponent, {
        panelClass: 'confirm-dailog-container',
        data: {
          confirmationMessage: isTemporary
            ? 'Are you sure you want to delete temporary and load original bookmark?'
            : 'Are you sure you want to delete bookmark?'
        },
        disableClose: false
      })
      .afterClosed()
      .subscribe(result => {
        if (result) {
          // do confirmation actions
          if (this.selectedBookmarkKey !== -1) {
            this.deleteBookmark(this.selectedBookmarkKey);
          } else {
            this.vizNotification.showError('Unable to delete bookmark as no bookmark is selected');
          }
        }
      });
  }

  public onBookmarkChange(matSelectChange: MatSelectChange) {
    console.debug('BookmarkComponent::onSearchCriteriaChange : ' + matSelectChange.value);
    this.searchService.clearSearchResult();
    // this.selectedBookmarkKey = matSelectChange.value;
    this.bookmarkService.loadBookmark(this.selectedBookmarkKey);
    this.change.emit(matSelectChange.value);
  }

  public clearBookmarkState() {
    console.debug('BookmarkComponent::onSearchCriteriaChange : ');
    this.dataStorageTreeService.clearAllFilters();
    this.searchService.clearSearchResult();
    this.selectedBookmarkKey = -1;
    this.bookmarkService.loadBookmark(this.selectedBookmarkKey);
  }

  public onNewBookmark() {
    console.debug('BookmarkComponent::onNewBookmark');
    this.clearBookmarkState();
    this.selectedBookmarkKey = -1;
  }

  public deleteBookmark(id: number) {
    console.debug('BookmarkComponent::deleteBookmark');
    this.bookmarkService.deleteBookmark(id);
  }

  public onSaveAs(title?: string, newBookmarkName?: string, isDefault: boolean = false) {
    console.debug('BookmarkComponent::onSaveAs');

    const dialogRef = this.dialog.open(DialogSaveAsComponent, {
      panelClass: 'confirm-dailog-container',
      data: {
        name: '',
        bookmarkName: newBookmarkName,
        type: title ? title : 'Save Bookmark As'
      }
    });

    dialogRef.afterClosed().subscribe((bookmarkName: string) => {
      console.debug(
        'BookmarkComponent::onSaveAs::The dialog was closed, user has enter criteriaName as :' + bookmarkName,
        this.bookmarkService.isBookmarkNameExist(bookmarkName)
      );
      if (bookmarkName) {
        bookmarkName = bookmarkName.trim();
        if (bookmarkName !== '') {
          if (this.bookmarkService.isBookmarkNameExist(bookmarkName)) {
            this.vizNotification.showError('Such Bookmark name is already exists, please choose another name');
          } else {
            console.debug(
              'BookmarkComponent::onSaveAs::The dialog was closed, user has enter criteriaName as :',
              bookmarkName,
              this.bookmarkService.isBookmarkNameExist(bookmarkName)
            );
            if (!isDefault) {
              const bookmarkRequest: BookmarkRequest = new BookmarkRequest();
              bookmarkRequest.bookmarkData = this.filtersService.filtersList;
              bookmarkRequest.bookmarkName = bookmarkName;

              this.bookmarkService.wrapperAddBookmark(bookmarkRequest);
            } else {
              const bookmarkRequest: BookmarkRequest = new BookmarkRequest();
              bookmarkRequest.bookmarkData = this.filtersService.filtersList;
              bookmarkRequest.bookmarkId = this.selectedBookmarkKey;
              bookmarkRequest.bookmarkName = bookmarkName;
              bookmarkRequest.isReload = true;
              this.bookmarkService.wrapperUpdateBookmark(bookmarkRequest);
            }
          }
        } else {
          this.vizNotification.showError('Bookmark name can not be blank');
        }
      }
    });
  }

  public onSave() {
    const bookmark: Bookmark = this.bookmarkService.getDefaultBookmarkIfSelected();

    console.debug('BookmarkComponent::onSave', bookmark, this.selectedBookmarkKey, this.bookmarkService.isCurrentBookmarkTemporary());
    if (bookmark) {
      this.onSaveAs('Save Bookmark', bookmark.name, true); // Show bookmark dialog so user can enter a name
    } else if (this.selectedBookmarkKey === -1) {
      this.onSaveAs('Save Bookmark', ''); // Show bookmark dialog so user can enter a name
    } else if (this.bookmarkService.isCurrentBookmarkTemporary()) {
      // TODO :: Write confirmation dialog before replacing original with temporary

      const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
        panelClass: 'confirm-dailog-container',
        data: { confirmationMessage: 'Do you want to override original version and delete temporary bookmark' },
        disableClose: false
      });

      dialogRef.afterClosed().subscribe((result: any) => {
        // console.debug("BookmarkComponent::onSave:: Bookmark Replace::", result);
        if (result) {
          const bookmarkRequest: BookmarkRequest = new BookmarkRequest();
          bookmarkRequest.bookmarkData = this.filtersService.filtersList;
          bookmarkRequest.bookmarkId = this.selectedBookmarkKey;
          this.bookmarkService.updateOriginalAndDeleteTemporaryBookmark(bookmarkRequest);
        }
      });
    } else {
      const bookmarkRequest: BookmarkRequest = new BookmarkRequest();
      bookmarkRequest.bookmarkData = this.filtersService.filtersList;
      bookmarkRequest.bookmarkId = this.selectedBookmarkKey;

      this.bookmarkService.wrapperUpdateBookmark(bookmarkRequest);
    }
  }

  // Delete temporary bookmarks
  public deleteTemporary(): void {
    console.debug('BookmarkComponent::deleteTemporary::');
    if (this.bookmarkService.isAnyTemporaryBookmarkExist()) {
      this.dialog
        .open(ConfirmationDialogComponent, {
          panelClass: 'confirm-dailog-container',
          data: {
            confirmationMessage: 'Do you really want to delete all temporary bookmarks?'
          },
          disableClose: false
        })
        .afterClosed()
        .subscribe(result => {
          if (result) {
            this.bookmarkService.deleteTempBookmarkWrapper();
          }
        });
    } else {
      this.vizNotification.showError('No temporary bookmarks available to delete');
    }
  }

  // Restore temporary bookmarks
  public restoreTemporary(): void {
    console.debug('BookmarkComponent::restoreTemporary::');
    this.bookmarkService.restoreAllBookmarkByUserId();
  }

  public ngOnDestroy() {
    this.alive.next();
    this.alive.complete();
    this.alive.unsubscribe();
  }

  private listenSearchResult(): void {
    this.searchPlusBookmark.searchInitiateObervable$
      .pipe(
        filter((searchResult: any) => this.tabsSearchService.isFirstTabActive), // Only listen on first tab where bookmark available
        takeUntil(this.alive)
      )
      .subscribe((searchResult: SearchResultDataSetBookmark) => {
        console.debug('BookmarkComponent::listenSearchResult::', searchResult);
        if (searchResult && searchResult.bookmarkWithStatus) {
          this.vizNotification.showMessage('Search fetched successfully');
          if (searchResult.bookmarkWithStatus.bookmarkStatus === 'SAVED') {
            this.bookmarkService.addBookmarkInUI(searchResult.bookmarkWithStatus.bookmark);
          } else {
            this.bookmarkService.updateBookmarkInUI(searchResult.bookmarkWithStatus.bookmark);
          }
        }
      });
  }
}
