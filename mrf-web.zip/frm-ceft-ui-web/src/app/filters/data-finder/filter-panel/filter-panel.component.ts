import { Component, OnInit, ViewChild } from '@angular/core';
import { SearchService } from '@aqua/filters/data-finder/search/search.service';
import { UserDataset } from '@aqua/filters/models';
import { FilterCancelService, FiltersService } from '@aqua/filters/services';
import { SearchPlusBookmarkService } from '@aqua/filters/services/search-plus-bookmark.service';
import { CeftDataSetStatus } from '@aqua/models';
import { FrmCommunicationHandlerService } from '@aqua/services/frm-communication-handler.service';
import { Subject } from 'rxjs';
import { finalize, map, shareReplay, takeUntil } from 'rxjs/operators';

import { SearchComponent } from '../search/search.component';

@Component({
  selector: 'filter-panel',
  templateUrl: './filter-panel.component.html',
  styleUrls: ['./filter-panel.component.scss']
})
export class FilterPanelComponent implements OnInit {
  public resultsExpanded: boolean = false;
  public filtersExpanded: boolean = true;
  public resultSetCount = 0;

  public cobDate: string | Date;
  public isFiltersViewMode$ = this.filtersService.listenFiltersViewMode$().pipe(shareReplay());
  public hasFilters$ = this.filtersService.listenFiltersList$().pipe(
    map(filtersList => filtersList.length > 0),
    shareReplay()
  );

  public userDatasets: UserDataset[] = [];
  public userDatasetsSrc: UserDataset[] = [];
  public isFiltered: boolean = false;
  public isLoadingDataSets: boolean = false;
  @ViewChild('aquaSearch') private aquaSearchRef: SearchComponent;
  private alive: Subject<void> = new Subject();

  // -------------------------------------------------------------------------------------------------------------------
  constructor(
    private searchService: SearchService,
    private filterCancelService: FilterCancelService,
    private filtersService: FiltersService,
    private searchPlusBookmarkService: SearchPlusBookmarkService,
    private frmCommunicationHandlerService: FrmCommunicationHandlerService
  ) {
    console.debug('FilterPanelComponent::constructor');
  }

  public ngOnInit() {
    console.debug('FilterPanelComponent::ngOnInit');
    this.resultChangeListener();
    this.filterFlagChangeListener();
  }

  public ngOnDestroy() {
    this.alive.next();
    this.alive.complete();
    this.alive.unsubscribe();
  }

  public onChangeBookmark() {
    this.switchEditMode(false);
  }

  public pullDataSetId(): void {
    console.debug('FilterPanelComponent::pullDataSetId::');
    this.userDatasets = [];
    this.configureVoyagerNavigationUrl();
  }

  public onClickSearch() {
    this.filtersService.setFiltersViewMode(true);
    this.resultsExpanded = true;
    this.aquaSearchRef.doSearch();
  }

  public onClickReset() {
    this.aquaSearchRef.openConfirmationDialog();
  }

  public onClickEditFilter() {
    this.switchEditMode();
  }

  public onVoyagerNavigate(event, datasets) {
    if (datasets.length > 4) {
      event.stopPropagation();
      return;
    } else if (datasets.length === 0) {
      return;
    }

    const TEMP_CONST_VOYAGER_CLIENT_NAME = 'frm-data-exp-client';
    const TEMP_CONST_PORTAL_CLIENT_NAME = 'frm-portal-client';
    const TEMP_CONST_VOYAGER_NAME_IN_PORTAL_APP = 'data_exp';
    const TEMP_CONST_CEFT_DATAPROVIDER_ID = 'CEFT_SPROC';

    const voyagerNavigationPayload = JSON.stringify(
      datasets.map(dataset => ({
        datasetId: `ceft_${dataset.value.bookmarkId}_${dataset.value.shortName}`,
        datasetProvider: TEMP_CONST_CEFT_DATAPROVIDER_ID
      }))
    );

    // Check if the application is running in a standalone mode.
    // @todo Postponed navigation.
    // if (window.parent === window) {
    //   // Temp stub.
    //   const VOYAGER_URL = 'VOYAGER_URL';
    //   const httpParams = new HttpParams({ fromObject: { 'frm-datasets': voyagerNavigationPayload } });
    //   window.open(`${VOYAGER_URL}?${httpParams.toString()}`, '_blank');
    //   return;
    // }

    // Ask Portal to mount Voyager Application.
    this.frmCommunicationHandlerService.emit({
      destinationApplicationId: TEMP_CONST_PORTAL_CLIENT_NAME,
      command: 'navigate',
      payload: `appId=${TEMP_CONST_VOYAGER_NAME_IN_PORTAL_APP}`
    });

    // Ask Voyager Application to open the dataset.
    this.frmCommunicationHandlerService.emit({
      destinationApplicationId: TEMP_CONST_VOYAGER_CLIENT_NAME,
      command: 'openDataset',
      payload: voyagerNavigationPayload
    });
  }

  private switchEditMode(cancelCurrentSearch = true) {
    this.filtersService.setFiltersViewMode(false);
    this.filtersExpanded = true;
    this.resultsExpanded = false;
    if (cancelCurrentSearch) {
      this.filterCancelService.cancelSubject();
    }
  }

  private resultChangeListener(): void {
    this.searchPlusBookmarkService.searchResultDataReadyObervable$.pipe(takeUntil(this.alive)).subscribe((result: CeftDataSetStatus) => {
      console.debug('FilterPanelComponent::resultChangeListener::Got new result::', result);
      if (result) {
        this.cobDate = 'NA';
        this.resultSetCount = result.total ? result.total : 0;
        this.userDatasets = [];
      }
      // Configure the new Voyager links
    });
  }

  private filterFlagChangeListener(): void {
    this.searchService
      .filterFlagChangeNotification()
      .pipe(takeUntil(this.alive))
      .subscribe(flag => {
        this.isFiltered = flag;
        if (this.userDatasetsSrc) {
          if (flag) {
            this.userDatasets = this.userDatasetsSrc.filter(tab => {
              console.debug('SearchResultComponent::listenResultDataChange::If' + tab.shortName);
              const name = tab.shortName + '';
              return name !== 'curr_post';
            });
          } else {
            this.userDatasets = this.userDatasetsSrc.filter(tab => {
              console.debug('SearchResultComponent::listenResultDataChange::else::' + tab.shortName);
              const name = tab.shortName + '';
              return name !== 'curr_post_filtered';
            });
          }
        }
      });
  }

  private configureVoyagerNavigationUrl() {
    console.debug('FilterPanelComponent::configureVoyagerNavigationUrl');
    this.userDatasets = [];
    this.isLoadingDataSets = true;
    this.searchService
      .getUserDataset()
      .pipe(
        takeUntil(this.alive),
        finalize(() => (this.isLoadingDataSets = false))
      )
      .subscribe(userDatasets => {
        if (userDatasets) {
          this.userDatasetsSrc = userDatasets;
          this.userDatasets = this.userDatasetsSrc;
          if (this.isFiltered) {
            this.userDatasets = this.userDatasetsSrc.filter(tab => {
              console.debug('if' + tab.shortName);
              const name = tab.shortName + '';
              return name !== 'curr_post';
            });
          } else {
            this.userDatasets = this.userDatasetsSrc.filter(tab => {
              console.debug('else::' + tab.shortName);
              const name = tab.shortName + '';
              return name !== 'curr_post_filtered';
            });
          }
        }
      });
  }
}
