export interface AgreementOptimalRank {
  agreementKey: number;
  optimalRank: string;
}
