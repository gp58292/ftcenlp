export enum FieldNames {
	AGREEMENT_ID = "agreement_id",
	AGREEMENT_KEY = "agreement_key",
	ID = 'key',
	CHARTFLAG = 'chartFlag',
	DELETE = 'delete',
	DATE = 'updatedTime',
}
