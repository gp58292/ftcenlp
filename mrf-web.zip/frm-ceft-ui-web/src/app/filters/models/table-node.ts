import { SearchField } from "@aqua/filters/models/search-field";

export interface TableNode {
	name: string;
	children: SearchField[];
}
