import { List } from 'lodash';

export interface SearchResultModel {
  // I have no idea what the listOfRecords is. Search service still hasn't deployed. Just a blind attempt to fix TS error.
  // It's dynamic columns with dynamic row
  listOfRecords?: List<Map<string, string | number | Date>>; // result of tab whcih include all columns and rows

  cobDate: string | Date; // Current search COB date, mostly latest cob date we get
  count: number; // total number record for that search and tab
}
