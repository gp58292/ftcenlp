export class Bookmark {
	public key: number;
	public name: string;
	public userId: string;
	public type: string;
	public criteria: string;
	public updatedTime: Date;
	public parentId: number;
	public chartFlag:number;
}
