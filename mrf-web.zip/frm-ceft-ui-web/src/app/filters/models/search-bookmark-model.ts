import { CeftDataSetStatus } from '@aqua/models/dataset-status.model';

import { BookmarkWithStatus } from './bookmark-with-status.model';
import { SearchResultModel } from './search-result.model';

export interface SearchResultDataSetBookmark {
  dataSetStatus: CeftDataSetStatus;
  searchResult: SearchResultModel;
  bookmarkWithStatus: BookmarkWithStatus;
}
