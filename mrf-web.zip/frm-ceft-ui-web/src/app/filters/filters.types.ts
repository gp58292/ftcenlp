export interface AttributeNode {
  name: string,
  children?: AttributeNode[],
}

export type AttributesTree = AttributeNode[];

export enum AttributesViewMode { FLAT, GROUP }

export enum WhoCanWhoHas {
  // Contractual Eligibility.
  CAN,

  // Actual Postings.
  HAS
}
