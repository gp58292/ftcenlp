import { Injectable } from '@angular/core';
import { CeftDataSetMessage, CeftDataSetStatus, DataStatus, TabsInfo } from '@aqua/models';
import { LocalAtmosphereHandlerService } from '@aqua/services/local-atmosphere-handler.service';
import { IServerSideGetRowsRequest } from 'ag-grid-community';
import { combineLatest, Observable, of, Subject } from 'rxjs';
import { debounceTime, filter, map, shareReplay, switchMap } from 'rxjs/operators';

import { BookmarkRequest } from '../data-finder/bookmark/bookmark-request.model';
import { BookmarkService } from '../data-finder/bookmark/bookmark.service';
import { SearchService } from '../data-finder/search/search.service';
import { Bookmark, SearchField } from '../models';
import { SearchResultDataSetBookmark } from '../models/search-bookmark-model';
import { SearchBookmarkRequest } from '../models/search-bookmark-request.model';
import { SearchRequest } from '../models/search-request.model';
import { FiltersService } from './filters.service';
import { GridNotificationService } from './grid-notification.service';
import { TabsSearchService } from './tabs-search.service';

@Injectable()
export class SearchPlusBookmarkService {
  private searchBookmarkRequest: SearchBookmarkRequest = new SearchBookmarkRequest();
  private searchRequest: SearchRequest = new SearchRequest();

  // private _dataResultObervable$: Observable<SearchBookmarkModel>;
  // private _searchBookmarkRequest$ = new BehaviorSubject<SearchBookmarkRequest>(undefined);

  private _searchInitiateObervable$: Observable<SearchResultDataSetBookmark>;
  private _searchResultDataReadyObervable$: Observable<CeftDataSetStatus>; // Subject<CeftDataSetStatus> = new Subject<CeftDataSetStatus>();
  private _searchResultObervable$: Observable<SearchResultDataSetBookmark>; // = new Subject<SearchBookmarkModel>();

  constructor(
    private searchService: SearchService,
    private bookmarkService: BookmarkService,
    private filtersService: FiltersService,
    private localAtmosphereHandlerService: LocalAtmosphereHandlerService,
    private tabsSearchService: TabsSearchService,
    private gridNotificationService: GridNotificationService
  ) {
    console.debug('SearchPlusBookmarkService::constructor');
    this.listenStartSearch();
    this.listenDataReady();
    this.listenData();

    // Below listeners are debugging purpose
    this.listenCriteriaChange();
    this.listenSearchActivity();
    this.listenTabNameActivity();
    this.listenBookmarkActivity();
  }
  // Will listen search initiate result
  public get searchInitiateObervable$(): Observable<SearchResultDataSetBookmark> {
    return this._searchInitiateObervable$.pipe(shareReplay({ refCount: true, bufferSize: 2 }));
  }
  // Will listen data ready event ( notfication may come from web socket)
  public get searchResultDataReadyObervable$(): Observable<CeftDataSetStatus> {
    return this._searchResultDataReadyObervable$.pipe(
      // filter((data: CeftDataSetStatus) => !!data),
      shareReplay({ refCount: true, bufferSize: 2 })
    );
  }
  // Listen actual (may be paged data) data from server
  public get searchResultObervable$(): Observable<SearchResultDataSetBookmark> {
    return this._searchResultObervable$.pipe(shareReplay({ refCount: true, bufferSize: 2 }));
  }

  private listenCriteriaChange(): void {
    // listen current search criteria
    this.filtersService
      .listenFiltersList$()
      .pipe(
        debounceTime(500),
        map((critieria: SearchField[]) => {
          return critieria && critieria.filter(field => !!field.value);
        })
      )
      .subscribe((critieria: SearchField[]) => {
        if (critieria.length > 0) {
          this.searchRequest.searchCriteria = critieria;
        }
      });
  }

  private listenSearchActivity() {
    this.tabsSearchService
      .startSearch$()
      .pipe(filter((isStarted: boolean) => isStarted))
      .subscribe(data => console.debug('SearchPlusBookmarkService::listenSearchActivity::', data));
  }

  private listenTabNameActivity() {
    this.tabsSearchService.activeTabInfo$().subscribe(data => console.debug('SearchPlusBookmarkService::listenTabNameActivity::', data));
  }

  private listenBookmarkActivity() {
    this.bookmarkService.activeBookmark$().subscribe(data => console.debug('SearchPlusBookmarkService::listenBookmarkActivity::', data));
  }

  private listenStartSearch(): void {
    this._searchInitiateObervable$ = combineLatest(this.tabsSearchService.startSearch$(), this.tabsSearchService.activeTabInfo$()).pipe(
      shareReplay(1),
      filter(([isStarted, activeTabInfo]: any) => isStarted),
      map(([isStarted, activeTabInfo]: any) => [isStarted, activeTabInfo, this.filtersService.filterListWithValues]),
      filter(([isStarted, activeTabInfo, criteria]: any) => criteria.length > 0),
      switchMap(([isStarted, activeTabInfo, criteria]: [boolean, TabsInfo, SearchField[]]) => {
        const activeBookmark: Bookmark = this.bookmarkService.activeBookmark;
        console.debug(
          'SearchPlusBookmarkService::listenStartSearch::switchMap',
          isStarted,
          activeTabInfo.tabId,
          activeBookmark,
          criteria,
          this.searchBookmarkRequest
        );

        const uuid: string = this.localAtmosphereHandlerService.getConnectionUuid();
        const searchBookmarkRequest: SearchBookmarkRequest = new SearchBookmarkRequest();
        // Update data set type before requesting data
        searchBookmarkRequest.searchRequest = new SearchRequest();
        searchBookmarkRequest.searchRequest.datasetType = activeTabInfo.tabId;
        searchBookmarkRequest.searchRequest.searchCriteria = criteria;
        const bookmarkRequest: BookmarkRequest = new BookmarkRequest();
        bookmarkRequest.bookmarkData = criteria;

        if (activeBookmark) {
          bookmarkRequest.bookmarkId = activeBookmark.key;
          bookmarkRequest.parentBookmarkId = activeBookmark.parentId;
        }
        searchBookmarkRequest.bookmarkRequest = bookmarkRequest;
        searchBookmarkRequest.atmosphereResourceUuid = uuid;

        console.debug('SearchPlusBookmarkService::listenStartSearch::switchMap', searchBookmarkRequest);

        return this.searchService.requestDataset(searchBookmarkRequest);
      }),
      shareReplay({ refCount: true, bufferSize: 3 })
    );
  }
  private listenDataReady(): void {
    this._searchResultDataReadyObervable$ = this._searchInitiateObervable$.pipe(
      switchMap((dataSetReqResponse: SearchResultDataSetBookmark) => {
        console.debug('SearchPlusBookmarkService::listenDataReady::switchMap::', dataSetReqResponse);
        const uuid: string = this.localAtmosphereHandlerService.getConnectionUuid();
        if (dataSetReqResponse.dataSetStatus && dataSetReqResponse.dataSetStatus.ready) {
          return of(dataSetReqResponse.dataSetStatus);
        } else {
          return this.localAtmosphereHandlerService.registerDataRequest(uuid).pipe(
            filter((data: CeftDataSetStatus) => {
              console.debug(
                'SearchPlusBookmarkService::listenDataReady::switchMap::localAtmosphereHandlerService::',
                data,
                data.status === DataStatus.READY
              );
              return data.status === DataStatus.READY;
            })
          );
        }
      })
    );
    // .subscribe((data: CeftDataSetStatus) => this._searchResultDataReadyObervable$.next(data));
  }

  private listenData(): void {
    this._searchResultObervable$ = combineLatest(this.gridNotificationService.rowsParam$, this._searchResultDataReadyObervable$).pipe(
      map(([gridFilter, dataSetReqResponse]: [IServerSideGetRowsRequest, CeftDataSetStatus]) => [
        gridFilter,
        dataSetReqResponse,
        this.bookmarkService.activeBookmark,
        this.tabsSearchService.activeTabInfo
      ]),
      filter(
        ([gridFilter, dataSetReqResponse, activeBookmark, activeTabInfo]: [
          IServerSideGetRowsRequest,
          CeftDataSetStatus,
          Bookmark,
          TabsInfo
        ]) => {
          console.debug(
            'SearchPlusBookmarkService::listenDataReady::switchMap::localAtmosphereHandlerService::',
            !!activeBookmark,
            dataSetReqResponse.dataSet.type,
            dataSetReqResponse
          );
          return !!activeBookmark && activeTabInfo.tabId === dataSetReqResponse.dataSet.type;
        }
      ),
      switchMap(
        ([gridFilter, dataSetReqResponse, activeBookmark, activeTabInfo]: [
          IServerSideGetRowsRequest,
          CeftDataSetStatus,
          Bookmark,
          TabsInfo
        ]) => {
          console.debug(
            'SearchPlusBookmarkService::listenData::switchMap::',
            gridFilter,
            dataSetReqResponse,
            activeBookmark,
            activeTabInfo
          );

          // Update data set type before requesting data
          const searchRequest = new SearchRequest();
          searchRequest.datasetType = activeTabInfo.tabId;
          const bookmarkRequest: BookmarkRequest = new BookmarkRequest();
          bookmarkRequest.bookmarkId = activeBookmark.key;

          const searchBookmarkRequest: SearchBookmarkRequest = new SearchBookmarkRequest();
          // Tomorrow multiple tabs loaded simultaneously, then set uuid in tabs info
          searchBookmarkRequest.atmosphereResourceUuid = this.localAtmosphereHandlerService.getConnectionUuid();
          searchBookmarkRequest.gridRequest = gridFilter;
          searchBookmarkRequest.bookmarkRequest = bookmarkRequest;
          searchBookmarkRequest.searchRequest = searchRequest;
          console.debug('SearchPlusBookmarkService::listenData::switchMap::', searchBookmarkRequest);

          return this.searchService.getTabsData(searchBookmarkRequest);
        }
      ),
      shareReplay({ refCount: true, bufferSize: 3 })
    );
  }
}
