import { Injectable, OnDestroy } from '@angular/core';
import { TabsInfo } from '@aqua/models';
import { BehaviorSubject, from, Observable, Subject } from 'rxjs';
import { distinct, filter, map, switchMap, takeUntil, toArray } from 'rxjs/operators';
import { SearchResultColumns } from '@aqua/filters/models';
import { FiltersUrlConfig } from './filters-url-config.service';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class SearchResultColumnService implements OnDestroy {
  public searchResultColumns$: BehaviorSubject<SearchResultColumns[]> = new BehaviorSubject([]);

  private alive: Subject<void> = new Subject<void>();

  constructor (private http: HttpClient, private urlConfig: FiltersUrlConfig) {
    console.debug('SearchResultColumnService:: constructor::');
  }

  public ngOnDestroy () {
    this.alive.next();
    this.alive.complete();
    this.alive.unsubscribe();
  }

  public loadResultColumns () {
    console.debug('SearchResultColumnService:: loadResultColumns::');
    const requestUrl: string = this.urlConfig.EP_CACHE_GET_RESULT_COLUMNS;
    this.http.get(requestUrl).subscribe((data: any) => {
      if (data) {
        // this.renderSearchData(response.responseData); TODO need to notify bookmark change by behavior subject and multiple lister
        console.debug('SearchResultColumnService:: loadResultColumns :: ', data);
        this.searchResultColumns$.next(data);
      }
    });
  }

  public listenResultColumns (): Observable<SearchResultColumns[]> {
    console.debug('SearchResultColumnService:: listenResultColumns::');
    return this.searchResultColumns$.pipe(takeUntil(this.alive));
  }

  public getVoyagerTabList (): Observable<string[]> {
    console.debug('SearchResultColumnService:: getVoyagerTabList::');

    return this.listenResultColumns().pipe(
      takeUntil(this.alive),
      switchMap(columns => this.extractVoyagerTabInfo(columns)),
    );
  }

  public getTabList (): Observable<TabsInfo[]> {
    console.debug('SearchResultColumnService:: getTabList::');
    return this.listenResultColumns().pipe(
      takeUntil(this.alive),
      switchMap(searchCol => this.extractTabInfo(searchCol)),
    );
  }

  public getColumnsListByTab (
    tabName: string,
  ): Observable<SearchResultColumns[]> {
    console.debug('SearchResultColumnService:: getVoyagerTabList::');

    return this.listenResultColumns().pipe(
      switchMap((column: SearchResultColumns[]) =>
        from(column).pipe(
          takeUntil(this.alive),
          filter((colum: SearchResultColumns) => colum.tabName === tabName),
          toArray(),
        ),
      ),
    );
  }

  private extractTabInfo (items: SearchResultColumns[]) {
    return from(items).pipe(
      takeUntil(this.alive),
      map(
        (column: SearchResultColumns) =>
          new TabsInfo(column.tabId, column.tabName, column.tabOrder),
      ),
      distinct((tab: TabsInfo) => tab.tabName),
      toArray(),
      map(array => array.sort(TabsInfo.comparator)),
    );
  }

  private extractVoyagerTabInfo (items: SearchResultColumns[]) {
    return from(items).pipe(
      takeUntil(this.alive),
      map((column: SearchResultColumns) => column.tabVoyagerId),
      distinct(),
      toArray(),
    );
  }
}
