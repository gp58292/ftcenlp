import { Injectable } from '@angular/core';
import { IServerSideGetRowsRequest } from 'ag-grid-community';
import { Subject } from 'rxjs';
import { shareReplay } from 'rxjs/operators';

@Injectable({ providedIn: 'root' })
export class GridNotificationService {
  private _rowsParam$ = new Subject<IServerSideGetRowsRequest>();

  public get rowsParam$() {
    return this._rowsParam$.asObservable().pipe(shareReplay(1));
  }

  public updateRowsParam(params: IServerSideGetRowsRequest): void {
    this._rowsParam$.next(params);
  }
}
