import { Injectable } from '@angular/core';
import { TabsInfo } from '@aqua/models';
import { BehaviorSubject } from 'rxjs';
import { shareReplay } from 'rxjs/operators';

@Injectable()
export class TabsSearchService {
  private _firstTab: TabsInfo = new TabsInfo('listed', 'Listed', 0);
  private _activeTabInfo$ = new BehaviorSubject<TabsInfo>(this._firstTab);
  private _startSearch$ = new BehaviorSubject<boolean>(false);

  public get isFirstTabActive() {
    return this._firstTab.equals(this.activeTabInfo);
  }

  public activeTabInfo$() {
    return this._activeTabInfo$.asObservable().pipe(shareReplay(1));
  }

  get activeTabInfo() {
    return this._activeTabInfo$.value;
  }

  public setTabInfo(tabInfo: TabsInfo) {
    this._activeTabInfo$.next(tabInfo);
  }

  public startSearch$() {
    return this._startSearch$.asObservable();
  }

  public setStartSearch(isStarted: boolean) {
    this._startSearch$.next(isStarted);
  }
}
