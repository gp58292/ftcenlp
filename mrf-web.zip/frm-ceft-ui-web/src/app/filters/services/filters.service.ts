import { Injectable } from '@angular/core';
import { SearchField } from '@aqua/filters/models';
import { reject, some } from 'lodash';
import { BehaviorSubject } from 'rxjs';
import { distinctUntilChanged, filter, map, shareReplay } from 'rxjs/operators';

@Injectable()
export class FiltersService {
  private filtersPool$ = new BehaviorSubject<SearchField[]>([]);

  private filtersViewMode$ = new BehaviorSubject<boolean>(false);

  public listenFiltersList$() {
    return this.filtersPool$.asObservable().pipe(distinctUntilChanged());
  }

  public get filtersList() {
    return this.filtersPool$.value;
  }

  public get filterListWithValues() {
    // return this.filtersPool$.pipe(map((filterList:SearchField[])=>filterList.filter((field: SearchField) => !!field.value)),shareReplay(1));
    return this.filtersPool$.value.filter((field: SearchField) => !!field.value);
  }

  public setFiltersList(filters) {
    this.filtersPool$.next(filters);
  }

  public resetFiltersList() {
    this.setFiltersList([]);
  }

  public filterToggle(newFieldIn: SearchField) {
    const fieldsList = this.filtersPool$.value;
    const newFieldsList = some(fieldsList, { key: newFieldIn.key, whoHasFlag: newFieldIn.whoHasFlag })
      ? reject(fieldsList, { key: newFieldIn.key, whoHasFlag: newFieldIn.whoHasFlag })
      : [...fieldsList, newFieldIn];

    this.setFiltersList(newFieldsList);
  }

  public get filtersViewMode() {
    return this.filtersViewMode$.value;
  }

  public setFiltersViewMode(newViewMode: boolean) {
    this.filtersViewMode$.next(newViewMode);
  }

  public listenFiltersViewMode$() {
    return this.filtersViewMode$.asObservable();
  }
}
