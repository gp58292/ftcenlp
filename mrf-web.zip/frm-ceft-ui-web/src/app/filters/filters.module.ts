import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatPaginatorModule, MatSortModule, MatTableModule } from '@angular/material';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { AquaComponentModule } from '@aqua/aqua-component/aqua-component.module';
import { PipeModule } from '@aqua/aqua-component/pipes';
import { PopupModule } from '@aqua/aqua-component/popup';
import { TenorRangeInNotInWrapperModule } from '@aqua/aqua-component/tenor-range-innotin-wrapper';
import { AppPanelLayoutComponent } from '@aqua/filters/data-finder/app-panel-layout/app-panel-layout.component';
import { BookmarkComponent } from '@aqua/filters/data-finder/bookmark/bookmark.component';
import { BookmarkService } from '@aqua/filters/data-finder/bookmark/bookmark.service';
import { DialogSaveAsComponent } from '@aqua/filters/data-finder/bookmark/dialog-save-as/dialog-save-as.component';
import { ConfirmationDialogComponent } from '@aqua/filters/data-finder/confirmation-dialog/confirmation-dialog.component';
import { DataFinderComponent } from '@aqua/filters/data-finder/data-finder.component';
import { FilterPanelComponent } from '@aqua/filters/data-finder/filter-panel/filter-panel.component';
import { DateRangeComponent } from '@aqua/filters/data-finder/search/controls/date-range/date-range.component';
import { DropdownComponent } from '@aqua/filters/data-finder/search/controls/dropdown/dropdown.component';
import { FilterDisplayWrapperComponent } from '@aqua/filters/data-finder/search/controls/filter-display';
import { FilterDisplayComponent } from '@aqua/filters/data-finder/search/controls/filter-display/filter-display.component';
import { FreeFormTextComponent } from '@aqua/filters/data-finder/search/controls/free-form-text/free-form-text.component';
import { IncludeExcludeComponent } from '@aqua/filters/data-finder/search/controls/include-exclude/include-exclude.component';
import { NumberRangeComponent } from '@aqua/filters/data-finder/search/controls/number-range/number-range.component';
import { RatingRankingComponent } from '@aqua/filters/data-finder/search/controls/rating-ranking/rating-ranking.component';
import { TenorRangeComponent } from '@aqua/filters/data-finder/search/controls/tenor-range-wrapper/tenor-range-wrapper.component';
import { TypeAheadComponent } from '@aqua/filters/data-finder/search/controls/type-ahead/type-ahead.component';
import {
  AggrementPopinComponent,
  CsaAgreementDetailsComponent,
  MasterAgreementDetailsComponent
} from '@aqua/filters/data-finder/search/search-result/filter-popin';
import { SearchResultComponent } from '@aqua/filters/data-finder/search/search-result/search-result.component';
import { SearchComponent } from '@aqua/filters/data-finder/search/search.component';
import { SearchService } from '@aqua/filters/data-finder/search/search.service';
import { SettingsSidePanelComponent } from '@aqua/filters/data-finder/settings-side-panel/settings-side-panel.component';
import { SettingsService } from '@aqua/filters/data-finder/settings/settings.service';
import { FilterCancelService, SearchResultColumnService, TabsSearchService } from '@aqua/filters/services';
import { DataTreeStorageService } from '@aqua/filters/services/datatree-storage.service';
import { FiltersUrlConfig } from '@aqua/filters/services/filters-url-config.service';
import { FiltersService } from '@aqua/filters/services/filters.service';
import { MaterialModule } from '@aqua/material.module';

import { ChartConfirmationDialogComponent } from './data-finder/bookmark';
import { CollateralTypeLookupComponent } from './data-finder/search/collateral-type-lookup/collateral-type-lookup.component';
import { MultiIncludeExcludeComponent } from './data-finder/search/controls/multi-include-exclude/multi-include-exclude.component';
import { SearchPlusBookmarkService } from './services/search-plus-bookmark.service';

@NgModule({
  imports: [
    CommonModule,
    MaterialModule,
    FormsModule,
    MatSlideToggleModule,
    MatButtonToggleModule,
    ReactiveFormsModule,
    AquaComponentModule,
    PipeModule,
    MatTableModule,
    MatSortModule,
    MatPaginatorModule,
    PopupModule,
    TenorRangeInNotInWrapperModule
  ],
  entryComponents: [
    DialogSaveAsComponent,
    ConfirmationDialogComponent,
    CollateralTypeLookupComponent,
    AggrementPopinComponent,
    ChartConfirmationDialogComponent
  ],
  declarations: [
    SearchComponent,
    SettingsSidePanelComponent,
    FilterPanelComponent,
    TypeAheadComponent,
    AppPanelLayoutComponent,
    DataFinderComponent,
    DropdownComponent,
    NumberRangeComponent,
    DateRangeComponent,
    FreeFormTextComponent,
    BookmarkComponent,
    IncludeExcludeComponent,
    SearchResultComponent,
    DialogSaveAsComponent,
    ConfirmationDialogComponent,
    FilterDisplayComponent,
    FilterDisplayWrapperComponent,
    CollateralTypeLookupComponent,
    AggrementPopinComponent,
    RatingRankingComponent,
    TenorRangeComponent,
    MasterAgreementDetailsComponent,
    CsaAgreementDetailsComponent,
    MultiIncludeExcludeComponent,
    ChartConfirmationDialogComponent
  ],
  exports: [],
  providers: [
    FiltersUrlConfig,
    BookmarkService,
    SearchResultColumnService,
    SearchService,
    SettingsService,
    DataTreeStorageService,
    FilterCancelService,
    FiltersService,
    SearchPlusBookmarkService,
    TabsSearchService
  ]
})
export class FiltersModule {}
