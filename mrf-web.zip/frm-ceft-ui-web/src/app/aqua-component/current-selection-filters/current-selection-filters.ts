import { Component, Input } from '@angular/core';

@Component({
  selector: 'aqua-current-selection-filters',
  templateUrl: './current-selection-filters.html',
  styleUrls: ['./current-selection-filters.scss'],
})
export class CurrentSelectionFilters {
  @Input('data')
  set currentSelection (data: Map<string, Set<string>>) {
    // Addapt odd Map<Set> construction to the normal collection.
    const filters = [];

    data.forEach((valuesSet, fieldName) => {
      const fieldData: any = { fieldName, values: Array.from(valuesSet) };

      if (fieldData.values.length > 4) {
        fieldData.displayString = `${fieldData.values.slice(0, 4).join('; ')} <b>...</b>`;
        fieldData.tooltipString = fieldData.values.join('; ');
        fieldData.showTooltip = true;
      }
      else {
        fieldData.displayString = fieldData.values.join('; ');
      }

      filters.push(fieldData);
    });

    this.adaptedFilters = filters;
  };

  public adaptedFilters: any;
}
