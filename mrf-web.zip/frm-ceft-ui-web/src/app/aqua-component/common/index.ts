export * from "./ng-model.common";
