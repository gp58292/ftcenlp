import {
	Component,
	ElementRef,
	Input,
	OnDestroy,
	Renderer2
} from "@angular/core";
import { AbstractControl, FormBuilder, FormGroup } from "@angular/forms";

import { FocusMonitor } from "@angular/cdk/a11y";
import { NgModelCommon } from "@aqua/aqua-component/common";
import { RangeValue, TenorRangeModel } from "@aqua/aqua-component/models";

import { DropDownModel } from "@aqua/aqua-component/dropdown-range";

import { TenorRangeValidator } from "@aqua/aqua-component/validations";
import * as lodash from "lodash";
import { debounceTime, distinctUntilChanged, takeUntil } from "rxjs/operators";

@Component({
	// tslint:disable-next-line:component-selector
	selector: "aqua-tenor-range",
	templateUrl: "./tenor-range.html",
	styleUrls: ["./tenor-range.scss"],
	providers: [
		NgModelCommon.CUSTOM_CONTROL_VALUE_ACCESSOR(TenorRange),
		NgModelCommon.CUSTOM_MAT_FORM_FIELD(TenorRange)
	]
})
// tslint:disable-next-line:component-class-suffix
export class TenorRange extends NgModelCommon<TenorRangeModel<number>>
	implements OnDestroy {
	@Input()
	get value(): TenorRangeModel<number> | null {
		// console.debug("numberRange::get Value::["+this.id+"]::",this.tenorRangeFormGroup.value);
		const n: TenorRangeModel<number> = this.tenorRangeFormGroup.value;
		if (n.rangeValue || n.period) {
			return new TenorRangeModel<number>(n.rangeValue, n.period);
		}
		return null;
	}
	set value(tenorRange: TenorRangeModel<number> | null) {
		tenorRange = tenorRange || new TenorRangeModel<number>();
		// console.debug("numberRange::Set Value::["+this.id+"]::",numberRange);
		if (
			(this.value !== tenorRange ||
				this.value.rangeValue !== tenorRange.rangeValue) &&
			!this.checkObjectEqual(this.value, tenorRange)
		) {
			tenorRange = TenorRangeModel.undefineValuesIfNull(tenorRange); // This will remove value if null
			this.errorState = TenorRangeValidator.isValid(tenorRange);
			this.onChangedCallback(tenorRange);
			this.stateChanges && this.stateChanges.next();
		}
	}

	get empty() {
		return (
			!this.value ||
			!this.value.rangeValue ||
			this.value.rangeValue == null ||
			(this.value.rangeValue &&
				!this.value.rangeValue.start &&
				!this.value.rangeValue.end)
		);
	}
	public tenorRangeFormGroup: FormGroup;

	public periodData: DropDownModel[] = [
		new DropDownModel(1, "Years"),
		new DropDownModel(2, "Months"),
		new DropDownModel(3, "Days")
	];

	constructor(
		public fb: FormBuilder,
		private fm: FocusMonitor,
		private elRef: ElementRef,
		private render2: Renderer2
	) {
		super(elRef, render2);
		if (fm && elRef) {
			fm.monitor(elRef.nativeElement, true).subscribe(origin => {
				this.focused = !!origin;
				this.stateChanges.next();
			});
		}
		this.updateControlType("aqua-tenor-range");
		this.tenorRangeFormGroup = this.fb.group({
			rangeValue: new RangeValue<number>(),
			period: this.periodData[0]
		});
		this.tenorRangeFormGroup.valueChanges
			.pipe(
				takeUntil(this.alive),
				debounceTime(300),
				distinctUntilChanged()
			)
			.subscribe(value => {
				this.value = value;
			});
	}

	public writeValue(newValue: TenorRangeModel<number>) {
		console.debug(
			"TenorRange::writeValue::",
			newValue,
			this.tenorRangeFormGroup.value,
			this.checkObjectEqual(this.tenorRangeFormGroup.value, newValue)
		);

		if (newValue == null || newValue === "" || newValue === undefined) {
			const ratingModel = new TenorRangeModel<number>();
			const model: TenorRangeModel<number> = new TenorRangeModel<number>(
				null,
				this.periodData[0]
			);
			// console.debug("TenorRange::writeValue:: Setting value ::", model);
			this.tenorRangeFormGroup.setValue(model);
			this.value = model;
		} else if (
			!this.checkObjectEqual(this.tenorRangeFormGroup.value, newValue)
		) {
			let index = -1;
			this.periodData.forEach((val: DropDownModel, i: number) => {
				if (val.key === newValue.period.key) {
					index = i;
				}
			});

			const model: TenorRangeModel<number> = new TenorRangeModel<number>(
				newValue.rangeValue,
				this.periodData[index]
			);
			// console.debug("TenorRange::writeValue:: Setting value ::", model);
			this.tenorRangeFormGroup.setValue(model);
			this.value = model;
		}
	}

	public getErrorMessage() {
		// console.debug("TenorRangeComponent::getErrorMessage::");
		let msg: string = "";
		const tenorRangeControl: AbstractControl = this.tenorRangeFormGroup.controls.rangeValue;
		switch (true) {
			case tenorRangeControl.hasError("validateTenorRange"):
				msg = "Please enter valid range";
				break;
			default:
				msg = "";
		}
		// console.debug("TenorRangeComponent::getErrorMessage::",msg);
		return msg;
	}

	public isErrorState(): boolean {
		const control: AbstractControl = this.tenorRangeFormGroup.controls.rangeValue;

    // console.debug(
		// 	"TenorRangeComponent::isErrorState::",
		// 	control,
		// 	control && control.invalid && (control.dirty || control.touched)
		// );
		return control && control.invalid && (control.dirty || control.touched);
	}

	// Focus first child input element
	public onContainerClick(event: MouseEvent) {
		const srcElement: HTMLElement = event.srcElement as HTMLElement;

		if ((srcElement as any).name !== "end" && this.isChild(srcElement)) {
			const startInput: HTMLElement = this.elRef.nativeElement.querySelector(
				'[name="start"]'
			);
			startInput.focus();
		}
		super.onContainerClick(event);
	}

	public ngOnDestroy() {
		this.fm.stopMonitoring(this.elRef.nativeElement);
		super.ngOnDestroy();
	}

	private checkObjectEqual(
		source: TenorRangeModel<number>,
		destination: TenorRangeModel<number>
	): boolean {
		let isEqual: boolean = true;
		if (
			(source == null || source === undefined) &&
			(destination != null && destination !== undefined)
		) {
			isEqual = false;
		} else if (
			source != null &&
			source !== undefined &&
			(destination == null || destination === undefined)
		) {
			isEqual = false;
		} else if (!lodash.isEqual(source, destination)) {
			isEqual = false;
		}

		return isEqual;
	}

	private isChild(srcElement: HTMLElement) {
		return srcElement.closest(".period-selector") == null;
	}
}
