import {
	Component,
	ElementRef,
	Input,
	OnDestroy,
	Renderer2
} from "@angular/core";
import { AbstractControl, FormBuilder, FormGroup } from "@angular/forms";

import { FocusMonitor } from "@angular/cdk/a11y";
import { NgModelCommon } from "@aqua/aqua-component/common";
import { RangeWrapperModel } from "@aqua/aqua-component/models/range-wrapper-model";

import * as lodash from "lodash";
import { debounceTime, distinctUntilChanged, takeUntil } from "rxjs/operators";

@Component({
	// tslint:disable-next-line:component-selector
	selector: "aqua-tenor-range-innotin-wrapper",
	templateUrl: "./tenor-range-innotin-wrapper.html",
	styleUrls: ["./tenor-range-innotin-wrapper.scss"],
	providers: [
		NgModelCommon.CUSTOM_CONTROL_VALUE_ACCESSOR(TenorRangeInNotInWrapper),
		NgModelCommon.CUSTOM_MAT_FORM_FIELD(TenorRangeInNotInWrapper)
	]
})
// tslint:disable-next-line:component-class-suffix
export class TenorRangeInNotInWrapper
	extends NgModelCommon<RangeWrapperModel<number>>
	implements OnDestroy {
	@Input()
	get value(): RangeWrapperModel<number> | null {
		// console.debug("TenorRangeInNotInWrapper::get Value::["+this.id+"]::",this.tenorRangeInNotInFormGroup.value);
		const n: RangeWrapperModel<number> = this.tenorRangeInNotInFormGroup.value;
		if (n.inValue || n.notInValue) {
			return new RangeWrapperModel<number>(n.inValue, n.notInValue);
		}
		return null;
	}

	set value(tenorRange: RangeWrapperModel<number> | null) {
		tenorRange = tenorRange || new RangeWrapperModel<number>();
		// console.debug("TenorRangeInNotInWrapper::Set Value::["+this.id+"]::",numberRange);
		if (
			(this.value !== tenorRange ||
				this.value.inValue !== tenorRange.notInValue) &&
			!this.checkObjectEqual(this.value, tenorRange)
		) {
			tenorRange = RangeWrapperModel.undefineValuesIfNull(tenorRange); // This will remove value if null
			this.onChangedCallback(tenorRange);
			this.stateChanges && this.stateChanges.next();
		}
	}

	get empty() {
		return !this.value || (!this.value.inValue && !this.value.notInValue);
	}
	public tenorRangeInNotInFormGroup: FormGroup;
	@Input() public label: string;

	constructor(
		public fb: FormBuilder,
		private fm: FocusMonitor,
		private elRef: ElementRef,
		private render2: Renderer2
	) {
		super(elRef, render2);
		if (fm && elRef) {
			fm.monitor(elRef.nativeElement, true).subscribe(origin => {
				this.focused = !!origin;
				this.stateChanges.next();
			});
		}
		this.updateControlType("aqua-tenor-range-innotin-wrapper");
		this.tenorRangeInNotInFormGroup = this.fb.group({
			inValue: undefined,
			notInValue: undefined
		});

		this.tenorRangeInNotInFormGroup.valueChanges
			.pipe(
				takeUntil(this.alive),
				debounceTime(300),
				distinctUntilChanged()
			)
			.subscribe(value => {
				this.value = value;
			});
	}

	public writeValue(newValue: RangeWrapperModel<number>) {
		console.debug(
			"TenorRangeInNotInWrapper::writeValue Value::[" + this.id + "]::",
			newValue
		);
		newValue &&
			this.tenorRangeInNotInFormGroup.patchValue(newValue, { emitEvent: false });
	}

	// // Focus first child input element
	public onContainerClick(event: MouseEvent) {
		const srcElement: HTMLElement = event.srcElement as HTMLElement;
		console.debug(
			"TenorRangeInNotInWrapper:onContainerClick::[" + this.id + "]::",
			event
		);
		// if ((srcElement as any).name !== "end" && this.isChild(srcElement)) {
		// 	const startInput: HTMLElement = this.elRef.nativeElement.querySelector(
		// 		'[name="start"]'
		// 	);
		// 	startInput.focus();
		// }
		super.onContainerClick(event);
	}

	public ngOnDestroy() {
		this.fm.stopMonitoring(this.elRef.nativeElement);
		super.ngOnDestroy();
	}

	private checkObjectEqual(
		source: RangeWrapperModel<number>,
		destination: RangeWrapperModel<number>
	): boolean {
		let isEqual: boolean = true;
		if (
			(source == null || source === undefined) &&
			(destination != null && destination !== undefined)
		) {
			isEqual = false;
		} else if (
			source != null &&
			source !== undefined &&
			(destination == null || destination === undefined)
		) {
			isEqual = false;
		} else if (!lodash.isEqual(source, destination)) {
			isEqual = false;
		}

		return isEqual;
	}

	private isChild(srcElement: HTMLElement) {
		return srcElement.closest(".period-selector") == null;
	}
}
