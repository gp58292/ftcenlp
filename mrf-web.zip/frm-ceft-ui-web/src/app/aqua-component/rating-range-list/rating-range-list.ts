import {
	ChangeDetectionStrategy,
	ChangeDetectorRef,
	Component,
	ElementRef,
	Input,
	OnDestroy,
	Renderer2
} from "@angular/core";
import {
	AbstractControl,
	FormArray,
	FormBuilder,
	FormControl,
	FormGroup
} from "@angular/forms";
import * as lodash from "lodash";

import { FocusMonitor } from "@angular/cdk/a11y";
import { NgModelCommon } from "@aqua/aqua-component/common";
import {
	DropDownModel,
	RatingRankingModel
} from "@aqua/aqua-component/dropdown-range";
import {
	OPERATOR,
	RatingRangeListModel,
	RatingRangeModel
} from "@aqua/aqua-component/models";
import { RatingRangeListValidator } from "@aqua/aqua-component/validations";
import { BehaviorSubject, from, Subject } from "rxjs";
import {
	debounceTime,
	distinct,
	distinctUntilChanged,
	filter,
	map,
	switchMap,
	takeUntil,
	toArray
} from "rxjs/operators";

@Component({
	// tslint:disable-next-line:component-selector
	selector: "aqua-rating-range-list",
	templateUrl: "./rating-range-list.html",
	styleUrls: ["./rating-range-list.scss"],
	providers: [
		NgModelCommon.CUSTOM_CONTROL_VALUE_ACCESSOR(RatingRangeList),
		NgModelCommon.CUSTOM_MAT_FORM_FIELD(RatingRangeList)
	],
	changeDetection: ChangeDetectionStrategy.OnPush
})
// tslint:disable-next-line:component-class-suffix
export class RatingRangeList extends NgModelCommon<RatingRangeListModel>
	implements OnDestroy {
	@Input()
	set referenceData(options: RatingRankingModel[]) {
		// console.debug(
		// 	"RatingRangeList::referenceData::",
		// 	this.id,
		// 	options && options.length
		// );
		this._referenceData = options;
		// this.prepareList(this._referenceData);
		this.sourceData$.next(options);
	}
	@Input()
	get value(): RatingRangeListModel | null {
		// console.debug("RatingRangeList::get Value::["+this.id+"]::",this.form.value);
		const n: RatingRangeListModel = this._innerValue;
		if (n && n.valueList) {
			return new RatingRangeListModel(n.valueList);
		}
		return null;
	}
	set value(ratingRangeList: RatingRangeListModel | null) {
		ratingRangeList = ratingRangeList || new RatingRangeListModel();
		// console.debug("RatingRangeList::Set Value::["+this.id+"]::",RatingRangeList,this.checkObjectEqual(this._innerValue,RatingRangeList));
		if (!this.checkObjectEqual(this._innerValue, ratingRangeList)) {
			// console.debug("RatingRangeList::Set Value:: to Model["+this.id+"]::", this._innerValue,ratingRangeList,this.checkObjectEqual(this._innerValue,ratingRangeList));
			ratingRangeList = RatingRangeListModel.undefineValuesIfNull(
				ratingRangeList
			); // This will remove value if null
			this._innerValue = ratingRangeList;
			// console.debug(
			// 	"RatingRangeList::ratingRangeList::",
			// 	RatingRangeListValidator.isValid(ratingRangeList)
			// );
			this.onChangedCallback(ratingRangeList);
			this.errorState = RatingRangeListValidator.isValid(ratingRangeList);
			this.stateChanges && this.stateChanges.next();
		}
	}

	@Input()
	public isButNot: boolean = false;
	// -------------------------------------------------------------------------------------------------------------------------

	get isEnableAdd(): boolean {
		let isAdd = false;
		if (this.value && this.value.valueList) {
			// tslint:disable-next-line:prefer-for-of
			for (let i = 0; i < this.value.valueList.length; i++) {
				const row = this.value.valueList[i];
				if (
					row.agencyName == null ||
					row.agencyName === undefined ||
					(row.period == null || row.period === undefined) ||
					(row.value == null || row.value === undefined) ||
					!(
						row.value &&
						(row.value.start == null ||
							row.value.start === undefined ||
							(row.value.end == null || row.value.end === undefined))
					)
				) {
					isAdd = true;
					break;
				}
			}
		}
		// console.debug("RatingRangeList::isEnableAdd::", isAdd);
		return isAdd;
	}
	get empty() {
		return (
			!this.value ||
			(!this.value &&
				!this.value.valueList &&
				this.value.valueList.length === 0)
		);
	}

	get valueListControls(): AbstractControl[] {
		return this.valueListFormArray.controls;
	}
	get valueListFormArray(): FormArray {
		return this.form.get("valueList") as FormArray;
	}

	get valueOrButton(): string {
		if (this.isButNot) {
			return OPERATOR.BUT_NOT;
		} else {
			return this.valueListControls.length > 0
				? this.valueListControls[0].value.operation
				: OPERATOR.OR;
		}
	}
	public form: FormGroup;
	public ENUMOPER: any = OPERATOR;

	@Input() public label: string;
	@Input() public isHideAndOr: boolean = false;

	public _referenceData: RatingRankingModel[];
	public ratingTypeList: string[] = [];
	public MAX_ITEM: number = 6;
	public agencyList: string[] = [];
	private sourceData$ = new BehaviorSubject<RatingRankingModel[]>([]);
	private controlCount: number = 1;

	private isFlagOnce: boolean = false;

	constructor(
		public fb: FormBuilder,
		private fm: FocusMonitor,
		private elRef: ElementRef,
		public render: Renderer2,
		private formBuilder: FormBuilder,
		private _emtChangeDetectorRef: ChangeDetectorRef
	) {
		super(elRef, render);
		if (fm && elRef) {
			fm.monitor(elRef.nativeElement, true)
				.pipe(takeUntil(this.alive))
				.subscribe(origin => {
					this.focused = !!origin;
					this.stateChanges.next();
				});
		}
		this.form = this.fb.group({
			valueList: this.formBuilder.array([this.createItem()])
		});
		this.form.valueChanges
			.pipe(
				takeUntil(this.alive),
				debounceTime(300),
				distinctUntilChanged()
			)
			.subscribe(value => {
				this.value = value;
			});
		this.updateControlType("aqua-rating-range-list");
		this.getAgenciesList();
		this.getRatingTypeList();
		// console.debug("RatingRangeList::constructor::", this.form);
	}

	public createItem(): FormGroup {
		// const idx = this.ratingRates ? this.ratingRates.length + 1 : 1;
		this.controlCount = this.form && this.valueListFormArray.length + 1;
		// console.debug("RatingRangeList::createItem::", this.controlCount);
		return this.formBuilder.group({
			operation: this.isButNot ? OPERATOR.BUT_NOT : OPERATOR.OR,
			value: undefined,
			agencyName: this.agencyList ? this.agencyList[0] : null,
			period: this.ratingTypeList ? this.ratingTypeList[0] : null,
			numIndex: this.controlCount++
		});
	}
	public addItem(isAdd: boolean): void {
		// console.debug("RatingRangeList::addItem::", isAdd);
		if (!isAdd) {
			return;
		}
		// this.ratingRates = this.form.get("valueList") as FormArray;
		this.valueListFormArray.push(this.createItem());
		// this._emtChangeDetectorRef.markForCheck();
	}
	public removeItem(index: number, item: FormControl): void {
		console.debug("RatingRangeList::removeItem::", index, item.value);
		// this.ratingRates = this.form.get("valueList") as FormArray;
		this.valueListFormArray.removeAt(index);
		// this._emtChangeDetectorRef.markForCheck();
	}
	public clearItem(index: number, item: FormGroup): void {
		// console.debug("RatingRangeList::clearItem::", index, item);
		item.value.value = undefined;
		const valueCtrl = item.controls.value as FormControl;
		valueCtrl.setValue(undefined);
		// this._emtChangeDetectorRef.markForCheck();
	}

	public createItemWithValue(ratingRangeModel: RatingRangeModel): FormGroup {
		// console.debug("RatingRangeList::createItem::", idx);
		return this.formBuilder.group({
			operation: ratingRangeModel.operation,
			value: ratingRangeModel.value,
			agencyName: ratingRangeModel.agencyName,
			period: ratingRangeModel.period,
			numIndex: ratingRangeModel.numIndex
		});
	}
	// writeValue(newValue:any) { console.debug('RatingRangeList::writeValue::',newValue); this.value=newValue;}
	public writeValue(newValue: any) {
		// console.debug(
		// 	"RatingRangeList::writeValue::",
		// 	newValue,
		// 	this.form.value,
		// 	this.checkObjectEqual(this.form.value, newValue)
		// );
		if (!newValue) {
			const ratingModel = new RatingRangeModel();
			const model: RatingRangeListModel = new RatingRangeListModel([
				ratingModel
			]);
			this.updateControlFirstTime(model);

			// console.debug("RatingRangeList::writeValue:: Setting value ::", model);
			this.form.patchValue(model, { onlySelf: true, emitEvent: false });
			this.value = model;
			// this._emtChangeDetectorRef.markForCheck();
		} else if (!this.checkObjectEqual(this.form.value, newValue)) {
			const model: RatingRangeListModel = new RatingRangeListModel(
				newValue.valueList
			);
			this.updateControlFirstTime(model);
			// 	console.debug("RatingRangeList::writeValue:: Setting value ::", model);
			this.form.patchValue(model, { onlySelf: true, emitEvent: false });
			this.value = model;
			// this._emtChangeDetectorRef.markForCheck();
		}
	}
	// Focus first child input element
	public onContainerClick(event: MouseEvent) {
		// console.debug("RatingRangeList::onContainerClick::", event.srcElement);
		// if((event.srcElement as any).name != "end") {
		//   let startInput:HTMLElement=this.elRef.nativeElement.querySelector('[name="start"]');
		//   startInput.focus();
		// }
		// super.onContainerClick(event);
	}

	public ngOnDestroy(): void {
		// console.debug("RatingRangeList::ngOnDestroy::");
		this.fm.stopMonitoring(this.elRef.nativeElement);
		super.ngOnDestroy();
	}

	// DON"T DO: Never enable track by on FormArray iteration, it cuases problem while removing item
	public trackByKey(index, item) {
		return index;
	}
	public getChildData(agencyName: string, term: string): any {
		// console.debug("RatingRangeList::getChildData::", agencyName, term);
		if (!agencyName || !term) {
			return;
		}
		return this.sourceData$.pipe(
			takeUntil(this.alive),
			switchMap(ratings =>
				from(ratings).pipe(
					filter(
						rating => rating.agencyName === agencyName && rating.term === term
					),
					map(rating => new DropDownModel(rating.rank, rating.rating)),
					distinct(p => p.key),
					toArray(),
					map(array => array.sort(DropDownModel.comparatorByKey))
				)
			)
		);
	}

	private getAgenciesList(): void {
		this.sourceData$
			.pipe(
				takeUntil(this.alive),
				switchMap(ratings =>
					from(ratings).pipe(
						map(rating => rating.agencyName),
						distinct(),
						toArray()
					)
				)
			)
			.subscribe(data => {
				// console.debug("RatingRangeList::getAgenciesList::", data);
				this.agencyList = data;
			});
	}
	private getRatingTypeList(): void {
		this.sourceData$
			.pipe(
				takeUntil(this.alive),
				switchMap(ratings =>
					from(ratings).pipe(
						map(rating => rating.term),
						distinct(),
						toArray()
					)
				)
			)
			.subscribe(data => {
				// console.debug("RatingRangeList::getRatingTypeList::", data);
				this.ratingTypeList = data;
			});
	}

	private createFormGroup(group: any): void {
		this.form = this.fb.group({
			valueList: this.formBuilder.array(group)
		});
		this.form.valueChanges
			.pipe(
				takeUntil(this.alive),
				debounceTime(300),
				distinctUntilChanged()
			)
			.subscribe(value => {
				this.value = value;
			});
	}

	private updateControlFirstTime(model: RatingRangeListModel): void {
		if (!this.isFlagOnce) {
			const group = [];
			// tslint:disable-next-line:prefer-for-of
			for (let i = 0; i < model.valueList.length; i++) {
				group.push(this.createItemWithValue(model.valueList[i]));
			}
			this.createFormGroup(group);
			this.isFlagOnce = true;
		}
	}
	private checkObjectEqual(
		source: RatingRangeListModel,
		destination: RatingRangeListModel
	): boolean {
		let isEqual = true;
		if (
			(source == null || source === undefined) &&
			(destination != null && destination !== undefined)
		) {
			isEqual = false;
		} else if (
			source != null &&
			source !== undefined &&
			(destination == null || destination === undefined)
		) {
			isEqual = false;
		} else if (
			source.valueList === undefined ||
			destination.valueList === undefined
		) {
			isEqual = false;
		} else if (source.valueList.length !== destination.valueList.length) {
			isEqual = false;
		} else if (!lodash.isEqual(source.valueList, destination.valueList)) {
			isEqual = false;
		}

		return isEqual;
	}
}
