import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { MaterialModule } from "@aqua/material.module";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { MatButtonToggleModule,	MatFormFieldModule,	MatOptionModule,	MatSelectModule} from "@angular/material";
import { DropDownRangeModule } from "@aqua/aqua-component/dropdown-range";
import { RatingRangeList } from "./rating-range-list";

@NgModule({
	imports: [
		CommonModule,
		FormsModule,
    MaterialModule,
		ReactiveFormsModule,
		MatFormFieldModule,
		MatButtonToggleModule,
		MatOptionModule,
		MatSelectModule,
		DropDownRangeModule
	],
	exports: [RatingRangeList],
	declarations: [RatingRangeList]
})
export class RatingRangeListModule {}
