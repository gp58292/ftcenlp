import { DropDownModel } from "@aqua/aqua-component/dropdown-range";
import { RangeValue } from "@aqua/aqua-component/models";

export class RangeModel<T> {
	public static undefineValuesIfNull(
		tenorRange: RangeModel<any>
	): RangeModel<any> {
		if (!tenorRange || tenorRange == null) {
			return undefined;
		}

		if (
			tenorRange.rangeValue == null ||
			tenorRange.rangeValue === undefined ||
			(!tenorRange.rangeValue.start && !tenorRange.rangeValue.end)
		) {
			return undefined;
		}

		return tenorRange;
	}
	constructor(
		public rangeValue?: RangeValue<T>,
		public period?: DropDownModel
	) {}
}
