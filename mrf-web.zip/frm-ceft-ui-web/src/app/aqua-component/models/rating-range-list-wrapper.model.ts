import { RatingRangeListModel } from ".";

export class RatingRangeListWrapperModel {
	public static undefineValuesIfNull(
		ratingRangeModels: RatingRangeListWrapperModel
	): RatingRangeListWrapperModel {
		if (!ratingRangeModels || ratingRangeModels == null) {
			return undefined;
		}
		if (
			(ratingRangeModels.inValueList == null ||
				ratingRangeModels.inValueList === undefined) &&
			(ratingRangeModels.notInValueList == null ||
				ratingRangeModels.notInValueList === undefined)
		) {
			return undefined;
		}

		return ratingRangeModels;
	}
	constructor(
		public inValueList?: RatingRangeListModel,
		public notInValueList?: RatingRangeListModel
	) {}
}
