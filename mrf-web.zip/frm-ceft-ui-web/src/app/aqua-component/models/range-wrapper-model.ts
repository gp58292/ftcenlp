import { RangeModel } from "./range-model";

export class RangeWrapperModel<T> {
	public static undefineValuesIfNull(
		rangeWrapperModel: RangeWrapperModel<any>
	): RangeWrapperModel<any> {
		if (!rangeWrapperModel || rangeWrapperModel == null) {
			return undefined;
		}
		if (
			(rangeWrapperModel.inValue === null ||
				rangeWrapperModel.inValue === undefined) &&
			(rangeWrapperModel.notInValue === null ||
				rangeWrapperModel.notInValue === undefined)
		) {
			return undefined;
		}

		return rangeWrapperModel;
	}
	public constructor(
		public inValue?: RangeModel<T>,
		public notInValue?: RangeModel<T>
	) {}
}
