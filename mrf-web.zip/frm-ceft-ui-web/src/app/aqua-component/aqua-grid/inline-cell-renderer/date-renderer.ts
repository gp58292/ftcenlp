import { Component } from "@angular/core";
import { ICellRendererAngularComp } from "ag-grid-angular";

@Component({
	// tslint:disable-next-line:component-selector
	selector: "aqua-date-renderer",
    template: `
		<span>{{params | date:'yyy-MM-dd h:mm a'}} </span>
	`
})
// tslint:disable-next-line:component-class-suffix
export class DateRenderer implements ICellRendererAngularComp {
	public params: any;

	public agInit(params: any): void {
		this.params = new Date(params.value);
	}

	public refresh(): boolean {
		return false;
	}
}
