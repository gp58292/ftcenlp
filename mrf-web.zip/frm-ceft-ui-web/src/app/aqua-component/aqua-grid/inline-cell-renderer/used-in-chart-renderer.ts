import { Component } from "@angular/core";
import { ICellRendererAngularComp } from "ag-grid-angular";

@Component({
	// tslint:disable-next-line:component-selector
	selector: "aqua-used-in-chart-renderer",
    template: `
	<img src="../../../../assets/images/icon-ok-blue.svg" alt="ok" title="ok" *ngIf="chartFlag"/>
	`
})
// tslint:disable-next-line:component-class-suffix
export class UsedInChartRenderer implements ICellRendererAngularComp {
	public chartFlag: boolean;

	public agInit(params: any): void {
		this.chartFlag = params.value === 1? true : false;
	}

	public refresh(): boolean {
		return false;
	}
}
