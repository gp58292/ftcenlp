import { Component } from "@angular/core";
import { ICellRendererAngularComp } from "ag-grid-angular";

@Component({
	// tslint:disable-next-line:component-selector
	selector: "aqua-delete-renderer",
    template: `        
	<img src="../../../../assets/images/icon-trash-grey.svg" alt="delete" title="delete" *ngIf="isDelete"/>
	`
})
// tslint:disable-next-line:component-class-suffix
export class DeleteRenderer implements ICellRendererAngularComp {
    public isDelete: boolean;

	public agInit(params: any): void {
        this.isDelete = params.node.data.chartFlag === 1 ? false : true;
	}

	public refresh(): boolean {
		return false;
	}
}
