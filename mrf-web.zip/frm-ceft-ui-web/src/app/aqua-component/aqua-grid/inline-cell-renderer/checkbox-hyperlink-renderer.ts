import { Component } from "@angular/core";
import { ICellRendererAngularComp } from "ag-grid-angular";

@Component({
	// tslint:disable-next-line:component-selector
	selector: "aqua-checkbox-hyperlink-renderer",
    template: `
		<mat-checkbox >
        </mat-checkbox>
        
		<span>{{ params.value }} </span>
	`,
	styles: [
		`
			span {
				cursor: pointer;
				border-bottom: 1px solid #285da3;
				color: #285da3;
            }
            .mat-checkbox-layout {
                width: auto;
            }
		`
	]
})
// tslint:disable-next-line:component-class-suffix
export class CheckboxHyperlinkRenderer implements ICellRendererAngularComp {
	public params: any;

	public agInit(params: any): void {
		this.params = params;
	}

	public refresh(): boolean {
		return false;
	}
}
