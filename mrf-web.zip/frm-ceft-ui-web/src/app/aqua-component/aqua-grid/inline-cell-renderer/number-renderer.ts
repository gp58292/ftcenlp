import { Component, OnInit } from "@angular/core";
import { ICellRendererAngularComp } from "ag-grid-angular";

@Component({
	// tslint:disable-next-line:component-selector
	selector: "aqua-number-renderer",
	template: `
		<span [style.color]="params.value >= 0 ? 'black' : 'red'"
			>{{ formatedValue }}
		</span>
	`
})
// tslint:disable-next-line:component-class-suffix
export class NumberRenderer implements ICellRendererAngularComp {
	public params: any;
	public formatedValue: string;
	public agInit(params: any): void {
		this.params = params;
		if (params.value !== undefined) {
			this.formatedValue = this.formatNumber(params.value);
		}
	}

	public refresh(): boolean {
		return false;
	}

	public formatNumber(num: number): string {
		return this.negateNumberWithBracket(
			this.numberWithCommas(this.round(num, 1).toFixed(0))
		);
	}
	public round(value: number, precision: number): number {
		const multiplier = Math.pow(10, precision || 0);
		return Math.round(value * multiplier) / multiplier;
	}

	public numberWithCommas = x => {
		const parts = x.toString().split(".");
		parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
		return parts.join(".");
	};
	public negateNumberWithBracket = (x: string) => {
		if (x.indexOf("-") === 0) {
			x = x.replace("-", "(") + ")";
		}
		return x;
	};
}
