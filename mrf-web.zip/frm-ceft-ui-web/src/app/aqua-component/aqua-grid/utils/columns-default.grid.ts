import { ColumnsDefinationGrid } from "@aqua/aqua-component/aqua-grid/model";

export class ColumnDefaultGrid {
	public static checkbox: ColumnsDefinationGrid = {
		headerName: "#",
		field: undefined,
		minWidth: 40,
		maxWidth: 40,
		checkboxSelection: true,
		enablePivot: false,
		enableValue: false,
		enableRowGroup: false,
		suppressMenu: true,
		headerCheckboxSelection: true,
		headerCheckboxSelectionFilteredOnly: true,
		pinned: true,
		filter: false,
		resizable: true,
		sortable: false
	};
	public static stringDef: ColumnsDefinationGrid = {
		headerName: undefined,
		field: undefined
	};
}
