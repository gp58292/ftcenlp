import {Component} from '@angular/core';
import {FilterCancelService} from '@aqua/filters/services';
import {ILoadingOverlayAngularComp} from 'ag-grid-angular';

@Component({
    selector: 'aqua-grid-loading-overlay',
    template: `
        <mat-spinner [diameter]="24"></mat-spinner>
        <div class="note">Please wait, the process is in progress...</div>
        <div class="cancel" (click)="spinnerCancelled($event, 'Listed')">Cancel</div>
    `,
    styles: [
            `
            :host {
                display: flex;
                flex-direction: column;
                height: 100%;
                width: 100%;
                align-content: center;
                justify-content: center;
                z-index: 100;
            }

            mat-spinner {
                align-self: center;
            }

            .note {
                font-style: italic;
                padding: 20px;
                color: #97999b;
            }

            .cancel {
                cursor: pointer;
                border-radius: 3px;
                padding: 0 10px;
                line-height: 30px;
                background: rgba(0, 90, 161, .1);
                display: inline-block;
                width: 100px;
                align-self: center;
                transition: background-color .2s ease;
                pointer-events: auto;
            }

            .cancel:hover {
                background: rgba(0, 90, 161, .2);
            }

        `
    ]
})
export class CustomLoadingOverlay implements ILoadingOverlayAngularComp {
    constructor(private filterCancelService: FilterCancelService) {
    }

    public getGui(): HTMLElement {
        throw new Error('Method not implemented.');
    }

    // tslint:disable-next-line:no-empty
    public agInit(): void {
    }

    public spinnerCancelled(event: Event, name?: string) {
        console.debug('AquaGrid::spinnerCancelled::', event, name);
        this.filterCancelService.cancelSubject();
    }
}
