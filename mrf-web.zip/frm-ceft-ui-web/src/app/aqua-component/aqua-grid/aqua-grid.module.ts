import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { MatOptionModule, MatProgressSpinnerModule, MatSelectModule, MatCheckboxModule } from "@angular/material";
import { AquaSpinnerModule } from "@aqua/aqua-component/progress-spinner";
import { AgGridModule } from "ag-grid-angular";
import { AquaGrid } from "./aqua-grid";
import { DateComponent } from "./date-component/date.component";

import {
	CustomLoadingOverlay,
	CustomNoRowsOverlay
} from "@aqua/aqua-component/aqua-grid/utils";

// Cell Renderer
import {
	HyperlinkRenderer,
	NumberRenderer,
	TooltipRenderer,
	CheckboxHyperlinkRenderer,
	UsedInChartRenderer,
	ChangeHistoryRenderer,
	DeleteRenderer,
	DateRenderer
} from "./inline-cell-renderer";

// import "ag-grid-enterprise/main";

@NgModule({
	imports: [
		CommonModule,
		FormsModule,
		ReactiveFormsModule,
		MatOptionModule,
		MatProgressSpinnerModule,
		MatSelectModule,
		MatCheckboxModule,
		AgGridModule.withComponents([
			/*optional Angular Components to be used in the grid*/
			DateComponent,
			NumberRenderer,
			TooltipRenderer,
			HyperlinkRenderer,
			CheckboxHyperlinkRenderer,
			UsedInChartRenderer,
			ChangeHistoryRenderer,
			DeleteRenderer,
			DateRenderer
		]),
		AquaSpinnerModule
	],
	exports: [AquaGrid],
	declarations: [
		DateComponent,
		NumberRenderer,
		HyperlinkRenderer,
		TooltipRenderer,
		AquaGrid,
		CustomLoadingOverlay,
		CustomNoRowsOverlay,
		CheckboxHyperlinkRenderer,
		UsedInChartRenderer,
		ChangeHistoryRenderer,
		DeleteRenderer,
		DateRenderer
	],
	entryComponents: [CustomLoadingOverlay, CustomNoRowsOverlay]
})
export class AquaGridModule {}
