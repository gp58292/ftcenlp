import { ChangeDetectionStrategy, ChangeDetectorRef, Component, EventEmitter, Input, OnDestroy, OnInit, Output } from '@angular/core';
import { FormControl } from '@angular/forms';
import { ColumnsDefinationGrid } from '@aqua/aqua-component/aqua-grid/model';

import { AgGridEvent, ColumnApi, GridApi, GridOptions, IServerSideDatasource } from 'ag-grid-community';
import { Subject } from 'rxjs';
import { debounceTime, takeUntil } from 'rxjs/operators';
import { DateComponent } from './date-component/date.component';
import { ExcelStyles } from './excel-styles';
import { CustomLoadingOverlay } from './utils/custom-loading.overlay';
import { CustomNoRowsOverlay } from './utils/custom-norows.overlay';

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'aqua-grid',
  templateUrl: './aqua-grid.html',
  styleUrls: ['./aqua-grid.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
// tslint:disable-next-line:component-class-suffix
export class AquaGrid implements OnInit, OnDestroy {
  @Input('datasource')
  set rowData(_rowData: any[]) {
    this._rowData = _rowData;
    if (this._isResizeOnReady) {
      this.gridApi.sizeColumnsToFit();
      // this.resizeColumns();
    }
    // console.debug("AquaGrid::rowData::", this._rowData && this._rowData.length);
    if (this.gridApi && _rowData != null && _rowData !== undefined && _rowData.length > 0) {
      this.gridDataAndScrollChange.next({ type: 'data' });
    }
    if (this.gridApi && this._rowData == null) {
      this.gridApi.hideOverlay();
      setTimeout(() => {
        this.gridApi.hideOverlay();
      }, 100);
    }
  }
  @Input('serverDataSource')
  set serverDataSource(datasource: IServerSideDatasource) {
    this._serverDataSource = datasource;
    if (this.gridApi) {
      this.hookupServerSideDataSourceOnGridApiReady();
    }
  }

  @Input()
  set dataLoadingStatus(_dataLoadingStatus: boolean) {
    // console.debug(
    // 	"AquaGrid::dataLoadingStatus::",
    // 	_dataLoadingStatus,
    // 	this.gridApi
    // );
    this._dataLoadingStatus = _dataLoadingStatus;
    if (this.gridApi) {
      if (this._dataLoadingStatus) {
        // this.gridApi.showLoadingOverlay();
        this.gridApi.showLoadingOverlay();
        // setTimeout(() => {
        // 	this.gridApi.showLoadingOverlay();
        // }, 100);
      } else {
        this.gridApi.hideOverlay();
      }
    }
  }

  @Input('columnDefs')
  set columnDefs(_columnDefs: ColumnsDefinationGrid[]) {
    // console.debug("AquaGrid::columnDefs::", _columnDefs);
    this._columnDefs = _columnDefs;
    this.gridDataAndScrollChange.next({ type: 'column' });
  }

  @Input()
  set isResizeOnReady(_isResizeOnReady: boolean) {
    // console.debug("AquaGrid::isResizeOnReady::", _isResizeOnReady);
    this._isResizeOnReady = _isResizeOnReady;
  }
  @Input()
  set gridId(id: string) {
    this._gridId = id;
  }
  get gridId() {
    return this._gridId;
  }
  @Input()
  set gridOptions(_gridOptions: GridOptions) {
    if (_gridOptions) {
      // console.debug(
      // 	"AquaGrid::gridOptions::",
      // 	this._gridOptions,
      // 	AquaGrid.gridOptions,
      // 	_gridOptions
      // );
      this._gridOptions = this._gridOptions || {};
      if (!!this._gridOptions.defaultColDef) {
        Object.assign(this._gridOptions.defaultColDef, AquaGrid.defaultColDef);
      }
      Object.assign(this._gridOptions, AquaGrid.gridOptions, _gridOptions);
      // console.debug("AquaGrid::gridOptions:: Post Merge::", this._gridOptions);
    }
  }
  get gridOptions() {
    return this._gridOptions || { ...AquaGrid.gridOptions };
  }

  get displayColumns() {
    return this._columnDefs ? this._columnDefs : [];
  }
  public set gridApi(_gApi: GridApi) {
    this._gridApi = _gApi;
    if (!this._rowData && this._gridApi) {
      // console.debug("AquaGrid::rowData::Clearing all record.................");
      this._gridApi.setRowData(undefined);
    }
    if (this._dataLoadingStatus) {
      // this.gridApi.showLoadingOverlay();
      // this.gridApi.showLoadingOverlay();
      this._gridApi.showLoadingOverlay();
    } else {
      this._gridApi.hideOverlay();
    }
    this.hookupServerSideDataSourceOnGridApiReady();
  }
  public get gridApi() {
    return this._gridApi;
  }
  public static sideBarDefaultConf = {
    toolPanels: ['columns', 'filters'],
    defaultToolPanel: ''
  };
  public static defaultColDef = {
    enableValue: true,
    enableRowGroup: true,
    enablePivot: true
  };
  // AG-GRID: version 20.X.X configuration
  private static readonly gridOptions: GridOptions = {
    suppressRowClickSelection: true,
    rowMultiSelectWithClick: true,
    sideBar: AquaGrid.sideBarDefaultConf,
    groupSelectsChildren: true,
    rowSelection: 'multiple',
    groupSuppressBlankHeader: true,
    pagination: false,
    rowHeight: 30,
    rowBuffer: 10,
    cacheBlockSize: 100,
    excelStyles: ExcelStyles,
    suppressColumnVirtualisation: false,
    rowClass: 'aqua-grid-global-row-cls',
    dateComponentFramework: DateComponent,
    defaultColDef: {
      headerComponentParams: {
        menuIcon: 'fa-bars'
      }
    }
  };
  public _gridOptions: GridOptions;
  public dateComponentFramework: DateComponent;
  // public gridApi: GridApi;
  public gridColumnApi: ColumnApi;
  @Input() public gridHeight: number = 370;
  public _rowData: any[];
  public _dataLoadingStatus: boolean = false;

  public _columnDefs: ColumnsDefinationGrid[];

  public _excelStyles: any = ExcelStyles;
  @Output() public selectedRows: EventEmitter<any[]> = new EventEmitter<any[]>();
  @Output() public selectedAggrement: EventEmitter<any[]> = new EventEmitter<any[]>();
  // @Output() selectedAggrement = new EventEmitter<{ agreementKey: any, agreementId: any }>();

  // Grid Overlay component
  public frameworkComponents = {
    customLoadingOverlay: CustomLoadingOverlay,
    customNoRowsOverlay: CustomNoRowsOverlay
  };
  public loadingOverlayComponent = 'customLoadingOverlay';
  public noRowsOverlayComponent = 'customNoRowsOverlay';

  // overlayLoadingTemplate = `
  // <aqua-spinner isCancel="true" (cancel)="spinnerCancelled($event,'Listed')" style="margin:0 auto;top:30%;"></aqua-spinner>
  // `;

  public columnFilter = new FormControl();
  private _serverDataSource: IServerSideDatasource;

  private _isResizeOnReady: boolean = false;

  // Gird variable
  private agGridEvent: AgGridEvent;
  private alive: Subject<void> = new Subject();
  private _gridApi: GridApi;
  private gridDataAndScrollChange: Subject<{
    type: 'data' | 'column' | 'scroll';
    data?: any;
  }> = new Subject<{
    type: 'data' | 'column' | 'scroll';
    data?: any;
  }>();

  private _gridId: string;

  // tslint:disable-next-line:no-empty
  constructor(private _changeDetectorRef: ChangeDetectorRef) {}

  public ngOnInit() {
    // console.debug("AquaGrid::ngOnInit");
    this.listenScrollAndDataChange();
  }

  public ngOnDestroy() {
    // console.debug("AquaGrid::ngOnDestroy::");
    this.alive.next();
    this.alive.complete();
    this.alive.unsubscribe();
  }

  // ------These are event functions called upon, some user action or data change
  public onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    if (this._isResizeOnReady) {
      this.gridApi.sizeColumnsToFit();
    }
    this.gridApi.hideOverlay();
    // console.debug("AquaGrid::onGridReady::", params);
  }

  public onGridScroll(event): void {
    // console.debug("AquaGrid::onGridScroll::", event.type);
    // this.gridDataAndScrollChange.next({ type: "scroll", data: event });
  }

  public onSelectionChanged($event) {
    // console.debug(
    // 	"AquaGrid::onSelectionChanged:: ",
    // 	this.gridApi.getSelectedRows()
    // );
    this.selectedRows.next(this.gridApi.getSelectedRows());
  }

  public onCellClicked($event) {
    console.debug('AquaGrid::onCellClicked:: ', $event);
    this.selectedAggrement.next($event);
    // this.selectedAggrement.emit({ $event.data.agreementKey, $event.data.agreementId });
  }

  public onExpandClicked($event) {
    console.debug('AquaGrid::onExpandClicked:: ', $event);
  }

  public onSelectClicked($event) {
    console.debug('AquaGrid::onSelectClicked:: ', $event);
  }
  public onFilterTextChanged($event) {
    console.debug('AquaGrid::onFilterTextChanged:: ', $event);
  }

  public onFilterChanged($event: any) {
    console.debug('AquaGrid::onFilterChanged:: ', $event);
  }
  public onFilterClear($event: any) {
    console.debug('AquaGrid::onFilterClear:: ', $event);
  }

  public onFilter($event: any) {
    console.debug('AquaGrid::onFilter:: ', $event);
  }

  public onGridSizeChanged($event: any) {
    console.debug('AquaGrid::onGridSizeChanged:: ', $event);
    this.resizeColumns();
  }

  public onViewportChanged($event: any) {
    console.debug('AquaGrid::onViewportChanged:: ', $event);
  }

  public onComponentStateChanged($event: any) {
    console.debug('AquaGrid::onComponentStateChanged:: ', $event);
  }

  private listenScrollAndDataChange(): void {
    // console.debug("AquaGrid::listenScrollAndDataChange::");

    this.gridDataAndScrollChange
      .pipe(
        takeUntil(this.alive),
        debounceTime(1000)
      )
      .subscribe((data: any) => {
        // console.debug("AquaGrid::gridDataAndScrollChange::", data);
        this.resizeColumns();
      });
  }

  private hookupServerSideDataSourceOnGridApiReady() {
    if (this._serverDataSource) {
      this.gridApi.setServerSideDatasource(this._serverDataSource);
      this.resizeColumns();
    }
  }

  private resizeColumns(): void {
    console.debug('AquaGrid::resizeColumns::', this.gridColumnApi);
    if (this.gridColumnApi) {
      this.gridColumnApi.autoSizeAllColumns();
      // const columnsId: string[] = this.gridColumnApi.getAllColumns().map(column => column.getColId());
      // this.gridColumnApi.autoSizeColumns(columnsId);
    }

    // this.gridColumnApi.getAllColumns()

    // console.timeEnd("AquaGrid::resizeColumns::");
    // console.debug("AquaGrid::resizeColumns::Length::", columnsId.length);
  }
}
