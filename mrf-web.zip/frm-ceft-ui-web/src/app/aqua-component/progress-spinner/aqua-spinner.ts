import { Platform } from "@angular/cdk/platform";
import { DOCUMENT } from "@angular/common";
import {
	ChangeDetectionStrategy,
	Component,
	ElementRef,
	EventEmitter,
	Inject,
	Input,
	Optional,
	Output,
	ViewEncapsulation
} from "@angular/core";
import { MatProgressSpinner } from "@angular/material";

@Component({
	selector: "aqua-spinner",
	host: {
		role: "progressbar",
		class: "mat-progress-spinner",
		"[class._mat-animation-noopable]": `_noopAnimations`,
		"[style.width.px]": "diameter",
		"[style.height.px]": "diameter",
		"[attr.aria-valuemin]": 'mode === "determinate" ? 0 : null',
		"[attr.aria-valuemax]": 'mode === "determinate" ? 100 : null',
		"[attr.aria-valuenow]": "value",
		"[attr.mode]": "mode"
	},
	inputs: ["color"],
	templateUrl: "aqua-spinner.html",
	styleUrls: ["aqua-spinner.scss"],
	changeDetection: ChangeDetectionStrategy.OnPush,
	encapsulation: ViewEncapsulation.None
})
export class AquaSpinner extends MatProgressSpinner {
	@Input() public isCancel: boolean = false;

	@Output() public cancel: EventEmitter<void> = new EventEmitter();
	constructor(
		elementRef: ElementRef,
		platform: Platform,
		@Optional()
		@Inject(DOCUMENT)
		document: any
	) {
		super(elementRef, platform, document);
		this.mode = "indeterminate";
	}
	public cancelSpinner(): void {
		// console.debug("AquaSpinner::cancelSpinner::");
		if (this.isCancel) {
			this.cancel.next();
		}
	}
}
