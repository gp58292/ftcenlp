import {
	ChangeDetectionStrategy,
	Component,
	ElementRef,
	Input
} from "@angular/core";
import { NgModelCommon } from "@aqua/aqua-component/common";
import { Options } from "@aqua/aqua-component/models";
import { FilterOptionsPipe } from "@aqua/aqua-component/pipes";

// <cdk-virtual-scroll-viewport itemSize="10" [style.height.px]="5 * 48">
// 				<mat-option
// 					*cdkVirtualFor="
// 						let source of (_optionsData | filterOptions: autoText);
// 						let i = index
// 					"
// 					[id]="source.key"
// 					[value]="source"
// 					[disabled]="source.disabled"
// 					(scrolledIndexChange)="scrolledIndexChange($event)"
// 				>
// 					{{ source.value }}
// 				</mat-option>
// 			</cdk-virtual-scroll-viewport>

@Component({
	selector: "aqua-filter-select",
	template: `
		<aqua-select
			[(ngModel)]="value"
			[(autoCompleteText)]="autoText"
			[placeholder]="placeholder"
			[(data)]="_optionsData"
			[multiple]="multiple"
			(focusChange)="gotFocus($event)"
			[chips]="chips"
		>
			<mat-option
				*ngFor="
					let source of (_optionsData | filterOptions: autoText);
					let i = index
				"
				[id]="source.key"
				[value]="source"
				[disabled]="source.disabled"
				(scrolledIndexChange)="scrolledIndexChange($event)"
			>
				{{ source.value }}
			</mat-option>
		</aqua-select>
	`,
	styles: [
		`
			:host {
				width: 100%;
				min-width: 0;
				display: flex;
			}
		`
	],
	providers: [
		NgModelCommon.CUSTOM_CONTROL_VALUE_ACCESSOR(AquaFilterSelect),
		NgModelCommon.CUSTOM_MAT_FORM_FIELD(AquaFilterSelect),
		FilterOptionsPipe
	]
	// changeDetection: ChangeDetectionStrategy.OnPush
	// Add checkin for count purpose only
})
export class AquaFilterSelect extends NgModelCommon<AquaFilterSelect> {
	@Input() public placeholder: string;
	public _optionsData: Options[];

	@Input()
	set optionsData(options: Options[]) {
		console.debug("AquaFilterSelect::optionsData::", this.id, options.length);
		this._optionsData = options;
	}
	@Input() public chips: boolean;
	@Input() public multiple: boolean = true;

	public autoText: string;
	// public initialRange: ListRange = { start: 0, end: 5 } as ListRange;
	// @ViewChild(CdkVirtualScrollViewport)
	// private cdkVirtualScrollViewport: CdkVirtualScrollViewport;

	constructor(public _elementRef: ElementRef) {
		super();
		this.updateControlType("aqua-filter-select");
	}

	public trackByKey(index, item: Options) {
		return item.key;
	}
	public gotFocus(value: boolean): void {
		this.focused = value;
		if (this.focused) {
			this._elementRef.nativeElement.focus();
		}
		// console.debug("AquaFilterSelect::gotFocus::", value);
	}
	// public scrolledIndexChange($event) {
	// 	if (!this.initialRange) {
	// 		this.initialRange = this.cdkVirtualScrollViewport.getRenderedRange();
	// 	}
	// }
	// public openedChange(opened) {
	// 	if (!opened) {
	// 		this.cdkVirtualScrollViewport.setRenderedContentOffset(0);
	// 		this.cdkVirtualScrollViewport.setRenderedRange(this.initialRange);
	// 	}
	// }

	get shouldLabelFloat(): boolean {
		return (this.value && this.value.length > 0) || this.focused;
	}

	/** Whether the select has a value. */
	get empty(): boolean {
		return !(this.value && this.value.length > 0);
	}
}
