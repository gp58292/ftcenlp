import { Options } from "./../models/options.model";
import { Pipe, PipeTransform } from "@angular/core";

@Pipe({
	name: "filterOptions"
})
export class FilterOptionsPipe implements PipeTransform {
	public resultsFromSrch: Options[] = [];

	transform(items: Options[], searchText?: string): any {
		if (!items || items.length == 0) return [];
		if (!searchText) return items;

		searchText = searchText.toLowerCase();

		const exactPattersMatch: Options[] = this.findExactMatch(items, searchText);

		const startingPatternMatch: Options[] = this.findStartingCase(
			items,
			searchText
		);
		const containgWordMatch: Options[] = this.findContainingCase(
			items,
			searchText
		);

		const resultsFromSrch: Options[] = [
			...exactPattersMatch,
			...startingPatternMatch,
			...containgWordMatch
		];

		const finalSrchRes = resultsFromSrch.filter((elem, i, resultsFromSrch) => {
			if (resultsFromSrch.indexOf(elem) === i) {
				return elem;
			}
		});

		return finalSrchRes;

		// return items.filter( (option:Options) => {
		//  return option.value.toLowerCase().includes(searchText);
		// });
	}

	findExactMatch(items: Options[], searchText?: string): any {
		return items.filter((option: Options) => {
			//  return option.value.toLowerCase().match(searchText);
			return option.value.toLowerCase() === searchText;
		});
	}

	findStartingCase(items: Options[], searchText?: string): any {
		return items.filter((option: Options) => {
			return option.value.toLowerCase().startsWith(searchText);
		});
	}

	findContainingCase(items: Options[], searchText?: string): any {
		return items.filter((option: Options) => {
			return option.value.toLowerCase().includes(searchText);
		});
	}
}
