import { MapKeys } from './map.Keys.pipe';
import { TruncatePipe } from './truncate.pipe';
import { FilterOptionsPipe } from './filter-options.pipe';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EscapeHtmlPipe } from './escape-html.pipe';
import { DataTableExportFormatter } from './data-table-export-formatter.pipe';
import { ArraySortPipe } from './array-sort.pipe';
import { NumberFormatPipe } from '@aqua/components/pipes/number-formating-pipe';
import { PrintCountPipe } from '././print-count.pipe';

@NgModule({
  imports: [CommonModule],
  exports: [FilterOptionsPipe, TruncatePipe, MapKeys, EscapeHtmlPipe, DataTableExportFormatter, ArraySortPipe, NumberFormatPipe, PrintCountPipe],
  declarations: [FilterOptionsPipe, TruncatePipe, MapKeys, EscapeHtmlPipe, DataTableExportFormatter, ArraySortPipe, NumberFormatPipe, PrintCountPipe],
  providers: [FilterOptionsPipe, MapKeys, EscapeHtmlPipe, DataTableExportFormatter, ArraySortPipe, NumberFormatPipe],
})
export class PipeModule {
}
