import { Pipe, PipeTransform } from '@angular/core';

/**
 * Print array length.
 * @usage
 * {{ [1, 2, 3] | printCount }}             // '(3)'
 * {{ [1, 2, 3] | printCount:true:'[]' }}   // '[3]'
 * {{ [1, 2, 3] | printCount:true:'' }}     // '3'
 * {{ [] | printCount }}                    // '(0)'
 * {{ [] | printCount:false }}              // ''
 */
@Pipe({ name: 'printCount' })
export class PrintCountPipe implements PipeTransform {
    public transform(arr: any[], displayZeroValue = true, wrapperChars = '()'): string {
        return Array.isArray(arr) && (arr.length > 0 || displayZeroValue) ? (wrapperChars[0] || '') + arr.length + (wrapperChars[1] || '') : '';
    }
}
