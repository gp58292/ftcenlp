import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { MultiIncludeExclude } from "./multi-include-exclude";

describe("MultiIncludeExclude", () => {
	let component: MultiIncludeExclude;
	let fixture: ComponentFixture<MultiIncludeExclude>;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			declarations: [MultiIncludeExclude]
		}).compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(MultiIncludeExclude);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});
});
