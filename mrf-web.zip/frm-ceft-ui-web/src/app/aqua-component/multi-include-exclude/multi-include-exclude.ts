import { FocusMonitor } from '@angular/cdk/a11y';
import { Component, ElementRef, Inject, Input, OnDestroy, Optional, Renderer2 } from '@angular/core';
import { AbstractControl, FormArray, FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { MAT_DIALOG_DATA } from '@angular/material';
import { NgModelCommon } from '@aqua/aqua-component/common';
import { IncludeExcludeListModel, IncludeExcludeModel, OPERATOR, Options } from '@aqua/aqua-component/models';
import * as lodash from 'lodash';
import { debounceTime, distinctUntilChanged, takeUntil } from 'rxjs/operators';
import { CoreMultiIncludeExclude } from './core-multi-include-exclude/cor-multi-include-exclude';

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'aqua-multi-include-exclude',
  templateUrl: './multi-include-exclude.html',
  styleUrls: ['./multi-include-exclude.scss'],
  providers: [
    NgModelCommon.CUSTOM_CONTROL_VALUE_ACCESSOR(MultiIncludeExclude),
    NgModelCommon.CUSTOM_MAT_FORM_FIELD(MultiIncludeExclude),
  ],
})
// tslint:disable-next-line:component-class-suffix
export class MultiIncludeExclude extends NgModelCommon<IncludeExcludeListModel>
  implements OnDestroy {
  @Input()
  get value (): IncludeExcludeListModel | null {
    // console.debug("MultiIncludeExclude::get Value::["+this.id+"]::",this.form.value);
    const n = this._innerValue;
    if (n && n.valueList) {
      return new IncludeExcludeListModel(n.valueList);
    }
    return null;
  }

  set value (includeExcludeList: IncludeExcludeListModel | null) {
    includeExcludeList = includeExcludeList || new IncludeExcludeListModel();
    console.debug(
      'MultiIncludeExclude::Set Value::[' + this.id + ']::',
      includeExcludeList,
      this.checkObjectEqual(this._innerValue, includeExcludeList),
    );
    if (!this.checkObjectEqual(this._innerValue, includeExcludeList)) {
      // console.debug("MultiIncludeExclude::Set Value:: to Model["+this.id+"]::", this._innerValue,includeExclude,this.checkObjectEqual(this._innerValue,includeExclude));
      includeExcludeList = IncludeExcludeListModel.undefineValuesIfNull(
        includeExcludeList,
      ); // This will remove value if null
      this._innerValue = includeExcludeList;
      this.onChangedCallback(
        !includeExcludeList || !includeExcludeList.valueList
          ? undefined
          : includeExcludeList,
      );
      this.stateChanges && this.stateChanges.next();
    }
  }

  get valueListControls (): AbstractControl[] {
    return this.valueListFormArray ? this.valueListFormArray.controls : [];
  }

  get valueListFormArray (): FormArray {
    return this.form.get('valueList') as FormArray;
  }

  get empty () {
    return (!this.value || (!this.value.valueList || this.value.valueList.length === 0));
  }

  public MAX_ITEM: number = 5;
  public form: FormGroup;
  public ENUMOPER: any = OPERATOR;

  @Input() public label: string;

  @Input()
  public referenceData: Options[];

  private controlCount: number = 1;
  private isFlagOnce: boolean = false;

  constructor (
    public fb: FormBuilder,
    private fm: FocusMonitor,
    private elRef: ElementRef,
    private render2: Renderer2,
    private formBuilder: FormBuilder,
    @Optional() @Inject(MAT_DIALOG_DATA) public popData: any,
  ) {
    super(elRef, render2);
    if (fm && elRef) {
      fm.monitor(elRef.nativeElement, true)
        .pipe(takeUntil(this.alive))
        .subscribe(origin => {
          this.focused = !!origin;
          this.stateChanges.next();
        });
    }
    this.updateControlType('aqua-multi-include-exclude');
    this.form = this.fb.group({
      valueList: this.formBuilder.array([this.createItem()]),
    });

    this.form.valueChanges
      .pipe(
        takeUntil(this.alive),
        distinctUntilChanged(),
      )
      .subscribe(value => (this.value = value));
  }

  // writeValue(newValue:any) { console.debug('MultiIncludeExclude::writeValue::',newValue); this.value=newValue;}
  public writeValue (newValue: IncludeExcludeListModel) {
    console.debug('MultiIncludeExclude::writeValue::', newValue, this.form.value, this.checkObjectEqual(this.form.value, newValue));
    if (!newValue) {
      console.debug('MultiIncludeExclude::writeValue:: Setting value ::');
      const model: IncludeExcludeListModel = new IncludeExcludeListModel([new IncludeExcludeModel()]);
      this.updateControlFirstTime(model);

      console.debug('MultiIncludeExclude::writeValue:: Setting value ::', model);
      this.form.patchValue(model, { onlySelf: true, emitEvent: false });
      this.value = model;
      // this._emtChangeDetectorRef.markForCheck();
    }
    else if (!this.checkObjectEqual(this.form.value, newValue)) {
      console.debug('MultiIncludeExclude::writeValue:: Setting value :: Object not equqal');
      if (newValue && !newValue.valueList) {
        newValue.valueList = [];
        newValue.valueList.push(newValue as any);
      }
      const model: IncludeExcludeListModel = new IncludeExcludeListModel(newValue.valueList);
      this.updateControlFirstTime(model);
      console.debug('MultiIncludeExclude::writeValue:: Setting value ::', model);
      this.form.patchValue(model, { onlySelf: true, emitEvent: false });
      this.value = model;
      // this._emtChangeDetectorRef.markForCheck();
    }
  }

  public createItem (): FormGroup {
    // const idx = this.ratingRates ? this.ratingRates.length + 1 : 1;
    this.controlCount = this.form && this.valueListFormArray.length + 1;
    // console.debug("MultiIncludeExclude::createItem::", this.controlCount);
    return this.formBuilder.group({ operation: OPERATOR.OR, value: undefined, butNotValue: undefined });
  }

  public createItemWithValue (includeExcludeModel: IncludeExcludeModel): FormGroup {
    // console.debug("MultiIncludeExclude::createItem::", idx);
    return this.formBuilder.group({
      operation: includeExcludeModel.operation,
      value: includeExcludeModel.value,
      butNotValue: includeExcludeModel.butNotValue,
    });
  }

  public addItem (isAdd: boolean): void {
    // console.debug("MultiIncludeExclude::addItem::", isAdd);
    if (isAdd) {
      this.valueListFormArray.push(this.createItem());
    }
    // this.ratingRates = this.form.get("valueList") as FormArray;
    // this._emtChangeDetectorRef.markForCheck();
  }

  public removeItem (isRemove: boolean, index: number, item: FormControl): void {
    if (isRemove) {
      console.debug('RatingRangeList::removeItem::', index, item.value);
      // this.ratingRates = this.form.get("valueList") as FormArray;
      this.valueListFormArray.removeAt(index);
      // this._emtChangeDetectorRef.markForCheck();
    }
  }

  // Focus first child input element
  public onContainerClick (event: MouseEvent) {
    console.debug('MultiIncludeExclude::onContainerClick::', event.srcElement);
    // if((event.srcElement as any).name != "end") {
    //   let startInput:HTMLElement=this.elRef.nativeElement.querySelector('[name="start"]');
    //   startInput.focus();
    // }
    super.onContainerClick(event);
  }

  public onLookup (coreMultiIncludeExclude: CoreMultiIncludeExclude) {
    coreMultiIncludeExclude.onLookUp();
  }

  public ngOnDestroy (): void {
    console.debug('MultiIncludeExclude::ngOnDestroy::');
    this.fm.stopMonitoring(this.elRef.nativeElement);
    super.ngOnDestroy();
  }

  private checkObjectEqual (source: IncludeExcludeListModel, destination: IncludeExcludeListModel): boolean {
    let isEqual = true;
    if (
      (source == null || source === undefined) &&
      (destination != null && destination !== undefined)
    ) {
      isEqual = false;
    } else if (
      source != null &&
      source !== undefined &&
      (destination == null || destination === undefined)
    ) {
      isEqual = false;
    } else if (
      source.valueList === undefined ||
      destination.valueList === undefined
    ) {
      isEqual = false;
    } else if (source.valueList.length !== destination.valueList.length) {
      isEqual = false;
    } else if (!lodash.isEqual(source.valueList, destination.valueList)) {
      isEqual = false;
    }

    return isEqual;
  }

  private createFormGroup (group: any): void {
    this.form = this.fb.group({
      valueList: this.formBuilder.array(group),
    });
    this.form.valueChanges
      .pipe(
        takeUntil(this.alive),
        debounceTime(300),
        distinctUntilChanged(),
      )
      .subscribe(value => {
        this.value = value;
      });
  }

  private updateControlFirstTime (model: IncludeExcludeListModel): void {
    if (!this.isFlagOnce) {
      const group = [];
      // tslint:disable-next-line:prefer-for-of
      for (let i = 0; i < model.valueList.length; i++) {
        group.push(this.createItemWithValue(model.valueList[i]));
      }
      this.createFormGroup(group);
      this.isFlagOnce = true;
    }
  }
}
