import { AfterContentInit, Component, ContentChildren, HostBinding, OnDestroy, QueryList } from '@angular/core';
import { ResizeSensor } from 'css-element-queries';

@Component({
  selector: 'app-filter-item-wrapper',
  template: '<ng-content></ng-content>',
})
export class FilterItemWrapperComponent implements AfterContentInit, OnDestroy {
  private readonly minFilterHeight = 10;
  private resizeSensor: ResizeSensor;

  @ContentChildren('filterItem') private filterItem: QueryList<any>;
  @HostBinding('style.grid-row-end') private gridRowEnd = '';

  public ngOnDestroy () {
    this.resizeSensor.detach();
  }

  public ngAfterContentInit () {
    this.resizeSensor = new ResizeSensor(this.filterItem.first.nativeElement, () => this.checkHostSize());
  }

  private checkHostSize = () => {
    const childHeight = this.filterItem.first.nativeElement.clientHeight;
    this.gridRowEnd = (childHeight > this.minFilterHeight)
      ? 'span ' + Math.ceil((childHeight + 10) / this.minFilterHeight)
      : '';
    console.debug('FilterItemWrapper::childHeight: ' + childHeight + '; cssClass:' + Math.ceil((childHeight + 10) / this.minFilterHeight));
  };
}
