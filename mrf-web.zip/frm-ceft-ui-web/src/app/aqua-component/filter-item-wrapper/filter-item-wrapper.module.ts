import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FilterItemWrapperComponent } from '@aqua/components/filter-item-wrapper/filter-item-wrapper.component';

@NgModule({
  imports: [CommonModule],
  exports: [FilterItemWrapperComponent],
  declarations: [FilterItemWrapperComponent],
})
export class FilterItemWrapperModule {
}
