import { Directive, forwardRef } from '@angular/core';
import { AbstractControl, NG_VALIDATORS, Validator, ValidatorFn } from '@angular/forms';
import { RangeValue } from '@aqua/aqua-component/models';

@Directive({
  selector: '[validateDateRange][ngModel],[validateDateRange][formControl]',
  providers: [
    {
      provide: NG_VALIDATORS,
      useExisting: forwardRef(() => DateRangeValidator),
      multi: true,
    },
  ],
})
export class DateRangeValidator implements Validator {
  public static validateDateRange (): ValidatorFn {
    return (control: AbstractControl) => DateRangeValidator.isValid(control.value)
      ? null
      : { validateDateRange: { valid: false } };
  }

  public static isValid (range: RangeValue<string>) {
    if (range && range.start && range.end) {
      const start = Date.parse(range.start);
      const end = Date.parse(range.end);
      return start <= end;
    }

    return true;
  }

  public validator = DateRangeValidator.validateDateRange();

  public validate (control: AbstractControl) {
    return this.validator(control);
  }
}
