import { Injectable } from '@angular/core';
import { AuthenticationService, FRMCommunication } from '@citi-icg-163206/frm-framework-npm-commons';
import { filter, map, share, take, tap } from 'rxjs/operators';
import { merge } from 'rxjs';
import { HttpParams } from '@angular/common/http';

// @todo: Handler wrapper environment will bew moved under the hood of FRM Commons after we resolve parent identification for FRM web apps.
@Injectable()
export class FrmCommunicationHandlerService {
  private portalInstanceId: string = null;

  private sharedMessage$ = this.frmCommunication.message$.pipe(
    tap(message => console.debug('COMMUNICATION DATA', message)),
    share(),
  );

  private firstMessageHandler$ = this.sharedMessage$.pipe(
    filter((message) => message.command === 'someCommand'),
    tap(message => {
      console.debug('First Message Handler', message);

      // Do some actions there.
    }),
    map(message => ({ ...message, served: true })),
  );

  constructor (private frmCommunication: FRMCommunication, private authenticationService: AuthenticationService) {
    // window['emitToSocket'] = (x) => this.frmCommunication.push(x);
  }

  public start = () => {
    AuthenticationService.isAuth$.pipe(filter(Boolean), take(1)).subscribe(() => {
      this.portalInstanceId = FrmCommunicationHandlerService.getOrGenerateUUID();
      this.frmCommunication.start({ uuid: this.portalInstanceId });
    });

    return merge(this.firstMessageHandler$)
      .pipe(filter(({ served }) => !!served))
      .subscribe(message => this.frmCommunication.push({ command: 'commandReceive', payload: JSON.stringify(message) }));
  };

  public emit = (message) => {
    this.authenticationService.subscribeUserDetails().pipe(take(1), map(user => user.soeid)).subscribe(
      userId => this.frmCommunication.push({ ...message, portalInstanceId: this.portalInstanceId, userId, created: new Date() })
    );
  };

  static getOrGenerateUUID () {
    return FrmCommunicationHandlerService.getParamValueQueryString('uuid') || FrmCommunicationHandlerService.generateGuid();
  }

  static getParamValueQueryString (paramName) {
    const query = window.location.href.split('?')[1];
    const httpParams = new HttpParams({ fromString: query });
    return httpParams.get(paramName);
  }

  static generateGuid () {
    let result, i, j;
    result = '';
    for (j = 0; j < 32; j++) {
      if (j === 8 || j === 12 || j === 16 || j === 20) {
        result = result + '-';
      }
      i = Math.floor(Math.random() * 16).toString(16).toUpperCase();
      result = result + i;
    }
    return result;
  }
}
