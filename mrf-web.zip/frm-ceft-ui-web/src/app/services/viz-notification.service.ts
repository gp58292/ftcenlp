import { Injectable } from '@angular/core';
import { MatSnackBar, MatSnackBarConfig, MatSnackBarRef, SimpleSnackBar} from '@angular/material';
import { SnackBarPosition } from '@aqua/models';

@Injectable()
export class VizNotificationService {
  private defaultAction = 'Dismiss';

  constructor (public snackBar: MatSnackBar, private snackBarConfig: MatSnackBarConfig) {
    this.snackBarConfig.horizontalPosition = SnackBarPosition.RIGHT;
    this.snackBarConfig.verticalPosition = SnackBarPosition.TOP;
    this.snackBarConfig.duration = 5000;
  }

  public showInternalSystemError (): void {
    console.debug('VizNotificationService::showInternalSystemError::');
    this.showError('Internal server error occured, Please contact AQAU CEFT Build Team');
  }

  public showMessage (message: string, action = this.defaultAction): MatSnackBarRef<SimpleSnackBar> {
    return this.snackBar.open(message, action, { ...this.snackBarConfig, panelClass: 'snackbar-success' });
  }

  public showError (message: string, action = this.defaultAction, timeout?: number): MatSnackBarRef<SimpleSnackBar> {
    return this.snackBar.open(message, action, { ...this.snackBarConfig, panelClass: 'snackbar-error'
      , duration: timeout ? timeout : this.snackBarConfig.duration});
  }

  public showWarning (message: string, action = this.defaultAction, config = {}): MatSnackBarRef<SimpleSnackBar> {
    return this.snackBar.open(message, action, { ...this.snackBarConfig, ...config, panelClass: 'snackbar-warning' });
  }
}
