import { enableProdMode } from "@angular/core";
import { platformBrowserDynamic } from "@angular/platform-browser-dynamic";

import { AppModule } from "./app/app.module";
import { environment } from "./environments/environment";

import { LicenseManager } from "ag-grid-enterprise/main";
LicenseManager.setLicenseKey(
	"SHI_International_Corp_-_USA_on_behalf_of_CitiGroup_MultiApp_2Devs26_April_2019__MTU1NjIzMzIwMDAwMA==841372169481ffb0eeabae1f82d0e02b"
);

if (environment.production) {
	enableProdMode();
	// Disable log and debug output in production
	// As we already have logs in servers
	// tslint:disable-next-line:no-empty
	window.console.log = () => {};
}
// Disable logs temporary
// window.console.log = function() {};
// window.console.warn = function() {};
// window.console.debug = function() {};

platformBrowserDynamic()
	.bootstrapModule(AppModule)
	.catch(err => console.error(err));
