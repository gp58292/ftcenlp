#### ~/.npmrc config
```jshelllanguage
.npmrc
registry=https://www.artifactrepository.citigroup.net/artifactory/api/npm/npm-npmjs-remote/
strict-ssl=false
@angular:registry=https://www.artifactrepository.citigroup.net/artifactory/api/npm/npm-npmjs-remote/
@angular-devkit:registry=https://www.artifactrepository.citigroup.net/artifactory/api/npm/npm-npmjs-remote/
@types:registry=https://www.artifactrepository.citigroup.net/artifactory/api/npm/npm-npmjs-remote/
#sass-binary-path=c:/Users/tg11567/Downloads/win32-x64-57_binding.node
sass-binary-path=c:\Users\tg11567\Downloads\win32-x64-57_binding.node
@citi-icg-163206:registry=https://www.artifactrepository.citigroup.net/artifactory/api/npm/npm-icg-teamdev-local/
_auth = XxXXXXXXXXXXXXX ENCRYPTED PASSWORD GENERATED IN ARTIFACTORY #########
email = tg11567@imceu.eu.ssmb.com
always-auth = true

```

#### Artifactory authentication setup for gradle
please setup your credentials in ~/.gradle/gradle.properties
```jshelllanguage
artifactRepositoryUser=tg11567
artifactRepositoryPassword=XXXXX
```

#### setup
```jshelllanguage
npm install
```

#### build and serve
```jshelllanguage
.\node_modules\.bin\ng serve
```

#### build webjar
```jshelllanguage
gradle build -x test
```
