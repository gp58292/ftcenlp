# -*- coding: utf-8 -*-
"""
Created on Wed Jun 12 17:42:56 2019

@author: ab57286
"""
################################## Data File ########################





#Component getter function    
def getComponent():
    
    compMap ={'collateral_type_name':'MULTI_INCLUDE_EXCLUDE','party_legal_entity':'DROPDOWN','legal_entity':'DROPDOWN','issue_currency':'DROPDOWN','csa_status':'DROPDOWN','index_name':'DROPDOWN','sttlmnt_cntry':'DROPDOWN'}
    return compMap


# Filedname getter function
def getSetMap():
    
    
    
    dataSetMapCan = dict([(n,'collateral_type_name') for n in range(0,185)]+[(n,'party_legal_entity') for n in range(185,364)]+[(n,'issue_currency') for n in range(364,375)]+[(n,'csa_status') for n in range(375,383)]+[(n,'index_name') for n in range(383,402)]+[(n,'sttlmnt_cntry') for n in range(402,431)])
    dataSetMapHas = dict([(n,'collateral_type_name') for n in range(0,185)]+[(n,'legal_entity') for n in range(185,364)]+[(n,'issue_currency') for n in range(364,375)]+[(n,'sttlmnt_cntry') for n in range(402,431)])
    # dataSetMapCan = {0:'collateral_type_name',1:'party_legal_entity'}
    #dataSetMapHas = {0:'collateral_type_name',1:'legal_entity'}
    
    return dataSetMapCan,dataSetMapHas
    
    