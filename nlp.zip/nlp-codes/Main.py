# -*- coding: utf-8 -*-
"""
Created on Tue Jun 11 13:12:48 2019

@author: ab57286
"""

import UtilityFunctions as util
import json
from collections import OrderedDict
from flask import Flask, jsonify,request
import pandas as pd
import re
import socket
import collections
import Sentence as sen
import STT as st
import STT_UI as ui


 
        
        



app = Flask(__name__)
@app.route('/python/collateral', methods=['POST'])        
def get_tasks():
    
    if request.headers['Content-Type'] == 'audio/wav':
         
         
         CHUNK = 1024
         RATE = 16000
         RECORD_SECONDS = 10
         #fname = request.files['audioBlob'].filename
         #blob = request.files['audioBlob']
         blob = request.data
         #soeid = 
         
         #file_name='output.wav'
         
         
         
         
         #blob = open("/home/ubuntu/abc/testing.wav").read()
         
         name = "output.wav"
         
         #f = open("/home/ubuntu/pabc/audio/text.txt", 'wb')
         #f.close()
         audio = wave.open(name,'wb')
    
         audio.setnchannels(1)
         audio.setsampwidth(2)
         audio.setframerate(16000)
         audio.setnframes(1)
         #audio.setnframes(int(RATE / CHUNK * RECORD_SECONDS))
         #output = '\0' * nframes * nchannels * sampwidth
         audio.writeframes(blob)
         audio.close()
     
     
    
    
    
    
    #response = requests.get(url)
    
    ############################### Common Parameters ############################
    '''
    global CompMap
    CompMap ={'collateral_type_name':'MULTI_INCLUDE_EXCLUDE','party_legal_entity':'DROPDOWN','legal_entity':'DROPDOWN'}'''
    '''
    who_can_contractual = request.args.get('who_can_contractual')
    but_not_contractual =  request.args.get('but_not_contractual')
    who_can_eligible = request.args.get('who_can_eligible')
    but_not_eligible=  request.args.get('but_not_eligible')'''
    
    
    
    
    
    '''
    listWhoCan=re.split(",|;|\*|\n|' '",request.args.get('who_can_post'))
    listButNot=re.split(",|;|\*|\n|' '",request.args.get('but_not_post'))
    listWhoHas=re.split(",|;|\*|\n|' '",request.args.get('who_has_posted'))
    listButNotHas=re.split(",|;|\*|\n|' '",request.args.get('but_not_posted'))'''
    
    '''
    listWhoCan = ['uscorp','usmuni','cgmi']
    listButNot = ['inrcash']
    listWhoHas =  ['uscorp','usmuni']
    listButNotHas = ['inrcash','cgml']'''
    
    
    #text= "I want collateral id as uscorp,usmuni but not cgmi,gbpcash"
    
    #text=st.UI()
    #ui.UI()
    text=st.main(name)
    
    print(text)
    
        
    
    
    
    
    list1,list2=sen.Sent(text)
    
    if(len(list1)>0): 
        listWhoCan=list1[0]
    else:
        listWhoCan=[]
        
        
        
    if(len(list2)>0):
        listButNot=list2[0]
    else:
        listButNot=[]
        
        
    
    
    
    
    if(len(list1)>1):    
        listWhoHas= list1[1]
    else:
        listWhoHas = []
        
    if(len(list2)>1):
        listButNotHas= list2[1]
    else:
        listButNotHas = []
        
    #listWhoHas=list1[1]
    #listButNotHas=list2[1]'''
    '''
    print(listWhoCan)
    print(listButNot)
    print(listWhoHas)
    print(listButNotHas)'''
    
    

    
    # This list holds the final JSON structure
    jsonList = []
    
    
    
    
    # This two lists will store the correct value and their filed namefor given input by user.
    # eg uscor,cgmi,inrca ---> [US_CORP,CGMI,INR_CASH]
    #                          [collateral_type_name,party_legal_entity_collateral_type_name]   
    representativeValues=[]
    representativeType = []
    
    
    
    
    
    # This dictionary is used to hold mapping of values against their fieldname'
    # {'collateral_type_name':[US_CROP,INR_CASH],'party_legal_entity':[CGMI]}
    valueDictMap = collections.defaultdict(list)
    
    
    # This holds the percent match for input values wrt to exact values
    percentMatch=0
    
    
    
    ############################ Contractual Posting  ###################################
    
    
    
    
    
    # This is call to function to get correct values for input values for who_can_post (box1) with flag 0
    util.getRepresentativeId(listWhoCan,representativeValues,representativeType,percentMatch,0)
    
    # This loop will map the fieldname and output from above function
    for i in range(0,len(representativeValues)):
        valueDictMap[representativeType[i]].append(representativeValues[i])
        
    
    print(valueDictMap)
    #print(representativeValues)
    #print(representativeType)
    
    
    # Clear all results for next iteration
    representativeValues.clear()
    representativeType.clear()
    
    
    
    # This is call to function to get correct values for but not input values( box2) with flag 0
    util.getRepresentativeId(listButNot,representativeValues,representativeType,percentMatch,0)
    
    
    
    
    #This will map all values except but not values for collateral type name
    for i in range(0,len(representativeValues)):
        if representativeType[i]!='collateral_type_name':
            valueDictMap[representativeType[i]].append(representativeValues[i])
            
    # List to hold results for but not value 
    representativeButNot = []
    
   
    
    for i in range(0,len(representativeValues)):
        if representativeType[i]=='collateral_type_name':
            representativeButNot.append(representativeValues[i])
            
         
    representativeType.clear()
    representativeValues.clear()
    
    # This function will populate the JSON structure with values
    util.populateJson(valueDictMap,0,representativeButNot,jsonList)
    
    
    #Clear all results for next iteration
    valueDictMap.clear()
    representativeButNot.clear()
    
    
    
    ############################################ Actual Posting  ####################################
    
    
    
    
    
    # This is call to function to get correct values for input values for who_has_posted (box3) with flag 1
    util.getRepresentativeId(listWhoHas,representativeValues,representativeType,percentMatch,1)
    
    
    # This loop will map the fieldname and output from above function
    for i in range(0,len(representativeValues)):
        valueDictMap[representativeType[i]].append(representativeValues[i])
        
    
    print(valueDictMap)
     
    #Clear all results for next iteration
    representativeValues.clear()
    representativeType.clear()
    
    
    # This is call to function to get correct values for input values for but not (box4) with flag 1
    util.getRepresentativeId(listButNotHas,representativeValues,representativeType,percentMatch,1)
    
    
    
    
    #This will map all values except but not values for collateral type name
    for i in range(0,len(representativeValues)):
        if representativeType[i]!='collateral_type_name':
            valueDictMap[representativeType[i]].append(representativeValues[i])
            
   
     
    for i in range(0,len(representativeValues)):
        if representativeType[i]=='collateral_type_name':
            representativeButNot.append(representativeValues[i])
            
         
    representativeType.clear()
    representativeValues.clear()
    
    # This function will populate the JSON structure with values
    util.populateJson(valueDictMap,1,representativeButNot,jsonList)
    
    
    
    
    
  ################################################# 
  
    command_list = text.split()
    
    if 'search' in command_list:
        newdict= OrderedDict([('command','search')])
        jsonList.append(newdict)
    
    
    # This will return results (JSON structure) 
    with open('JsonFile.json', 'w') as outfile:
        return (json.dumps(jsonList, indent=4))
    
    
    
    
# Start of Program from main    
if __name__ == '__main__':
    #This is used to get ip address of server on which this cod eis running
    app.run(host=socket.gethostbyname(socket.gethostname()),port=8443,ssl_context=('server.crt','server.key')) 