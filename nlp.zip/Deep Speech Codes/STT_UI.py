# -*- coding: utf-8 -*-
"""
Created on Fri Jun 21 11:32:00 2019

@author: Harsh

"""

import tkinter
from tkinter import *
import sounddevice as sd
import soundfile as sf
from scipy.io.wavfile import write

import pyaudio
import wave
import STT as st

def UI():
    window = Tk()
    #global text
    
    def record(event):
        
        CHUNK = 1024
        FORMAT = pyaudio.paInt16
        CHANNELS = 1
        RATE = 16000
        RECORD_SECONDS = 10
        WAVE_OUTPUT_FILENAME = "output.wav"
    
        p = pyaudio.PyAudio()
        #print('format {}',FORMAT)
        stream = p.open(format = FORMAT, channels = CHANNELS, rate = RATE, input = True, frames_per_buffer = CHUNK)
    
        
        frames  = []
        #print('Nframes: {}',(RATE / CHUNK) * RECORD_SECONDS)
        
    
        for i in range(0, int(RATE / CHUNK * RECORD_SECONDS)):
             data = stream.read(CHUNK)
             frames.append(data)
        
        label.config(text='Recording Done.', fg='green',font = ("Halvetica",8))
        label.place(x=60,y=30) 
        #lbl = Label(window, text ="Recording Done." , fg='blue',font = ("Halvetica",8))
        #lbl.place(x=0,y=50)
        
        stream.stop_stream()
        stream.close()
        p.terminate()
    
        waveFile = wave.open(WAVE_OUTPUT_FILENAME, 'wb') 
        waveFile.setnchannels(CHANNELS)
        waveFile.setsampwidth(p.get_sample_size(FORMAT))
        #print('Sample Width: {}',p.get_sample_size(FORMAT))
        waveFile.setframerate(RATE)
        waveFile.writeframes(b''.join(frames))
        waveFile.close()
    
    def play(event):
        
        filename = 'output.wav'
        # Extract data and sampling rate from file
        data, fs = sf.read(filename, dtype='float32')  
        sd.play(data, fs)
        status = sd.wait()  # Wait until file is done playing
        
    '''
    def convert(event):
        t = st.main()
        
        text=t
        
        label.config(text=t, fg='red',font = ("Halvetica",10))
        label.place(x=0,y=80)
        return text'''
        
        #label = Label(window, text = t , fg='red',font = ("Halvetica",12))
        #label.place(x=0,y=90) 
        
        
        
    """
    def clear(event)
        
         for w in lbl.children.values(): w.destroy()
    """    
    """
    txtfld = Entry(window, text="This is Entry Widget", bd=5)
    txtfld.place(x=60, y=150)
    """
    
    window.title('Speech-to-Text')
    window.geometry("300x200+10+20")
    label = Label(window, text = "Speech-to-text" , fg='red',font = ("Halvetica",10))
    label.place(x=60,y=30) 
    
    #add widgets here
    btn1 = Button(window, text = "Record", fg ='blue')
    btn1.bind('<Button-1>', record)
    btn1.grid(column=1, row=1)
    
    btn2 = Button(window, text = "Play", fg ='blue')
    btn2.bind('<Button-1>', play)
    btn2.grid(column=2, row=1)
    '''
    btn3 = Button(window, text = "Convert", fg = 'blue')
    btn3.bind('<Button-1>', convert)
    btn3.grid(column=3, row=1)'''
    
    
    #lbl = tk.StringVar()
    #lbl.set('STT UI')
    #return text
    window.mainloop()



