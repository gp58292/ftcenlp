# -*- coding: utf-8 -*-
"""
Created on Tue Jun 11 13:12:48 2019

@author: ab57286
"""

import UtilityFunctions as util
import json
from collections import OrderedDict
from flask import Flask, jsonify,request
import pandas as pd
import re
import socket
import collections

 
        
        
    


app = Flask(__name__)
@app.route('/python/collateral', methods=['GET'])        
def get_tasks():
    
    
    
    
    ############################### Common Parameters ############################
    '''
    global CompMap
    CompMap ={'collateral_type_name':'MULTI_INCLUDE_EXCLUDE','party_legal_entity':'DROPDOWN','legal_entity':'DROPDOWN'}'''
    '''
    who_can_contractual = request.args.get('who_can_contractual')
    but_not_contractual =  request.args.get('but_not_contractual')
    who_can_eligible = request.args.get('who_can_eligible')
    but_not_eligible=  request.args.get('but_not_eligible')'''
    
    
    
    
    
    
    listWhoCan=re.split(",|;|\*|\n|' '",request.args.get('who_can_post'))
    listButNot=re.split(",|;|\*|\n|' '",request.args.get('but_not_post'))
    listWhoHas=re.split(",|;|\*|\n|' '",request.args.get('who_has_posted'))
    listButNotHas=re.split(",|;|\*|\n|' '",request.args.get('but_not_posted'))

    
    # This list holds the final JSON structure
    jsonList = []
    
    
    
    
    # This two lists will store the correct value and their filed namefor given input by user.
    # eg uscor,cgmi,inrca ---> [US_CORP,CGMI,INR_CASH]
    #                          [collateral_type_name,party_legal_entity_collateral_type_name]   
    representativeValues=[]
    representativeType = []
    
    
    
    
    
    # This dictionary is used to hold mapping of values against their fieldname'
    # {'collateral_type_name':[US_CROP,INR_CASH],'party_legal_entity':[CGMI]}
    valueDictMap = collections.defaultdict(list)
    
    
    # This holds the percent match for input values wrt to exact values
    percentMatch=0
    
    
    
    ############################ Contractual Posting  ###################################
    
    
    
    
    
    # This is call to function to get correct values for input values for who_can_post (box1) with flag 0
    util.getRepresentativeId(listWhoCan,representativeValues,representativeType,percentMatch,0)
    
    # This loop will map the fieldname and output from above function
    for i in range(0,len(representativeValues)):
        valueDictMap[representativeType[i]].append(representativeValues[i])
        
    
    print(valueDictMap)
    #print(representativeValues)
    #print(representativeType)
    
    
    # Clear all results for next iteration
    representativeValues.clear()
    representativeType.clear()
    
    
    
    # This is call to function to get correct values for but not input values( box2) with flag 0
    util.getRepresentativeId(listButNot,representativeValues,representativeType,percentMatch,0)
    
    
    
    
    #This will map all values except but not values for collateral type name
    for i in range(0,len(representativeValues)):
        if representativeType[i]!='collateral_type_name':
            valueDictMap[representativeType[i]].append(representativeValues[i])
            
    # List to hold results for but not value 
    representativeButNot = []
    
   
    
    for i in range(0,len(representativeValues)):
        if representativeType[i]=='collateral_type_name':
            representativeButNot.append(representativeValues[i])
            
         
    representativeType.clear()
    representativeValues.clear()
    
    # This function will populate the JSON structure with values
    util.populateJson(valueDictMap,0,representativeButNot,jsonList)
    
    
    #Clear all results for next iteration
    valueDictMap.clear()
    representativeButNot.clear()
    
    
    
    ############################################ Actual Posting  ####################################
    
    
    
    
    
    # This is call to function to get correct values for input values for who_has_posted (box3) with flag 1
    util.getRepresentativeId(listWhoHas,representativeValues,representativeType,percentMatch,1)
    
    
    # This loop will map the fieldname and output from above function
    for i in range(0,len(representativeValues)):
        valueDictMap[representativeType[i]].append(representativeValues[i])
        
    
    print(valueDictMap)
    
    #Clear all results for next iteration
    representativeValues.clear()
    representativeType.clear()
    
    
    # This is call to function to get correct values for input values for but not (box4) with flag 1
    util.getRepresentativeId(listButNotHas,representativeValues,representativeType,percentMatch,1)
    
    
    
    
    #This will map all values except but not values for collateral type name
    for i in range(0,len(representativeValues)):
        if representativeType[i]!='collateral_type_name':
            valueDictMap[representativeType[i]].append(representativeValues[i])
            
   
     
    for i in range(0,len(representativeValues)):
        if representativeType[i]=='collateral_type_name':
            representativeButNot.append(representativeValues[i])
            
         
    representativeType.clear()
    representativeValues.clear()
    
    # This function will populate the JSON structure with values
    util.populateJson(valueDictMap,1,representativeButNot,jsonList)
    
    
    
    
    
  #################################################  
    # This will return results (JSON structure) 
    with open('JsonFile.json', 'w') as outfile:
        return (json.dumps(jsonList, indent=4))
    
    
    
    
# Start of Program from main    
if __name__ == '__main__':
    #This is used to get ip address of server on which this cod eis running
    app.run(host=socket.gethostbyname(socket.gethostname()),port=5003)    