#!/bin/bash

echo "Starting AQUA NLP Webserver...."

export PATH="/opt/middleware/redhat_python/3.6.3/bin:$PATH" 

nohup python Main.py 
