# -*- coding: utf-8 -*-
"""
Created on Mon Jul  8 16:15:48 2019

@author: ab57286
"""

import socket
import sys

s = socket.socket()
s.connect(("localhost",9999))
f = open ("output.wav", "rb")
l = f.read(1024)
while (l):
    s.send(l)
    l = f.read(1024)
    
    
    
    
# client code    
    
    
s.close()