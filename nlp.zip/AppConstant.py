# -*- coding: utf-8 -*-
"""
Created on Wed Jun 12 17:42:56 2019

@author: ab57286
"""
################################## Data File ########################





#Component getter function    
def getComponent():
    
    compMap ={'collateral_type_name':'MULTI_INCLUDE_EXCLUDE','party_legal_entity':'DROPDOWN','legal_entity':'DROPDOWN'}
    return compMap


# Filedname getter function
def getSetMap():
    
    
    
    dataSetMapCan = dict([(n,'collateral_type_name') for n in range(0,186)]+[(n,'party_legal_entity') for n in range(186,372)])
    dataSetMapHas = dict([(n,'collateral_type_name') for n in range(0,186)]+[(n,'legal_entity') for n in range(186,372)])
    # dataSetMapCan = {0:'collateral_type_name',1:'party_legal_entity'}
    #dataSetMapHas = {0:'collateral_type_name',1:'legal_entity'}
    
    return dataSetMapCan,dataSetMapHas
    
    