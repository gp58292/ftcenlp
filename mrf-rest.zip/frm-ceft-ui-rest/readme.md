#### build
gradle build

#### run
gradle bootRun

#### swagger ui
```jshelllanguage
http://localhost:8080/swagger-ui.html
```

#### Artifactory authentication setup
please setup your credentials in ~/.gradle/gradle.properties
```jshelllanguage
artifactRepositoryUser=tg11567
artifactRepositoryPassword=XXXXX
```