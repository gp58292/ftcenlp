package com.citi.aqua.derivz.vo;

import java.sql.Date;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class BoxDataVO {

	private Date busDate;

	private String legalEntityNumber;

	private String cusip;

	private String positionType;

	private Long quantity;

	private Long marketValueUSD;

	private Long loanValueUSD;

	private Long haircutPercentage;

	private Double price;

	private Date dataDate;

	private String firmCode;

	private String firmCodeShortName;

	private String cusipDescription;

	private String isin;

	private Date matuarityDate;

	private String issuerName;

	private String custodian;

	private String issueCurrency;

	private String treasuryClass;

	private String tLevel2;

	private Long mvAi;

	private String moody;

	private String sAndP;

	private String marketSectorDescription;

	private String country;

	private String lcrAssetLevel;

	private String collateralSourceSystem;



	/**
	 * @return the tLevel2
	 */
	public String gettLevel2() {
		return tLevel2;
	}

	/**
	 * @param tLevel2
	 *            the tLevel2 to set
	 */
	public void settLevel2(String tLevel2) {
		this.tLevel2 = tLevel2;
	}

	/**
	 * @return the sAndP
	 */
	public String getsAndP() {
		return sAndP;
	}

	/**
	 * @param sAndP
	 *            the sAndP to set
	 */
	public void setsAndP(String sAndP) {
		this.sAndP = sAndP;
	}

}