package com.citi.aqua.derivz.services.grid.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Map;

/**
 * @author Aleksander Nowinski, aleksander.nowinski@citi.com
 * @since 6/21/2019
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class SearchQueryResult {
    private List<Map<String, Object>> values;
    private List<ColumnValues> pivotColumns;
    private long limit;
    private long offset;
}
