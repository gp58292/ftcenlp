package com.citi.aqua.derivz.data.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.citi.aqua.derivz.model.TableMetaData;
import com.citi.aqua.derivz.model.TableMetaData.TableMetadataKey;

/**
 * @name 
 * @description Interface for TableMetadata table
 *
 */
@Repository
public interface TableMetadataRepository extends CrudRepository<TableMetaData, TableMetadataKey> {
	
	List<TableMetaData> findByTableName(String tableName);
}
