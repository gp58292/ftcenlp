package com.citi.aqua.derivz.websocket;

import com.citi.aqua.derivz.services.grid.CeftDataSet;
import com.citi.aqua.derivz.services.grid.CeftDataSetStatus;
import com.citi.aqua.derivz.services.grid.LoadingProgressTracker;
import com.citi.aqua.frm.framework.grid.data.DataSetLoadingMsg;
import com.citi.aqua.frm.framework.grid.data.DataSetStatusCode;
import com.citi.aqua.frm.framework.grid.data.DefaultTopicNameConstants;
import com.citi.aqua.frm.framework.grid.data.ProcessLoadingMsg;
import com.citi.aqua.frm.framework.grid.utils.JSONUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.ignite.Ignite;
import org.apache.ignite.IgniteException;
import org.apache.ignite.events.EventType;
import org.apache.ignite.lang.IgniteBiPredicate;
import org.apache.ignite.lifecycle.LifecycleBean;
import org.apache.ignite.lifecycle.LifecycleEventType;
import org.apache.ignite.resources.IgniteInstanceResource;
import org.atmosphere.config.service.Disconnect;
import org.atmosphere.config.service.ManagedService;
import org.atmosphere.config.service.Ready;
import org.atmosphere.cpr.AtmosphereResource;
import org.atmosphere.cpr.AtmosphereResourceEvent;
import org.atmosphere.cpr.AtmosphereResourceFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.Optional;
import java.util.UUID;

@Slf4j
@Component
@ManagedService(path = "/websocket/dataservice")
@Profile("ignite")
public class WebsocketDataLoadingService implements LifecycleBean {

    @IgniteInstanceResource
    private Ignite ignite;
    private final AtmosphereResourceFactory atmosphereResourceFactory;
    private LoadingProgressTracker loadingProgressTracker;

    @Autowired
    public WebsocketDataLoadingService(AtmosphereResourceFactory atmosphereResourceFactory,
            Optional<LoadingProgressTracker> loadingProgressTracker) {
        this.atmosphereResourceFactory = atmosphereResourceFactory;
        loadingProgressTracker.ifPresent(progressTracker -> {
            this.loadingProgressTracker = progressTracker;
        });
    }


    @Ready
    public void onReady(final AtmosphereResource resource) {
        log.trace("onReady... " + resource.uuid());
    }

    @Disconnect
    public void onDisconnect(AtmosphereResourceEvent event) {
        if (event.isCancelled()) {
            log.info("Browser {} unexpectedly disconnected", event.getResource().uuid());
        } else if (event.isClosedByClient()) {
            log.info("Browser {} closed the connection", event.getResource().uuid());
        }
        atmosphereResourceFactory.remove(event.getResource().uuid());
    }


    public void bindMessaging() {
        IgniteBiPredicate<UUID, Object> processingBiPredicate = (uuid, message) -> {
            try {
                if (ProcessLoadingMsg.class.isInstance(message)) {
                    executeProgressMessage((ProcessLoadingMsg) message);
                } else if (DataSetLoadingMsg.class.isInstance(message)) {
                    processStatusMessage((DataSetLoadingMsg) message);
                } else {
                    log.warn("Unexpected message with class {}, message: {} ", message.getClass(), message);
                }
            } catch (Exception exc) {
                //we want not to stop because of single exception
                log.warn("Exception on ignite messaging, resuming.", exc);
            }
            return true;
        };
        ignite.message().localListen(DefaultTopicNameConstants.DEFAULT_LOADING_PROGRESS_TOPIC, processingBiPredicate);
//        ignite.message().localListen(DefaultTopicNameConstants.DEFAULT_DATA_SET_STATUS_TOPIC, processingBiPredicate);
    }

    private void processStatusMessage(DataSetLoadingMsg message) {
        String uuid = loadingProgressTracker.findUUID(message.getDataSetId(), message.getDataSetVersion());
        //we are not sending oryginal user back and forth, it is easier to get it back from request maping
        CeftDataSet dataSet = loadingProgressTracker.findDataSet(message.getDataSetId(), message.getDataSetVersion());

        if (uuid == null || dataSet == null) {
            //this is the case we did not initialize request via "requestDataSet" api method, we may skip
            return;
        }

        DataSetStatusCode type;
        long count = 0L;
        long total = Optional.ofNullable(message.getTotalSize()).orElse(-1L);
        switch (message.getOperationType()) {
            case FINISHED:
                type = DataSetStatusCode.READY;
                count=total;
                break;
            case STARTED:
                type = DataSetStatusCode.LOADING;
                break;
            case CANCEL:
            case FAILED:
            default:
                type = DataSetStatusCode.NOT_LOADED;
        }

        CeftDataSetStatus rstatus =
                new CeftDataSetStatus(dataSet, new Date(message.getDataSetVersion()), type, count, total, uuid);
        sendMessage(rstatus, uuid);
    }

    private void sendMessage(Object msg, String uuid) {
        //we should at least filter user according to msg.dataSet.soeId here
        //we can do it when integration on frontend will do.\
        log.debug("Sending message over atmosphere resource {}, message: {}", uuid, msg);
        AtmosphereResource socket = atmosphereResourceFactory.find(uuid);
        if (socket != null) {
            String textMessage = JSONUtils.stringify(msg);
            socket.write(textMessage);
        } else {
            log.debug("No socket with id {} found.", uuid);
        }
    }


    private void executeProgressMessage(ProcessLoadingMsg message) {
        String uuid = loadingProgressTracker.findUUID(message.getDataSetId(), null);
        //we are not sending original user back and forth, it is easier to get it back from request maping
        CeftDataSet dataSet = loadingProgressTracker.findDataSet(message.getDataSetId(), null);


        if (uuid == null || dataSet == null) {
            //this is the case we did not initialize request via "requestDataSet" api method.
            return;
        }

        DataSetStatusCode code;
        switch (message.getStatus()) {
            case SUCCESS:
                code = DataSetStatusCode.READY;
                break;
            case RUNNING:
                code = DataSetStatusCode.LOADING;
                break;
            default:
                code = DataSetStatusCode.NOT_LOADED;
        }
        CeftDataSetStatus rstatus = new CeftDataSetStatus(dataSet, new Date(message.getDataSetVersion()), code,
                message.getProcessedItemCount(),
                Optional.ofNullable(message.getTotalCount()).orElse(-1L), uuid);
        sendMessage(rstatus, uuid);
    }


    @Override
    public void onLifecycleEvent(LifecycleEventType event) throws IgniteException {
        if (event == LifecycleEventType.AFTER_NODE_START) {
            log.info("Inititing messaging.");
            bindMessaging();
            ignite.events().localListen(evt -> {
                if (EventType.EVT_CLIENT_NODE_RECONNECTED == evt.type()) {
                    bindMessaging();
                } else {
                    log.info(
                            "Unable to restore remote Ignite message listener for dataset updates. Quite likely that node is disconnected");
                }
                return true;
            }, EventType.EVT_CLIENT_NODE_RECONNECTED, EventType.EVT_CLIENT_NODE_DISCONNECTED);
        }
    }
}
