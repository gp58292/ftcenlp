package com.citi.aqua.derivz.data.repository;

import java.util.List;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import com.citi.aqua.derivz.model.CustomAttributes;

@Repository
public interface CustomFieldRepository extends CrudRepository<CustomAttributes, Long> {

	// This method is used to find all the available filters without any
	// restrictions applied to them
	public List<CustomAttributes> findAllByOrderByLogicalGroupAsc();

	public List<CustomAttributes> findAllByOrderByDisplayNameAsc();

	// @Cacheable(value="TreeViewFilterListCache",keyGenerator="customKeyGenerator")
	// This method is used to find only those filters with the params listed keys
	public List<CustomAttributes> findByFilterKeyIn(final List<Long> keys);

	// This method is used to find individual filter with the parameter key
	public CustomAttributes findByFilterKey(final Long attributeKey);

	public List<CustomAttributes> findByComponentTypeIn(final List<String> componentTypes);

	// This method is used to define the predefined results only
	public List<CustomAttributes> findTop20ByNodeName(final String nodeName);

	// This method is used to load all data
	public List<CustomAttributes> findAll();

	public List<CustomAttributes> findByIsDisplayed(final int value);

	public List<CustomAttributes> findByCollateralLookup(final int value);

}
