package com.citi.aqua.derivz.services.grid.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;

/**
 * @author Aleksander Nowinski, aleksander.nowinski@citi.com
 * @since 7/9/2019
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ColumnAggregation {
    String column;
    Aggregation aggregation;

    public enum Aggregation {
        SUM("SUM"), AVG("AVG"), MIN("MIN"), MAX("MAX"), COUNT("COUNT"), FIRST("ANY");
        @Getter
        private final String function;

        Aggregation(String function) {
            this.function = function;
        }
    }
}
