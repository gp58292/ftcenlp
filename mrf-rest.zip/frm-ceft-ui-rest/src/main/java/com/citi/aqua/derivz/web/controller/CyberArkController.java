package com.citi.aqua.derivz.web.controller;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.citi.aqua.derivz.commons.constants.DerivzAPIUriConstants;
import com.citi.aqua.derivz.security.cyberark.CyberArkFactory;
import com.citi.secretagentclient.SecretAgentClient;

@Controller
@RequestMapping(DerivzAPIUriConstants.CYBERARK_API_URI)
public class CyberArkController {
	
		
		private static final Logger LOGGER = LoggerFactory.getLogger(CyberArkController.class);

		@GetMapping(value = "/getPassword/{appId}/{safe}/{object}")
		public @ResponseBody String checkConnection(@PathVariable String appId, @PathVariable String safe,@PathVariable String object) {
			
			LOGGER.debug("CyberArcTestController.checkConnection() ::starts ");
			LOGGER.info("CyberArkFactory -> Fetching password with query [appId{}; Safe={}; Object={}].",appId,safe,object);
			try {
				CyberArkFactory factory= new CyberArkFactory();
				return factory.getPassword(appId, safe, object, "Test_Connection");
			} catch (Exception e) {
				LOGGER.error("CyberArcTestController.checkConnection() ::error " + e, e);
				return "Error in getting connection as " + e;
			}
		}
		
		@GetMapping(value = "/getPasswordUsingNickname/{cyberarkNickname}")
		public @ResponseBody String getPasswordUsingNickname(@PathVariable String cyberarkNickname) {
			
			LOGGER.info("CyberArkFactory -> Fetching password with query [cyberarkNickname{};].",cyberarkNickname);
			try {
				SecretAgentClient secretAgentClient= new SecretAgentClient();
				return secretAgentClient.getPassword(cyberarkNickname) ;
			} catch (Exception e) {
				LOGGER.error("CyberArcTestController.getPasswordUsingNickname() ::error " + e, e);
				return "Error in getting connection as " + e;
			}
		}

}
