package com.citi.aqua.derivz.dto;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
@Getter
@Setter
@ToString
public class BatchStatusResponseDTO {

	private String sourceData;
	private String bau;
	private String sla;
	private Date dbBusinessDate;
	private Date uiBusinessDate;
	private String comments;
	private int dataExist;
	private boolean isDelayedFeed;
	
}