package com.citi.aqua.derivz.config;

import com.citi.aqua.derivz.services.grid.CeftFrmGroupingPivotQueryService;
import com.citi.aqua.derivz.services.grid.CeftFrmQueryService;
import com.citi.aqua.derivz.services.grid.LoadingProgressTracker;
import com.citi.aqua.derivz.services.grid.LoadingStatusService;
import com.citi.aqua.derivz.services.grid.impl.CeftFrmGroupingPivotQueryServiceImpl;
import com.citi.aqua.derivz.services.grid.impl.CeftFrmQueryServiceImpl;
import com.citi.aqua.derivz.services.grid.impl.LoadingStatusServiceImpl;
import com.citi.aqua.derivz.services.grid.postprocessing.ColumnNamePostprocessor;
import com.citi.aqua.derivz.services.grid.postprocessing.RowPostprocessor;
import com.citi.aqua.derivz.services.grid.postprocessing.SearchQueryPostprocessor;
import com.citi.aqua.frm.framework.client.FrmGridClientNodeConfig;
import com.citi.aqua.frm.framework.grid.tools.FrmGrid;
import com.citi.aqua.frm.framework.messaging.config.MessagingConfig;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Profile;

import java.util.List;

/**
 * @author Aleksander Nowinski, aleksander.nowinski@citi.com
 * @since 1/11/2019
 */
@Configuration
@Import({FrmGridClientNodeConfig.class, MessagingConfig.class})
@Profile("ignite")
public class FrmGridConfiguration {

    @Bean
    LoadingProgressTracker loadingProgressTracker() {
        return new LoadingProgressTracker();
    }

    @Bean
    LoadingStatusService igniteLoadingStatusService(FrmGrid grid,
            LoadingProgressTracker progressTracker) {
        LoadingStatusServiceImpl res = new LoadingStatusServiceImpl(grid, progressTracker);
        return res;
    }


    @Bean
    RowPostprocessor lowercaseColumnNamePostprocessor() {
        return new ColumnNamePostprocessor(name -> name.toLowerCase());
    }

    @Bean
    SearchQueryPostprocessor postprocessor(List<RowPostprocessor> rowPostprocessors) {
        return new SearchQueryPostprocessor(rowPostprocessors);
    }

    @Bean
    CeftFrmQueryService igniteQueryService(FrmGrid grid,
            SearchQueryPostprocessor postprocessor) {
        CeftFrmQueryServiceImpl res = new CeftFrmQueryServiceImpl(grid, postprocessor);
        return res;
    }

    @Bean
    CeftFrmGroupingPivotQueryService pivotQueryService(FrmGrid grid, SearchQueryPostprocessor postprocessor,
            CeftFrmQueryService queryService) {
        return new CeftFrmGroupingPivotQueryServiceImpl(grid, postprocessor, queryService);
    }


}
