package com.citi.aqua.derivz.config;

import com.citi.aqua.derivz.services.grid.CeftFrmQueryService;
import com.citi.aqua.derivz.services.grid.LoadingStatusService;
import com.citi.aqua.derivz.services.grid.mock.CeftFrmQueryServiceMock;
import com.citi.aqua.derivz.services.grid.mock.LoadingStatusServiceMock;
import com.citi.aqua.frm.framework.client.FrmGridClientNodeConfig;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Profile;

/**
 * @author Aleksander Nowinski, aleksander.nowinski@citi.com
 * @since 1/11/2019
 */
@Configuration
@Import(FrmGridClientNodeConfig.class)
@Profile("!ignite")
public class MockGridConfiguration {

    @Bean
    public LoadingStatusService buildLoadingStatusService() {
        return new LoadingStatusServiceMock();
    }

    @Bean
    public CeftFrmQueryService buildQueryService() {
        return new CeftFrmQueryServiceMock();
    }


}
