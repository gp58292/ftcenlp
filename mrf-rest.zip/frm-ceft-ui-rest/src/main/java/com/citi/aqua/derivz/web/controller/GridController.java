package com.citi.aqua.derivz.web.controller;

import com.citi.aqua.derivz.services.grid.*;
import com.citi.aqua.derivz.services.grid.model.*;
import com.citi.aqua.frm.ceft.CeftDataSetType;
import com.google.common.base.Stopwatch;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @author Aleksander Nowinski, aleksander.nowinski@citi.com
 * @since 6/19/2019
 * @Modified Viraj
 */
@Slf4j
@RestController
@RequestMapping("/api/grid")
public class GridController {

    @Autowired
    LoadingStatusService loadingStatusService;

    @Autowired
    CeftFrmQueryService queryService;

    @Autowired
    CeftFrmGroupingPivotQueryService groupingPivotQueryService;


    @GetMapping(value = "set/{bookmark}/{dataSet}/loaded")
    public boolean isLoaded(@PathVariable long bookmark, @PathVariable String dataSet, String soeid) {
        return loadingStatusService.isDataSetReady(
                new CeftDataSet(soeid, bookmark, CeftDataSetType.findByCode(dataSet)));
    }

    @GetMapping(value = "set/{bookmark}/{dataSet}/load")
    public String loadData(@PathVariable long bookmark, @PathVariable CeftDataSetType dataSet, String soeid) {
        loadingStatusService.loadData(new CeftDataSet(soeid, bookmark, dataSet));
        return "Loading initialized.";
    }


    @RequestMapping(value = "set/{bookmark}/{dataSet}/requestDataSet", method = RequestMethod.GET)
    CeftDataSetStatus requestDataSet(@PathVariable long bookmark, @PathVariable String dataSet,
            String soeid, @RequestParam(name = "socket", required = false) String atmosphereResource) {
        CeftDataSet set = new CeftDataSet(soeid, bookmark, CeftDataSetType.findByCode(dataSet));
        log.info("Requestind data set {}", set);
        CeftDataSetStatus result = loadingStatusService.requestDataSet(set, atmosphereResource);
        log.info("Got result: {}", result);
        return result;
    }

    @GetMapping(value = "set/{bookmark}/{dataSet}/status")
    public  CeftDataSetStatus loadingStatus(@PathVariable long bookmark, @PathVariable CeftDataSetType dataSet, String soeid) {
        return loadingStatusService.dataSetStatus(new CeftDataSet(soeid, bookmark, dataSet));
    }

    @GetMapping(value = "set/{bookmark}/status")
    public CeftDataSetStatus[] loadingStatus(@PathVariable long bookmark, String soeid) {
        return loadingStatusService.dataSetStatusForBookmark(soeid, bookmark);
    }


    @PostMapping(value = "count")
    public long countQuery(CountDataRequest request) {
        log.info("Request to count, Data set: {}, request: {}", request.getDataSet(), request);
        long size = queryService.countQuery(request);
        log.info("Query result size: {}", size);
        return size;
    }

    @PostMapping(value = "query")
   public  SearchQueryResult searchQuery(SearchDataRequest request) {
        log.info("Request to count, Data set: {}, request: {}", request.getDataSet(), request);
        SearchQueryResult result = queryService.searchQuery(request);
        log.info("Query result : {}", result);
        return result;
    }

    @PostMapping(value = "distinct")
    public List<Object> distinctValuesQuery(DistinctValueDataRequest request) {
        log.info("Request to get distinct values for query, Data set: {}, column: {} request: {}", request.getDataSet(),
                request.getColumn(), request);
        List<Object> result = queryService.distinctValuesQuery(request);
        log.info("Query result : {}", result);
        return result;
    }



    @RequestMapping(value = "grouping-query", method = RequestMethod.POST)
    SearchQueryResult searchGroupingQuery(@RequestBody GroupingSearchDataRequest request) {
        log.info("Request to perform grouping rows request, Data set: {}, request: {}", request.getDataSet(), request);
        return groupingPivotQueryService.searchQueryGrouping(request);
    }


    @RequestMapping(value = "grouping-count", method = RequestMethod.POST)
    long countGroupingQuery(@RequestBody GroupingSearchDataRequest request) {
        log.info("Request to perform grouping rows request, Data set: {}, request: {}", request.getDataSet(), request);
        return groupingPivotQueryService.countQueryGrouping(request);
    }
    @RequestMapping(value = "pivot-query", method = RequestMethod.POST)
    SearchQueryResult searchPivotQuery(@RequestBody GroupingSearchDataRequest request) {
        log.info("Pivot query,  Data set: {}, request: {}", request.getDataSet(), request);
        Stopwatch started = Stopwatch.createStarted();
        SearchQueryResult result = groupingPivotQueryService.pivotQuery(request);
        log.debug("Pivot query, request completed in {}",started.elapsed());
        return result;
    }


    @RequestMapping(value = "pivot-count", method = RequestMethod.POST)
    long countPivotQuery(@RequestBody GroupingSearchDataRequest request) {
        log.info("Request to perform grouping rows request, Data set: {}, request: {}", request.getDataSet(), request);
        return groupingPivotQueryService.countPivotQuery(request);
    }

}
