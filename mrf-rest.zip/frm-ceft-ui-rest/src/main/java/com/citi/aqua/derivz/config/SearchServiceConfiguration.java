package com.citi.aqua.derivz.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.jdbc.core.JdbcTemplate;

import com.citi.aqua.derivz.data.jdbc.SearchResultDAO;
import com.citi.aqua.derivz.services.grid.CeftFrmQueryService;
import com.citi.aqua.derivz.services.grid.LoadingStatusService;
import com.citi.aqua.derivz.services.service.impl.SearchResultServiceImpl;

/**
 * @author Aleksander Nowinski, aleksander.nowinski@citi.com
 * @since 1/11/2019
 */
@Configuration
@Profile("ignite")
public class SearchServiceConfiguration {
	@Autowired
	private LoadingStatusService loadingStatusService;
	@Autowired
	private CeftFrmQueryService queryService;
	
    @Bean
    SearchResultDAO searchResultDAO() {
    	SearchResultServiceImpl res = new SearchResultServiceImpl(loadingStatusService,queryService );
        return res;
    }
    
}
