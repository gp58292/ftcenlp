package com.citi.aqua.derivz.vo;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class FilterColumnVO {

	String columnName;

	String labelName;

	int index;

	String type;

}