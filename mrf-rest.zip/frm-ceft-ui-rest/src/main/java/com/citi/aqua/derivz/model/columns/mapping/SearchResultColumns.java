package com.citi.aqua.derivz.model.columns.mapping;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import com.citi.aqua.derivz.model.BaseEntity;
import com.citi.aqua.derivz.model.DerivzDBConstants;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Entity
@Table(name = DerivzDBConstants.TBL_FIELD_MAPPING, schema=DerivzDBConstants.SCHEMA_CEFT)
public class SearchResultColumns extends BaseEntity {

	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "uniq_key")
	private long key;
	
	@Column(name = "field_name")
	private String fieldName;
	
	@Column(name = "display_name")
	private String displayName;
	
	@Column(name = "tab_name")
	private String tabName;
	
	@Column(name = "tab_id")
    private String tabId;
	
	@Column(name = "field_type",length = 8)
	@Enumerated(EnumType.STRING)
	private FieldDataType fieldType;
	
	@Column(name = "is_search_flag",columnDefinition="INT(1)")
	private Boolean isSearchable;
	
	@Column(name = "is_enable",columnDefinition="INT(1)")
    private Boolean isEnabled;
	
	@Column(name = "tab_voyager_id")
	private String tabVoyagerId;
	
	@Column(name = "field_order")
	private Integer fieldOrder;
	
	@Column(name = "default_display_flag",columnDefinition="INT(1)")
	private Boolean isDefaultDisplay;
	
	@Column(name = "tab_order")
	private Integer tabOrder;
}
