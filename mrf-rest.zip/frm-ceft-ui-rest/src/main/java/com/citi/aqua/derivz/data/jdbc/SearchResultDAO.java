package com.citi.aqua.derivz.data.jdbc;


import java.util.List;
import org.springframework.stereotype.Repository;
import com.citi.aqua.derivz.commons.exceptions.CEFTException;
import com.citi.aqua.derivz.dto.ListDataResponseDTO;
import com.citi.aqua.derivz.model.columns.mapping.SearchResultColumns;
import com.citi.aqua.derivz.vo.AgreementOptimalRankVO;
import com.citi.aqua.derivz.vo.RatingFieldVO;
import com.citi.aqua.derivz.vo.aggrid.request.EnterpriseGetRowsRequest;

@Repository
public interface SearchResultDAO {


	@SuppressWarnings("rawtypes")
	public ListDataResponseDTO retriveResultsFromDB(final String tabName,final List<SearchResultColumns> searchResultColumnsList,
	            final Boolean isFilterd,
	            final List<Long> agreementKeyList,
	            final List<AgreementOptimalRankVO> agreementOptimalRanks,
	            final List<String[]> rowList,
	            final String collatralTypeNamesCSV,
	            final List<RatingFieldVO> listOfRangeField,
	            final List<SearchResultColumns> smsColumns, List<String[]> listOfTenorRange) throws CEFTException;

	public ListDataResponseDTO retriveDatasetResultsUsingBookmarkId(String datasetType,
			List<SearchResultColumns> searchResultColumnsList, String userId, Long bookmarkId,
			EnterpriseGetRowsRequest gridRequest) throws CEFTException;

}