package com.citi.aqua.derivz.utils;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.springframework.stereotype.Component;

import com.citi.aqua.derivz.vo.ReferenceDataVO;

@Component
public class ReferenceUtils {

	@SuppressWarnings("rawtypes")
	public List<ReferenceDataVO> findSearchedList(final List<ReferenceDataVO> distinctValueList, final String valueAlike) {
		List<ReferenceDataVO> referenceDataList = new ArrayList<>();

		final List<ReferenceDataVO> exactMatchList = distinctValueList.parallelStream()
				.filter(p -> p.getValue().toString().equals(valueAlike)).collect(Collectors.toList());
		final List<ReferenceDataVO> startMatchList = distinctValueList.parallelStream()
				.filter(p -> p.getValue().toString().toUpperCase().startsWith(valueAlike.toUpperCase()))
				.collect(Collectors.toList());
		final Pattern pattern = Pattern.compile(".*" + valueAlike.toUpperCase() + ".*");
		final List<ReferenceDataVO> includeMatchList = distinctValueList.parallelStream()
				.filter(p -> pattern.matcher(p.getValue().toString().toUpperCase()).find())
				.collect(Collectors.toList());

		exactMatchList.addAll(startMatchList);
		exactMatchList.addAll(includeMatchList);

		referenceDataList = exactMatchList.stream().distinct().collect(Collectors.toList());
		return referenceDataList;

	}

}
