package com.citi.aqua.derivz.services.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;

import org.dozer.DozerBeanMapper;
import org.dozer.loader.api.BeanMappingBuilder;
import org.dozer.loader.api.TypeMappingOptions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.citi.aqua.derivz.commons.constants.DerivzBeanConstants;
import com.citi.aqua.derivz.commons.constants.DerivzCommonConstants;
import com.citi.aqua.derivz.commons.exceptions.CEFTException;
import com.citi.aqua.derivz.commons.exceptions.DerivzApplicationException;
import com.citi.aqua.derivz.commons.exceptions.DerivzDAOLayerException;
import com.citi.aqua.derivz.commons.utils.DBCommonUtils;
import com.citi.aqua.derivz.data.cache.eh.StaticCacheKeys;
import com.citi.aqua.derivz.data.jdbc.SearchDAO;
import com.citi.aqua.derivz.data.jdbc.SearchResultDAO;
import com.citi.aqua.derivz.data.repository.BaseRepository;
import com.citi.aqua.derivz.data.repository.DimAgreementRepository;
import com.citi.aqua.derivz.data.repository.DistinctValuesRepository;
import com.citi.aqua.derivz.data.repository.SelectionFiltersRepository;
import com.citi.aqua.derivz.dto.CollateralResponseDTO;
import com.citi.aqua.derivz.dto.ListDataResponseDTO;
import com.citi.aqua.derivz.dto.ListedResponseDTO;
import com.citi.aqua.derivz.enums.ComponentType;
import com.citi.aqua.derivz.enums.OPERATION;
import com.citi.aqua.derivz.model.DerivzDBConstants;
import com.citi.aqua.derivz.model.DimAgreement;
import com.citi.aqua.derivz.model.SelectionFilters;
import com.citi.aqua.derivz.model.VoyagerNavigationData;
import com.citi.aqua.derivz.model.VoyagerNavigationLink;
import com.citi.aqua.derivz.model.columns.mapping.SearchResultColumns;
import com.citi.aqua.derivz.services.service.CacheService;
import com.citi.aqua.derivz.services.service.UserSearchCriteriaService;
import com.citi.aqua.derivz.vo.AgreementOptimalRankVO;
import com.citi.aqua.derivz.vo.IncludeExcludeListWrapper;
import com.citi.aqua.derivz.vo.IncludeExcludeVO;
import com.citi.aqua.derivz.vo.RangeVO;
import com.citi.aqua.derivz.vo.RatingFieldVO;
import com.citi.aqua.derivz.vo.RatingRange;
import com.citi.aqua.derivz.vo.RatingRangeList;
import com.citi.aqua.derivz.vo.RatingRangeListWrapper;
import com.citi.aqua.derivz.vo.ReferenceDataVO;
import com.citi.aqua.derivz.vo.SearchCriteriaResultVO;
import com.citi.aqua.derivz.vo.SearchFieldVO;
import com.citi.aqua.derivz.vo.TenorRange;
import com.citi.aqua.derivz.vo.TenorRangeList;
import com.citi.aqua.derivz.vo.UserDatasetVO;
import com.citi.aqua.derivz.vo.aggrid.request.EnterpriseGetRowsRequest;

@Service(DerivzBeanConstants.SEARCH_CRITERIA_SERVICE_BEAN)
public class UserSearchCriteriaServiceImpl implements UserSearchCriteriaService {

	private static final String FROM_ACTUAL_POSTINGS_NOTIN = "4";
	private static final String FROM_CONTRACTUAL_ELIGIBILITY_NOTIN = "2";
	private static final String FROM_ACTUAL_POSTINGS_IN = "3";
	private static final String FROM_CONTRACTUAL_ELIGIBILITY_IN = "1";
	private static final Integer WHO_CAN_FLAG = new Integer(0);
	private static final Logger LOGGER = LoggerFactory.getLogger(UserSearchCriteriaServiceImpl.class);
	public static final String QUERY_DELIMETER = "|~";
	public static final String UNDERSCORE_DELIMETER = "_";

	@Autowired
	DBCommonUtils commonUtils;

	@Autowired
	BaseRepository baseRepository;

	@Autowired
	DimAgreementRepository dimAgreementRepository;

	@Autowired
	SearchDAO searchDAO;

	@Autowired
	SearchResultDAO searchResultDAO;

	@Autowired
	DistinctValuesRepository distinctValuesRepository;

	@Autowired
	CacheService cachingService;

	@Autowired
	SelectionFiltersRepository selectionFiltersRepository;

	@Autowired
	VoyagerNavigationLink voyagerConfig;

	/**
	 * @name findUserFilterSearch
	 * @description This method is used to get the MAC data for the search fields
	 *              selected by user.
	 * @return list
	 * @param selectionFilterVOList
	 */
	@SuppressWarnings("rawtypes")
	public ListedResponseDTO findUserFilterSearch(List<SearchFieldVO> selectionFilterVOList) {
		LOGGER.debug("UserSearchCriteriaServiceImpl:: findUserFilterSearch() ");
		final ListedResponseDTO listedResponseDTO = new ListedResponseDTO();
		try {
			final ListDataResponseDTO listDataResponseDTO = searchDAO.callMacDataRetrivalProc(
					formatCriteriaObjectForRows(selectionFilterVOList), formatRatingInRows(selectionFilterVOList));
			final List<SearchCriteriaResultVO> searchCriteriaResultList = createSearchCriteriaResult(
					listDataResponseDTO.getDimAgreementList());
			listedResponseDTO.setCobDate(listDataResponseDTO.getCobDate());
			listedResponseDTO.setCount(listDataResponseDTO.getCount());
			listedResponseDTO.setSearchCriteriaResultList(searchCriteriaResultList);
		} catch (DerivzApplicationException e) {
			LOGGER.error(
					"UserFilterSearchServiceImpl::findUserFilterSearch() :: DerivzApplicationException occured " + e,
					e);
			throw new DerivzApplicationException(e, DerivzDAOLayerException.FAILED_SEARCH_PROCEDURE);
		} catch (Exception e) {
			LOGGER.error("UserFilterSearchServiceImpl::findUserFilterSearch() :: Exception occured " + e, e);
			throw new DerivzApplicationException(e, DerivzDAOLayerException.FAILED_SEARCH_PROCEDURE);
		}
		return listedResponseDTO;
	}

	private List<String> nullCheckReplacement(ReferenceDataVO<String>[] referenceDataVOArray) {
		return Arrays.asList(referenceDataVOArray).parallelStream().map(ReferenceDataVO::getValue)
				.map(indVal -> indVal.equalsIgnoreCase(DerivzDBConstants.NULL_VALUE_CHECK) ? " " : indVal)
				.collect(Collectors.toList());
	}

	@SuppressWarnings("rawtypes")
	private final String[] updateFieldRecords(final SearchFieldVO criteriaObject) {
		final String[] fieldsValues = new String[5];
		final String fieldName = criteriaObject.getFieldName();
		if (null != fieldName && !fieldName.equals("") && !fieldName.contains(UNDERSCORE_DELIMETER)) {
			fieldsValues[0] = DBCommonUtils.replaceCamelCaseToUnderscoreSeparated(fieldName);
		} else {
			fieldsValues[0] = fieldName;
		}
		fieldsValues[1] = DerivzDBConstants.SCHEMA_DZ + "." + criteriaObject.getNodeName();
		fieldsValues[4] = criteriaObject.getWhoHasFlag().toString();

		return fieldsValues;
	}

	private void updateDropDwonTypeAheadValues(final SearchFieldVO<ReferenceDataVO<String>[]> criteriaObject,
			final List<String[]> rowsList) {
		final String[] fieldsValues = updateFieldRecords(criteriaObject);
		List<String> valueList = nullCheckReplacement(criteriaObject.getValue());
		fieldsValues[2] = commonUtils.createInValueForProc(valueList);
		fieldsValues[3] = "IN|~";
		rowsList.add(fieldsValues);
	}

	private void updateIncludeExclude(final SearchFieldVO<IncludeExcludeVO<ReferenceDataVO<String>[]>> criteriaObject,
			final List<String[]> rowsList) {

		final String[] fieldsValues = updateFieldRecords(criteriaObject);
		IncludeExcludeVO<ReferenceDataVO<String>[]> includeExclude = criteriaObject.getValue();
		List<String> andValuesList = new LinkedList<>();
		List<String> orValuesList = new LinkedList<>();
		List<String> butNotValuesList = new LinkedList<>();
		final ReferenceDataVO<String>[] listOfValue = includeExclude.getValue();

		if (null != listOfValue) {
			if (0 == OPERATION.AND.compareTo(includeExclude.getOperation())) {
				andValuesList = nullCheckReplacement(listOfValue);
			} else if (0 == OPERATION.OR.compareTo(includeExclude.getOperation())) {
				orValuesList = nullCheckReplacement(listOfValue);
			}
		}
		if (null != includeExclude.getButNotValue()) {
			butNotValuesList = nullCheckReplacement(includeExclude.getButNotValue());
		}
		fieldsValues[2] = commonUtils.createIncludeExcludeValue(andValuesList, orValuesList, butNotValuesList);
		fieldsValues[3] = commonUtils.createIncludeExcludeCondition(andValuesList, orValuesList, butNotValuesList);
		rowsList.add(fieldsValues);

	}

	private void updateIncludeExcludeWrapper(
			final SearchFieldVO<IncludeExcludeListWrapper<ReferenceDataVO<String>[]>> criteriaObject,
			final List<String[]> rowsList) {

		IncludeExcludeListWrapper<ReferenceDataVO<String>[]> wrapper = criteriaObject.getValue();
		for (IncludeExcludeVO<ReferenceDataVO<String>[]> includeExclude : wrapper.getValueList()) {
			final String[] fieldsValues = updateFieldRecords(criteriaObject);
			List<String> andValuesList = new LinkedList<>();
			List<String> orValuesList = new LinkedList<>();
			List<String> butNotValuesList = new LinkedList<>();
			final ReferenceDataVO<String>[] listOfValue = includeExclude.getValue();

			if (null != listOfValue) {
				if (0 == OPERATION.AND.compareTo(includeExclude.getOperation())) {
					andValuesList = nullCheckReplacement(listOfValue);
				} else if (0 == OPERATION.OR.compareTo(includeExclude.getOperation())) {
					orValuesList = nullCheckReplacement(listOfValue);
				}
			}

			if (null != includeExclude.getButNotValue()) {
				butNotValuesList = nullCheckReplacement(includeExclude.getButNotValue());
			}
			fieldsValues[2] = commonUtils.createIncludeExcludeValue(andValuesList, orValuesList, butNotValuesList);
			fieldsValues[3] = commonUtils.createIncludeExcludeCondition(andValuesList, orValuesList, butNotValuesList);
			rowsList.add(fieldsValues);

		}

	}

	private void updateRange(final SearchFieldVO<RangeVO<?>> criteriaObject, final List<String[]> rowsList) {
		final String[] fieldsValues = updateFieldRecords(criteriaObject);
		RangeVO<?> range = criteriaObject.getValue();
		fieldsValues[2] = commonUtils.creatRangeValueForProc(range.getStart(), range.getEnd());
		fieldsValues[3] = commonUtils.createRangeConditioneForProc(range.getStart(), range.getEnd());
		rowsList.add(fieldsValues);
	}

	private void updateTenorRange(final SearchFieldVO<TenorRangeList<Long, String>> criteriaObject,
			final List<String[]> rowsList) {

		String[] fieldsValues = updateFieldRecords(criteriaObject);
		TenorRangeList<Long, String> tenorRangeList = criteriaObject.getValue();
		if (tenorRangeList.getInValue() != null) {

			RangeVO<Long> rangeInDays = getTenorRangeInDays(tenorRangeList.getInValue());
			LOGGER.debug("UserSearchCriteriaServiceImpl:: updateTenorRange()::{} ", rangeInDays);
			fieldsValues[2] = commonUtils.creatRangeValueForProc(rangeInDays.getStart(), rangeInDays.getEnd());
			fieldsValues[3] = commonUtils.createRangeConditioneForProc(rangeInDays.getStart(), rangeInDays.getEnd());
			fieldsValues[4] = criteriaObject.getWhoHasFlag().equals(WHO_CAN_FLAG) ? FROM_CONTRACTUAL_ELIGIBILITY_IN
					: FROM_ACTUAL_POSTINGS_IN;
			rowsList.add(fieldsValues);
		}
		if (tenorRangeList.getNotInValue() != null) {
			fieldsValues = updateFieldRecords(criteriaObject);
			RangeVO<Long> butNotRangeInDays = getTenorRangeInDays(tenorRangeList.getNotInValue());
			LOGGER.debug("UserSearchCriteriaServiceImpl:: updateTenorRange()::{} ", butNotRangeInDays);
			fieldsValues[2] = commonUtils.creatRangeValueForProc(butNotRangeInDays.getStart(),
					butNotRangeInDays.getEnd());
			fieldsValues[3] = commonUtils.createRangeConditioneForProc(butNotRangeInDays.getStart(),
					butNotRangeInDays.getEnd());
			fieldsValues[4] = criteriaObject.getWhoHasFlag().equals(WHO_CAN_FLAG) ? FROM_CONTRACTUAL_ELIGIBILITY_NOTIN
					: FROM_ACTUAL_POSTINGS_NOTIN;
			rowsList.add(fieldsValues);
		}
	}

	private RangeVO<Long> getTenorRangeInDays(TenorRange<Long, String> tenorRange) {
		Long days = 1L;
		switch (tenorRange.getPeriod().getValue()) {
		case "Years":
			days = days * 365L;
			break;
		case "Months":
			days = days * 30;
			break;

		default:
			break;
		}
		RangeVO<Long> rangeInDays = new RangeVO<>();
		if (tenorRange.getRangeValue().getStart() != null) {
			rangeInDays.setStart(tenorRange.getRangeValue().getStart() * days);
		}
		if (tenorRange.getRangeValue().getEnd() != null) {
			rangeInDays.setEnd(tenorRange.getRangeValue().getEnd() * days);
		}
		return rangeInDays;
	}

	private void updateFreeTextForm(final SearchFieldVO<String> criteriaObject, final List<String[]> rowsList) {
		final String[] fieldsValues = updateFieldRecords(criteriaObject);
		fieldsValues[2] = "'%" + criteriaObject.getValue() + "%'|~";
		fieldsValues[3] = "LIKE|~";
		rowsList.add(fieldsValues);
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public List<String[]> formatCriteriaObjectForRows(List<SearchFieldVO> serachCriteriaVoListData) {
		LOGGER.debug("UserSearchCriteriaServiceImpl:: formatCriteriaObjectForRows() ");
		List<String[]> rowsList = new LinkedList<>();
		try {
			// Skip all field with empty values for criteria formation.
			List<SearchFieldVO> serachCriteriaVoList = serachCriteriaVoListData.stream()
					.filter(searchFieldVO -> searchFieldVO.getValue() != null).collect(Collectors.toList());

			for (SearchFieldVO criteriaObject : serachCriteriaVoList) {

				switch (criteriaObject.getComponentType()) {
				case DROPDOWN:
					updateDropDwonTypeAheadValues(criteriaObject, rowsList);
					break;
				case TYPEAHEAD_TEXTBOX:
					updateDropDwonTypeAheadValues(criteriaObject, rowsList);
					break;
				case FREE_FORM_TEXT:
					updateFreeTextForm(criteriaObject, rowsList);
					break;
				case INCLUDE_EXCLUDE:
					updateIncludeExclude(criteriaObject, rowsList);
					break;
				case MULTI_INCLUDE_EXCLUDE:
					updateIncludeExcludeWrapper(criteriaObject, rowsList);
					break;
				case DATE_RANGE_FILTER:
					updateRange(criteriaObject, rowsList);
					break;
				case NUMERIC_RANGE_FILTER:
					updateRange(criteriaObject, rowsList);
					break;

				default:
					break;
				}
			}
		} catch (Exception e) {
			throw new DerivzApplicationException(e, DerivzDAOLayerException.FAILED_SETTINGS_SAVE_LIST);
		}
		return rowsList;
	}

	@SuppressWarnings({ "rawtypes" })
	public List<RatingFieldVO> formatRatingInRows(List<SearchFieldVO> serachCriteriaVoListData) {
		LOGGER.debug("UserSearchCriteriaServiceImpl:: formatCriteriaObjectForRows() ");
		List<RatingFieldVO> ratingList = new ArrayList<>();
		try {
			// Skip all field with empty values for criteria formation.
			List<SearchFieldVO> serachCriteriaVoList = serachCriteriaVoListData.stream()
					.filter(searchFieldVO -> searchFieldVO.getValue() != null
							&& ComponentType.RATING_RANGE.compareTo(searchFieldVO.getComponentType()) == 0)
					.collect(Collectors.toList());
			serachCriteriaVoList.forEach(p -> {
				processRating(ratingList, p);
			});
		} catch (Exception e) {
			throw new DerivzApplicationException(e, DerivzDAOLayerException.FAILED_SETTINGS_SAVE_LIST);
		}
		return ratingList;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private void processRating(List<RatingFieldVO> ratingList, SearchFieldVO searchFeild) {
		RatingRangeListWrapper rangeWrapper = (RatingRangeListWrapper) searchFeild.getValue();
		RatingRangeList inRangeList = (RatingRangeList) rangeWrapper.getInValueList();
		RatingRangeList notInRangeList = (RatingRangeList) rangeWrapper.getNotInValueList();

		RatingRange[] listOfInValues = inRangeList.getValueList();
		for (int i = 0; i < listOfInValues.length; i++) {
			RatingRange<ReferenceDataVO<String>> mp = (RatingRange<ReferenceDataVO<String>>) listOfInValues[i];
			if (mp.getValue() != null) {
				ReferenceDataVO<String> start = mp.getValue().getStart();
				ReferenceDataVO<String> end = mp.getValue().getEnd();
				if (start != null || end != null) {
					RatingFieldVO rfv = new RatingFieldVO(start != null ? start.getKey() : null,
							end != null ? end.getKey() : null, searchFeild.getFieldName(), mp.getOperation().getName(),
							i + 1);
					LOGGER.debug("UserSearchCriteriaServiceImpl:: processRating():: {}", rfv);
					ratingList.add(rfv);
				}
			}
		}
		RatingRange[] listOfNotInValues = notInRangeList.getValueList();
		for (int i = 0; i < listOfNotInValues.length; i++) {
			RatingRange<ReferenceDataVO<String>> mp = (RatingRange<ReferenceDataVO<String>>) listOfNotInValues[i];
			if (mp.getValue() != null) {
				ReferenceDataVO<String> start = mp.getValue().getStart();
				ReferenceDataVO<String> end = mp.getValue().getEnd();
				if (start != null || end != null) {
					RatingFieldVO rfv = new RatingFieldVO(start != null ? start.getKey() : null,
							end != null ? end.getKey() : null, searchFeild.getFieldName(), mp.getOperation().getName(),
							i + 1); // Not reading numIndex from now as it is not consistent with row deletion
					LOGGER.debug("UserSearchCriteriaServiceImpl:: processRating():: {}", rfv);
					ratingList.add(rfv);
				}
			}
		}
	}

	@SuppressWarnings("rawtypes")
	private void addPredefinedFinedResult(final SelectionFilters filter,
			final List<SearchFieldVO> searchCriteriaVOList) {
		final SearchFieldVO.SearchFieldVOBuilder<?> scvb = SearchFieldVO.builder();
		if (filter.getFieldName() != null)
			scvb.fieldName(DBCommonUtils.formattingString(filter.getFieldName()));
		if (filter.getDisplayName() != null)
			scvb.name(filter.getDisplayName());
		if (filter.getSchemaName() != null)
			scvb.schemaName(filter.getSchemaName());
		if (filter.getNodeName() != null)
			scvb.nodeName(filter.getNodeName());
		if (filter.getLogicalGroup() != null)
			scvb.logicalGroupName(filter.getLogicalGroup());
		if (filter.getAttributeDatatype() != null)
			scvb.dataType(filter.getAttributeDatatype());
		if (filter.getNodeDisplayName() != null)
			scvb.nodeDisplayName(filter.getNodeDisplayName());
		scvb.distinctRequired(filter.getDistinctRequired());
		if (filter.getFilterKey() != null)
			scvb.key(filter.getFilterKey());
		if (filter.getDefaultSelected() != null)
			scvb.defaultSelected(filter.getDefaultSelected());
		searchCriteriaVOList.add(scvb.build());
	}

	/**
	 * @name findPredefinedResultSet
	 * @description Method to find the list of the predefined columns which needs to
	 *              be by default shown in the search result
	 * @return list
	 */
	@SuppressWarnings("rawtypes")
	public List<SearchFieldVO> findPredefinedResultSet() {
		LOGGER.debug("UserSearchCriteriaServiceImpl::findPredefinedResultSet() ");
		List<SearchFieldVO> searchCriteriaVOList = new LinkedList<>();
		try {
			final List<SelectionFilters> filterSelectionList = selectionFiltersRepository
					.findByIsDisplayed(DerivzCommonConstants.INTERGER_ONE);

			// Iterate through all the filters to make the response object for the API
			filterSelectionList.stream().forEach(filter -> addPredefinedFinedResult(filter, searchCriteriaVOList));

		} catch (Exception e) {
			LOGGER.error("UserSearchCriteriaServiceImpl::findPredefinedResultSet() :: Error :" + e, e);
			throw new DerivzApplicationException(e, DerivzDAOLayerException.FAILED_SEARCH_DELETE_LIST);
		}
		return searchCriteriaVOList;
	}

	/**
	 * @name createSearchCriteriaResult
	 * @description This method is used to do the dozer mapping to convert the
	 *              search result into application specific POJO format
	 * @param dimAgreementResultList
	 * @return list
	 */
	private List<SearchCriteriaResultVO> createSearchCriteriaResult(final List<?> dimAgreementResultList) {
		LOGGER.debug("UserSearchCriteriaServiceImpl:: createSearchCriteriaResult");
		List<SearchCriteriaResultVO> searchResultList = new LinkedList<>();
		try {
			BeanMappingBuilder mappingBuilder = new BeanMappingBuilder() {
				@Override
				protected void configure() {
					String dateFormat = DerivzCommonConstants.YYYYMMDD_FORMAT;
					mapping(DimAgreement.class, SearchCriteriaResultVO.class,
							TypeMappingOptions.dateFormat(dateFormat));
				}
			};
			DozerBeanMapper apiBeanMapper = new DozerBeanMapper();
			apiBeanMapper.addMapping(mappingBuilder);
			dimAgreementResultList.stream().forEach(dimAgreement -> {
				final SearchCriteriaResultVO searchCriteriaResultVO = apiBeanMapper.map(dimAgreement,
						SearchCriteriaResultVO.class);
				searchResultList.add(searchCriteriaResultVO);
			});

		} catch (Exception e) {
			LOGGER.error("UserSearchCriteriaServiceImpl::createSearchCriteriaResult() ::Error" + e, e);
			throw e;
		}
		return searchResultList;
	}

	@SuppressWarnings("rawtypes")
	public List<SearchFieldVO> getCollateralLookupColumns() {
		LOGGER.debug("UserSearchCriteriaServiceImpl::getCollateralLookupColumns() ");
		List<SearchFieldVO> searchCriteriaVOList = new LinkedList<>();
		try {
			final List<SelectionFilters> filterSelectionList = selectionFiltersRepository
					.findByCollateralLookup(DerivzCommonConstants.INTERGER_ONE);
			if (null != filterSelectionList) {
				// Iterate through all the filters to make the response object for the API
				filterSelectionList.stream().forEach(filter -> {
					final SearchFieldVO searchCriteriaVO = new SearchFieldVO();
					if (null != filter.getFieldName()) {
						searchCriteriaVO.setFieldName(DBCommonUtils.formattingString(filter.getFieldName()));
					}
					searchCriteriaVO.setName(filter.getDisplayName());
					searchCriteriaVO.setSchemaName(filter.getSchemaName());
					searchCriteriaVO.setNodeName(filter.getNodeName());
					searchCriteriaVO.setLogicalGroupName(filter.getLogicalGroup());
					searchCriteriaVO.setDataType(filter.getAttributeDatatype());
					searchCriteriaVO.setNodeDisplayName(filter.getNodeDisplayName());
					searchCriteriaVO.setKey(filter.getFilterKey());
					searchCriteriaVO.setDefaultSelected(1);
					searchCriteriaVO.setComponentType(ComponentType.valueOfByName(filter.getComponentType()));
					searchCriteriaVO.setWhoHasFlag(filter.getWhoHasFlag());
					searchCriteriaVOList.add(searchCriteriaVO);
				});
			}
		} catch (Exception e) {
			LOGGER.error("UserSearchCriteriaServiceImpl::getCollateralLookupColumns() :: Error :" + e, e);
			throw new DerivzApplicationException(e, DerivzDAOLayerException.FAILED_SEARCH_DELETE_LIST);
		}
		return searchCriteriaVOList;
	}

	@SuppressWarnings("rawtypes")
	public List<CollateralResponseDTO> findCollateralFilterSearch(List<SearchFieldVO> selectionFilterVOList) {
		LOGGER.debug("UserSearchCriteriaServiceImpl:: findCollateralFilterSearch() ");
		try {
			return searchDAO.callCollateralLookupProc(formatCriteriaObjectForRows(selectionFilterVOList));
		} catch (DerivzApplicationException e) {
			LOGGER.error(
					"UserFilterSearchServiceImpl::findCollateralFilterSearch() :: DerivzApplicationException occured "
							+ e,
					e);
			throw new DerivzApplicationException(e, DerivzDAOLayerException.FAILED_SEARCH_PROCEDURE);
		} catch (Exception e) {
			LOGGER.error("UserFilterSearchServiceImpl::findCollateralFilterSearch() :: Exception occured " + e, e);
			throw new DerivzApplicationException(e, DerivzDAOLayerException.FAILED_SEARCH_PROCEDURE);
		}
	}

	@Override
	public List<VoyagerNavigationData> loadUserDatasetIds(final String userId) {
		List<VoyagerNavigationData> voyagerNavigationDataList = new ArrayList<>();
		List<UserDatasetVO> userDatasetVOList = searchDAO.callGetCurrentDatasetIdProc(userId);
		for (UserDatasetVO userDatasetVO : userDatasetVOList) {
			if (userDatasetVO.getDisplayFlag() == 1 || "curr_post_filtered".equals(userDatasetVO.getShortName())) {
				VoyagerNavigationData data = new VoyagerNavigationData();
				String navigationURL = "http://" + voyagerConfig.getHostname() + ":" + voyagerConfig.getPort()
						+ "/?datasetId=" + userDatasetVO.getDatasetId() + "&soeId=" + userId;
				data.setNavigationUrl(navigationURL);
				BeanUtils.copyProperties(userDatasetVO, data);
				voyagerNavigationDataList.add(data);
			}
		}
		return voyagerNavigationDataList;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public ListDataResponseDTO loadTabsData(final String tabName, List<Long> agreementKeyList,
			final List<AgreementOptimalRankVO> agreementOptimalRanks, Boolean isFilterd, List<SearchFieldVO> criteria,
			final List<SearchResultColumns> smsColumns) throws CEFTException {
		ListDataResponseDTO result = null;
		try {
			List<SearchResultColumns> searchResultColumnsList = cachingService
					.getAllSearchResultColumns(StaticCacheKeys.RESULT_COLUMNS);

			IncludeExcludeListWrapper wrapper = null;
			StringBuilder ctnCSV = new StringBuilder("");
			for (SearchFieldVO searchVo : criteria) {
				if (ComponentType.MULTI_INCLUDE_EXCLUDE.compareTo(searchVo.getComponentType()) == 0
						&& "collateral_type_name".equalsIgnoreCase(searchVo.getFieldName())) {
					wrapper = (IncludeExcludeListWrapper) searchVo.getValue();
					break;
				}
			}
			if (wrapper != null) {
				IncludeExcludeVO[] incList = wrapper.getValueList();
				for (IncludeExcludeVO ievo : incList) {
					if (ievo.getValue() != null) {
						ReferenceDataVO<String>[] refData = (ReferenceDataVO<String>[]) ievo.getValue();
						for (ReferenceDataVO<String> refVo : refData) {
							if (refVo.getValue() != null) {
								ctnCSV.append(refVo.getValue()).append(",");
							}
						}
					}
				}
			}
			String collatralTypeNameCSV = ctnCSV.toString();
			result = searchResultDAO.retriveResultsFromDB(tabName, searchResultColumnsList, isFilterd, agreementKeyList,
					agreementOptimalRanks, formatCriteriaObjectForRows(criteria), collatralTypeNameCSV,
					formatRatingInRows(criteria), smsColumns, formatTenorCriteriaForRows(criteria));
			if (result != null && result.getListOfRecords() != null)
				LOGGER.info("UserFilterSearchServiceImpl::loadTabsData() ::List Size::{}",
						result.getListOfRecords().size());
		} catch (CEFTException e) {
			LOGGER.error("UserFilterSearchServiceImpl::loadTabsData() :: Exception occured ");
			throw new CEFTException(e);
		}
		return result;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<String[]> formatTenorCriteriaForRows(List<SearchFieldVO> serachCriteriaVoListData) {
		LOGGER.debug("UserSearchCriteriaServiceImpl:: formatTenorCriteriaForRows() ");
		List<String[]> rowsList = new LinkedList<>();
		try {

			// Skip all field with empty values for criteria formation.
			List<SearchFieldVO> serachCriteriaVoList = serachCriteriaVoListData.stream()
					.filter(searchFieldVO -> searchFieldVO.getValue() != null
							&& ComponentType.TENOR_RANGE.compareTo(searchFieldVO.getComponentType()) == 0)
					.collect(Collectors.toList());

			for (SearchFieldVO criteriaObject : serachCriteriaVoList) {
				updateTenorRange(criteriaObject, rowsList);
			}
		} catch (Exception e) {
			throw new DerivzApplicationException(e, DerivzDAOLayerException.FAILED_SETTINGS_SAVE_LIST);
		}
		return rowsList;
	}

	@Override
	public ListDataResponseDTO searchDatasetResults(String tabName, String userId, Long bookmarkId, EnterpriseGetRowsRequest gridRequest)
			throws CEFTException {
		ListDataResponseDTO result = null;
		try {
			List<SearchResultColumns> searchResultColumnsList = cachingService
					.getAllSearchResultColumns(StaticCacheKeys.RESULT_COLUMNS);

			result = searchResultDAO.retriveDatasetResultsUsingBookmarkId(tabName, searchResultColumnsList, userId,
					bookmarkId, gridRequest);
			if (result != null && result.getListOfRecords() != null) {
				LOGGER.info("UserFilterSearchServiceImpl::loadDataset() ::List Size::{}",
						result.getListOfRecords().size());
			}
		} catch (CEFTException e) {
			LOGGER.error("UserFilterSearchServiceImpl::loadDataset() :: Exception occured ");
			throw new CEFTException(e);
		}
		return result;
	}

}
