package com.citi.aqua.derivz.services.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import com.citi.aqua.derivz.commons.exceptions.CEFTException;
import com.citi.aqua.derivz.data.jdbc.SearchResultDAO;
import com.citi.aqua.derivz.dto.ListDataResponseDTO;
import com.citi.aqua.derivz.model.columns.mapping.SearchResultColumns;
import com.citi.aqua.derivz.services.grid.CeftDataSet;
import com.citi.aqua.derivz.services.grid.CeftFrmQueryService;
import com.citi.aqua.derivz.services.grid.LoadingStatusService;
import com.citi.aqua.derivz.services.grid.model.SearchDataRequest;
import com.citi.aqua.derivz.services.grid.model.SearchQueryResult;
import com.citi.aqua.derivz.vo.AgreementOptimalRankVO;
import com.citi.aqua.derivz.vo.RatingFieldVO;
import com.citi.aqua.derivz.vo.aggrid.request.EnterpriseGetRowsRequest;
import com.citi.aqua.frm.ceft.CeftDataSetType;
import com.citi.aqua.frm.framework.grid.exception.DataSetNotLoadedException;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class SearchResultServiceImpl implements SearchResultDAO {
	
	private static final int LIMIT = 10;

    private LoadingStatusService loadingStatusService;

    private CeftFrmQueryService queryService;
    
	public SearchResultServiceImpl(LoadingStatusService loadingStatusService, CeftFrmQueryService queryService) {
		this.loadingStatusService=loadingStatusService;
		this.queryService=queryService;
	}

	@Override @Deprecated
	public ListDataResponseDTO retriveResultsFromDB(String tabName, List<SearchResultColumns> searchResultColumnsList,
			Boolean isFilterd, List<Long> agreementKeyList, List<AgreementOptimalRankVO> agreementOptimalRanks,
			List<String[]> rowList, String collatralTypeNamesCSV, List<RatingFieldVO> listOfRangeField,
			List<SearchResultColumns> smsColumns, List<String[]> listOfTenorRange) throws CEFTException {
		return null;
	}

	@Override
	public ListDataResponseDTO retriveDatasetResultsUsingBookmarkId(String datasetType,
			List<SearchResultColumns> searchResultColumnsList, String userId, Long bookmarkId, EnterpriseGetRowsRequest gridRequest) throws CEFTException {
		
		CeftDataSet ceftDataset=new CeftDataSet(userId, bookmarkId, CeftDataSetType.findByCode(datasetType.toLowerCase()));
		log.debug("Request to ignite cache, Data set: {}", ceftDataset);
		List<String> filterColumnList = searchResultColumnsList.parallelStream()
				.filter(p -> p.getTabId().equalsIgnoreCase(datasetType)).map(SearchResultColumns::getFieldName)
				.collect(Collectors.toList());
		SearchDataRequest request= new SearchDataRequest();
		request.setDataSet(ceftDataset);
		request.setColumns(filterColumnList);
		request.setLimit(gridRequest.getLimit());
		request.setOffset(gridRequest.getStartRow());
		ListDataResponseDTO dto= new ListDataResponseDTO();
		try {
		SearchQueryResult queryResult=queryService.searchQuery(request);
		log.info("Query result: {}", queryResult);
		
		dto.setListOfRecords(queryResult.getValues());
		dto.setCount((long) dto.getListOfRecords().size());
		}catch(DataSetNotLoadedException de) {
			log.debug("Dataset not yet loaded: {}", ceftDataset);
		}
		return dto;
	}
}
