package com.citi.aqua.derivz.data.repository;

import java.util.List;
import org.springframework.data.repository.CrudRepository;
import com.citi.aqua.derivz.model.RatingRankings;

public interface RatingRankingRepository extends CrudRepository<RatingRankings,Long> {

  public List<RatingRankings> findAll();
}
