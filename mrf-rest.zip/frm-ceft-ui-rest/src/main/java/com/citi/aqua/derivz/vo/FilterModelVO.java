package com.citi.aqua.derivz.vo;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;

@JsonTypeInfo(
        use = JsonTypeInfo.Id.NAME,
        include = JsonTypeInfo.As.PROPERTY,
        property = "filterType")
@JsonSubTypes({
        @JsonSubTypes.Type(value = NumberFilterModelVO.class, name = "number"),
        @JsonSubTypes.Type(value = ColumnFilterModelVO.class, name = "set") })
public abstract class FilterModelVO implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	String filterType;
}