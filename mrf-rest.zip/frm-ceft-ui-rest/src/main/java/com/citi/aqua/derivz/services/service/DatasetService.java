package com.citi.aqua.derivz.services.service;

import java.util.List;

import com.citi.aqua.derivz.model.BaseEntity;
import com.citi.aqua.derivz.model.Dataset;

public interface DatasetService extends BaseService {
	
	public Dataset findByName(String name);
	
	public List<? extends BaseEntity> getDataset(String entity, String filterQuery, int maxResults);

}
