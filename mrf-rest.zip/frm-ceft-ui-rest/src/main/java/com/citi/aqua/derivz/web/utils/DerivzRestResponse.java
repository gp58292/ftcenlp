package com.citi.aqua.derivz.web.utils;

import com.citi.aqua.derivz.web.exception.DerivzRestAPIError;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * @name
 * @description This response POJO is used to send the final response from REST API
 */
@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
@ToString
public class DerivzRestResponse<T> {

	private int responseStatus;

	private DerivzRestAPIError restError;

	private T responseData;

	private String message;

}
