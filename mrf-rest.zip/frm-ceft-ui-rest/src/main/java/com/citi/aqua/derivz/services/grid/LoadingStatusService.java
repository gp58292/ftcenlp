package com.citi.aqua.derivz.services.grid;

import com.citi.aqua.frm.framework.grid.exception.FrmDataGridException;

/**
 * Wrapper for grid services.
 *
 * @author Aleksander Nowinski, aleksander.nowinski@citi.com
 * @since 6/19/2019
 */
public interface LoadingStatusService {
    /** Initiate loading of the data set */
    void loadData(CeftDataSet dataSet);

    /** Initiate loading of the given data set and start reporting progress on the websocket with
     * given uuid.
     * @param dataSet data set to be load
     * @param atmosphereResourceUUID uuid of the websocket to send progress to
     * @return current status of the data set loaded.
     */
    CeftDataSetStatus requestDataSet(CeftDataSet dataSet, String atmosphereResourceUUID) throws FrmDataGridException;

    boolean isDataSetReady(CeftDataSet dataSet);

    CeftDataSetStatus dataSetStatus(CeftDataSet dataSet);

    CeftDataSetStatus[] dataSetStatusForBookmark(String soeId, long bookmark);
}
