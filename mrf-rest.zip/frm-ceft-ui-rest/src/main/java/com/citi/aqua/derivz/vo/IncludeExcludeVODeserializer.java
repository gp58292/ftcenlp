package com.citi.aqua.derivz.vo;

import java.io.IOException;

import com.citi.aqua.derivz.enums.OPERATION;
import com.citi.aqua.derivz.model.DerivzJsonConstants;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;
import com.fasterxml.jackson.databind.type.TypeFactory;

public class IncludeExcludeVODeserializer<T> extends StdDeserializer<IncludeExcludeVO<T>> {


	static ObjectMapper objectMapper = new ObjectMapper();
	static TypeFactory typeFactory = objectMapper.getTypeFactory();

	public IncludeExcludeVODeserializer() {
		this(null);
	}

	protected IncludeExcludeVODeserializer(Class<?> vc) {
		super(vc);
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Override
	public IncludeExcludeVO<T> deserialize(JsonParser p, DeserializationContext ctxt)
			throws IOException, JsonProcessingException {
		JsonNode node = p.getCodec().readTree(p);
		IncludeExcludeVO.IncludeExcludeVOBuilder<T> scvb = IncludeExcludeVO.builder();

		if (node.get(DerivzJsonConstants.VALUE) != null) {
			
			scvb.value(objectMapper.readValue(node.get(DerivzJsonConstants.VALUE).toString(), typeFactory.constructArrayType(ReferenceDataVO.class)));
		}
		
		if (node.get(DerivzJsonConstants.BUT_NOT_VALUE) != null) {
			scvb.butNotValue(objectMapper.readValue(node.get(DerivzJsonConstants.BUT_NOT_VALUE).toString(), typeFactory.constructArrayType(ReferenceDataVO.class)));
		}
		
		if (node.get(DerivzJsonConstants.OPERATION) != null) {
			String nameOfOperation = node.get(DerivzJsonConstants.OPERATION).asText();
			OPERATION operationType = OPERATION.valueOfByName(nameOfOperation);
			scvb.operation(operationType);
			return (IncludeExcludeVO<T>) scvb.build();
		}
			
		return null;
	}

}
