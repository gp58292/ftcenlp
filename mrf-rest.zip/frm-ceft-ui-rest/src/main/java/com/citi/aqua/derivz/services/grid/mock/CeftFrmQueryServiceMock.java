package com.citi.aqua.derivz.services.grid.mock;

import com.citi.aqua.derivz.services.grid.model.DistinctValueDataRequest;
import com.citi.aqua.derivz.services.grid.CeftFrmQueryService;
import com.citi.aqua.derivz.services.grid.model.CountDataRequest;
import com.citi.aqua.derivz.services.grid.model.SearchDataRequest;
import com.citi.aqua.derivz.services.grid.model.SearchQueryResult;

import java.util.List;

/**
 * @author Aleksander Nowinski, aleksander.nowinski@citi.com
 * @since 6/25/2019
 */
public class CeftFrmQueryServiceMock implements CeftFrmQueryService {
    @Override
    public long countQuery(CountDataRequest request) {
        throw new UnsupportedOperationException();
    }

    @Override
    public SearchQueryResult searchQuery(SearchDataRequest request) {
        throw new UnsupportedOperationException();
    }

    @Override
    public List<Object> distinctValuesQuery(DistinctValueDataRequest request) {
        throw new UnsupportedOperationException();
    }
}
