package com.citi.aqua.derivz.vo;

import java.io.IOException;
import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class ReferenceDataVO<T> implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private Long key;

	private T value;

	public ReferenceDataVO() {
	}

	public ReferenceDataVO(final Long key) {
		this.key = key;
	}

    private void writeObject(java.io.ObjectOutputStream stream) throws IOException {
        stream.writeObject(value);
    }

    @SuppressWarnings("unchecked")
	private void readObject(java.io.ObjectInputStream stream)  throws IOException, ClassNotFoundException {
    	value = (T) stream.readObject();
    }

}
