package com.citi.aqua.derivz.services.service;

import java.sql.Timestamp;
import java.util.List;
import java.util.Map;
import java.util.Set;
import com.citi.aqua.derivz.data.cache.eh.ReferenceCacheKeys;
import com.citi.aqua.derivz.data.cache.eh.StaticCacheKeys;
import com.citi.aqua.derivz.model.BatchProcessAudit;
import com.citi.aqua.derivz.model.DistinctValues;
import com.citi.aqua.derivz.model.RatingRankings;
import com.citi.aqua.derivz.model.SelectionFilters;
import com.citi.aqua.derivz.model.columns.mapping.SearchResultColumns;
import com.citi.aqua.derivz.vo.ReferenceDataVO;

public interface CacheService {

	
	// Reference data services
	@SuppressWarnings("rawtypes")
	public Map<Long, List<ReferenceDataVO>> loadReferenceData();
	
	@SuppressWarnings("rawtypes")
	public Map<Long, List<ReferenceDataVO>> getReferenceData();
	
	public void evictReferenceDataCache();

	public BatchProcessAudit getBatchProcessAuditByModule(String module);
	
	public List<BatchProcessAudit> getBatchProcessAudit();
	
	public int updateCacheUpdatedTimeForModule(Timestamp cacheUpdatedTime, String module);
	
	// Static data services
	public void evictStaticDataCache();

	public Map<Long, SelectionFilters> findStaticComponentData(StaticCacheKeys key);
	
	// Brings all columns to display in Result grid 
	public List<SearchResultColumns> getAllSearchResultColumns(StaticCacheKeys key);
	
	public List<SearchResultColumns> getAllSearchResultColumnsByTabName(StaticCacheKeys key,String tabName);
	
	public List<DistinctValues> loadAllReferenceData(ReferenceCacheKeys key);
	@SuppressWarnings("rawtypes")
	public Map<Long, List<ReferenceDataVO>> createReferenceData(final List<DistinctValues> distinctDataList, ReferenceCacheKeys key);
	@SuppressWarnings("rawtypes")
	public List<ReferenceDataVO> getReferenceDataByKey(final Long referenceKey, ReferenceCacheKeys key);
	
	public Set<RatingRankings> getRatingRankings(ReferenceCacheKeys key);
}
