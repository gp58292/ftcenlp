package com.citi.aqua.derivz.services;

import lombok.extern.slf4j.Slf4j;
import org.jasypt.util.password.BasicPasswordEncryptor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * @author Aleksander Nowinski, aleksander.nowinski@citi.com
 * @since 2/28/2019
 */
@Slf4j
@Component
public class ApiKeyService {
    @Value("${ceft.admin.apiKeyEncrypted:'undefined'}")
    String encodedKey;

    BasicPasswordEncryptor passwordEncryptor = new BasicPasswordEncryptor();

    public boolean isKeyValid(String key) {
    	log.debug("ApiKeyService:: isKeyValid {}", key);
        return passwordEncryptor.checkPassword(key, encodedKey);
    }
}
