package com.citi.aqua.derivz.web.controller;

import java.util.ArrayList;
import java.util.List;
import org.apache.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import com.citi.aqua.derivz.commons.constants.DerivzAPIUriConstants;
import com.citi.aqua.derivz.commons.constants.DerivzCommonConstants;
import com.citi.aqua.derivz.commons.exceptions.DerivzApplicationException;
import com.citi.aqua.derivz.model.Bookmark;
import com.citi.aqua.derivz.services.service.BookmarkService;
import com.citi.aqua.derivz.vo.SearchFieldVO;
import com.citi.aqua.derivz.web.utils.DerivzBookmarkRestRequest;
import com.citi.aqua.derivz.web.utils.DerivzRestResponse;
import com.citi.aqua.derivz.web.utils.ResponseBuilder;

@RestController
@RequestMapping(DerivzAPIUriConstants.BOOKMARK_API_URI)
public class BookmarkController {

	private static final String DS007 = "DS007";

	private static final Logger LOGGER = LoggerFactory.getLogger(BookmarkController.class);

	@Autowired
	BookmarkService bookmarkService;

	@GetMapping(value = DerivzAPIUriConstants.GET_BOOKMARK_FOR_USER_URI)
	public @ResponseBody DerivzRestResponse<List<Bookmark>> getBookmarksForUser(
			@PathVariable("userId") final String userId) {
		LOGGER.debug("BookmarkController::getBookmarksForUser() ");
		List<Bookmark> searchCriteriaVOList = null;
		try {
			searchCriteriaVOList = bookmarkService.getSearchCriteriaList(userId,
					DerivzCommonConstants.SEARCH_TYPE_LIST);
			if (!searchCriteriaVOList.isEmpty()) {
				return ResponseBuilder.build(searchCriteriaVOList, HttpStatus.SC_OK);
			} else {
				return ResponseBuilder.build(searchCriteriaVOList, HttpStatus.SC_NOT_FOUND,
						"No Bookmarks Exists for the given user", DS007);
			}
		} catch (DerivzApplicationException de) {
			LOGGER.error("BookmarkController::getBookmarksForUser() :: Error " + de, de);
			return ResponseBuilder.build(searchCriteriaVOList, HttpStatus.SC_NOT_FOUND,
					"No Bookmarks Exists for the given user", DS007);
		} 
	}
	
	@SuppressWarnings("rawtypes")
	@GetMapping(value = DerivzAPIUriConstants.GET_BOOKMARK_WITH_ID_URI)
	public @ResponseBody DerivzRestResponse<List<SearchFieldVO>> getBookmarkValue(
			@PathVariable("userId") final String userId,@PathVariable("bookmarkId") final Long bookmarkId) {
		LOGGER.debug("BookmarkController::getBookmarkValue() ");
		List<SearchFieldVO> bookmarkData = null;
		try {
			bookmarkData = bookmarkService.getBookmarkForGivenId(userId,bookmarkId);
			return ResponseBuilder.build(bookmarkData, HttpStatus.SC_OK);
		} catch (DerivzApplicationException de) {
			LOGGER.error("BookmarkController::getBookmarkValue() :: Error " + de, de);
			return ResponseBuilder.build(bookmarkData, HttpStatus.SC_NOT_FOUND, "Failed to retrieve settings list",
					"DS003");
		}
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@PostMapping()
	public @ResponseBody DerivzRestResponse<Bookmark> saveBookMark(@RequestBody final DerivzBookmarkRestRequest bookmarkRequest) {
		LOGGER.debug("BookmarkController::saveBookMark() ");
		Bookmark updatedBookmark = null;
		try {
			updatedBookmark = bookmarkService.saveUserBookmark(bookmarkRequest.getUserId(),
					bookmarkRequest.getBookmarkName(), bookmarkRequest.getBookmarkData(),bookmarkRequest.getSearchCriteria(),bookmarkRequest.getParentBookmarkId());
			return ResponseBuilder.build(updatedBookmark, HttpStatus.SC_OK);
		} catch (DerivzApplicationException de) {
			LOGGER.error("BookmarkController::saveBookMark() :: Error " + de, de);
			return ResponseBuilder.build(updatedBookmark, HttpStatus.SC_NOT_FOUND, "Failed to save bookmark data", "DS102");
		} 
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@PutMapping()
	public @ResponseBody DerivzRestResponse<Bookmark> updateBookMark(
			@RequestBody final DerivzBookmarkRestRequest bookmarkRequest) {
		LOGGER.debug("BookmarkController::updateBookMark() ");
		try {
			Bookmark bookmark= bookmarkService.updateUserBookmark(bookmarkRequest.getBookmarkId(),
					bookmarkRequest.getBookmarkData(),bookmarkRequest.getUserId(),bookmarkRequest.getSearchCriteria(),bookmarkRequest.getBookmarkName());
			return ResponseBuilder.build(bookmark, HttpStatus.SC_OK);
		} catch (DerivzApplicationException de) {
			LOGGER.error("BookmarkController::updateBookMark() :: Error " + de, de);
			return ResponseBuilder.build(null, HttpStatus.SC_NOT_FOUND, "Failed to update bookmark data",
					"DS103");
		} 
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@PutMapping(value=DerivzAPIUriConstants.PUT_TEMP_BOOKMARK_WITH_ORIGINAL_URI)
	public @ResponseBody DerivzRestResponse<Bookmark> updateOriginalAndDeleteTmporaryBookmark(
			@RequestBody final DerivzBookmarkRestRequest bookmarkRequest) {
		LOGGER.debug("BookmarkController::updateOriginalAndDeleteTmporaryBookmark() ");
		 Bookmark bookmark=null;
		try {
			bookmark = bookmarkService.updateOriginalAndDeleteTmporaryBookmark(bookmarkRequest.getBookmarkId(),
					bookmarkRequest.getBookmarkData(),bookmarkRequest.getUserId(),bookmarkRequest.getSearchCriteria());
			return ResponseBuilder.build(bookmark, HttpStatus.SC_OK);
		} catch (DerivzApplicationException de) {
			LOGGER.error("BookmarkController::updateOriginalAndDeleteTmporaryBookmark() :: Error " + de, de);
			return ResponseBuilder.build(bookmark, HttpStatus.SC_NOT_FOUND, "Failed to update original bookmark data",
					"DS103");
		} 
	}

	@SuppressWarnings({ "rawtypes" })
	@DeleteMapping(value = DerivzAPIUriConstants.DELETE_BOOKMARK_WITH_ID_URI)
	public @ResponseBody DerivzRestResponse deleteBookmarksById(@PathVariable("userId") final String userId,@PathVariable("bookmarkId") final Long bookmarkId) {
		LOGGER.debug("BookmarkController::deleteBookmarksById()");
		boolean flag = false;List<String> charts;
		try {
			charts= checkForDeleteBookmarksById(userId,bookmarkId);
			if(charts.isEmpty()) {
			flag = bookmarkService.deleteBookmark(userId,bookmarkId);
			return ResponseBuilder.build(flag, HttpStatus.SC_OK);
			} else {
				return ResponseBuilder.build(charts, HttpStatus.SC_OK);	
			}
		} catch (DerivzApplicationException de) {
			LOGGER.error("BookmarkController::deleteBookmarksById() :: Error " + de, de);
			return ResponseBuilder.build(flag, HttpStatus.SC_NOT_FOUND, "Exception Occured while deleting bookmark",
					"DS004");
		}
	}

	
	private List<String> checkForDeleteBookmarksById(String userId,final Long bookmarkId) {
		LOGGER.debug("BookmarkController::checkForDeleteBookmarksById()");
		List<String> charts=null;
		try {
			charts = bookmarkService.checkForDeleteBookmark(userId,bookmarkId);
			LOGGER.debug("BookmarkController::Charts available {}",charts.size());
			return charts;
		} catch (DerivzApplicationException de) {
			LOGGER.error("BookmarkController::checkForDeleteBookmarksById() :: Error " + de, de);
		}
		return charts;
	}

	/*@GetMapping(value = DerivzAPIUriConstants.SHARE_BOOKMARK_DATA_URI)
	public @ResponseBody DerivzRestResponse<Boolean> shareBookmark(
			@PathVariable("sharedBookmarkId") final Long sharedBookmarkId,
			@PathVariable("userId") final String userId,
			@PathVariable("bookmarkName") final String bookmarkName
			) {
		LOGGER.debug("BookmarkController::updateBookMark() ");
		Boolean updateFlag = false;
		try {
			updateFlag = bookmarkService.shareUserBookmark(userId,
					bookmarkName, sharedBookmarkId);
			return ResponseBuilder.build(updateFlag, HttpStatus.SC_OK);
		} catch (DerivzApplicationException de) {
			LOGGER.error("BookmarkController::updateBookMark() :: Error " + de, de);
			return ResponseBuilder.build(updateFlag, HttpStatus.SC_NOT_FOUND, "Failed to share bookmark data",
					"DS106");
		} 
	}*/
	
	@GetMapping(value = DerivzAPIUriConstants.SHARE_BOOKMARK_DATA_URI)
	public @ResponseBody DerivzRestResponse<Boolean> shareBookmark(
			@PathVariable("sharedBookmarkId") final Long sharedBookmarkId,
			@PathVariable("userId") final String userId, @PathVariable("sharedUserId") final String sharedUserId
			) {
		LOGGER.debug("BookmarkController::shareBookmark() ");
		Boolean isShared = false;
		try {
			isShared = bookmarkService.shareUserBookmark(userId,sharedBookmarkId,sharedUserId);
			return ResponseBuilder.build(isShared, HttpStatus.SC_OK);
		} catch (DerivzApplicationException de) {
			LOGGER.error("BookmarkController::shareBookmark() :: Error " + de, de);
			return ResponseBuilder.build(isShared, HttpStatus.SC_NOT_FOUND, "Failed to share bookmark data",
					"DS106");
		} 
	}
	
	@DeleteMapping(value = DerivzAPIUriConstants.DELETE_ALL_TEMP_BOOKMARK_URI)
	public @ResponseBody DerivzRestResponse<Boolean> deleteAllTempBookmark(
			@PathVariable("userId") final String userId
			) {
		LOGGER.debug("BookmarkController::deleteAllTempBookmark() ");
		Boolean updateFlag = false;
		try {
			updateFlag = bookmarkService.deleteAllTempBookmarkByUserId(userId);
			return ResponseBuilder.build(updateFlag, HttpStatus.SC_OK);
		} catch (DerivzApplicationException de) {
			LOGGER.error("BookmarkController::deleteAllTempBookmark() :: Error " + de, de);
			return ResponseBuilder.build(updateFlag, HttpStatus.SC_NOT_FOUND, "Failed to delete Temp bookmark data",
					"DS106");
		} 
	}
	
	@GetMapping(value = DerivzAPIUriConstants.RESTORE_TEMP_BOOKMARK_URI)
	public @ResponseBody DerivzRestResponse<List<Bookmark>> restoreTempBookmark(
			@PathVariable("userId") final String userId) {
		LOGGER.debug("BookmarkController::restoreTempBookmark() ");
		List<Bookmark> tempBookmarkList = null;
		try {
			tempBookmarkList = bookmarkService.restoreTempBookmarkByUserId(userId);
			if (!tempBookmarkList.isEmpty()) {
				return ResponseBuilder.build(tempBookmarkList, HttpStatus.SC_OK);
			} else {
				return ResponseBuilder.build(tempBookmarkList, HttpStatus.SC_NOT_FOUND,
						"No recently deleted bookmarks available to restore", DS007);
			}
		} catch (DerivzApplicationException de) {
			LOGGER.error("BookmarkController::restoreTempBookmark() :: Error " + de, de);
			return ResponseBuilder.build(tempBookmarkList, HttpStatus.SC_NOT_FOUND,
					"No recently deleted bookmarks available to restore", DS007);
		} 
	}

	@GetMapping(value = DerivzAPIUriConstants.GET_COB_DATE_URI)
	public @ResponseBody DerivzRestResponse<String> getCobDate() {
		LOGGER.debug("BookmarkController::getCobDate() ");
		String cobDate = "";
		try {
			cobDate = bookmarkService.getCobDateFromDB();
			if (!cobDate.isEmpty()) {
				return ResponseBuilder.build(cobDate, HttpStatus.SC_OK);
			} else {
				return ResponseBuilder.build(cobDate, HttpStatus.SC_NOT_FOUND,
						"No Cob Date found in database", DS007);
			}
		} catch (DerivzApplicationException de) {
			LOGGER.error("BookmarkController::getCobDate() :: Error " + de, de);
			return ResponseBuilder.build(cobDate, HttpStatus.SC_NOT_FOUND,
					"No Cob Date found in database", DS007);
		} 
	}
}
