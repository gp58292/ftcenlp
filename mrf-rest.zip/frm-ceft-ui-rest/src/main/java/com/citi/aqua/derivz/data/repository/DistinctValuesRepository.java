package com.citi.aqua.derivz.data.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.citi.aqua.derivz.model.DerivzDBConstants;
import com.citi.aqua.derivz.model.DistinctValues;

@Repository
public interface DistinctValuesRepository extends CrudRepository<DistinctValues, Long> {

	// This query is used to get the distinct values from the database for distinct
	// values of drop down list
	@Query(value = "select * from " + DerivzDBConstants.SCHEMA_CEFT + "." + DerivzDBConstants.TBL_DISTINCT_DATA
			+ " where composite_key= :key order by CASE ISNUMERIC(value) WHEN 1 THEN REPLICATE('0', 100 - LEN(value))+ value ELSE value END ",nativeQuery= true)
	public List<DistinctValues> findDistinctValueByKey(@Param("key") final Long key);

	// This query is used to get the distinct values from the database for distinct
	// values of type ahead values
	@Query(value = "select  top 20 * from " + DerivzDBConstants.SCHEMA_CEFT + "." + DerivzDBConstants.TBL_DISTINCT_DATA
			+ " where composite_key= :key and value LIKE CONCAT('%', :value ,'%') order by CASE ISNUMERIC(value) WHEN 1 THEN REPLICATE('0', 100 - LEN(value))+ value ELSE value END ",nativeQuery= true)
	public List<DistinctValues> findTypeAheadValue(@Param("key") final Long key, @Param("value") final String value);

	public List<DistinctValues> findByKeyIn(List<Long> key);
	public List<DistinctValues> findAll();
	
	@Query(value = "select * from " + DerivzDBConstants.SCHEMA_CEFT + "." + DerivzDBConstants.TBL_DISTINCT_DATA
			+ " where composite_key In( :key) order by CASE ISNUMERIC(value) WHEN 1 THEN REPLICATE('0', 100 - LEN(value))+ value ELSE value END ",nativeQuery= true)
	public List<DistinctValues> findByCompositeKeyIn(@Param("key") List<Long> compositeKeyList);
	
//  Not developed this, only focused on using cache	
//	@Query(value = "select * from " + DBConstants.SCHEMA_CEFT + "." + DBConstants.TBL_DISTINCT_DATA
//			+ " where composite_key= :key and value in (:value)", nativeQuery = true)
//	public List<DistinctValues> findTypeAheadValueByPstedValue(@Param("key") final Long key, @Param("value") final String[] value);

}
