package com.citi.aqua.derivz.services.grid.model;

import lombok.Data;

/**
 * @author Aleksander Nowinski, aleksander.nowinski@citi.com
 * @since 6/21/2019
 */
@Data
public class CountDataRequest extends DataRequest {
}
