package com.citi.aqua.derivz.utils.hibernate;

import org.hibernate.dialect.SQLServer2008Dialect;
import org.hibernate.type.StandardBasicTypes;

import java.sql.Types;

public class SQLServer2008DialectWithNvarchar extends SQLServer2008Dialect {

    public static final String NVARCHAR_MAX = "nvarchar(MAX)";

    public SQLServer2008DialectWithNvarchar () {
        registerColumnType( Types.NCLOB, NVARCHAR_MAX);
        registerColumnType( Types.LONGNVARCHAR, NVARCHAR_MAX );
        registerColumnType( Types.NVARCHAR, NVARCHAR_MAX );
        registerColumnType( Types.NVARCHAR, 4000, "nvarchar($1)" );
        registerHibernateType(Types.NCHAR, StandardBasicTypes.CHARACTER.getName());
        registerHibernateType(Types.NCHAR, 1, StandardBasicTypes.CHARACTER.getName());
        registerHibernateType(Types.NCHAR, 255, StandardBasicTypes.STRING.getName());
        registerHibernateType(Types.NVARCHAR, StandardBasicTypes.STRING.getName());
        registerHibernateType(Types.LONGNVARCHAR, StandardBasicTypes.TEXT.getName());
        registerHibernateType(Types.NCLOB, StandardBasicTypes.CLOB.getName());
    }
}