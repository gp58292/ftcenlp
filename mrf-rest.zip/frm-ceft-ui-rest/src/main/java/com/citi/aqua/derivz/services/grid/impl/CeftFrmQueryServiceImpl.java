package com.citi.aqua.derivz.services.grid.impl;

import com.citi.aqua.derivz.services.grid.*;
import com.citi.aqua.derivz.services.grid.model.*;
import com.citi.aqua.derivz.services.grid.postprocessing.SearchQueryPostprocessor;
import com.citi.aqua.frm.framework.grid.User;
import com.citi.aqua.frm.framework.grid.query.QueryResult;
import com.citi.aqua.frm.framework.grid.tools.FrmGrid;
import com.citi.aqua.frm.framework.query.FrmQuery;
import com.citi.aqua.frm.framework.query.model.*;
import com.google.common.collect.Iterables;
import lombok.extern.slf4j.Slf4j;

import java.util.*;
import java.util.stream.Collectors;

/**
 * @author Aleksander Nowinski, aleksander.nowinski@citi.com
 * @since 6/21/2019
 */
@Slf4j
public class CeftFrmQueryServiceImpl implements CeftFrmQueryService {

    private final FrmGrid grid;
    private final SearchQueryPostprocessor postprocessor;

    public CeftFrmQueryServiceImpl(FrmGrid grid,
            SearchQueryPostprocessor postprocessor) {
        this.grid = grid;
        this.postprocessor = postprocessor;
    }



    protected FrmQuery buildCoreQuery(DataRequest request) {
        FrmQuery query = new FrmQuery();
        query.setQueryType(FrmQuery.QueryType.SELECT);
        query.setDataSetId(request.getDataSet().toDataSetId());
        List<ConditionAware> filterConditions =
                Optional.ofNullable(request.getFilters()).orElse(Collections.emptyList())
                        .stream()
                        .map(filter -> buildColumnFilter(filter))
                        .collect(Collectors.toList());

        if (!filterConditions.isEmpty()) {
            query.setWhereConditions(Collections.singletonList(CompoundCondition.and(filterConditions)));
        }
        return query;
    }

    protected static ConditionAware buildColumnFilter(ColumnFilter filter) {
        if (filter == null || filter.getColumn() == null || filter.getColumn().isEmpty()
                || filter.getValues() == null || filter.getValues().length == 0) {
            throw new IllegalArgumentException("ColumnFilter should not be null or empty. Current value: " + String.valueOf(filter));
        }

        List<ConditionAware> conditions = Arrays.stream(filter.getValues())
                .map(val ->  new FilterDefinition(filter.getColumn(), val, FilterDefinition.FilterType.EQUAL))
                .collect(Collectors.toList());

        if (Arrays.asList(filter.getValues()).contains("")) {
            conditions.add(new FilterDefinition(filter.getColumn(), null, FilterDefinition.FilterType.IS_NULL));
        }
        return conditions.size() == 1 ? conditions.get(0) : CompoundCondition.or(conditions);
    }

    public long countQuery(CountDataRequest request) {
        log.info("Querying set {} for size, query={}", request.getDataSet(), request);
        FrmQuery query = buildCoreQuery(request);
        query.setQueryType(FrmQuery.QueryType.COUNT);
        QueryResult result = executeQuery(query, request.getDataSet().getSoeId());

        log.debug("Got result: {}", result);
        Map row = result.getResult().get(0);
        Long size = (Long) Iterables.getFirst(row.values(), null);

        return Optional.ofNullable(size).orElse(-1L);
    }

    protected QueryResult executeQuery(FrmQuery query, String soeId) {
        return grid.connectQueryService().queryDataSet(query, new User(soeId, false));
    }

    public SearchQueryResult searchQuery(SearchDataRequest request) {
        log.info("SearchQuery: Querying set {} for size, query={}", request.getDataSet(), request);
        FrmQuery frmQuery = buildCoreQuery(request);
        if (request.getColumns() != null && !request.getColumns().isEmpty()) {
            frmQuery.setSelectDefinitions(request.getColumns().stream()
                    .map(SelectDefinition::new)
                    .collect(Collectors.toList()));
        }
        if (request.getSortCriteria() != null && !request.getSortCriteria().isEmpty()) {
            frmQuery.setOrderDefinitions(
                    request.getSortCriteria()
                            .stream()
                            .map(order -> new OrderDefinition(order.getColumn(),
                                    OrderDefinition.Ordering.NATURAL, order.getOrder().isReversed()))
                            .collect(Collectors.toList()));
        }
        frmQuery.setPagination(new Pagination(request.getLimit(), request.getOffset()));
        QueryResult result = executeQuery(frmQuery, request.getDataSet().getSoeId());
        log.debug("SearchQuery: query completed, got {} result rows in {}", result.getResult().size(),
                result.getExecutionTime());
        SearchQueryResult res =
                new SearchQueryResult((List) result.getResult(), null, request.getLimit(), request.getOffset());
        if(postprocessor!=null) {
            res  = postprocessor.processQueryResult(res);
            log.debug("Applying postprocessing to query result, after posprocessing got {} rows.", res.getValues().size());
        }
        return res;
    }

    public List<Object> distinctValuesQuery(DistinctValueDataRequest request) {
        log.debug("DistinctValuesQuery: Querying set {} for distinct column {} values, query={}", request.getDataSet(),
                request.getColumn(), request);
        FrmQuery query = buildCoreQuery(request);
        query.setSelectDefinitions(Collections.singletonList(new SelectDefinition(request.getColumn())));
        query.setOrderDefinitions(Collections.singletonList(new OrderDefinition(request.getColumn())));
        query.setDistinct(true);
        QueryResult result = executeQuery(query, request.getDataSet().getSoeId());

        List<Object> list = result.getResult()
                .stream()
                .map(row -> Iterables.getFirst(row.values(), null))
                .collect(Collectors.toList());
        List<Object> logList = list.size()>5? list.subList(0,5):list;
        log.info("DistinctValuesQuery: Querying set {} for distinct column {} values, got result: {}{}.", request.getDataSet(),
                request.getColumn(), logList, list.size()>logList.size()?"... ":"");

        return list;
    }
}
