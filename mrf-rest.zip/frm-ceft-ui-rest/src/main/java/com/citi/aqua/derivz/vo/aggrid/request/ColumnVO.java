package com.citi.aqua.derivz.vo.aggrid.request;

import java.io.Serializable;

import lombok.Data;

@Data
public class ColumnVO implements Serializable {
	private static final long serialVersionUID = 1L;
	private String id;
    private String displayName;
    private String field;
    private String aggFunc;
}