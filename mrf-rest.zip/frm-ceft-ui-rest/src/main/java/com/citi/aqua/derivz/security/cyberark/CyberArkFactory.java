package com.citi.aqua.derivz.security.cyberark;

import javapasswordsdk.PSDKPassword;
import javapasswordsdk.PSDKPasswordRequest;
import javapasswordsdk.exceptions.PSDKException;

public class CyberArkFactory {


    public String getPassword(String appId, String safe, String object, String reason) throws InterruptedException, PSDKException {
        PSDKPasswordRequest passRequest = new PSDKPasswordRequest();
        PSDKPassword password = null;
        passRequest.setAppID(appId);
        passRequest.setSafe(safe);
        passRequest.setObject(object);
        passRequest.setReason(reason);
        passRequest.setFailRequestOnPasswordChange(false);
        boolean passRetrieved = false;

        while (!passRetrieved) {
            // Sending the request to get the password
            password = javapasswordsdk.PasswordSDK.getPassword(passRequest);
            if (password.getAttribute("PasswordChangeInProcess").equals("true")) {
                Thread.sleep(3000);
            } else {
                passRetrieved = true;
            }
        }

        return password.getContent();
    }

}