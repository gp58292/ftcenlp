package com.citi.aqua.derivz.services.grid;

import com.citi.aqua.derivz.services.grid.model.CountDataRequest;
import com.citi.aqua.derivz.services.grid.model.DistinctValueDataRequest;
import com.citi.aqua.derivz.services.grid.model.SearchDataRequest;
import com.citi.aqua.derivz.services.grid.model.SearchQueryResult;

import java.util.List;

/**
 * @author Aleksander Nowinski, aleksander.nowinski@citi.com
 * @since 6/21/2019
 */
public interface CeftFrmQueryService {
    long countQuery(CountDataRequest request);

    SearchQueryResult searchQuery(SearchDataRequest request);

    List<Object> distinctValuesQuery(DistinctValueDataRequest request);
}
