package com.citi.aqua.derivz.model.ui;

import java.util.Optional;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.Setter;


/**
 * @author vn06956
 *
 */
@ConfigurationProperties(prefix=UIComponentConstant.AQUA_UI_COMPONENT)
@Component
@Getter
@Setter
public class UIComponentConfig {

	UIComponent typeahead;
	
	@Getter
	@Setter
	public static class UIComponent {		
		private Optional<Long> limit;
	}
}
