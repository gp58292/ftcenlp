package com.citi.aqua.derivz.services.grid.postprocessing;

import com.citi.aqua.derivz.services.grid.model.SearchQueryResult;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * @author Aleksander Nowinski, aleksander.nowinski@citi.com
 * @since 7/5/2019
 */
public class SearchQueryPostprocessor {

    private List<RowPostprocessor> rowPostprocessors;

    public SearchQueryPostprocessor(List<RowPostprocessor> rowPostprocessors) {
        this.rowPostprocessors = rowPostprocessors;
    }

    public SearchQueryResult processQueryResult(SearchQueryResult input) {
        List<Map<String, Object>> values = input.getValues();
        List<Map<String, Object>> filteredValues = values.stream()
                .map(this::processRow)
                .filter(Objects::nonNull)
                .collect(Collectors.toList());
        return new SearchQueryResult(filteredValues, null, input.getLimit(), input.getOffset());
    }

    protected Map<String, Object> processRow(Map<String, Object> row) {
        for (RowPostprocessor p : rowPostprocessors) {
            row = Optional.ofNullable(row).map(p::processRow).orElse(null);
        }
        return row;
    }
}
