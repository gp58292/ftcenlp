package com.citi.aqua.derivz.web.utils;

import java.util.List;

import com.citi.aqua.derivz.vo.SearchFieldVO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DerivzExportResultRestRequest {
	
	private String source;
	
	@SuppressWarnings("rawtypes")
	private List<SearchFieldVO> criteria;
	
	private List<Long> agreementKeys;

}
