package com.citi.aqua.derivz.services.grid.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Aleksander Nowinski, aleksander.nowinski@citi.com
 * @since 7/9/2019
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class GroupingSearchDataRequest extends SearchDataRequest {
    List<String> columnGrouping=new ArrayList<>();
    List<String> groupValues=new ArrayList<>();
    List<ColumnAggregation> aggregations=new ArrayList<>();
    List<String> pivotColumns=new ArrayList<>();
}
