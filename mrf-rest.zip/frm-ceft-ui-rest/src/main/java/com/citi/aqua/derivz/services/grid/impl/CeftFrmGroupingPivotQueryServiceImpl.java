package com.citi.aqua.derivz.services.grid.impl;

import com.citi.aqua.derivz.services.grid.*;
import com.citi.aqua.derivz.services.grid.model.*;
import com.citi.aqua.derivz.services.grid.postprocessing.SearchQueryPostprocessor;
import com.citi.aqua.frm.framework.grid.query.DirectSqlQuery;
import com.citi.aqua.frm.framework.grid.query.QueryResult;
import com.citi.aqua.frm.framework.grid.tools.FrmGrid;
import com.google.common.collect.Iterables;
import com.google.common.collect.Streams;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.ListUtils;
import org.apache.commons.lang3.tuple.ImmutablePair;

import java.util.*;
import java.util.stream.Collectors;

/**
 * @author Aleksander Nowinski, aleksander.nowinski@citi.com
 * @since 7/9/2019
 */
@Slf4j
public class CeftFrmGroupingPivotQueryServiceImpl implements CeftFrmGroupingPivotQueryService {

    private static final int MAX_PIVOT_VALUES = 100;
    private final FrmGrid grid;
    private final SearchQueryPostprocessor postprocessor;
    private final CeftFrmQueryService queryService;

    public CeftFrmGroupingPivotQueryServiceImpl(FrmGrid grid,
            SearchQueryPostprocessor postprocessor, CeftFrmQueryService queryService) {
        this.grid = grid;
        this.postprocessor = postprocessor;
        this.queryService = queryService;
    }

    @Override
    public long countQueryGrouping(GroupingSearchDataRequest request) {
        String sqlQuery;
        if (isAggregate(request)) {
            sqlQuery = buildCountAggregateQuery(request);
            log.debug("Generated aggregation query: {}", sqlQuery);
        } else {
            sqlQuery = buildPlainCountQuery(request);
            log.debug("Generated plain request query: {}", sqlQuery);
        }
        CeftDataSet dataSet = request.getDataSet();
        return executeCountQuery(sqlQuery, dataSet);
    }

    protected long executeCountQuery(String sqlQuery, CeftDataSet dataSet) {
        List<Map<String, ?>> res = executePlainQuery(sqlQuery, dataSet);
        Object first = Iterables.getFirst(res.get(0).values(), null);
        return ((Number) Objects.requireNonNull(first)).longValue();
    }

    @Override
    public SearchQueryResult searchQueryGrouping(GroupingSearchDataRequest request) {
        String sqlQuery;
        if (isAggregate(request)) {
            sqlQuery = buildAggregateQuery(request);
            log.debug("Generated aggregation query: {}", sqlQuery);
        } else {
            sqlQuery = buildPlainQuery(request);
            log.debug("Generated plain request query: {}", sqlQuery);
        }
        List<Map<String, Object>> qres;
        qres = executePlainQuery(sqlQuery, request.getDataSet()).stream()
                .map(m -> (Map<String, Object>) m)
                .collect(Collectors.toList());

        SearchQueryResult result = new SearchQueryResult(qres, null, request.getLimit(), request.getOffset());
        if (Objects.nonNull(postprocessor)) {
            result = postprocessor.processQueryResult(result);
        }
        return result;

    }

    @Override
    public SearchQueryResult pivotQuery(GroupingSearchDataRequest request) {
        List<List<Object>> pivotValues = extractPivotValues(request);
        String pivotQuery = buildPivotQuery(request, pivotValues);

        log.debug("CeftFrmGroupingPivotQueryServiceImpl::pivotQuery executing pivot, request: {} SQL: {}", request,
                pivotQuery);

        List<Map<String, ?>> qres = executePlainQuery(pivotQuery, request.getDataSet());
        List<Map<String, Object>> obqres = qres.stream().map(m -> (Map<String, Object>) m).collect(Collectors.toList());

        log.debug("Got result, {} rows.", qres.size());
        List<ColumnValues> pivotColumnValues = Streams.zip(request.getPivotColumns().stream(),
                pivotValues.stream()
                        .map(l -> l.stream()
                                .map(val -> val == null ? null : val.toString())
                                .collect(Collectors.toList())), (col, vals) -> new ColumnValues(col, vals)).collect(
                Collectors.toList());
        SearchQueryResult res = new SearchQueryResult(obqres,
                pivotColumnValues,
                request.getLimit(), request.getOffset());
        return res;
    }


    @Override
    public long countPivotQuery(GroupingSearchDataRequest request) {
        String sql = countQuery(buildPivotQueryCore(request, extractPivotValues(request)));
        return executeCountQuery(sql, request.getDataSet());
    }

    private String buildPivotQueryCore(GroupingSearchDataRequest request, List<List<Object>> pivotValues) {
        List<List<Object>> pivotCombinations = cartesian(pivotValues);
        List<String> pivotColumnStatements = pivotCombinations.stream()
                .flatMap(combination -> request.getAggregations()
                        .stream()
                        .map(aggregation -> new ImmutablePair<>(combination, aggregation)))
                .map(p -> pivotQueryColumns(request.getPivotColumns(), p.left, p.right))
                .collect(Collectors.toList());
        List<String> groupingColumnStatement = buildGroupingColumnList(request);

        return buildSelectClause(groupingColumnStatement, pivotColumnStatements)
                + buildFromClause(request.getDataSet())
                + buildWhereClause(request)
                + buildGroupClause(groupingColumnStatement);
    }

    protected static List<List<Object>> cartesian(List<List<Object>> lists) {
        if (lists.isEmpty()) {
            return Collections.emptyList();
        } else if (lists.size() == 1) {
            return lists.get(0).stream().map(Collections::singletonList).collect(Collectors.toList());
        }
        List<List<Object>> restCartesian = cartesian(lists.subList(1, lists.size()));
        List<List<Object>> collect = lists.get(0)
                .stream()
                .flatMap(o -> restCartesian.stream().map(l -> ListUtils.union(Collections.singletonList(o), l)))
                .collect(Collectors.toList());
        return collect;

    }

    private String buildPivotQuery(GroupingSearchDataRequest request, List<List<Object>> pivotValues) {
        return buildPivotQueryCore(request, pivotValues) + buildLimitClause(request);
    }

    private String pivotQueryColumns(List<String> columns, List<Object> columnValues, ColumnAggregation aggregation) {
        String valCond = Streams.zip(columns.stream(),
                columnValues.stream(),
                (col, val) -> buildEqCondition(col, val))
                .collect(Collectors.joining(" AND "));

        String colName = String.format("PIVOT|%s|%s(%s)",
                columnValues.stream().map(v -> ("" + v).replace('|', '_')).collect(Collectors.joining("|")),
                aggregation.getAggregation().getFunction(),
                aggregation.getColumn());

        String res = String.format("%s(CASE WHEN (%s) THEN %s END) AS \"%s\"",
                aggregation.getAggregation().getFunction(), valCond, aggregation.getColumn(), colName);
        return res;
    }

    protected List<List<Object>> extractPivotValues(GroupingSearchDataRequest request) {
        return request.getPivotColumns()
                .stream()
                .map(col -> columnPivotValues(col, request))
                .collect(Collectors.toList());
    }

    private List<Object> columnPivotValues(String col, GroupingSearchDataRequest groupingRequest) {
        DistinctValueDataRequest req = new DistinctValueDataRequest();
        req.setDataSet(groupingRequest.getDataSet());
        req.setFilters(groupingRequest.getFilters());
        req.setColumn(col);

        List<Object> res = queryService.distinctValuesQuery(req);
        if (res.size() > MAX_PIVOT_VALUES) {
            res = res.subList(0, MAX_PIVOT_VALUES);
        }
        return res;
    }

    private List<Map<String, ?>> executePlainQuery(String sqlQuery, CeftDataSet dataSet) {
        QueryResult queryResult = grid.connectQueryService()
                .queryDatasetDirect(new DirectSqlQuery(dataSet.toDataSetId(), sqlQuery), dataSet.toUser());
        return queryResult.getResult();
    }

    protected String buildPlainQuery(GroupingSearchDataRequest request) {
        String coreSqlClause = buildPlainQueryCore(request);
        return coreSqlClause + buildLimitClause(request);
    }

    protected String buildPlainCountQuery(GroupingSearchDataRequest request) {
        String coreSqlClause = buildPlainQueryCore(request);
        return countQuery(coreSqlClause);
    }

    private String countQuery(String coreSqlClause) {
        return String.format("SELECT COUNT(*) FROM (%s)", coreSqlClause);
    }


    private String buildPlainQueryCore(GroupingSearchDataRequest request) {
        List<String> selectGroupingValues = buildGroupingColumnList(request);

        List<String> aggregationColumnAsValues = Optional.ofNullable(request.getAggregations())
                .map(al -> al.stream().map(ColumnAggregation::getColumn).collect(Collectors.toList()))
                .orElse(Collections.emptyList());

        List<String> otherColumns;
        if (request.getColumns() == null || request.getColumns().isEmpty()) {
            otherColumns = Collections.singletonList("*");
        } else {
            otherColumns = new ArrayList<>(request.getColumns());
        }
        String selectClause = buildSelectClause(selectGroupingValues, aggregationColumnAsValues, otherColumns);

        return selectClause + buildFromClause(request.getDataSet()) + buildWhereClause(request);
    }


    protected String buildAggregateQuery(GroupingSearchDataRequest request) {
        return buildAggregateQueryCore(request) + buildLimitClause(request);
    }

    protected String buildCountAggregateQuery(GroupingSearchDataRequest request) {
        return countQuery(buildAggregateQueryCore(request));
    }

    private String buildAggregateQueryCore(GroupingSearchDataRequest request) {
        //agregacja
        //select (l1, l2, ln+1) (agg1, agg2, ...)
        List<String> selectGroupingValues = buildGroupingColumnList(request);

        List<ColumnAggregation> aggregationList =
                Optional.ofNullable(request.getAggregations()).orElse(Collections.emptyList());
        List<String> aggregationColumns =
                aggregationList.stream().map(this::buildColumnAggregation).collect(Collectors.toList());

        String selectClause = buildSelectClause(selectGroupingValues, aggregationColumns);

        // from ()
        String fromClause = buildFromClause(request.getDataSet());

        // where ()
        String whereClause = buildWhereClause(request);
        // group by ()
        String groupClause = buildGroupClause(selectGroupingValues);

        return selectClause + fromClause + whereClause + groupClause;
    }

    private String buildGroupClause(List<String> selectGroupingValues) {
        return " GROUP BY " + String.join(", ", selectGroupingValues);
    }

    private List<String> buildGroupingColumnList(GroupingSearchDataRequest request) {
        if (isAggregate(request)) {
            return request.getColumnGrouping()
                    .stream()
                    .limit(request.getGroupValues().size() + 1)
                    .collect(Collectors.toList());
        } else {
            return new ArrayList<>(request.getColumnGrouping());
        }
    }


    private String buildLimitClause(GroupingSearchDataRequest request) {
        return String.format(" LIMIT %s OFFSET %s", request.getLimit(), request.getOffset());
    }

    private String buildWhereClause(GroupingSearchDataRequest request) {
        List<String> groupInducedConditions =
                Streams.zip(request.getGroupValues().stream(), request.getColumnGrouping().stream(),
                        (v, c) -> buildEqCondition(c, v)).collect(Collectors.toList());

        List<String> filterConditions = buildFilterConditions(request.getFilters());

        String conditions = Streams.concat(groupInducedConditions.stream(), filterConditions.stream())
                .collect(Collectors.joining(" AND "));
        return conditions.isEmpty() ? " " : " WHERE " + conditions;
    }

    protected String buildSelectClause(List<String>... columnClauses) {
        String columns = Arrays.stream(columnClauses).flatMap(List::stream)
                .collect(Collectors.joining(", "));
        if (columns.isEmpty()) {
            columns = "*";
        }
        return "SELECT " + columns;
    }

    private List<String> buildFilterConditions(List<ColumnFilter> filters) {
        return Optional.ofNullable(filters)
                .orElse(Collections.emptyList())
                .stream()
                .map(this::buildFilterClause)
                .collect(Collectors.toList());
    }

    protected String buildFilterClause(ColumnFilter filter) {
        String combined = Arrays.stream(filter.getValues())
                .map(val -> buildEqCondition(filter.getColumn(), val))
                .collect(Collectors.joining(" OR "));
        if (filter.getValues().length > 1) {
            return "(" + combined + ")";
        } else {
            return combined;
        }
    }

    protected static String buildEqCondition(String column, Object value) {
        if (value == null || (String.class.isInstance(value) && ((String) value).isEmpty())) {
            return String.format("(%1$s='' OR %1$s IS NULL)", column, value);
        } else {
            return String.format("%s='%s'", column, value);
        }
    }

    protected String buildFromClause(CeftDataSet ceftDataSet) {
        String sqlNamespace = grid.connectQueryService().getDataSetSQLNamespace(ceftDataSet.toDataSetId(), ceftDataSet
                .toUser());
        String sqlTableName = grid.connectQueryService().getDataSetSQLTableName(ceftDataSet.toDataSetId(), ceftDataSet
                .toUser());
        return String.format(" FROM %s.%s", sqlNamespace, sqlTableName);
    }

    private String buildColumnAggregation(ColumnAggregation columnAggregation) {
        return String.format("%s(%s)", columnAggregation.getAggregation().getFunction(), columnAggregation.getColumn());
    }

    protected boolean isAggregate(GroupingSearchDataRequest request) {
        return Optional.ofNullable(request.getGroupValues()).map(List::size).orElse(0) < request.getColumnGrouping()
                .size();
    }
}
