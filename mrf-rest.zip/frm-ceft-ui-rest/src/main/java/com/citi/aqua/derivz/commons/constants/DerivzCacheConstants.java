package com.citi.aqua.derivz.commons.constants;

public final class DerivzCacheConstants {

	// Cache
	public static final String REFERENCE_DATA_CACHE = "ReferenceDataCache";
	public static final String TREE_VIEW_FILTER_LIST_CACHE =  "TreeViewFilterListCache";	
	public static final String FLAT_VIEW_FILTER_LIST_CACHE =  "FlatViewFilterListCache";
	public static final String STATIC_DATA_CACHE="StaticDataCache";


	
	private DerivzCacheConstants() {
	    throw new AssertionError();
	}

}
