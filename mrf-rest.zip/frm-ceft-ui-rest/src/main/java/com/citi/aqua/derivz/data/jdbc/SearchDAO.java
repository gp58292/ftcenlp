package com.citi.aqua.derivz.data.jdbc;


import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Repository;
import com.citi.aqua.derivz.commons.exceptions.DerivzApplicationException;
import com.citi.aqua.derivz.dto.CollateralResponseDTO;
import com.citi.aqua.derivz.dto.ListDataResponseDTO;
import com.citi.aqua.derivz.vo.RatingFieldVO;
import com.citi.aqua.derivz.vo.UserDatasetVO;

@Repository
public interface SearchDAO {

	@SuppressWarnings("rawtypes")
	public ListDataResponseDTO callMacDataRetrivalProc(final List<String[]> rowList,List<RatingFieldVO> listOfRangeField) throws DerivzApplicationException;

	public List<CollateralResponseDTO> callCollateralLookupProc(final List<String[]> rowList) throws DerivzApplicationException;
	
	public List<Map<String,Object>> callDataRetrivalProc(final String tabsName,final List<Long> agreementIdList,final Boolean isFilterd,final List<String[]> rowList) throws DerivzApplicationException;

	public List<UserDatasetVO> callGetCurrentDatasetIdProc(String soeId) throws DerivzApplicationException;

}