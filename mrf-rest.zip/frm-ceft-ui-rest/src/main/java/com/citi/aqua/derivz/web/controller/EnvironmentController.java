package com.citi.aqua.derivz.web.controller;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping(value = {"/api/utils"})
@Slf4j
public class EnvironmentController {

    @Value("${security.oauth2.client.userAuthorizationUri:http://localhost:8080/oauth/authorize}")
    private String userAuthorizationUri;

    @Value("${security.oauth2.client.accessTokenUri:http://localhost:8080/oauth/token}")
    private String accessTokenUri;

    @Value("${security.oauth2.resource.tokenInfoUri:http://localhost:8080/oauth/check_token}")
    private String tokenInfoUri;

    @Value("${security.oauth2.resource.userInfoUri:http://localhost:8080/info/user/me}")
    private String userInfoUri;

    @Value("${citi.frm.environment:dev}")
    private String applicationEnvironment;

    @RequestMapping(value = "/environmentDetails", method = RequestMethod.GET)
    public Map<String, String> environmentDetails() {
        Map<String, String> map = new HashMap<>();
        map.put("envName", this.applicationEnvironment);
        map.put("buildVersion", "n/a");
        map.put("userAuthorizationUri", this.userAuthorizationUri);
        map.put("accessTokenUri", this.accessTokenUri);
        map.put("tokenInfoUri", this.tokenInfoUri);
        map.put("userInfoUri", this.userInfoUri);
        return map;
    }

}
