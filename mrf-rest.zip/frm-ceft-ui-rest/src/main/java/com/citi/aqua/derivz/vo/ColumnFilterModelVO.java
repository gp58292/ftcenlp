package com.citi.aqua.derivz.vo;

import java.util.List;

public class ColumnFilterModelVO extends FilterModelVO {
	
	private static final long serialVersionUID = 1L;
	
	private List<String> values;

    public ColumnFilterModelVO() {}

    public ColumnFilterModelVO(List<String> values) {
        this.values = values;
    }

    public List<String> getValues() {
        return values;
    }
}
