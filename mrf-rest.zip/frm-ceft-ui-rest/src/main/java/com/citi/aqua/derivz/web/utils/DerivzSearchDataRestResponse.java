package com.citi.aqua.derivz.web.utils;

import com.citi.aqua.derivz.dto.BookmarkResponseDTO;
import com.citi.aqua.derivz.dto.ListDataResponseDTO;
import com.citi.aqua.derivz.services.grid.CeftDataSetStatus;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Getter;
import lombok.Setter;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
@Getter
@Setter
public class DerivzSearchDataRestResponse {

	private ListDataResponseDTO searchResult;
	
	private CeftDataSetStatus dataSetStatus;
	
	private BookmarkResponseDTO bookmarkWithStatus;
}
