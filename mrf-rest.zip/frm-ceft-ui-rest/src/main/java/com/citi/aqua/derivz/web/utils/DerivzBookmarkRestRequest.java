package com.citi.aqua.derivz.web.utils;

import java.util.List;
import com.citi.aqua.derivz.vo.BookmarkVO;
import com.citi.aqua.derivz.vo.SearchFieldVO;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DerivzBookmarkRestRequest<T> {

	private String userId;

	private Long bookmarkId;

	private List<BookmarkVO> bookmarkData;

	@SuppressWarnings("rawtypes")
	private List<SearchFieldVO> searchCriteria;

	private String bookmarkName;
	
	private Long parentBookmarkId;

}
