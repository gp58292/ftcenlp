package com.citi.aqua.derivz.services.grid;

import com.citi.aqua.derivz.services.grid.model.GroupingSearchDataRequest;
import com.citi.aqua.derivz.services.grid.model.SearchQueryResult;

/**
 * @author Aleksander Nowinski, aleksander.nowinski@citi.com
 * @since 7/9/2019
 */
public interface CeftFrmGroupingPivotQueryService {

    SearchQueryResult searchQueryGrouping(GroupingSearchDataRequest request);

    long countQueryGrouping(GroupingSearchDataRequest request);

    SearchQueryResult pivotQuery(GroupingSearchDataRequest request);

    long countPivotQuery(GroupingSearchDataRequest request);
}
