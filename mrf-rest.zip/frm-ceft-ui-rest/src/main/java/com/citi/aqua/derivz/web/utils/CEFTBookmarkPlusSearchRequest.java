package com.citi.aqua.derivz.web.utils;

import com.citi.aqua.derivz.vo.aggrid.request.EnterpriseGetRowsRequest;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CEFTBookmarkPlusSearchRequest {

	private BookmarkRequest bookmarkRequest;

	private SearchRequest searchRequest;
	
	private String atmosphereResourceUuid;
	
	private EnterpriseGetRowsRequest gridRequest ;

}
