package com.citi.aqua.derivz.model.ui;


/**
 * @author vn06956
 *
 */
public class UIComponentConstant {

	public static final String AQUA_UI_COMPONENT="ui.component";
	
	
	private UIComponentConstant() {}
}
