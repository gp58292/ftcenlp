package com.citi.aqua.derivz.services.grid;

import lombok.NoArgsConstructor;
import lombok.Value;
import lombok.extern.slf4j.Slf4j;

import java.util.HashMap;
import java.util.Map;

/**
 * Support for routing of the websocket messages.
 *
 * @author Aleksander Nowinski, aleksander.nowinski@citi.com
 * @since 6/28/2019
 */
@Slf4j
@NoArgsConstructor
public class LoadingProgressTracker {

    private final Map<String, CeftDataSetEntry> requestMap = new HashMap<>();

    public void registerWebSocketUUID(CeftDataSet dataSet, long version, String requestUuid) {
        requestMap.put(dataSet.toDataSetId().getSetId(), new CeftDataSetEntry(dataSet, requestUuid, version));
    }

    public String findUUID(String frmSetId, Long version) {
        CeftDataSetEntry entry = requestMap.get(frmSetId);
        if (entry != null && (version == null || version.equals(entry.getVersion()))) {
            return entry.getUuid();
        } else {
            return null;
        }
    }

    public CeftDataSet findDataSet(String frmSetId, Long version) {
        CeftDataSetEntry entry = requestMap.get(frmSetId);
        if (entry != null && (version == null || version.equals(entry.getVersion()))) {
            return entry.getDataSet();
        } else {
            return null;
        }
    }

    @Value
    private static class CeftDataSetEntry {
        CeftDataSet dataSet;
        String uuid;
        long version;
    }
}
