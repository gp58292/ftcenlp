package com.citi.aqua.derivz.services.grid;

import com.citi.aqua.frm.ceft.CeftDataSetType;
import com.citi.aqua.frm.ceft.CeftIdMapper;
import com.citi.aqua.frm.framework.grid.data.DataSetStatus;
import com.citi.aqua.frm.framework.grid.data.DataSetStatusCode;
import com.citi.aqua.frm.framework.grid.data.LoadingProcessStatus;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.Optional;

/**
 * @author Aleksander Nowinski, aleksander.nowinski@citi.com
 * @since 6/26/2019
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CeftDataSetStatus {
    private CeftDataSet dataSet;
    //bookmark timestamp
    private Date timestamp;
    private DataSetStatusCode status;
    private long loaded = -1L;
    private long total = -1L;
    private String webSocketUuid = null;

    public CeftDataSetStatus(DataSetStatus frmStatus, String soeId) {
        String setId = frmStatus.getId().getSetId();
        long bookmark = CeftIdMapper.bookmarkIdFromDataSetId(setId);
        CeftDataSetType type = CeftIdMapper.ceftDataSetTypeFromDataSetId(setId);
        this.dataSet = new CeftDataSet(soeId, bookmark, type);
        if (frmStatus.getVersion() != null && frmStatus.getVersion().getVersion() != null) {
            this.timestamp = new Date(frmStatus.getVersion().getVersion());
        }
        this.status = frmStatus.getStatus();
        LoadingProcessStatus loadingState = frmStatus.getLastOperationState();
        if (loadingState != null) {
            this.loaded = Optional.ofNullable(loadingState.getLoadedItems()).orElse(-1L);
            this.total = Optional.ofNullable(loadingState.getTotalItems()).orElse(-1L);
        }
    }


    public boolean isReady() {
        return DataSetStatusCode.READY == this.status;
    }

    public Double getLoadingProgress() {
        if (total > 0 && loaded >= 0) {
            return loaded / (double) total;
        } else if (total == 0 && loaded == 0) {
            return 1.0;
        } else {
            return null;
        }
    }
}
