package com.citi.aqua.derivz.vo;

import java.math.BigDecimal;
import java.sql.Date;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@JsonInclude(Include.NON_NULL)
public class ForwardMtmDataVO {
	
	private long fwdMtmKey;
	private int agreementId;
	private long agreementKey;
	private Date busDate;
	private int underlyingTenor;
	private BigDecimal underlyingene;
	private BigDecimal underlyingepe;
	private BigDecimal fwdCollExposure;
	private BigDecimal fwdCollExposurePostConcentration;
	private String clearingAgreement;
	private String collateralTypeName;
	private String consentToSubstitution;
	private String counterPartyName;
	private String cpMarginType;
	private String csaDescription;
	private String csaMarginType;
	private String csaStatus;
	private String custodianRequired;
	private String customerName;
	private String exchangeClearedAgreement;
	private String gfcid;
	private String gfcidType;
	private String gfcidDescription;
	private String governingLaw;
	private String imVm;
	private String incorporatedCountry;
	private String industrySector;
	private String masterAgreement;
	private String masterAgreementStatus;
	private String mgdSegLevel5Desc;
	private String partyLegalEntity;
	private String pledgor;
	private String resolvedBusinessUnit;
	private String sme;
	private String saTriggerEvent;
	private String sixCApplies;
	private String triggerEvent;
	private String typeOfCollateral;
	private String underlyingBusinessUnit;
	private String lvidName;
	private String mandatoryMarkFrequency; 
	private String interCompanyAgreement;
	private String partyCustodianRequired;
	private String counterPartyCustodianRequired;
	private String businessDate;
	private String underlyingTenorDesc;
	
}