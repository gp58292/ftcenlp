package com.citi.aqua.derivz.services.grid;

import lombok.Data;

/**
 * @author Aleksander Nowinski, aleksander.nowinski@citi.com
 * @since 6/21/2019
 */
@Data
public class ColumnSortCriteria {
    String column;
    SortOrder order;
}
