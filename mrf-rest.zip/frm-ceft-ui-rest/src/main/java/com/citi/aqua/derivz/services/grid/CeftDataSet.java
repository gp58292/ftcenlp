package com.citi.aqua.derivz.services.grid;

import com.citi.aqua.frm.ceft.CeftConstants;
import com.citi.aqua.frm.ceft.CeftDataSetType;
import com.citi.aqua.frm.ceft.CeftIdMapper;
import com.citi.aqua.frm.framework.grid.User;
import com.citi.aqua.frm.framework.grid.data.DataSetId;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Aleksander Nowinski, aleksander.nowinski@citi.com
 * @since 6/21/2019
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CeftDataSet {
    private String soeId;
    private long bookmarkId;
    private CeftDataSetType type;

    public DataSetId toDataSetId() {
        return new DataSetId(CeftConstants.CEFT_DATA_SET_SOURCE_ID, CeftIdMapper.buildDataSetId(bookmarkId, type));
    }

    public User toUser() {
        return new User(soeId, false);
    }
}
