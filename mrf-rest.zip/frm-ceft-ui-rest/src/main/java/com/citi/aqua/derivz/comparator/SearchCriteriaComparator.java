package com.citi.aqua.derivz.comparator;

import java.util.Comparator;

import com.citi.aqua.derivz.vo.SearchFieldVO;

public class SearchCriteriaComparator implements Comparator<SearchFieldVO> {

	@Override
	public int compare(SearchFieldVO o1, SearchFieldVO o2) {
		return o1.getName().compareTo(o2.getName());
	}

}
