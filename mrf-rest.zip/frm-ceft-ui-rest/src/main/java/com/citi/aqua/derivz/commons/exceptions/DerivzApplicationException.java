package com.citi.aqua.derivz.commons.exceptions;

import java.text.MessageFormat;
import java.util.Locale;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @name  DerivzApplicationException
 * @description Class used to keep track of application exception
 *
 */
public class DerivzApplicationException extends DerivzException {

	private static final long serialVersionUID = 1L;

	private static final Locale defaultLocale = Locale.US;

	private final String cause;

	private static final Logger LOGGER = LoggerFactory.getLogger(DerivzApplicationException.class);

	private final transient Object[] replaceOption;

	private final transient ExceptionMessageDescriptor messageDescriptor;

	/**
	 * @name DerivzApplicationException
	 * @description Creates Application Exception which can be accessed as
	 *              DerivzException
	 * @param exception
	 * @param messageDescriptor
	 * @param replaceOption
	 * @return DerivzApplicationException
	 */
	public DerivzApplicationException(Throwable exception, ExceptionMessageDescriptor messageDescriptor,
			Object... replaceOption) {
		super(exception);
		this.cause = exception.getMessage();
		this.replaceOption = replaceOption;
		this.messageDescriptor = messageDescriptor;
	}

	/**
	 * @name getInterpolatedMessage
	 * @param locale
	 * @return string
	 */
	public String getInterpolatedMessage(Locale locale) {
		ResourceBundle bundle = ResourceBundle.getBundle("i18n.race-message-bundle", locale);
		return constructInterpolatedMessages(bundle);
	}

	/**
	 * @name constructInterpolatedMessages
	 * @param bundle
	 * @return string
	 */
	private String constructInterpolatedMessages(ResourceBundle bundle) {
		String message;
		try {
			message = bundle.getString(messageDescriptor.getMessageCode());
			if (replaceOption != null && replaceOption.length > 0) {
				message = MessageFormat.format(message, replaceOption);
			}
		} catch (MissingResourceException ex) {
			// If description not found for this code in bundle, set default description
			LOGGER.error("No message found for code: " + messageDescriptor.getMessageCode()
					+ ", setting default message desciption");
			LOGGER.error(ex.getClass() + ": " + ex.getMessage() + ": " + ex.getCause(), ex);
			message = messageDescriptor.getMessageDescription();
		}

		// If description returned from bundle is empty, set default
		if (message.isEmpty()) {
			message = messageDescriptor.getMessageDescription();
		}
		return message;
	}

	/**
	 * @name getDefaultInterpolatedMessage
	 * @param
	 * @return string
	 */
	public String getDefaultInterpolatedMessage() {
		return getInterpolatedMessage(defaultLocale);
	}

	/**
	 * @name getReplaceOption
	 * @param
	 * @return Object[]
	 */
	public Object[] getReplaceOption() {
		return replaceOption;
	}

	/**
	 * @name getCauseMessage
	 * @param
	 * @return String
	 */
	public String getCauseMessage() {
		return this.cause;
	}

	/**
	 * @name getExceptionCode
	 * @param
	 * @return String
	 */
	public String getExceptionCode() {
		return (messageDescriptor != null) ? messageDescriptor.getMessageCode() : "UNKNOWN";
	}

}
