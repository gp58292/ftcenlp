package com.citi.aqua.derivz.model;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Entity
@Table(name = DerivzDBConstants.IP_INPUT_PARAMETERS, schema=DerivzDBConstants.SCHEMA_CEFT)
public class InputParameters implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "field")
	private String fieldName;

	@Id
	@Column(name = "node")
	private String node;

	@Id
	@Column(name = "filter_value")
	private String filterValue;

	@Id
	@Column(name = "conditions")
	private String conditions;

}