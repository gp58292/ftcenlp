package com.citi.aqua.derivz.data.jdbc.impl;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.citi.aqua.derivz.commons.constants.DerivzCommonConstants;
import com.citi.aqua.derivz.commons.constants.TabsName;
import com.citi.aqua.derivz.commons.exceptions.CEFTException;
import com.citi.aqua.derivz.commons.exceptions.DerivzApplicationException;
import com.citi.aqua.derivz.commons.exceptions.DerivzDAOLayerException;
import com.citi.aqua.derivz.data.jdbc.SearchResultDAO;
import com.citi.aqua.derivz.dto.ListDataResponseDTO;
import com.citi.aqua.derivz.model.DBConstants;
import com.citi.aqua.derivz.model.DerivzDBConstants;
import com.citi.aqua.derivz.model.columns.mapping.SearchResultColumns;
import com.citi.aqua.derivz.vo.AgreementOptimalRankVO;
import com.citi.aqua.derivz.vo.RatingFieldVO;
import com.citi.aqua.derivz.vo.aggrid.request.EnterpriseGetRowsRequest;
import com.microsoft.sqlserver.jdbc.SQLServerCallableStatement;
import com.microsoft.sqlserver.jdbc.SQLServerDataTable;
import com.microsoft.sqlserver.jdbc.SQLServerException;

@Repository
public class SearchResultDAOImpl implements SearchResultDAO {

	private static final Logger LOGGER = LoggerFactory.getLogger(SearchResultDAOImpl.class);

	@Autowired
	private JdbcTemplate jdbcTemplate;

	public SearchResultDAOImpl(JdbcTemplate jdbcTemplate2) {
		this.jdbcTemplate=jdbcTemplate2;
	}


	private ListDataResponseDTO processResultSet(SQLServerCallableStatement cs,
			final List<String> searchResultColumnsList) throws SQLException {
		List<Map<String, Object>> resultList = new ArrayList<>();
		ListDataResponseDTO respone = new ListDataResponseDTO();

		boolean resultSetReturned = cs.execute();
		if (resultSetReturned) {
			ResultSet rs = cs.getResultSet();
			// this.printMetaData(rs);
			while (rs.next()) {
				Map<String, Object> rowMap = new HashMap<>();
				for (String resultColumn : searchResultColumnsList) {
					Object data=rs.getObject(resultColumn);
					if(data!=null)
						rowMap.put(resultColumn,data);
				}
				resultList.add(rowMap);
			}
			
		}

		respone.setListOfRecords(resultList);
		//respone.setCount(rs.get);
		return respone;
	}


	private void prepareInputSearchCritiera(int position, SQLServerCallableStatement cs,
			final List<String[]> rowList) throws SQLServerException {
		SQLServerDataTable sourceDataTable = new SQLServerDataTable();
		sourceDataTable.addColumnMetadata(DerivzDBConstants.FIELD, java.sql.Types.VARCHAR);
		sourceDataTable.addColumnMetadata(DerivzDBConstants.NODE, java.sql.Types.VARCHAR);
		sourceDataTable.addColumnMetadata(DerivzDBConstants.FILTER_VALUE, java.sql.Types.VARCHAR);
		sourceDataTable.addColumnMetadata(DerivzDBConstants.CONDITIONS, java.sql.Types.VARCHAR);
		sourceDataTable.addColumnMetadata(DerivzDBConstants.WHO_HAS_FLAG, java.sql.Types.INTEGER);
		if (rowList != null) {
			for (String[] indValues : rowList) {
				LOGGER.debug(
						"SearchResultDAOImpl:: prepareInputSearchCritiera:: input : {} {} {} {} {} ",
						indValues[0], indValues[1], indValues[2], indValues[3],indValues[4]);
				sourceDataTable.addRow(indValues[0], indValues[1], indValues[2], indValues[3],
						Integer.parseInt(indValues[4]));
			}
		}
		cs.setStructured(position,
				DerivzDBConstants.SCHEMA_CEFT + "." + DerivzDBConstants.IP_INPUT_PARAMETERS,
				sourceDataTable);

	}

	private void prepareInputAgreementKeyList(int position, SQLServerCallableStatement cs,
			final List<Long> agreementKeyList) throws SQLServerException {
		SQLServerDataTable sourceDataTable = new SQLServerDataTable();
		sourceDataTable.addColumnMetadata(DerivzDBConstants.AGREEMENT_KEY, java.sql.Types.VARCHAR);
		agreementKeyList.stream().forEach(key -> {
			try {
				sourceDataTable.addRow(key.toString());
			} catch (SQLServerException e) {
				throw new DerivzApplicationException(e,
						DerivzDAOLayerException.FAILED_SEARCH_PROCEDURE);
			}
		});
		cs.setStructured(position,
				DerivzDBConstants.SCHEMA_CEFT + "." + DerivzDBConstants.POSTINGS_INPUT,
				sourceDataTable);

	}

	private void prepareInputAgreementOptimalRank(int position, SQLServerCallableStatement cs,
			final List<AgreementOptimalRankVO> agreementOptimalRankList) throws SQLServerException {
		SQLServerDataTable sourceDataTable = new SQLServerDataTable();
		sourceDataTable.addColumnMetadata(DerivzDBConstants.AGREEMENT_KEY, java.sql.Types.BIGINT);
		sourceDataTable.addColumnMetadata(DerivzDBConstants.OPTIMAL_RANK, java.sql.Types.VARCHAR);

		for (AgreementOptimalRankVO vo : agreementOptimalRankList) {
			sourceDataTable.addRow(vo.getAgreementKey(), vo.getOptimalRank());
		}

		cs.setStructured(position,
				DerivzDBConstants.SCHEMA_CEFT + "." + DerivzDBConstants.POSTINGS_INPUT_PARAMETERS,
				sourceDataTable);

	}

	@SuppressWarnings("rawtypes")
	private void preapreRangOfField(int position, SQLServerCallableStatement cs,
			final List<RatingFieldVO> listOfRangeField) throws SQLServerException {
		SQLServerDataTable sourceDataTable = new SQLServerDataTable();
		sourceDataTable.addColumnMetadata("rating_value1", java.sql.Types.INTEGER);
		sourceDataTable.addColumnMetadata("rating_value2", java.sql.Types.INTEGER);
		sourceDataTable.addColumnMetadata("issuer_flag", java.sql.Types.VARCHAR);
		sourceDataTable.addColumnMetadata("and_or_flag", java.sql.Types.VARCHAR);
		sourceDataTable.addColumnMetadata("seq", java.sql.Types.INTEGER);

		for (RatingFieldVO indValues : listOfRangeField) {
			LOGGER.debug(
					"SearchResultDAOImpl:: preapreRangOfField:: input : {} {} {} {} {} ",
					indValues.getRatingStart(), indValues.getRatingEnd(),
							indValues.getIssuerFlag(), indValues.getAndOr(), indValues.getSeq());
			sourceDataTable.addRow(indValues.getRatingStart(), indValues.getRatingEnd(),
					indValues.getIssuerFlag(), indValues.getAndOr(), indValues.getSeq());
		}
		cs.setStructured("Rating_Data",
				DerivzDBConstants.SCHEMA_CEFT + "." + DBConstants.IP_INPUT_RATING_VARIABLE,
				sourceDataTable);
	}

	@SuppressWarnings("rawtypes")
	@Override
	public ListDataResponseDTO retriveResultsFromDB(final String tabName,
			final List<SearchResultColumns> searchResultColumnsList, final Boolean isFilterd,
			final List<Long> agreementKeyList,
			final List<AgreementOptimalRankVO> agreementOptimalRanks, final List<String[]> rowList,
			final String collatralTypeNamesCSV, final List<RatingFieldVO> listOfRangeField,
			final List<SearchResultColumns> smsColumns, List<String[]> listOfTenorRange)
			throws CEFTException {
		LOGGER.debug("SearchResultDAOImpl:: retriveResultsFromDB::{}", isFilterd);

		ListDataResponseDTO resultList = null;
		StringBuilder sqlBuilder = new StringBuilder(DerivzDBConstants.CALL_PROC);
		// DerivzDBConstants.CALL_PROC + DerivzDBConstants.SCHEMA_CEFT + ".
		try (Connection conn = jdbcTemplate.getDataSource().getConnection()) {

			List<String> filterColumnList = searchResultColumnsList.parallelStream()
					.filter(p -> p.getTabName().equalsIgnoreCase(tabName))
					.map(SearchResultColumns::getFieldName).collect(Collectors.toList());

			switch (tabName) {
				case TabsName.LISTED:
					sqlBuilder.append(DerivzDBConstants.SCHEMA_CEFT + ".")
							.append(DerivzDBConstants.USP_DERIV_MAC_DATA_RETRIEVAL)
							.append(DerivzDBConstants.PROC_FIVE_ARG);
					resultList = retriveListedResultsFromDB(conn, filterColumnList, rowList,
							sqlBuilder.toString(), listOfRangeField, listOfTenorRange);
					break;
				case TabsName.POSTING:
					if (smsColumns != null && !smsColumns.isEmpty()) {
						filterColumnList
								.addAll(smsColumns.stream().map(SearchResultColumns::getFieldName)
										.collect(Collectors.toList()));
					}
					sqlBuilder.append(DerivzDBConstants.SCHEMA_CEFT + ".")
							.append(DerivzDBConstants.SP_GET_FACT_POSTING)
							.append(DerivzDBConstants.PROC_THREE_ARG);
					resultList = retrivePostingResultsFromDB(conn, agreementKeyList,
							agreementOptimalRanks, isFilterd, filterColumnList, rowList,
							sqlBuilder.toString());
					break;
				case TabsName.BOX:
					if (smsColumns != null && !smsColumns.isEmpty()) {
						filterColumnList
								.addAll(smsColumns.stream().map(SearchResultColumns::getFieldName)
										.collect(Collectors.toList()));
					}
					sqlBuilder.append(DerivzDBConstants.SCHEMA_CEFT + ".")
							.append(DerivzDBConstants.SP_GET_FACT_BOX)
							.append(DerivzDBConstants.PROC_TWO_ARG);
					resultList = retriveBoxResultsFromDB(conn, agreementKeyList, filterColumnList,
							rowList, sqlBuilder.toString());
					break;
				case TabsName.CAPACITY:
					sqlBuilder.append(DerivzDBConstants.SCHEMA_CEFT + ".")
							.append(DerivzDBConstants.USP_GET_CAPACITY_DATA)
							.append(DerivzDBConstants.PROC_TWO_ARG);
					resultList = retriveResultsFromDB(conn, agreementKeyList, agreementOptimalRanks,
							filterColumnList, rowList, sqlBuilder.toString());
					break;
				case TabsName.FMTM:
					sqlBuilder.append(DerivzDBConstants.SCHEMA_VOYAGER + ".")
							.append(DerivzDBConstants.USP_GET_FWD_MTM_DATA)
							.append(DerivzDBConstants.PROC_THREE_ARG);
					resultList = retriveFMTMResultsFromDB(conn, agreementKeyList,
							agreementOptimalRanks, filterColumnList, collatralTypeNamesCSV, rowList,
							sqlBuilder.toString());
					break;
				case TabsName.MTM:
					sqlBuilder.append(DerivzDBConstants.SCHEMA_CEFT + ".")
							.append(DerivzDBConstants.USP_GET_MTM_DATA)
							.append(DerivzDBConstants.PROC_TWO_ARG);
					resultList =
							retriveMTMResultsFromDB(conn, agreementKeyList, agreementOptimalRanks,
									filterColumnList, rowList, sqlBuilder.toString());
					break;
				case TabsName.GSST:
					sqlBuilder.append(DerivzDBConstants.SCHEMA_CEFT + ".")
							.append(DerivzDBConstants.USP_GET_GSST_DATA)
							.append(DerivzDBConstants.PROC_FOUR_ARG);
					resultList = retriveGSSTResultsFromDB(conn, agreementKeyList,
							agreementOptimalRanks, filterColumnList, collatralTypeNamesCSV, rowList,
							sqlBuilder.toString());
					break;
				case TabsName.FRTB:
					sqlBuilder.append(DerivzDBConstants.SCHEMA_CEFT + ".")
							.append(DerivzDBConstants.USP_GET_FRTB_DATA)
							.append(DerivzDBConstants.PROC_TWO_ARG);
					resultList = retriveResultsFromDB(conn, agreementKeyList, agreementOptimalRanks,
							filterColumnList, rowList, sqlBuilder.toString());
					break;
				default:
					break;
			}


		} catch(DerivzApplicationException de) {
			LOGGER.error("SearchResultDAOImpl::retriveResultsFromDB()::DerivzApplicationException ::Error::");
			String msg = de.getMessage();
			String startStr = "The column name ";
			String endStr = " is not valid";
			int strIdx=msg.lastIndexOf(startStr);
			if(strIdx!=-1) {
				LOGGER.error("SearchResultDAOImpl::retriveResultsFromDB()::DerivzApplicationException ::Error::{}",msg.lastIndexOf(startStr));
				String columnName = msg.substring(msg.lastIndexOf(startStr) + startStr.length(),
						msg.indexOf(endStr));
				throw new CEFTException("COLUMN: Mapping problem [" + columnName + "]", de);
			} else {
				throw new CEFTException(de);
			}
			
        } catch (SQLException e) {
			LOGGER.error("SearchResultDAOImpl::retriveResultsFromDB() ::Error::");
			String msg = e.getMessage();
			String startStr = "The column name ";
			String endStr = " is not valid";
			String columnName = msg.substring(msg.lastIndexOf(startStr) + startStr.length(),
					msg.indexOf(endStr));
			throw new CEFTException("COLUMN: Mapping problem [" + columnName + "]", e);
		}

		return resultList;
	}
	/// Actual tab wise method below start here...............................


	@SuppressWarnings("rawtypes")
	private ListDataResponseDTO retriveListedResultsFromDB(Connection conn,
			final List<String> searchResultColumnsList, final List<String[]> rowList,
                                                           final String sql, List<RatingFieldVO> listOfRangeField, List<String[]> listOfTenorRange)
			throws DerivzApplicationException {

		LOGGER.debug("SearchResultDAOImpl:: retriveListedResultsFromDB");

		ListDataResponseDTO listDataResponseDTO = null;
        try (SQLServerCallableStatement cs = conn.prepareCall(sql).unwrap(SQLServerCallableStatement.class)) {
			prepareInputSearchCritiera(1, cs, rowList);
			preapreRangOfField(2, cs, listOfRangeField);
			prepareInputSearchCritiera(3, cs, listOfTenorRange);

			cs.registerOutParameter(DerivzDBConstants.COUNT, Types.BIGINT);
			cs.registerOutParameter(DerivzDBConstants.COB_DATE, Types.VARCHAR);
			listDataResponseDTO = processResultSet(cs, searchResultColumnsList);

			Long count = cs.getLong(DerivzDBConstants.COUNT);
			String cobDate = cs.getString(DerivzDBConstants.COB_DATE);
			listDataResponseDTO.setCobDate(cobDate);
			listDataResponseDTO.setCount(count);

		} catch (SQLException e) {
			LOGGER.error("SearchResultDAOImpl::retriveListedResultsFromDB() ::Error");
			throw new DerivzApplicationException(e,
					DerivzDAOLayerException.FAILED_SEARCH_PROCEDURE);
		}
		return listDataResponseDTO;
	}

	private ListDataResponseDTO retrivePostingResultsFromDB(Connection conn,
			final List<Long> agreementKeyList,
			final List<AgreementOptimalRankVO> agreementOptimalRanks, final Boolean isFilterd,
			final List<String> searchResultColumnsList, final List<String[]> rowList,
                                                            final String sql) throws SQLException {

		ListDataResponseDTO resultList = null;

        try (SQLServerCallableStatement cs = conn.prepareCall(sql).unwrap(SQLServerCallableStatement.class)) {

			prepareInputSearchCritiera(1, cs, rowList);
			prepareInputAgreementOptimalRank(2, cs, agreementOptimalRanks);
			cs.setInt(3, isFilterd ? 1 : 0);

			resultList = processResultSet(cs, searchResultColumnsList);
		} catch (SQLException e) {
			LOGGER.error("SearchResultDAOImpl::retrivePostingResultsFromDB() ::Error");
			throw new DerivzApplicationException(e,
					DerivzDAOLayerException.FAILED_SEARCH_PROCEDURE);
		}
		return resultList;
	}

	private ListDataResponseDTO retriveBoxResultsFromDB(Connection conn,
			final List<Long> agreementKeyList, final List<String> searchResultColumnsList,
                                                        final List<String[]> rowList, final String sql) throws SQLException {

		ListDataResponseDTO resultList = null;

        try (SQLServerCallableStatement cs = conn.prepareCall(sql).unwrap(SQLServerCallableStatement.class)) {

			prepareInputSearchCritiera(1, cs, rowList);
			prepareInputAgreementKeyList(2, cs, agreementKeyList);

			resultList = processResultSet(cs, searchResultColumnsList);
		} catch (SQLException e) {
			LOGGER.error("SearchResultDAOImpl::retriveBoxResultsFromDB() ::Error");
			throw new DerivzApplicationException(e,
					DerivzDAOLayerException.FAILED_SEARCH_PROCEDURE);
		}
		return resultList;
	}


	private ListDataResponseDTO retriveResultsFromDB(Connection conn,
			final List<Long> agreementKeyList,
			final List<AgreementOptimalRankVO> agreementOptimalRanks,
			final List<String> searchResultColumnsList, final List<String[]> rowList,
                                                     final String sql) throws SQLException {

		ListDataResponseDTO resultList = null;

        try (SQLServerCallableStatement cs = conn.prepareCall(sql).unwrap(SQLServerCallableStatement.class)) {

			prepareInputAgreementOptimalRank(1, cs, agreementOptimalRanks);
			prepareInputSearchCritiera(2, cs, rowList);
			resultList = processResultSet(cs, searchResultColumnsList);
		} catch (SQLException e) {
			LOGGER.error("SearchResultDAOImpl::retriveResultsFromDB() ::Error");
			throw new DerivzApplicationException(e,
					DerivzDAOLayerException.FAILED_SEARCH_PROCEDURE);
		}
		return resultList;
	}

	private ListDataResponseDTO retriveGSSTResultsFromDB(Connection conn,
			final List<Long> agreementKeyList,
			final List<AgreementOptimalRankVO> agreementOptimalRanks,
			final List<String> searchResultColumnsList, final String collatralTypeNamesCSV,
                                                         final List<String[]> rowList, final String sql) throws SQLException {

		ListDataResponseDTO resultList = null;

        try (SQLServerCallableStatement cs = conn.prepareCall(sql).unwrap(SQLServerCallableStatement.class)) {

			prepareInputAgreementOptimalRank(1, cs, agreementOptimalRanks);
			cs.setString(2, collatralTypeNamesCSV);
			cs.setString(3, DerivzCommonConstants.APP_MNEMONIC);
			prepareInputSearchCritiera(4, cs, rowList);

			resultList = processResultSet(cs, searchResultColumnsList);
		} catch (SQLException e) {
			LOGGER.error("SearchResultDAOImpl::retriveGSSTResultsFromDB() ::Error");
			throw new DerivzApplicationException(e,
					DerivzDAOLayerException.FAILED_SEARCH_PROCEDURE);
		}
		return resultList;
	}

	private ListDataResponseDTO retriveFMTMResultsFromDB(Connection conn,
			final List<Long> agreementKeyList,
			final List<AgreementOptimalRankVO> agreementOptimalRanks,
			final List<String> searchResultColumnsList, final String collatralTypeNamesCSV,
                                                         final List<String[]> rowList, final String sql) throws SQLException {

		ListDataResponseDTO resultList = null;

        try (SQLServerCallableStatement cs = conn.prepareCall(sql).unwrap(SQLServerCallableStatement.class)) {

			prepareInputAgreementOptimalRank(1, cs, agreementOptimalRanks);
			cs.setString(2, collatralTypeNamesCSV);
			prepareInputSearchCritiera(3, cs, rowList);
			resultList = processResultSet(cs, searchResultColumnsList);
		} catch (SQLException e) {
			LOGGER.error("SearchResultDAOImpl::retriveFMTMResultsFromDB() ::Error");
			throw new DerivzApplicationException(e,
					DerivzDAOLayerException.FAILED_SEARCH_PROCEDURE);
		}
		return resultList;
	}

	private ListDataResponseDTO retriveMTMResultsFromDB(Connection conn,
			final List<Long> agreementKeyList,
			final List<AgreementOptimalRankVO> agreementOptimalRanks,
			final List<String> searchResultColumnsList, final List<String[]> rowList,
                                                        final String sql) throws SQLException {

		ListDataResponseDTO resultList = null;

        try (SQLServerCallableStatement cs = conn.prepareCall(sql).unwrap(SQLServerCallableStatement.class)) {

			prepareInputAgreementOptimalRank(1, cs, agreementOptimalRanks);
			prepareInputSearchCritiera(2, cs, rowList);
			resultList = processResultSet(cs, searchResultColumnsList);
		}catch (SQLException e) {
			LOGGER.error("SearchResultDAOImpl::retriveMTMResultsFromDB() ::Error");
			throw new DerivzApplicationException(e,
					DerivzDAOLayerException.FAILED_SEARCH_PROCEDURE);
		}
		return resultList;
	}

	private void printMetaData(ResultSet rs) {
		try {
			ResultSetMetaData metaData = rs.getMetaData();

			int cols = metaData.getColumnCount();
			for (int i = 1; i <= cols; i++) {
				LOGGER.debug("COLUMN[{}]-Label[{}]-Type[{}]", metaData.getColumnName(i),
						metaData.getColumnLabel(i), metaData.getColumnTypeName(i));
			}
		} catch (SQLException e) {
			LOGGER.error(
					"SearchResultDAOImpl::printMetaData::Exception occured in printMetaData {}", e);
		}

	}

	/**
	 * Returns DatasetType data using Dataset type, Bookmark Id  and UserId
	 */
	@Override
	public ListDataResponseDTO retriveDatasetResultsUsingBookmarkId(String datasetType,
			List<SearchResultColumns> searchResultColumnsList, String userId, Long bookmarkId, EnterpriseGetRowsRequest gridRequest) throws CEFTException {
		LOGGER.debug("SearchResultDAOImpl:: retriveDatasetResultsFromDB::{}");

		ListDataResponseDTO resultList = null;
		StringBuilder sqlBuilder = new StringBuilder(DerivzDBConstants.CALL_PROC);
		try (Connection conn = jdbcTemplate.getDataSource().getConnection()) {

			List<String> filterColumnList = searchResultColumnsList.parallelStream()
					.filter(p -> p.getTabId().equalsIgnoreCase(datasetType)).map(SearchResultColumns::getFieldName)
					.collect(Collectors.toList());

			sqlBuilder.append(DerivzDBConstants.SCHEMA_CEFT + ".").append(DerivzDBConstants.USP_GET_DATA_BY_BOOKMARK_ID)
					.append(DerivzDBConstants.PROC_FOUR_ARG);
			resultList = retriveResultSetFromDB(conn, userId, bookmarkId, datasetType, filterColumnList,
					sqlBuilder.toString());
			if("Listed".equalsIgnoreCase(datasetType)) {
			String cobDate =getCobDateFromDB(conn);
			resultList.setCobDate(cobDate);
			resultList.setCount(new Long(resultList.getListOfRecords().size()));
			}
		} catch (DerivzApplicationException de) {
			LOGGER.error("SearchResultDAOImpl::retriveResultsFromDB()::DerivzApplicationException ::Error::");
			String msg = de.getMessage();
			String startStr = "The column name ";
			String endStr = " is not valid";
			int strIdx = msg.lastIndexOf(startStr);
			if (strIdx != -1) {
				LOGGER.error("SearchResultDAOImpl::retriveResultsFromDB()::DerivzApplicationException ::Error::{}",
						msg.lastIndexOf(startStr));
				String columnName = msg.substring(msg.lastIndexOf(startStr) + startStr.length(), msg.indexOf(endStr));
				throw new CEFTException("COLUMN: Mapping problem [" + columnName + "]", de);
			} else {
				throw new CEFTException(de);
			}

		} catch (SQLException e) {
			LOGGER.error("SearchResultDAOImpl::retriveResultsFromDB() ::Error::");
			String msg = e.getMessage();
			String startStr = "The column name ";
			String endStr = " is not valid";
			String columnName = msg.substring(msg.lastIndexOf(startStr) + startStr.length(), msg.indexOf(endStr));
			throw new CEFTException("COLUMN: Mapping problem [" + columnName + "]", e);
		}
		System.out.println("Results Size" + resultList.getListOfRecords().size());
		return resultList;
	}


	private String getCobDateFromDB(Connection conn) throws SQLException {
		String cobDate=null;
		try {
		ResultSet rs= conn.prepareStatement("SELECT TOP 1 CONVERT(VARCHAR(20),bus_date) FROM "+DBConstants.DERIV_DZ
				+"."+DBConstants.SCHEMA_CEFT+"."+ DBConstants.RPT_POSTINGS).executeQuery();
		if(rs.next()) {
		cobDate=rs.getString(1);
		}
		}catch(SQLException se) {
			LOGGER.error("SearchResultDAOImpl::getCobDateFromDB() ::Error"+se.getMessage());
		}
		return cobDate;
	}

	private ListDataResponseDTO retriveResultSetFromDB(Connection conn, String userId, Long bookmarkId,
                                                       String datasetType, final List<String> searchResultColumnsList, final String sql) throws SQLException {
		ListDataResponseDTO resultList = null;
        try (SQLServerCallableStatement cs = conn.prepareCall(sql).unwrap(SQLServerCallableStatement.class)) {

			cs.setString(1, userId);
			cs.setLong(2, bookmarkId);
			cs.setString(4, datasetType);

			SQLServerDataTable sourceDataTable = new SQLServerDataTable();
			sourceDataTable.addColumnMetadata(DerivzDBConstants.BUS_DATE, java.sql.Types.DATE);
			// TODO Add Current COB date in case of multiple dates
			// sourceDataTable.addRow(null);
			cs.setStructured(3, DerivzDBConstants.SCHEMA_CEFT + "." + DerivzDBConstants.INPUT_DATES_CEFT,
					sourceDataTable);

			resultList = processResultSet(cs, searchResultColumnsList);
			
		} catch (SQLException e) {
			LOGGER.error("SearchResultDAOImpl::retriveResultSetFromDB() ::Error");
			throw new DerivzApplicationException(e, DerivzDAOLayerException.FAILED_SEARCH_PROCEDURE);
		}
		return resultList;
	}

}
