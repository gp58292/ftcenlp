package com.citi.aqua.derivz.model;

public final class DerivzDBConstants {
  
    private  DerivzDBConstants () {}

	public static final String SCHEMA_CEFT = "ceft";
	public static final String SCHEMA_DZ = "dz";
	public static final String SCHEMA_VOYAGER = "voyager";

	public static final String IP_INPUT_PARAMETERS = "input_variable_ceft_max";
	public static final String POSTINGS_INPUT_PARAMETERS = "input_postings_optimal";
	public static final String POSTINGS_INPUT = "input_postings";
	public static final String BOX_INPUT_PARAMETERS = "input_box";

	// Below are dimensional or fact names
	public static final String DIM_AGREEMENT = "dim_agreement"; // dimensional or fact

	// Below are table names, schema=DBConstants.schemaCEFT
	public static final String TBL_DISTINCT_DATA = "tbl_distinct_data";
	public static final String TBL_USER_SEARCH_SAVED_LIST = "tbl_user_search_saved_list";
	public static final String TBL_STATIC_COMPONENT = "tbl_static_component";
	public static final String TBL_META_DATA = "table_metadata";
	public static final String TBL_BATCH_PROCESS_AUDIT = "tbl_batch_process_audit";
	public static final String TBL_USER = "tbl_user";
	public static final String TBL_EMT_DASHBOARD_ENTITLEMENT = "tbl_emt_dashboard_entitlement";
	public static final String TBL_CEFT_APP_USER_LOG = "tbl_ceft_app_user_log";
	
	public static final String TBL_FIELD_MAPPING = "tbl_field_mapping";
	public static final String TBL_USER_SAVED_CHART = "tbl_user_saved_chart";
	public static final String USER_DATASET_TABLE = "user_dataset_table";
	
	// Below are procedure names
	public static final String USP_DERIV_MAC_DATA_RETRIEVAL = "usp_deriv_mac_data_retrieval_parent";
	public static final String SP_GET_FACT_POSTING = "sp_get_fact_posting";
	public static final String SP_GET_FACT_BOX = "sp_get_fact_box";
	public static final String USP_GET_FWD_MTM_DATA = "sp_get_forward_mtm_data_set";
	public static final String USP_GET_MTM_DATA = "usp_get_mtm";
	public static final String USP_GET_GSST_DATA="usp_get_gsst_data_set";
	public static final String USP_GET_FRTB_DATA="usp_get_frtb";
	public static final String USP_GET_CAPACITY_DATA = "usp_get_capacity_data";
	
	public static final String USP_DERIV_VOYAGER_DATASET_RETRIEVAL = "usp_deriv_mac_data_retrieval_parent_fact_posting";
	public static final String USP_GET_USER_AUTHENTICATION = "usp_get_user_authentication";
	public static final String SP_PERSIST_CEFT_BOOKMARK_TO_VOYAGER= "sp_persist_ceft_bookmark_to_voyager";
	public static final String SP_GET_CURRENT_DATASETID= "sp_get_current_datasetid_based_of_ceft_link_click";
	public static final String USP_GET_USAGE_SUMMARY_DETAILS = "usp_get_usage_summary_details";
	public static final String USP_DERIV_COLLATERAL_LOOKUP_RETRIEVAL = "usp_ceft_collateral_type_lookup_reg";
	

	public static final String DASHBOARD_TYPE_CEFT = "Collateral Exposure Forecasting Tool";
	public static final String DASHBOARD_TYPE_VOYAGER = "Voyager Visualization Tool";
	
	public static final String NULL_VALUE_CHECK="<NULL>";
	public static final String CALL_PROC = "{CALL ";
	
	public static final String PROC_ONE_ARG = " (?)}";
	public static final String PROC_TWO_ARG = " (?,?)}";
	public static final String PROC_THREE_ARG = " (?,?,?)}";
	public static final String PROC_FOUR_ARG = " (?,?,?,?)}";
	public static final String PROC_FIVE_ARG = " (?,?,?,?,?)}";
	
	public static final String COUNT = "COUNT";
	public static final String COB_DATE = "COB_DATE";
	
	//DB Procedure Input field constants
	public static final String AGREEMENT_KEY = "agreement_key";
	public static final String FIELD = "field";
	public static final String NODE = "node";
	public static final String FILTER_VALUE = "filter_value";
	public static final String CONDITIONS = "conditions";
    public static final String WHO_HAS_FLAG = "who_has_flag";
    public static final String OPTIMAL_RANK = "optimal_rank";
	
	
	//DB Column Fields
	public static final String COUNTERPARTY_CUSTODIAN_REQUIRED = "Counterparty Custodian Required";
	public static final String AGREEMENT_ID = "Agreement ID";
	public static final String AGREEMENT_ID_1 = "agreement_id";
	public static final String BUSINESS_DATE = "Business Date";
	public static final String CLEARING_AGREEMENT = "Clearing Agreement";
	public static final String CONSENT_TO_SUBSTITUTION = "Consent to Substitution";
	public static final String COUNTERPARTY_NAME = "Counterparty Name";
	public static final String CP_MARGIN_TYPE = "CP Margin Type";
	public static final String CSA_DESCRIPTION = "CSA Description";
	public static final String CSA_STATUS = "CSA Status";
	public static final String CSA_DESCRIPTION_1 = "csa_description";
	public static final String CUSTOMER_NAME = "Customer Name";
	public static final String GFCID_TYPE = "GFCID Type";
	public static final String GFCID = "GFCID";
	public static final String GOVERNING_LAW = "Governing Law";
	public static final String INCORPORATED_COUNTRY = "Incorporated Country";
	public static final String INTER_COMPANY_AGREEMENT = "Inter Company Agreement";
	public static final String MANDATORY_MARK_FREQUENCY = "Mandatory Mark Frequency";
	public static final String MASTER_AGREEMENT_STATUS = "Master Agreement Status";
	public static final String MASTER_AGREEMENT = "Master Agreement";
	public static final String MGD_SEG_LEVEL5_DESC = "Mgd Seg Level5 Desc";
	public static final String PARTY_CUSTODIAN_REQUIRED = "Party Custodian Required";
	public static final String PARTY_LEGAL_ENTITY = "Party Legal Entity";
	public static final String PLEDGOR = "Pledgor";
	public static final String RIGHT_OF_REUSE = "Right of Reuse";
	public static final String SA_TRIGGER_EVENT = "SA Trigger Event";
	public static final String TRIGGER_EVENT = "Trigger Event";
	public static final String BUS_DATE = "bus_date";
	public static final String INPUT_DATES_CEFT = "input_dates_ceft";
	public static final String USP_GET_DATA_BY_BOOKMARK_ID = "usp_get_data_by_bookmark_id";

}