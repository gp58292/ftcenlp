package com.citi.aqua.derivz.vo.aggrid.request;

import java.io.Serializable;

import lombok.Data;

@Data
public class SortModel implements Serializable {
	private static final long serialVersionUID = 1L;
	private String colId;
    private String sort;
}