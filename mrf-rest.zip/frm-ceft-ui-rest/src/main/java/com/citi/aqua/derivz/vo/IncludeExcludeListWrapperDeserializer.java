package com.citi.aqua.derivz.vo;

import java.io.IOException;

import com.citi.aqua.derivz.model.DerivzJsonConstants;
import com.citi.aqua.derivz.vo.IncludeExcludeListWrapper.IncludeExcludeListWrapperBuilder;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;
import com.fasterxml.jackson.databind.type.TypeFactory;

public class IncludeExcludeListWrapperDeserializer<T> extends StdDeserializer<IncludeExcludeListWrapper<T>> {


	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	static ObjectMapper objectMapper = new ObjectMapper();
	static TypeFactory typeFactory = objectMapper.getTypeFactory();

	public IncludeExcludeListWrapperDeserializer() {
		this(null);
	}

	protected IncludeExcludeListWrapperDeserializer(Class<?> vc) {
		super(vc);
	}

	@Override
	public IncludeExcludeListWrapper<T> deserialize(JsonParser p, DeserializationContext ctxt)
			throws IOException, JsonProcessingException {
		JsonNode node = p.getCodec().readTree(p);
		IncludeExcludeListWrapperBuilder<T> scvb = IncludeExcludeListWrapper.builder();
	    
	    if (node.get(DerivzJsonConstants.VALUE_LIST) != null) {
	        scvb.valueList(objectMapper.readValue(node.get(DerivzJsonConstants.VALUE_LIST).toString(),typeFactory.constructArrayType(IncludeExcludeVO.class)));
	   }
	    return (IncludeExcludeListWrapper<T>)scvb.build();
	  }
	
	
}
