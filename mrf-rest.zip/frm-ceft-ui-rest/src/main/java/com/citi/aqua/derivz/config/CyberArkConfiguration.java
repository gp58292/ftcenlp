package com.citi.aqua.derivz.config;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

import com.citi.secretagentclient.SecretAgentClient;
import com.zaxxer.hikari.HikariDataSource;


@Configuration
public class CyberArkConfiguration {

    @Value("${aqua.datasource.cyberark.nickname:EQAQUA2SQUA01_aqua_ceft_ecs_sql_ua}")
    String cyberarkNickname;

    @Bean
    @Profile("!cyberark")
    @ConfigurationProperties(prefix = "aqua.datasource")
    DataSource dataSource(){
        return DataSourceBuilder
                .<HikariDataSource>create()
                .build();
    }

    @Profile("cyberark")
    @Bean
    SecretAgentClient secretAgentClient(){
        return new SecretAgentClient();
    }

    @Bean
    @Profile("cyberark")
    @ConfigurationProperties(prefix = "aqua.datasource")
    DataSource dataSourceCyberark(SecretAgentClient secretAgentClient) throws Exception {
        DataSource dataSource = DataSourceBuilder
                .<HikariDataSource>create()
                .password(secretAgentClient.getPassword(cyberarkNickname))
                .build();

        return dataSource;
    }

}