package com.citi.aqua.derivz.data.repository;

import java.util.Date;
import java.util.List;
import javax.persistence.LockModeType;
import javax.transaction.Transactional;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.citi.aqua.derivz.model.Bookmark;
import com.citi.aqua.derivz.model.DerivzDBConstants;

@Repository
@Transactional
public interface BookmarkRepository extends CrudRepository<Bookmark, Long> {

	// This query is used to fetch the saved list for the settings screen last saved
	// by user
	@Query(value = "SELECT * FROM " + DerivzDBConstants.SCHEMA_CEFT + "." + DerivzDBConstants.TBL_USER_SEARCH_SAVED_LIST
			+ " where user_id = :userId and list_type= :listType and delete_flag=0 order by updated_time desc", nativeQuery = true)
	public List<Bookmark> findByUserIdAndListCatagoryOrderByupdatedTimeDesc(@Param("userId") final String userId,
			@Param("listType") final String listType);

	@Query(value = "SELECT * FROM " + DerivzDBConstants.SCHEMA_CEFT + "." + DerivzDBConstants.TBL_USER_SEARCH_SAVED_LIST
			+ " where user_id = :userId and list_type= :listType and list_name=:listName and delete_flag=0", nativeQuery = true)
	public Bookmark findByUserIdAndListTypeAndListName(@Param("userId") String userId,
			@Param("listType") final String listType, @Param("listName") final String listName);

//	@Query(value = "delete  FROM " + DerivzDBConstants.SCHEMA_CEFT + "." + DerivzDBConstants.TBL_USER_SEARCH_SAVED_LIST
//			+ "  t  where t.user_id = :userId and t.list_type= :listType and t.list_name=:listName", nativeQuery = true)
	@Query(value = "update " + DerivzDBConstants.SCHEMA_CEFT + "." + DerivzDBConstants.TBL_USER_SEARCH_SAVED_LIST
			+ " set delete_flag=1 where user_id = :userId "
			+" and list_type=:listType and list_name=:listName", nativeQuery = true)
	public boolean deleteByUserIdAndListTypeAndListName(@Param("userId") final String userId,
			@Param("listType") final String listType, @Param("listName") final String listName);

	@Modifying (flushAutomatically = true , clearAutomatically = true) 
	@Query(value = "update  " + DerivzDBConstants.SCHEMA_CEFT + "." + DerivzDBConstants.TBL_USER_SEARCH_SAVED_LIST
			+ "    set  saved_list =:listValue , updated_time =:updatedTime  where  uniq_key= :key", nativeQuery = true)
	public Integer updateUserSettingsList(@Param("key") final Long key,
			@Param("listValue") final String newSettingsList, @Param("updatedTime") final Date updatedTime);
	
	@Modifying (flushAutomatically = true , clearAutomatically   = true)
	@Query(value = "update  " + DerivzDBConstants.SCHEMA_CEFT + "." + DerivzDBConstants.TBL_USER_SEARCH_SAVED_LIST
			+ "    set  saved_list =:listValue , updated_time =:updatedTime , list_name=:bookmarkName  where  uniq_key= :key", nativeQuery = true)
	public Integer updateUserSettingsListWithName(@Param("key") final Long key,
			@Param("listValue") final String newSettingsList, @Param("updatedTime") final Date updatedTime,@Param("bookmarkName") final String bookmarkName);

	public Bookmark findByUserIdAndType(final String userId, final String type);

	@Lock(LockModeType.PESSIMISTIC_READ)
	public Bookmark findByKey(final Long uniqKey);
	
	@Query(value = "SELECT * FROM " + DerivzDBConstants.SCHEMA_CEFT + "." + DerivzDBConstants.TBL_USER_SEARCH_SAVED_LIST
			+ "  where user_id = :userId and uniq_key= :key and delete_flag=0", nativeQuery = true)
	public Bookmark findByUserIdAndKey(@Param("userId") String userId,@Param("key") final Long key);

//	public int deleteByKey(final Long uniqKey);
//	public int deleteByUserIdAndKey(final String userId,final Long uniqKey);
	

	@Modifying (flushAutomatically = true , clearAutomatically   = true)
	@Query(value = "update " + DerivzDBConstants.SCHEMA_CEFT + "." + DerivzDBConstants.TBL_USER_SEARCH_SAVED_LIST
			+ " set delete_flag=1 where user_id = :userId and uniq_key=:key", nativeQuery = true)
	public int deleteSoftBookmarkByUserIdAndKey(@Param("userId") final String userId,@Param("key") final Long uniqKey);
	
	@Modifying (flushAutomatically = true , clearAutomatically   = true)
	@Query(value = "update " + DerivzDBConstants.SCHEMA_CEFT + "." + DerivzDBConstants.TBL_USER_SEARCH_SAVED_LIST
			+ " set delete_flag=1 where user_id =:userId and parent_id IS NOT NULL", nativeQuery = true)
	public int deleteSoftTempBookmarkByUserId(@Param("userId") final String userId);
	
	@Modifying
	@Query(value = "SELECT * FROM " + DerivzDBConstants.SCHEMA_CEFT + "." + DerivzDBConstants.TBL_USER_SEARCH_SAVED_LIST
			+ "  where user_id = :userId and delete_flag=1", nativeQuery = true)
	public List<Bookmark> getTempBookmarksToRestore(@Param("userId") final String userId);
	
	@Modifying (flushAutomatically = true , clearAutomatically   = true)
	@Query(value = "update " + DerivzDBConstants.SCHEMA_CEFT + "." + DerivzDBConstants.TBL_USER_SEARCH_SAVED_LIST
			+ "  set delete_flag=0 where user_id = :userId and delete_flag=1", nativeQuery = true)
	public int restoreTempBookmarkByUserId(@Param("userId") final String userId);
	
	@Modifying (flushAutomatically = true , clearAutomatically   = true)
	@Query(value = "update " + DerivzDBConstants.SCHEMA_CEFT + "." + DerivzDBConstants.TBL_USER_SEARCH_SAVED_LIST
			+ " set delete_flag=1 where user_id = :userId and parent_id=:parent_id", nativeQuery = true)
	public int deleteTempBookmarksOfOriginal(@Param("userId")final String userId,@Param("parent_id") final Long parentBookmarkId);

	@Query(value = "SELECT * FROM " + DerivzDBConstants.SCHEMA_CEFT + "." + DerivzDBConstants.TBL_USER_SEARCH_SAVED_LIST
			+ " where user_id = :userId and parent_id=:parent_id", nativeQuery = true)
	public Bookmark findTempBookmarkByParentId(@Param("userId")final String userId,@Param("parent_id") final Long parentBookmarkId);
	
	@Modifying (flushAutomatically = true , clearAutomatically   = true)
	@Query(value = "update " + DerivzDBConstants.SCHEMA_CEFT + "." + DerivzDBConstants.TBL_USER_SEARCH_SAVED_LIST
			+ " set saved_list= :criteria , delete_flag=0, updated_time =:updatedTime where user_id = :userId and parent_id=:parent_id", nativeQuery = true)
	public int updateTempBookmark(@Param("criteria")String criteria,@Param("userId")final String userId,@Param("parent_id")final Long parentId, @Param("updatedTime")final Date updatedTime);

	@Modifying
	@Query(value = "select short_name from " + DerivzDBConstants.SCHEMA_VOYAGER + "." + "dataset_type_table", nativeQuery = true)
	//SELECT short_name FROM voyager.dataset_type_table WITH(NOLOCK)
	public List<String> getAllDatasetType();
	
	@Modifying
	@Query(value="SELECT b.chart_name FROM " +DerivzDBConstants.SCHEMA_VOYAGER + "."+DerivzDBConstants.USER_DATASET_TABLE 
			+" a with(NOLOCK) INNER JOIN "+DerivzDBConstants.SCHEMA_VOYAGER + "."+DerivzDBConstants.TBL_USER_SAVED_CHART
			+" b with(NOLOCK) ON a.dataset_id = b.dataset_id WHERE a.soeid = :userId AND" 
			+" a.bookmark_id = :bookmarkId AND a.flag = 1 ",nativeQuery = true)
	public List<String> getChartsForBookmarks(@Param("userId")String userId,@Param("bookmarkId") Long bookmarkId);
	
}

