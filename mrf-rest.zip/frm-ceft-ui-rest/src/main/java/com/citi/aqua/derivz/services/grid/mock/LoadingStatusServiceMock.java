package com.citi.aqua.derivz.services.grid.mock;

import com.citi.aqua.derivz.services.grid.CeftDataSet;
import com.citi.aqua.derivz.services.grid.CeftDataSetStatus;
import com.citi.aqua.derivz.services.grid.LoadingStatusService;

/**
 * @author Aleksander Nowinski, aleksander.nowinski@citi.com
 * @since 6/19/2019
 */
public class LoadingStatusServiceMock implements LoadingStatusService {

    @Override
    public boolean isDataSetReady(CeftDataSet dataSet) {
        throw new UnsupportedOperationException();
    }

    @Override
    public void loadData(CeftDataSet dataSet) {
        throw new UnsupportedOperationException();
    }

    @Override
    public CeftDataSetStatus dataSetStatus(CeftDataSet dataSet) {
        throw new UnsupportedOperationException();
    }

    @Override
    public CeftDataSetStatus[] dataSetStatusForBookmark(String soeId, long bookmark) {
        throw new UnsupportedOperationException();
    }

    @Override
    public CeftDataSetStatus requestDataSet(CeftDataSet dataSet, String atmosphereResourceUUID) {
        throw new UnsupportedOperationException();
    }
}
