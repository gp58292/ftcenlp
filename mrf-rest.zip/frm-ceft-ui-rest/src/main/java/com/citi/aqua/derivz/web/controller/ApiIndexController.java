package com.citi.aqua.derivz.web.controller;

import org.apache.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@RestController
@RequestMapping("/api")
public class ApiIndexController {

    private static final Logger LOGGER = LoggerFactory.getLogger("UIERROR");

    private final HttpSession httpSession;

    @Autowired
    public ApiIndexController(HttpSession httpSession) {
        this.httpSession = httpSession;
    }

    @RequestMapping(value = "/heartBeat", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public void heartBeat(HttpServletRequest request, HttpServletResponse response) {
        LOGGER.debug("## heartBeat Ping [SessionId:" + request.getSession().getId() + "]");
    }

    @RequestMapping(value = "/logClientErrors", method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE)
    public int logClientErrors(@RequestBody String errorMessage) {
        String id = "NA";
        if (this.httpSession != null) {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            id = authentication.getName();
        }
        LOGGER.error("## UI ERROR Start ## :{} \n {}", id, errorMessage);
        LOGGER.error("## UI ERROR End   ## : ");
        return HttpStatus.SC_OK;
    }

}
