package com.citi.aqua.derivz.vo;

public class NumberFilterModelVO extends FilterModelVO {

	
	private static final long serialVersionUID = 1L;
	
	private String type;
    private Integer filter;
    private Integer filterTo;

    public NumberFilterModelVO() {}

    public NumberFilterModelVO(String type, Integer filter, Integer filterTo) {
        this.type = type;
        this.filter = filter;
        this.filterTo = filterTo;
    }

    public String getFilterType() {
        return filterType;
    }

    public String getType() {
        return type;
    }

    public Integer getFilter() {
        return filter;
    }

    public Integer getFilterTo() {
        return filterTo;
    }
}
