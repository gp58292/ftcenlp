package com.citi.aqua.derivz.model;

import java.io.Serializable;
import java.sql.Timestamp;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Entity
@Table(name = DerivzDBConstants.TBL_USER, schema = DerivzDBConstants.SCHEMA_CEFT)
public class CEFTUser implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;

	@Column(name = "soeid")
	private String soeid;

	@Column(name = "friendly_name")
	private String friendlyName;

	@Column(name = "domain_name")
	private String domainName;

	@Column(name = "email")
	private String email;

	@Column(name = "group_name")
	private String groupName;

	@Column(name = "group_email")
	private String groupEmail;

	@Column(name = "manager_soeid")
	private String managerSoeId;

	@Column(name = "created_time")
	private Timestamp createdTime;

	@Column(name = "created_by")
	private String createdBy;

	@Column(name = "modified_by")
	private String modifiedBy;

	@Column(name = "modified_time")
	private Timestamp modifiedTime;

	@Column(name = "status")
	private String status;

	@Column(name = "user_role")
	private String userRole;

	@Column(name = "ceft_access")
	private String ceftAccess;

	@Column(name = "voyager_access")
	private String voyagerAccess;

}