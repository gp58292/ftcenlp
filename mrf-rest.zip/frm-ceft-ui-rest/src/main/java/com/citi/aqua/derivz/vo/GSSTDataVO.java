package com.citi.aqua.derivz.vo;

import java.math.BigDecimal;
import java.sql.Date;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@JsonInclude(Include.NON_NULL)
public class GSSTDataVO {
	
	private int agreementID;	
	private Date busDate;
	private String cSADescription;
	private BigDecimal basePV;
	private BigDecimal mtmUSD;
	private BigDecimal actualCollateral;
	private String scenarioName;
	private BigDecimal stressedPV;
	private BigDecimal exposure;
	private String rightofReuse;
	private String clearingAgreement;
	private String consenttoSubstitution;
	private String pledger;
	private String partylegalEntity;
	private String counterpartyName;
	private String gfcid;
	private String gfcidType;
	private String thresholdParty;
	private String thresholdCounterparty;
	private String masterAgreement;
	private String masterAgreementStatus;	
	private String businessDate;

}
