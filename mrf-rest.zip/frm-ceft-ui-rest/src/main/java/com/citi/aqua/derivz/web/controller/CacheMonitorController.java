package com.citi.aqua.derivz.web.controller;

import java.util.List;
import java.util.Map;

import org.apache.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.citi.aqua.derivz.commons.constants.DerivzAPIUriConstants;
import com.citi.aqua.derivz.commons.exceptions.DerivzApplicationException;
import com.citi.aqua.derivz.data.cache.eh.StaticCacheKeys;
import com.citi.aqua.derivz.model.BatchProcessAudit;
import com.citi.aqua.derivz.model.SelectionFilters;
import com.citi.aqua.derivz.model.columns.mapping.SearchResultColumns;
import com.citi.aqua.derivz.services.service.CacheService;
import com.citi.aqua.derivz.web.utils.DerivzRestResponse;
import com.citi.aqua.derivz.web.utils.ResponseBuilder;

@RestController
@RequestMapping(DerivzAPIUriConstants.CACHE_API_URI)
public class CacheMonitorController {

	private static final String DS002 = "DS002";

	private static final Logger LOGGER = LoggerFactory.getLogger(ReferenceDataController.class);

	@Autowired
	private CacheService cacheService;

	// Redudnt method
	@RequestMapping(value = DerivzAPIUriConstants.LOAD_REFERENCE_DATA_URI, method = RequestMethod.GET)
	public @ResponseBody DerivzRestResponse<String> loadReferenceData() {
		LOGGER.debug("CacheMonitorController::loadReferenceData() ");
		try {
			cacheService.loadReferenceData();
			return ResponseBuilder.build("Success: Reference data is loaded into cache", HttpStatus.SC_OK);
		} catch (DerivzApplicationException de) {
			LOGGER.error("ReferenceDataController::loadReferenceData() :: Error:" + de, de);
			return ResponseBuilder.build("Error occured: Reference data is not loaded into cache",HttpStatus.SC_NOT_FOUND, "Failed to retrieve reference data", DS002);
		} catch (Exception e) {
			LOGGER.error("ReferenceDataController::evictReferenceData() :: Error " + e, e);
			return ResponseBuilder.build("Error occured: Reference data is not loaded into reference cache",HttpStatus.SC_NOT_FOUND, "GENERIC_MESSAGE_FOR_FAILURE", "GM001");
		}
	}
	
	
	// This URL name and method name need to rename to search field static
	@RequestMapping(value = DerivzAPIUriConstants.LOAD_STATIC_DATA_URI, method = RequestMethod.GET)
	public @ResponseBody DerivzRestResponse<Map<Long, SelectionFilters>> loadStaticData() {
		LOGGER.debug("CacheMonitorController::loadStaticData() ");
		Map<Long, SelectionFilters> staticComponentMap = null;
		try {
			staticComponentMap = cacheService.findStaticComponentData(StaticCacheKeys.STATIC_COMPONENT_DATA);
			return ResponseBuilder.build(staticComponentMap, HttpStatus.SC_OK);
		} catch (DerivzApplicationException de) {
			LOGGER.error("ReferenceDataController::loadStaticData() :: Error " + de, de);
			return ResponseBuilder.build(staticComponentMap, HttpStatus.SC_NOT_FOUND, "Exception:: Failed to load static data", "DS003");
		} catch (Exception e) {
			LOGGER.error("ReferenceDataController::loadStaticData() :: Error " + e, e);
			return ResponseBuilder.buildExceptionResponse();
		}
	}
	
	@RequestMapping(value = DerivzAPIUriConstants.LOAD_STATIC_SEARCH_RESULT_COLUMNS_URI, method = RequestMethod.GET)
	public @ResponseBody DerivzRestResponse<List<SearchResultColumns>> getResultColumnsDetails() {
		LOGGER.debug("CacheMonitorController::getResultColumnsDetails() ");
		List<SearchResultColumns> staticResultColumns = null;
		try {
			staticResultColumns = cacheService.getAllSearchResultColumns(StaticCacheKeys.RESULT_COLUMNS);
			return ResponseBuilder.build(staticResultColumns, HttpStatus.SC_OK);
		} catch (DerivzApplicationException de) {
			LOGGER.error("ReferenceDataController::getResultColumnsDetails() :: Error " + de, de);
			return ResponseBuilder.build(staticResultColumns, HttpStatus.SC_NOT_FOUND, "Failed to load static data for result column details", "DS004");
		} catch (Exception e) {
			LOGGER.error("ReferenceDataController::getResultColumnsDetails() :: Error " + e, e);
			return ResponseBuilder.buildExceptionResponse();
		}
	}

	//Return batch cache status
	@RequestMapping(value = DerivzAPIUriConstants.CACHE_STATUS_URI, method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody DerivzRestResponse<List<BatchProcessAudit>> getCacheStatus() {
		LOGGER.debug("CacheMonitorController::getCacheStatus() ");
		List<BatchProcessAudit> batchProcessAuditList = null;
		try {
			batchProcessAuditList = cacheService.getBatchProcessAudit();
			return ResponseBuilder.build(batchProcessAuditList, HttpStatus.SC_OK);
		} catch (Exception e) {
			LOGGER.error("ReferenceDataController::getCacheStatus() :: Error " + e, e);
			return ResponseBuilder.buildExceptionResponse();
		}
	}

	// This will wipe reference cache, on new call data will be loaded from DB
	@RequestMapping(value = DerivzAPIUriConstants.EVICT_REFERENCE_DATA_URI, method = RequestMethod.GET)
	public @ResponseBody DerivzRestResponse<String> evictReferenceData() {
		LOGGER.debug("CacheMonitorController::evictReferenceData() ");
		try {
			cacheService.evictReferenceDataCache();
			return ResponseBuilder.build("Success: Reference data is evicted from cache", HttpStatus.SC_OK);
		} catch (DerivzApplicationException de) {
			LOGGER.error("ReferenceDataController::evictReferenceData() :: Error:" + de, de);
			return ResponseBuilder.build("Error occured: Reference data is not evicted from cache",HttpStatus.SC_NOT_FOUND, "Failed to evict reference data", "DS005");
		} catch (Exception e) {
			LOGGER.error("ReferenceDataController::evictReferenceData() :: Error " + e, e);
			return ResponseBuilder.buildExceptionResponse();
		}
	}

	// This will wpie static cache, on new call data will be loaded from DB
	@RequestMapping(value = DerivzAPIUriConstants.EVICT_STATIC_DATA_URI, method = RequestMethod.GET)
	public @ResponseBody DerivzRestResponse<String> evictStaticDataCache() {
		LOGGER.debug("CacheMonitorController::evictStaticDataCache() ");
		try {
			cacheService.evictStaticDataCache();
			return ResponseBuilder.build("Success: Static data is evicted from cache", HttpStatus.SC_OK);
		} catch (DerivzApplicationException de) {
			LOGGER.error("ReferenceDataController::evictStaticData() :: Error:" + de, de);
			return ResponseBuilder.build("Error occured: Static data is not evicted from cache",HttpStatus.SC_NOT_FOUND, "Failed to evict static data", "DS006");
		} catch (Exception e) {
			LOGGER.error("ReferenceDataController::evictStaticData() :: Error " + e, e);
			return ResponseBuilder.buildExceptionResponse();
		}
	}
	//------------------------------ Cache Refresh or reload API Start-------------------------------------------
	
	// Data will stale for already loaded app, need improvement
	@RequestMapping(value = DerivzAPIUriConstants.REFRESH_CACHE_URI, method = RequestMethod.GET)
	public @ResponseBody DerivzRestResponse<Map<Long, SelectionFilters>> refreshCache() {
		LOGGER.debug("CacheMonitorController::refreshCache() ");
		Map<Long, SelectionFilters> staticComponentMap = null;
		try {
			// First evict reference data
			cacheService.evictReferenceDataCache();
			// Load reference data
			cacheService.loadReferenceData();
			// Evict Static data
			cacheService.evictStaticDataCache();
			// Load static data
			cacheService.getAllSearchResultColumns(StaticCacheKeys.RESULT_COLUMNS);
			staticComponentMap = cacheService.findStaticComponentData(StaticCacheKeys.STATIC_COMPONENT_DATA);
			LOGGER.debug("CacheMonitorController::refreshCache():: Completed");
			return ResponseBuilder.build(staticComponentMap, HttpStatus.SC_OK);
		} catch (DerivzApplicationException de) {
			LOGGER.error("ReferenceDataController::refreshCache() :: Error:" + de, de);
			return ResponseBuilder.build(staticComponentMap, HttpStatus.SC_NOT_FOUND, "Failed to refresh cache","DS007");
		} catch (Exception e) {
			LOGGER.error("ReferenceDataController::refreshCache() :: Error " + e, e);
			return ResponseBuilder.buildExceptionResponse();
		}
	}

	// These API need to be improved , if we are calling from loaded app then, this will not work, app data will be stale 
	// But if we do reload app then , it will have fresh data
	@RequestMapping(value = DerivzAPIUriConstants.REFRESH_STATIC_DATA_URI, method = RequestMethod.GET)
	public @ResponseBody DerivzRestResponse<Map<Long, SelectionFilters>> refreshStaticData() {
		LOGGER.debug("CacheMonitorController::refreshStaticData() ");
		Map<Long, SelectionFilters> staticComponentMap = null;
		try {
			// Evict Static data
			cacheService.evictStaticDataCache();
			// Load static data
			cacheService.getAllSearchResultColumns(StaticCacheKeys.RESULT_COLUMNS);
			staticComponentMap = cacheService.findStaticComponentData(StaticCacheKeys.STATIC_COMPONENT_DATA);
			return ResponseBuilder.build(staticComponentMap, HttpStatus.SC_OK);
		} catch (DerivzApplicationException de) {
			LOGGER.error("ReferenceDataController::refreshStaticData() :: Error:" + de, de);
			return ResponseBuilder.build(staticComponentMap, HttpStatus.SC_NOT_FOUND, "Failed to refresh static data",
					DS002);
		} catch (Exception e) {
			LOGGER.error("ReferenceDataController::refreshStaticData() :: Error " + e, e);
			return ResponseBuilder.buildExceptionResponse();
		}
	}

	@RequestMapping(value = DerivzAPIUriConstants.REFRESH_REFERENCE_DATA_URI, method = RequestMethod.GET)
	public @ResponseBody DerivzRestResponse<String> refreshReferenceData() {
		LOGGER.debug("CacheMonitorController::refreshReferenceData() ");
		try {
			// First evict reference data
			cacheService.evictReferenceDataCache();
			// Load reference data
			cacheService.loadReferenceData();
			return ResponseBuilder.build("Success: Reference data is loaded into cache", HttpStatus.SC_OK);
		} catch (DerivzApplicationException de) {
			LOGGER.error("ReferenceDataController::refreshReferenceData() :: Error:" + de, de);
			return ResponseBuilder.build("Error occured: Reference data is not refereshed into cache",
					HttpStatus.SC_NOT_FOUND, "Failed to retrieve reference data", DS002);
		} catch (Exception e) {
			LOGGER.error("ReferenceDataController::refreshReferenceData() :: Error " + e, e);
			return ResponseBuilder.build("Error occured: Reference data is not refereshed into cache",
					HttpStatus.SC_NOT_FOUND, "GENERIC_MESSAGE_FOR_FAILURE", "GM001");
		}
	}
}
