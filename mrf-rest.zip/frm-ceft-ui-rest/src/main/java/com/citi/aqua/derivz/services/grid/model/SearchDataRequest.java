package com.citi.aqua.derivz.services.grid.model;

import com.citi.aqua.derivz.services.grid.ColumnSortCriteria;
import lombok.Data;

import java.util.List;

/**
 * @author Aleksander Nowinski, aleksander.nowinski@citi.com
 * @since 6/21/2019
 */
@Data
public class SearchDataRequest extends DataRequest {
    private List<String> columns;
    private List<ColumnSortCriteria> sortCriteria;
    private int offset;
    private int limit;
}
