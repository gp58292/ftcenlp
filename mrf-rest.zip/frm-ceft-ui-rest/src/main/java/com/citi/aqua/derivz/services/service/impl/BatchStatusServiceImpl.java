package com.citi.aqua.derivz.services.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.citi.aqua.derivz.data.jdbc.BatchStatusDAO;
import com.citi.aqua.derivz.dto.BatchStatusResponseDTO;
import com.citi.aqua.derivz.services.service.BatchStatusService;

@Service
public class BatchStatusServiceImpl implements BatchStatusService {

	@Autowired
	BatchStatusDAO batchStatusDao;

	@Override
	public List<BatchStatusResponseDTO> getStatusReport(String cobDate) {
		return batchStatusDao.callDailyBatchStatusReportProc(cobDate);
	}


}
