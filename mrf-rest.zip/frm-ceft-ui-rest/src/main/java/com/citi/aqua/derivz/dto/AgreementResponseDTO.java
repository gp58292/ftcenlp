package com.citi.aqua.derivz.dto;

import java.util.List;
import java.util.Map;
import java.util.Set;

import com.citi.aqua.derivz.vo.PartyDetailsVO;
import com.citi.aqua.derivz.vo.ProductDetailsVO;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
@Getter
@Setter
@ToString
public class AgreementResponseDTO {

	private long agreementId;
	private long agreementKey;
	private String clearingAgreement;
	private String closeoutNettingEnforcabilityFlag;
	private String entity;
	private String partyLegalEntity;
	private String exchangeClearedAgreement;
	private String governingLaw;
	private String incorporatedCountry;
	private String masterAgreement;
	private String masterAgreementStatus;
	private String party;
	private String partyGfcId;
	private Set<PartyDetailsVO> partyDetails;
	private String counterParty;
	private String counterPartyGfcId;
	private Set<PartyDetailsVO> counterPartyDetails;
	private List<ProductDetailsVO> coveredProducts;

	private String sendToCredit;
	private String sme;
	private List<Map<String,String>> csaTypeDescList;
}