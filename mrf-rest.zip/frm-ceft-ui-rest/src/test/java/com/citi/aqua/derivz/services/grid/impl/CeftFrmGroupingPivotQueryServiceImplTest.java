package com.citi.aqua.derivz.services.grid.impl;

import com.citi.aqua.derivz.services.grid.CeftDataSet;
import com.citi.aqua.derivz.services.grid.ColumnFilter;
import com.citi.aqua.derivz.services.grid.model.ColumnAggregation;
import com.citi.aqua.derivz.services.grid.model.GroupingSearchDataRequest;
import com.citi.aqua.frm.ceft.CeftDataSetType;
import com.citi.aqua.frm.framework.grid.DataSetQueryService;
import com.citi.aqua.frm.framework.grid.tools.FrmGrid;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Collections;
import java.util.List;

import static java.util.Arrays.asList;
import static java.util.Collections.emptyList;
import static junit.framework.TestCase.assertEquals;
import static junit.framework.TestCase.assertTrue;
import static org.junit.Assert.assertFalse;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

/**
 * @author Aleksander Nowinski, aleksander.nowinski@citi.com
 * @since 7/10/2019
 */
@RunWith(MockitoJUnitRunner.class)
public class CeftFrmGroupingPivotQueryServiceImplTest {

    @Mock
    FrmGrid grid;

    @Mock
    DataSetQueryService queryService;

    @InjectMocks
    CeftFrmGroupingPivotQueryServiceImpl instance;
    private CeftDataSet testCeftDataSet = new CeftDataSet("testSoeId", 10L, CeftDataSetType.FMTM);

    @Before
    public void setup() {
        when(grid.connectQueryService()).thenReturn(queryService);
        when(queryService.getDataSetSQLNamespace(any(), any())).thenReturn("namespace");
        when(queryService.getDataSetSQLTableName(any(), any())).thenReturn("table");
//        when(queryService.getCacheNameForDataset(any(), any())).thenReturn("cache");
    }


    @Test
    public void searchQueryGrouping() {
    }

    @Test
    public void buildAggregateQuery() {
        GroupingSearchDataRequest request = new GroupingSearchDataRequest();
        request.setColumnGrouping(asList("a", "b"));
        request.setGroupValues(asList("v2"));
        request.setDataSet(testCeftDataSet);
        request.setAggregations(asList(new ColumnAggregation("col1", ColumnAggregation.Aggregation.SUM),
                new ColumnAggregation("col2", ColumnAggregation.Aggregation.COUNT)));
        request.setFilters(asList(new ColumnFilter("fc1", new String[]{"fv1", null}),
                new ColumnFilter("fc2", new String[]{"fv2"})));
        request.setLimit(10);
        request.setOffset(0);
        String res = instance.buildAggregateQuery(request);
        assertEquals(
                "SELECT a, b, SUM(col1), COUNT(col2) FROM namespace.table WHERE a='v2' AND (fc1='fv1' OR (fc1='' OR fc1 IS NULL)) AND fc2='fv2' GROUP BY a, b LIMIT 10 OFFSET 0",
                res
        );
    }


    @Test
    public void testCartesian() {

        List<Object> c1 = asList(1,2, null);
        List<Object> c2 = asList("a", "b");
        List<Object> c3 = Collections.singletonList(12L);

        List<List<Object>> expRes = asList(
                asList(1, "a", 12L),
                asList(1, "b", 12L),
                asList(2, "a", 12L),
                asList(2, "b", 12L),
                asList(null, "a", 12L),
                asList(null, "b", 12L)
        );
        assertEquals(expRes, CeftFrmGroupingPivotQueryServiceImpl.cartesian(asList(c1, c2, c3)));

        //test on empty:
        assertEquals(emptyList(), CeftFrmGroupingPivotQueryServiceImpl.cartesian(emptyList()));
        //test on onelist:
        expRes= asList(
                asList("1"),
                asList("2")
                );
        assertEquals(expRes, CeftFrmGroupingPivotQueryServiceImpl.cartesian(asList(asList("1","2"))));
    }

    @Test
    public void buildFromClause() {
        String from = instance.buildFromClause(testCeftDataSet);
        assertEquals(" FROM namespace.table", from);
    }

    @Test
    public void isAggregate() {
        GroupingSearchDataRequest request = new GroupingSearchDataRequest();
        request.setColumnGrouping(asList("a", "b"));
        request.setGroupValues(emptyList());
        assertTrue(instance.isAggregate(request));

        request.setGroupValues(asList("v2"));
        assertTrue(instance.isAggregate(request));

        request.setGroupValues(asList("v2", "v2"));
        assertFalse(instance.isAggregate(request));
    }

    @Test
    public void testEqClause() {
        assertEquals("col='val'", CeftFrmGroupingPivotQueryServiceImpl.buildEqCondition("col", "val"));
        assertEquals("(col='' OR col IS NULL)", CeftFrmGroupingPivotQueryServiceImpl.buildEqCondition("col", null));
        assertEquals("(col='' OR col IS NULL)", CeftFrmGroupingPivotQueryServiceImpl.buildEqCondition("col", ""));
    }
}