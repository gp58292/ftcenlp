package com.citi.aqua.derivz.services.grid;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class LoadingProgressTrackerTest {

    private final String frmSetId = TestObjectProvider.SAMPLE_CEFT_DATA_SET.toDataSetId().getSetId();
    private LoadingProgressTracker instance;

    @Before
    public void setUp() {
        instance = new LoadingProgressTracker();
    }

    @After
    public void tearDown() {
    }

    @Test
    public void registerUUID() {
        assertNull(instance.findDataSet(frmSetId, null));
        instance.registerWebSocketUUID(TestObjectProvider.SAMPLE_CEFT_DATA_SET, TestObjectProvider.SAMPLE_VERSION, TestObjectProvider.SAMPLE_UUID);
        assertEquals(TestObjectProvider.SAMPLE_CEFT_DATA_SET, instance.findDataSet(frmSetId, null));
    }

    @Test
    public void findUUID() {
        instance.registerWebSocketUUID(TestObjectProvider.SAMPLE_CEFT_DATA_SET, TestObjectProvider.SAMPLE_VERSION, TestObjectProvider.SAMPLE_UUID);
        assertEquals(TestObjectProvider.SAMPLE_UUID, instance.findUUID(frmSetId, TestObjectProvider.SAMPLE_VERSION));
        assertEquals(TestObjectProvider.SAMPLE_UUID, instance.findUUID(frmSetId, null));
        assertNull(instance.findUUID(frmSetId, TestObjectProvider.SAMPLE_VERSION +1));

    }

    @Test
    public void findDataSet() {
        instance.registerWebSocketUUID(TestObjectProvider.SAMPLE_CEFT_DATA_SET, TestObjectProvider.SAMPLE_VERSION, TestObjectProvider.SAMPLE_UUID);
        assertEquals(TestObjectProvider.SAMPLE_CEFT_DATA_SET, instance.findDataSet(frmSetId, null));
        assertEquals(TestObjectProvider.SAMPLE_CEFT_DATA_SET, instance.findDataSet(frmSetId, TestObjectProvider.SAMPLE_VERSION));
        assertNull(instance.findDataSet(frmSetId, TestObjectProvider.SAMPLE_VERSION +1));
    }
}