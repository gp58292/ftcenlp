package com.citi.aqua.derivz.vo;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import com.citi.aqua.derivz.enums.OPERATION;
import com.jayway.jsonpath.internal.path.ArraySliceOperation.Operation;

public class IncludeExcludeVOTest {
	
	IncludeExcludeVO includeExcludeVO;

	@Before
	public void setUp() throws Exception {
		includeExcludeVO= new IncludeExcludeVO<>();
	}

	@Test
	public void testGetOperation() {
		IncludeExcludeVO vo= new IncludeExcludeVO<>();
		vo.setOperation(OPERATION.OR);
		includeExcludeVO.setOperation(vo.getOperation());
		includeExcludeVO.setButNotValue(vo.getButNotValue());
		includeExcludeVO.setValue(vo.getValue());
		includeExcludeVO.toString();
		includeExcludeVO.hashCode();
		includeExcludeVO.equals(vo);
		assertEquals(OPERATION.OR,includeExcludeVO.getOperation());
	}

}

