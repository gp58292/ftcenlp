package com.citi.aqua.derivz.vo;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class ConditionCriteriaVOTest {

	ConditionCriteriaVO conditionCriteriaVO;
	@Before
	public void setUp() throws Exception {
		conditionCriteriaVO= new ConditionCriteriaVO<>();
	}

	@Test
	public void testGetInValue() {
		ConditionCriteriaVO vo= new ConditionCriteriaVO<>();
		conditionCriteriaVO.setStart(vo.getStart());
		conditionCriteriaVO.setEnd(vo.getStart());
		String[] strArr= {"Test"};
		vo.setInValue(strArr);
		vo.setAndValue(strArr);
		vo.setButNotValue(strArr);
		vo.setOrValue(strArr);
		conditionCriteriaVO.setAndValue(vo.getAndValue());
		conditionCriteriaVO.setButNotValue(vo.getButNotValue());
		conditionCriteriaVO.setOrValue(vo.getOrValue());
		conditionCriteriaVO.setInValue(vo.getInValue());
		conditionCriteriaVO.hashCode();
		conditionCriteriaVO.toString();
		conditionCriteriaVO.equals(vo);
		assertEquals("Test",conditionCriteriaVO.getInValue()[0]);
	}

}
