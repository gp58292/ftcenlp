package com.citi.aqua.derivz.services.grid.impl;

import com.citi.aqua.derivz.services.grid.LoadingProgressTracker;
import com.citi.aqua.derivz.services.grid.TestObjectProvider;
import com.citi.aqua.frm.framework.grid.DataLoadingService;
import com.citi.aqua.frm.framework.grid.User;
import com.citi.aqua.frm.framework.grid.tools.FrmGrid;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.*;

/**
 * @author Aleksander Nowinski, aleksander.nowinski@citi.com
 * @since 7/17/2019
 */
@RunWith(MockitoJUnitRunner.class)
public class LoadingStatusServiceImplTest {

    @Mock
    FrmGrid gridMock;

    @Mock
    DataLoadingService loadingService;

    @Mock
    LoadingProgressTracker tracker;

    @InjectMocks
    LoadingStatusServiceImpl instance;

    @Before
    public void setup() {
        Mockito.when(gridMock.connectLoadingService()).thenReturn(loadingService);

    }

    @Test
    public void loadData() {

        instance.loadData(TestObjectProvider.SAMPLE_CEFT_DATA_SET);
        Mockito.verify(loadingService).loadDataSet(TestObjectProvider.SAMPLE_FRM_DATA_SET_ID,
                new User(TestObjectProvider.SAMPLE_SOE_ID, false));
    }

}