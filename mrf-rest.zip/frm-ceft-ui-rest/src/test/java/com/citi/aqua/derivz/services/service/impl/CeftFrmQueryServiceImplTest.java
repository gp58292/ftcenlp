package com.citi.aqua.derivz.services.service.impl;

import com.citi.aqua.derivz.services.grid.CeftDataSet;
import com.citi.aqua.derivz.services.grid.ColumnFilter;
import com.citi.aqua.derivz.services.grid.impl.CeftFrmQueryServiceImpl;
import com.citi.aqua.derivz.services.grid.model.DataRequest;
import com.citi.aqua.derivz.services.grid.model.SearchDataRequest;
import com.citi.aqua.derivz.services.grid.postprocessing.SearchQueryPostprocessor;
import com.citi.aqua.frm.framework.grid.tools.FrmGrid;
import com.citi.aqua.frm.framework.query.FrmQuery;
import com.citi.aqua.frm.framework.query.model.CompoundCondition;
import com.citi.aqua.frm.framework.query.model.ConditionAware;
import com.citi.aqua.frm.framework.query.model.FilterDefinition;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Arrays;
import java.util.Collections;

@RunWith(SpringRunner.class)
public class CeftFrmQueryServiceImplTest {

    class CeftFrmQueryServiceImplMock extends CeftFrmQueryServiceImpl {
        public CeftFrmQueryServiceImplMock(FrmGrid grid, SearchQueryPostprocessor postprocessor) {
            super(grid, postprocessor);
        }

        public ConditionAware callBuildColumnFilter(ColumnFilter filter) {
            return CeftFrmQueryServiceImpl.buildColumnFilter(filter);
        }

        public FrmQuery callBuildCoreQuery(DataRequest request) {
            return buildCoreQuery(request);
        }
    }

    @MockBean
    FrmGrid frmGrid;

    @MockBean
    CeftDataSet dataSet;

    private SearchQueryPostprocessor postprocessor;
    private CeftFrmQueryServiceImplMock ceftFrmQueryService;
    private ColumnFilter testColumnFilter;

    @Before
    public void setUp() {
        postprocessor = new SearchQueryPostprocessor(Collections.emptyList());
        ceftFrmQueryService = new CeftFrmQueryServiceImplMock(frmGrid, postprocessor);

        testColumnFilter = new ColumnFilter();
        testColumnFilter.setColumn("column1");
    }

    @Test
    public void testBuildColumnFilterNoBlanks() {
        String[] filterValues = {"1", "2"};
        testColumnFilter.setValues(filterValues);

        CompoundCondition res = (CompoundCondition) ceftFrmQueryService.callBuildColumnFilter(testColumnFilter);

        assert (res.getConditions().size() == 2);
        FilterDefinition filter1 = (FilterDefinition) res.getConditions().toArray()[0];
        FilterDefinition filter2 = (FilterDefinition) res.getConditions().toArray()[1];

        assert (filter1.getFilterType().equals(FilterDefinition.FilterType.EQUAL));
        assert (filter1.getValue().equals("1"));
        assert (filter2.getValue().equals("2"));
    }

    @Test
    public void testBuildColumnFilterBlankAddsNull() {
        String[] filterValues = {"1", ""};
        testColumnFilter.setValues(filterValues);

        CompoundCondition res = (CompoundCondition) ceftFrmQueryService.callBuildColumnFilter(testColumnFilter);

        assert (res.getConditions().size() == 3);
        FilterDefinition filter1 = (FilterDefinition) res.getConditions().toArray()[0];
        FilterDefinition filter2 = (FilterDefinition) res.getConditions().toArray()[1];
        FilterDefinition filter3 = (FilterDefinition) res.getConditions().toArray()[2];

        assert (filter1.getFilterType().equals(FilterDefinition.FilterType.EQUAL));
        assert (filter1.getValue().equals("1"));
        assert (filter2.getValue().equals(""));
        assert (filter3.getFilterType().equals(FilterDefinition.FilterType.IS_NULL));
        assert (filter3.getValue() == null);
    }

    @Test
    public void testCeftQueryWithBlank() {
        String[] filterValues = {"1", ""};
        testColumnFilter.setValues(filterValues);

        SearchDataRequest searchDataRequest = new SearchDataRequest();
        searchDataRequest.setColumns(Arrays.asList("column1", "column2"));
        searchDataRequest.setOffset(0);
        searchDataRequest.setLimit(10);
        searchDataRequest.setDataSet(dataSet);

        searchDataRequest.setFilters(Arrays.asList(testColumnFilter));

        FrmQuery query = ceftFrmQueryService.callBuildCoreQuery(searchDataRequest);
        assert (query != null);
    }

    @Test(expected  = IllegalArgumentException.class)
    public void testBuildColumnFilterNullFilter() {
        ceftFrmQueryService.callBuildColumnFilter(null);
    }

    @Test(expected  = IllegalArgumentException.class)
    public void testBuildColumnFilterEmptyColumn() {
        testColumnFilter.setColumn("");
        ceftFrmQueryService.callBuildColumnFilter(testColumnFilter);
    }

    @Test(expected  = IllegalArgumentException.class)
    public void testBuildColumnFilterNullValues() {
        testColumnFilter.setValues(null);
        ceftFrmQueryService.callBuildColumnFilter(testColumnFilter);
    }
}
