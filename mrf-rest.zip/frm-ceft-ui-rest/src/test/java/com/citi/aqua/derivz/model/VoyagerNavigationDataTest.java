package com.citi.aqua.derivz.model;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

public class VoyagerNavigationDataTest {
	private static final String DUMMY = "Dummy";
	private VoyagerNavigationData voyagerNavigationData;

	@Before
	public void setUp() throws Exception {
		voyagerNavigationData= new VoyagerNavigationData();
	}

	@Test
	public void testGetDatasetId() {
		VoyagerNavigationData data= new VoyagerNavigationData();
		data.setDatasetId(1);
		data.setDisplayFlag(1);
		data.setDisplayName(DUMMY);
		data.setNavigationUrl(DUMMY);
		data.setShortName(DUMMY);
		voyagerNavigationData.setDatasetId(data.getDatasetId());
		voyagerNavigationData.setDisplayFlag(data.getDisplayFlag());
		voyagerNavigationData.setDisplayName(data.getDisplayName());
		voyagerNavigationData.setNavigationUrl(data.getNavigationUrl());
		voyagerNavigationData.setShortName(data.getShortName());
		voyagerNavigationData.equals(data);
		voyagerNavigationData.toString();
		voyagerNavigationData.hashCode();
		assertEquals(1,voyagerNavigationData.getDatasetId());
	}

}
