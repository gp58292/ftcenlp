package com.citi.aqua.derivz.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Before;
import org.junit.Test;

public class RatingRankingsTest {
	
	private RatingRankings ratingRankings;
	
	@Before
	public void setUp() throws Exception {
		ratingRankings = new RatingRankings();
	}

	@Test
	public void testGetAgencyName() {
		RatingRankings ranks= new RatingRankings();
		ranks.setAgencyName("TEST");
		ratingRankings.setAgencyName(ranks.getAgencyName());
		ratingRankings.setRank(ranks.getRank());
		ratingRankings.setRating(ranks.getRating());
		ratingRankings.setRatingRankingKey(ranks.getRatingRankingKey());
		ratingRankings.setTerm(ranks.getTerm());
		ratingRankings.equals(ranks);
		
		RatingRankings.builder().build();
		
		assertEquals("TEST", ranks.getAgencyName());
		
		RatingRankings allArgs = new RatingRankings(1L, "TEST", "", "", 1L);
		assertEquals("TEST", allArgs.getAgencyName());
		
		String ranksStr = allArgs.toString();
		int ranksHashCode = allArgs.hashCode();
		
		assertNotNull(ranksStr);
		assertNotNull(ranksHashCode);
		
		
	}


}
