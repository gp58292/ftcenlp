package com.citi.aqua.derivz.vo;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import org.junit.Before;
import org.junit.Test;

public class CollateralHaircutDetailsVOTest {

	CollateralHaircutDetailsVO collateralHaircutDetailsVO;

	@Before
	public void setUp() throws Exception {
		collateralHaircutDetailsVO = new CollateralHaircutDetailsVO();

	}

	@Test
	public void test() {
		CollateralHaircutDetailsVO vo = new CollateralHaircutDetailsVO();
		vo.setAchType("TEST");
		collateralHaircutDetailsVO.setAchType(vo.getAchType());
		collateralHaircutDetailsVO.setAchCollateralApplied(vo.getAchCollateralApplied());
		collateralHaircutDetailsVO.setAchHaicutPercentage(vo.getAchHaicutPercentage());
		collateralHaircutDetailsVO.setAchMaxTerm(vo.getAchMaxTerm());
		collateralHaircutDetailsVO.setAchMinTerm(vo.getAchMinTerm());
		collateralHaircutDetailsVO.setAchRanking(vo.getAchRanking());
		collateralHaircutDetailsVO.setAchRating(vo.getAchRating());
		collateralHaircutDetailsVO.setAchIssuerRating(vo.getAchIssuerRating());
		collateralHaircutDetailsVO.setCollateralParty(vo.getCollateralParty());
		collateralHaircutDetailsVO.hashCode();
		collateralHaircutDetailsVO.toString();
		collateralHaircutDetailsVO.equals(vo);
		assertEquals("TEST", collateralHaircutDetailsVO.getAchType());
	}
	@Test
	public void test2() {
		CollateralHaircutDetailsVO vo = new CollateralHaircutDetailsVO();
		CollateralHaircutDetailsVO vo1 = new CollateralHaircutDetailsVO();
		CollateralHaircutDetailsVO vo2 = new CollateralHaircutDetailsVO();
		CollateralHaircutDetailsVO vo3 = new CollateralHaircutDetailsVO();
		vo.setAchMinTerm("0 DAYS");vo.setAchMaxTerm("2 MONTHS");vo.setAchType("Aab");
		vo1.setAchMinTerm("0 MONTHS");vo1.setAchMaxTerm("1 MONTHS");vo1.setAchType("Aab");
		vo2.setAchMinTerm("10 DAYS");vo2.setAchMaxTerm("2 MONTHS");vo2.setAchType("Aab");
		vo3.setAchMinTerm("1 YEARS");vo3.setAchMaxTerm("2 MONTHS");vo3.setAchType("Aab");
		Set<CollateralHaircutDetailsVO> collateralHaircutSet= new LinkedHashSet<>();
		collateralHaircutSet.add(vo);collateralHaircutSet.add(vo1);collateralHaircutSet.add(vo2);collateralHaircutSet.add(vo3);
		System.out.println("Before"+collateralHaircutSet);
		sortCollateralHairCutList(collateralHaircutSet);
		
		System.out.println("After"+collateralHaircutSet);
	}
	
	private void sortCollateralHairCutList(Set<CollateralHaircutDetailsVO> collateralHaircutSet) {
		List<CollateralHaircutDetailsVO> sortedList = new ArrayList<>(collateralHaircutSet);
		Collections.sort(sortedList, new Comparator<CollateralHaircutDetailsVO>() {

			@Override
			public int compare(CollateralHaircutDetailsVO o1, CollateralHaircutDetailsVO o2) {
				int minTermO1=0;int minTermO2=0;
				int result=0;
				minTermO1=convertToDays(o1.getAchMinTerm());
				minTermO2=convertToDays(o2.getAchMinTerm());
				result= minTermO1 -minTermO2;
				if(result==0) {
					int maxTermO1=0;int maxTermO2=0;
					maxTermO1=convertToDays(o1.getAchMaxTerm());
					maxTermO2=convertToDays(o2.getAchMaxTerm());
					result= maxTermO1 -maxTermO2;
					if(result ==0) {
						result=o1.getAchType().compareTo(o2.getAchType());
					}
				}
				return result;
			}

			private int convertToDays(String str) {
				int days=0;
				if(str.contains(" DAYS")) {
					days=Integer.parseInt(str.replace(" DAYS",""));
				}if(str.contains(" MONTHS")) {
					days= 30*Integer.parseInt(str.replace(" MONTHS",""));
				}
				if(str.contains(" YEARS")) {
					days= 365*Integer.parseInt(str.replace(" YEARS",""));
				}
				return days;
			}

		});
		collateralHaircutSet.clear();
		collateralHaircutSet.addAll(sortedList);

	}
}
