
package com.citi.aqua.derivz.services.service.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.when;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.sql.DataSource;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.junit4.SpringRunner;
import com.citi.aqua.derivz.commons.constants.DerivzCommonConstants;
import com.citi.aqua.derivz.commons.exceptions.DerivzApplicationException;
import com.citi.aqua.derivz.data.repository.BookmarkRepository;
import com.citi.aqua.derivz.model.Bookmark;
import com.citi.aqua.derivz.model.VoyagerNavigationLink;
import com.citi.aqua.derivz.services.service.CacheService;
import com.citi.aqua.derivz.services.service.UserSearchCriteriaService;



@RunWith(SpringRunner.class)
@SuppressWarnings("unchecked")
public class BookmarkServiceImplTest {

	private static final Bookmark bookmarkObj = new Bookmark();

	private static final String USER_ID = "sa98695";
	private static final String SHARED_USER_ID = "mk35063";

	private static final Long KEY = 1L;

	@InjectMocks
	BookmarkServiceImpl bookmarkServiceImpl;

	@Mock
	private JdbcTemplate jdbcTemplate;

    @Mock
    BookmarkRepository bookmarkRepository;

    @Mock
    DataSource dataSource;

    @Mock
    CacheService cachingService;

    @Mock
    VoyagerNavigationLink voyagerConfig;
    @Mock Connection conn ;
    @Mock
    private UserSearchCriteriaService userSearchCriteriaService;

	@Before
	public void setup() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testDeleteSearchList()  {
        when(bookmarkRepository.deleteByUserIdAndListTypeAndListName(USER_ID, "test", null)).thenReturn(true);

		assertEquals(true, bookmarkServiceImpl.deleteSearchList(USER_ID, "test", null));
	}
	@Test(expected=DerivzApplicationException.class)
	public void testDeleteSearchListWithException()  {
        when(bookmarkRepository.deleteByUserIdAndListTypeAndListName(USER_ID, "test", null)).thenThrow(IllegalArgumentException.class);
		assertEquals(true, bookmarkServiceImpl.deleteSearchList(USER_ID, "test", null));
	}
	@Test
	public void testFindUserSettingsColumns()  {
        when(bookmarkRepository.findByUserIdAndType(USER_ID, DerivzCommonConstants.SETTINGS_TYPE_LIST)).thenReturn(bookmarkObj);
		assertNotNull(bookmarkServiceImpl.findUserSettingsColumns(USER_ID));
	}
	@Test(expected=DerivzApplicationException.class)
	public void testFindUserSettingsColumnsExp() {
        when(bookmarkRepository.findByUserIdAndType(USER_ID, DerivzCommonConstants.SETTINGS_TYPE_LIST)).thenThrow(IllegalArgumentException.class);
		assertNotNull(bookmarkServiceImpl.findUserSettingsColumns(USER_ID));
	}
	@Test
	public void testGetBookmarkForGivenId() {
        when(bookmarkRepository.findByUserIdAndKey(USER_ID,KEY)).thenReturn(bookmarkObj);
        assertEquals(0,bookmarkServiceImpl.getBookmarkForGivenId(USER_ID,KEY).size());
	}
	@Test(expected=DerivzApplicationException.class)
	public void testGetBookmarkForGivenIdExp()  {
		bookmarkObj.setCriteria("");
        when(bookmarkRepository.findByUserIdAndKey(USER_ID,KEY)).thenReturn(bookmarkObj);
        assertEquals(0,bookmarkServiceImpl.getBookmarkForGivenId(USER_ID,KEY).size());
	}
	@Test
	public void testShareBookmark() {
        when(bookmarkRepository.findByUserIdAndKey(USER_ID,KEY)).thenReturn(bookmarkObj);
        when(bookmarkRepository.save(Matchers.any(Bookmark.class))).thenReturn(bookmarkObj);
        assertEquals(true,bookmarkServiceImpl.shareUserBookmark(USER_ID, KEY,SHARED_USER_ID));
	}
	@Test(expected=DerivzApplicationException.class)
	public void testShareBookmarkExp() {
        when(bookmarkRepository.findByKey(KEY)).thenReturn(bookmarkObj);
        when(bookmarkRepository.save(Matchers.any(Bookmark.class))).thenThrow(IllegalArgumentException.class);
        assertEquals(true,bookmarkServiceImpl.shareUserBookmark(USER_ID,KEY,SHARED_USER_ID));
	}
	@Test
	public void testSaveUserSearch()  {
        when(bookmarkRepository.save(Matchers.any(Bookmark.class))).thenReturn(bookmarkObj);
        assertEquals(true,bookmarkServiceImpl.saveUserSearch(USER_ID,null, new ArrayList<>(), null));
	}
	
	@Test(expected=DerivzApplicationException.class)
	public void testSaveUserSearchExp() {
        when(bookmarkRepository.save(Matchers.any(Bookmark.class))).thenThrow(IllegalArgumentException.class);
        assertEquals(true,bookmarkServiceImpl.saveUserSearch(USER_ID,null, new ArrayList<>(), null));
	}
	@Test
	public void testSaveUserSettingColumns()  {
        when(bookmarkRepository.save(Matchers.any(Bookmark.class))).thenReturn(bookmarkObj);
        assertEquals(true,bookmarkServiceImpl.saveUserSettingColumns(USER_ID,null,null));
	}
	@Test(expected=DerivzApplicationException.class)
	public void testSaveUserSettingColumnsExp()  {
        when(bookmarkRepository.save(Matchers.any(Bookmark.class))).thenThrow(IllegalArgumentException.class);
        assertEquals(true,bookmarkServiceImpl.saveUserSettingColumns(USER_ID,null,null));
	}
	@Test
	public void testUpdateUserSettingColumns()  {
        when(bookmarkRepository.updateUserSettingsList(Matchers.any(), Matchers.any(), Matchers.any())).thenReturn(1);
        assertEquals(true,bookmarkServiceImpl.updateSettingsColumnList(KEY, null));
	}
	@Test(expected=DerivzApplicationException.class)
	public void testUpdateUserSettingColumnsExp() {
        when(bookmarkRepository.updateUserSettingsList(Matchers.any(), Matchers.any(), Matchers.any())).thenThrow(IllegalArgumentException.class);
        assertEquals(true,bookmarkServiceImpl.updateSettingsColumnList(KEY, null));
	}
	@Test(expected=DerivzApplicationException.class)
	public void testSaveUserBookmark() throws SQLException {
		List<String[]> str= new ArrayList<>();
        when(userSearchCriteriaService.formatCriteriaObjectForRows(null)).thenReturn(str);
        when( jdbcTemplate.getDataSource()).thenReturn(dataSource);
        when( jdbcTemplate.getDataSource().getConnection()).thenReturn(conn);
        Bookmark newBookmark =new Bookmark();
        newBookmark.setKey(KEY);
        when(bookmarkRepository.save(Matchers.any(Bookmark.class))).thenReturn(newBookmark);
        bookmarkServiceImpl.saveUserBookmark(USER_ID, null, new ArrayList<>(),null,null);
	}
	
	@SuppressWarnings("rawtypes")
	@Test
	public void testGetSearchCriteriaList() {
		List list= new ArrayList<>();
		list.add(bookmarkObj);
        when(bookmarkRepository.findByUserIdAndListCatagoryOrderByupdatedTimeDesc(USER_ID,null)).thenReturn(list);
        assertEquals(1,bookmarkServiceImpl.getSearchCriteriaList(USER_ID,null).size());
	}
	@SuppressWarnings("rawtypes")
	@Test(expected=DerivzApplicationException.class)
	public void testGetSearchCriteriaListExp() {
		List list= new ArrayList<>();
		list.add(bookmarkObj);
        when(bookmarkRepository.findByUserIdAndListCatagoryOrderByupdatedTimeDesc(USER_ID,null)).thenThrow(IllegalArgumentException.class);
        assertEquals(1,bookmarkServiceImpl.getSearchCriteriaList(USER_ID,null).size());
	}
	@Test
	public void testUpdateUserBookmark() throws SQLException {
		List<String[]> str= new ArrayList<>();
        when(userSearchCriteriaService.formatCriteriaObjectForRows(null)).thenReturn(str);
        when( jdbcTemplate.getDataSource()).thenReturn(dataSource);
        when( jdbcTemplate.getDataSource().getConnection()).thenReturn(conn);
        
        when(bookmarkRepository.updateUserSettingsList(Matchers.any(),Matchers.any(),Matchers.any())).thenReturn(1);
        assertNull(bookmarkServiceImpl.updateUserBookmark(KEY, null, USER_ID,  new ArrayList<>(),null));
	}
	@Test(expected=Exception.class)
	public void testGetDatasetId() {
		assertEquals(true,bookmarkServiceImpl.getDatasetId("", "TEST"));
		
	}
}
