package com.citi.aqua.derivz.vo;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

@SuppressWarnings({"unchecked", "static-access", "rawtypes"})
public class SearchFieldVOTest {
	SearchFieldVO searchFieldVO;

	@Before
	public void setUp() throws Exception {
		searchFieldVO= new SearchFieldVO();
	}

	
	@Test
	public void testGetFieldName() {
		SearchFieldVO vo = new SearchFieldVO("TEST", null, null, null, null, null, null, null, 0, null, null, null, null,null).builder().build();
		vo.setFieldName("TEST");
		searchFieldVO.setComponentType(vo.getComponentType());
		searchFieldVO.setDataType(vo.getDataType());
		searchFieldVO.setDefaultSelected(vo.getDefaultSelected());
		searchFieldVO.setDistinctRequired(vo.getDistinctRequired());
		searchFieldVO.setFieldName(vo.getFieldName());
		searchFieldVO.setKey(vo.getKey());
		searchFieldVO.setLogicalGroupName(vo.getLogicalGroupName());
		searchFieldVO.setName(vo.getName());
		searchFieldVO.setNodeDisplayName(vo.getNodeDisplayName());
		searchFieldVO.setNodeName(vo.getNodeName());
		searchFieldVO.setSchemaName(vo.getSchemaName());
		searchFieldVO.setValue(vo.getValue());
		searchFieldVO.setWhoHasFlag(vo.getWhoHasFlag());
		searchFieldVO.toString();
		
		assertEquals("TEST",searchFieldVO.getFieldName());
	}

}
