
package com.citi.aqua.derivz.services.service.impl;

import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import javax.servlet.ServletOutputStream;
import javax.servlet.WriteListener;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit4.SpringRunner;

import com.citi.aqua.derivz.services.factory.SearchResultSource;
import com.citi.aqua.derivz.services.factory.SearchResultSourceFactory;
import com.citi.aqua.derivz.vo.SearchFieldVO;

@RunWith(SpringRunner.class)
public class ExportServiceImplTest {
	
	
	@InjectMocks
	ExportServiceImpl exportServiceImpl;

	@Mock
	SearchResultSourceFactory searchResultSourceFactory;
	@Mock
	HttpServletResponse response;

	@Before
	public void setup() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testExportToExcel() throws IOException {
		SearchResultSource searchResultSource = new SearchResultSource() {
			
			@Override
			public List<String> getHeaders() {
				// TODO Auto-generated method stub
				return Arrays.asList("Header1");
			}
			
			@SuppressWarnings("rawtypes")
			@Override
			public int addDataRow(HSSFWorkbook workbook, String source, List<SearchFieldVO> searchCriteria,
					List<Long> agreementKeyList, int rowNum) {
				// TODO Auto-generated method stub
				return 0;
			}
		} ;
		when(searchResultSourceFactory.getSearchResultSource("Source")).thenReturn(searchResultSource);
		when(response.getOutputStream()).thenReturn(new ServletOutputStream() {
			
			@Override
			public void write(int b) throws IOException {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void setWriteListener(WriteListener listener) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public boolean isReady() {
				// TODO Auto-generated method stub
				return false;
			}
		});
		exportServiceImpl.exportToExcel(response, "Source", Arrays.asList(new SearchFieldVO<>()), Arrays.asList(new Long(10)));
		//assertEquals(2, exportServiceImpl.findDistinctReferenceData(1l).size());

	}
	
}
