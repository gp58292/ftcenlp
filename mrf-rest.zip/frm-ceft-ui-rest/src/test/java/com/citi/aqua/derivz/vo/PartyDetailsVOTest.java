package com.citi.aqua.derivz.vo;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class PartyDetailsVOTest {
	private static final String TEST = "TEST";
	PartyDetailsVO partyDetailsVO;

	@Before
	public void setUp() throws Exception {
		partyDetailsVO= new PartyDetailsVO();
	}

	@Test
	public void testGetPartyLocation() {
		PartyDetailsVO vo= new PartyDetailsVO();
		vo.setPartyLocation(TEST);
		vo.setFundingIndex(0);
		vo.setPartyBranchName(TEST);
		vo.setPartyGfcId(TEST);
		partyDetailsVO.setPartyLocation(vo.getPartyLocation());
		partyDetailsVO.setFundingIndex(vo.getFundingIndex());
		partyDetailsVO.setPartyBranchName(vo.getPartyBranchName());
		partyDetailsVO.setPartyGfcId(vo.getPartyGfcId());
		partyDetailsVO.hashCode();
		partyDetailsVO.toString();
		partyDetailsVO.equals(vo);
		assertEquals(TEST,partyDetailsVO.getPartyLocation());
	}

}
