import { Injectable } from "@angular/core";

@Injectable()
export class AppSessionStorage {
	constructor() {
		console.debug("AppSessionStorage::constructor");
	}

	/*  removeStorage: removes a key from sessionStorage and its sibling expiracy key
	params:
	key <string>     : sessionStorage key to remove
	returns:
	<boolean> : telling if operation succeeded
	*/
	public removeStorageKey(key) {
		console.debug("AppSessionStorage::removeStorageKey ", key);
		try {
			sessionStorage.removeItem(key);
			sessionStorage.removeItem(key + "_expiresIn");
		} catch (e) {
			console.debug(
				"removeStorage: Error removing key [" +
					key +
					"] from sessionStorage: " +
					JSON.stringify(e)
			);
			return false;
		}
		return true;
	}

	/*  getStorage: retrieves a key from sessionStorage previously set with setStorage().
 	params:
 	key <string> : sessionStorage key
 	returns:
 	<string> : value of sessionStorage key
 	null : in case of expired key or failure
	*/
	public getStorageKey(key) {
		// console.debug("AppSessionStorage::getStorageKey ", key);
		const now = Date.now(); // epoch time, lets deal only with integer

		// set expiration for storage
		const expiresInStr = sessionStorage.getItem(key + "_expiresIn");
		let expiresIn = 0;
		if (!(expiresInStr === undefined || expiresInStr === null)) {
			expiresIn = +expiresInStr;
		}

		// console.debug("AppSessionStorage::getStorageKey  NOW: ", today.toUTCString() + ' Expires: ' + expiresInStr);
		if (expiresIn > 0 && expiresIn < now) {
			// Expired
			console.debug(
				"AppSessionStorage::getStorageKey key expired, cleaning up"
			);
			this.removeStorageKey(key);
			return null;
		} else {
			try {
				const value = sessionStorage.getItem(key);
				// console.debug("AppSessionStorage::getStorageKey key value:", value);
				return value;
			} catch (e) {
				console.debug(
					"getStorage: Error reading key [" +
						key +
						"] from sessionStorage: " +
						JSON.stringify(e)
				);
				return null;
			}
		}
	}

	/*  setStorage: writes a key into sessionStorage setting a expire time
	params:
	key <string>     : sessionStorage key
	value <string>   : sessionStorage value
	expires <number> : number of seconds from now to expire the key
	returns:
	<boolean> : telling if operation succeeded
	*/
	public setStorageKey(key, value, expires?) {
		console.debug("AppSessionStorage::setStorageKey ", key, expires);
		if (expires === undefined || expires === null) {
			expires = 24 * 60 * 60 * 1000; // default: seconds for 1 day
		} else {
			expires = Math.abs(expires); // make sure it's positive
		}

		const now = Date.now(); // millisecs since epoch time, lets deal only with integer
		const schedule = "" + (now + expires * 100000);
		try {
			sessionStorage.setItem(key, value);
			sessionStorage.setItem(key + "_expiresIn", schedule);
		} catch (e) {
			console.debug(
				"setStorage: Error setting key [" +
					key +
					"] in sessionStorage: " +
					JSON.stringify(e)
			);
			return false;
		}
		return true;
	}

	/**
	 *
	 */
	public cleanUp() {
		console.debug("AppSessionStorage::cleanUp");
		sessionStorage.clear();
	}
}
