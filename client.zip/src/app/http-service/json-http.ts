import { Injectable } from "@angular/core";
import { Observable } from "rxjs";

import { HttpClient } from "@angular/common/http";
import { Jsonp, RequestOptionsArgs, Response } from "@angular/http";
import { AppHttpResponse } from "@aqua/models";
import { catchError } from "rxjs/operators";

@Injectable()
export class JsonHttp {
	constructor(private http: HttpClient, private jsonpvar: Jsonp) {
		console.debug("JsonHttp::constructor::");
	}

	public get(
		url: string,
		options?: RequestOptionsArgs
	): Observable<AppHttpResponse<any>> {
		// console.debug("JsonHttp::get:: ", url, options);
		return this.http.get<AppHttpResponse<any>>(url);
	}

	public post(url: string, paramObj?: any): Observable<AppHttpResponse<any>> {
		// console.debug("JsonHttp::post:: ", url, paramObj);
		// if(paramObj) {
		//    const param:HttpParams=new HttpParams();
		//    Object.keys(paramObj).forEach((key:string)=>param.set(key,paramObj[key]));
		//    console.debug("JsonHttp::post:: ", url, param.toString(),Object.keys(paramObj));
		//   return this.http.post<Response>( url,paramObj);

		// } else
		return this.http.post<AppHttpResponse<any>>(url, paramObj);
	}

	public postDefault(url: string, body: any, options?: any): Observable<any> {
		console.debug("JsonHttp::post ", url, body, options);
		const request: Observable<any> = this.http.post(url, body, options).pipe(
			catchError(err => {
				return this.handleError(err);
			})
		);
		return request;
	}

	public put(url: string, paramObj?: any): Observable<AppHttpResponse<any>> {
		// console.debug("JsonHttp::put:: ", url, paramObj);
		return this.http.put<AppHttpResponse<any>>(url, paramObj);
	}

	public delete(url: string, paramObj?: any): Observable<AppHttpResponse<any>> {
		// console.debug("JsonHttp::delete:: ", url, paramObj);
		return this.http.delete<AppHttpResponse<any>>(url);
	}

	public patch(
		url: string,
		paramObj?: object
	): Observable<AppHttpResponse<any>> {
		// console.debug("JsonHttp::patch:: ", url, paramObj);
		return this.http.patch<AppHttpResponse<any>>(url, paramObj);
	}

	public head(
		url: string,
		paramObj?: object
	): Observable<AppHttpResponse<any>> {
		// 	console.debug("JsonHttp::head:: ", url, paramObj);
		return this.http.head<AppHttpResponse<any>>(url);
	}

	public jsonp(
		url: string,
		callback: string = "JSONP_CALLBACK"
	): Observable<any> {
		return this.jsonpvar.get(url + "&callback=" + callback);
		// this.http.jsonp(url+"&format=json",callback);
	}

	private handleError(error: Response | any): Observable<any> {
		let errMsg: string;
		if (error instanceof Response) {
			console.error("Response Error :: " + error);
			return Observable.throw(error);
		} else {
			errMsg = error.message ? error.message : error.toString();
			console.error(errMsg);
		}

		return null;
	}
}
