import {
	HttpEvent,
	HttpHandler,
	HttpInterceptor,
	HttpRequest
} from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";

@Injectable()
export class HttpDataRquestInterceptor implements HttpInterceptor {
	public intercept(
		req: HttpRequest<any>,
		next: HttpHandler
	): Observable<HttpEvent<any>> {
		console.debug("HttpDataRquestInterceptor::intercept:: ", req.url);
		const modified = req.clone({ setHeaders: this.getHeaders() });
		// passing control to the handler in the chain
		return next.handle(modified);
	}

	private getHeaders(): any {
		const header = {
			"Cache-Control": "no-cache, no-store, max-age=0, must-revalidate",
			Expires: "0",
			Pragma: "no-cache",
			"Content-Type": "application/json"
		};
		const authToken: string = localStorage.getItem("jwt");
		if (authToken) {
			header.Pragma = "no-cache";
		}
		return header;
	}
}
