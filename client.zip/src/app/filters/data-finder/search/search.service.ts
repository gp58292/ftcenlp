import { Injectable, OnDestroy } from "@angular/core";
import { FormControl, FormGroup } from "@angular/forms";
import {
	Agreement,
	DerivzRestResponse,
	RatingRanking,
	SearchResultColumns,
	UserDataset
} from "@aqua/filters/models";
import { AgreementOptimalRank } from "@aqua/filters/models/agreement-optimal-rank";
import { BatchReport } from "@aqua/filters/models/batch-report";
import { SearchField } from "@aqua/filters/models/search-field";
import { FilterCancelService, FiltersUrlConfig } from "@aqua/filters/services";
import { JsonHttp } from "@aqua/http-service";
import { AppHttpResponse } from "@aqua/models";
import { AuthService, VizNotificationService } from "@aqua/services";
import { BehaviorSubject, Observable, Subject } from "rxjs";
import {
	catchError,
	debounceTime,
	distinctUntilChanged,
	finalize,
	map,
	publishReplay,
	refCount,
	share,
	takeUntil
} from "rxjs/operators";

@Injectable()
export class SearchService implements OnDestroy {
	public batchReportDate: string;
	public refDataCallCount: number = 0;
	public userId: string;
	public resultList: Agreement[];
	public searchResultChange: BehaviorSubject<Agreement[]> = new BehaviorSubject(
		null
	);

	public searchStarted: BehaviorSubject<boolean> = new BehaviorSubject(false);
	public onSearchTabAlert: BehaviorSubject<boolean> = new BehaviorSubject(
		false
	);
	public filterFlagChanged: BehaviorSubject<boolean> = new BehaviorSubject(
		false
	);
	private alive: Subject<void> = new Subject<void>();

	constructor(
		private http: JsonHttp,
		private urlConfig: FiltersUrlConfig,
		private authService: AuthService,
		private vizNotification: VizNotificationService,
		private filterCancelService: FilterCancelService
	) {
		this.userId = this.authService.getUserSoeId();
		console.debug(
			"SearchService::constructor:: Loading Search Service .................................."
		);
	}

	public getReferenceData(field: SearchField): Observable<any> {
		console.debug("SearchService::getReferenceData " + this.refDataCallCount++);
		const requestUrl: string = this.urlConfig.EP_GET_REFERENCE_DATA + field.key;
		console.debug("SearchService::getReferenceData" + requestUrl);
		return this.http.get(requestUrl).pipe(
			map(res => res.responseData),
			debounceTime(400),
			publishReplay(1),
			refCount(),
			share()
		);
	}

	public getTypeAheadData(
		field: SearchField,
		valueLike: string
	): Observable<any> {
		const requestUrl: string =
			this.urlConfig.EP_GET_TYPEAHEAD_DATA + field.key + "/" + valueLike;
		console.debug("SearchService::getTypeAheadData" + requestUrl);
		if (valueLike) {
			return this.http.get(requestUrl).pipe(
				map(res => res.responseData),
				debounceTime(400),
				publishReplay(1),
				refCount()
			);
		}
	}

	public getTypeAheadDataByPastedValue(
		field: SearchField,
		valueLike: string[]
	): Observable<any> {
		const requestUrl: string =
			this.urlConfig.EP_GET_TYPEAHEAD_DATA_BY_PASTED_VALUES + field.key;
		console.debug(
			"SearchService::getTypeAheadDataByPastedValue::" + requestUrl
		);
		if (valueLike && valueLike.length > 0) {
			// this.searchStarted.next(true);
			return this.http.post(requestUrl, valueLike).pipe(
				map(res => res.responseData),
				debounceTime(400),
				publishReplay(1),
				refCount()
			);
			// .finally(() => this.searchStarted.next(false));
		}
	}

	public searchCriteria(criteria): Observable<DerivzRestResponse<any>> {
		console.debug("SearchService::searchCriteria");
		this.searchStarted.next(true);
		return this.http
			.post(this.urlConfig.EP_SEARCH_AGREEMENT, {
				userId: this.userId,
				criteria
			})
			.pipe(
				takeUntil(this.filterCancelService.getSubject()),
				distinctUntilChanged(),
				finalize(() => this.searchStarted.next(false))
			);
	}
	public lookupCollateralType(criteria): Observable<DerivzRestResponse<any>> {
		console.debug("SearchService::searchCriteria");
		this.searchStarted.next(true);
		return this.http
			.post(this.urlConfig.EP_SEARCH_COLLATERAL_TYPE, {
				userId: this.userId,
				criteria
			})
			.pipe(
				takeUntil(this.filterCancelService.getSubject()),
				distinctUntilChanged(),
				finalize(() => this.searchStarted.next(false))
			);
	}

	public exportSearchResult(
		source: string,
		criteria: SearchField[],
		agreementKeys: number[]
	): Observable<any> {
		console.debug("SearchService::exportSearchResult");
		const requestOptionsArgs = { responseType: "blob" };
		return this.http
			.postDefault(
				this.urlConfig.EP_RESULT_EXPORT,
				{ source, criteria, agreementKeys },
				requestOptionsArgs
			)
			.pipe(takeUntil(this.filterCancelService.getSubject()));
	}

	public getCollateralTypeLookupColums(): Observable<DerivzRestResponse<any>> {
		const requestUrl: string = this.urlConfig.EP_SEARCH_COLLATERAL_TYPE;
		console.debug("SearchService::getCollateralTypeLookupColums" + requestUrl);
		return this.http.get(requestUrl).pipe(
			debounceTime(400),
			publishReplay(1),
			refCount(),
			share()
		);
	}

	public getResultColumns(): Observable<DerivzRestResponse<any>> {
		console.debug("SearchService::getResultColumns");
		this.searchStarted.next(true);
		return this.http.get(this.urlConfig.EP_RESULT_COLUMNS).pipe(
			takeUntil(this.filterCancelService.getSubject()),
			distinctUntilChanged(),
			finalize(() => this.searchStarted.next(false))
		);
	}
	// --- helper methods

	public find(critieria: SearchField[], smcFields: SearchResultColumns[]) {
		console.debug("SearchComponent::serachCritieria");
		this.onSearchTabAlert.next(true);
		this.getTabsData("Listed", [], [], false, critieria, smcFields)
			.pipe(takeUntil(this.alive))
			.subscribe(
				(response: DerivzRestResponse<Agreement[]>) => {
					console.debug("SearchResultComponent::getData::", response);
					if (response && response.responseStatus === 200) {
						this.vizNotification.showMessage("Search fetched successfully");
						this.resultList = response.responseData;
						this.searchResultChange.next(this.resultList);
					} else {
						if (response && response.restError) {
							this.vizNotification.showError(response.restError.errorMessage);
						} else {
							this.vizNotification.showInternalSystemError();
						}

						this.searchResultChange.next([]);
					}
				},
				error => {
					this.vizNotification.showInternalSystemError();
					console.debug("SearchResultComponent::getData::error::", error);
				}
			);
	}

	public clearSearchResult(): void {
		this.searchResultChange.next(null);
	}

	public searchResultChangeNotification(): Observable<any[]> {
		return this.searchResultChange.asObservable();
	}

	public searchingStatus(): Observable<boolean> {
		return this.searchStarted.asObservable();
	}
	public onSearchTabNotification(): Observable<boolean> {
		return this.onSearchTabAlert.asObservable();
	}
	// ============= used in integration ==========
	// Gets the datasetId given the soeid and datasetTypeName
	public getDatasetId(
		soeid: string,
		datasetTypeName: string
	): Observable<AppHttpResponse<any>> {
		const requestUrl: string = this.urlConfig.EP_FINDER_DATASETID;
		console.debug("BookmarkService:: getDatasetId" + requestUrl);
		return this.http.post(requestUrl, {
			// tslint:disable-next-line:object-literal-shorthand
			soeid: soeid,
			// tslint:disable-next-line:object-literal-shorthand
			datasetTypeName: datasetTypeName
		});
	}

	public getUserDataset(): Observable<DerivzRestResponse<UserDataset[]>> {
		const requestUrl: string = this.urlConfig.EP_GET_USER_DATASET;
		console.debug("BookmarkService:: getDatasetId" + requestUrl);
		return this.http.get(requestUrl);
	}

	public toFormGroup(fields: SearchField[], form: FormGroup) {
		console.debug("SearchService::toFormGroup:::...");
		if (!form) {
			const group: any = {};
			console.debug(
				"SearchService::toFormGroup::: Adding New Form Controls again."
			);
			fields.forEach(field => {
				group[
					field.fieldName + "_" + field.key + "_" + field.whoHasFlag
				] = new FormControl(field.value);
				console.debug(
					"#### SearchService::toFormGroup : other ::" +
						field.fieldName +
						"-" +
						field.key
				);
			});
			return new FormGroup(group);
		} else {
			// This include exclude will be removed, when include exclude component updated
			Object.keys(form.controls).forEach(key => {
				const item = fields.find((f: SearchField) => {
					return key === f.fieldName + "_" + f.key + "_" + f.whoHasFlag;
				});

				if (!item) {
					form.removeControl(key);
					console.debug(
						"SearchService::toFormGroup::Not found removing control named [" +
							key +
							"] = ",
						item
					);
				}
			});
			fields.forEach(field => {
				this.addOrReplaceControl(
					form,
					field.fieldName + "_" + field.key + "_" + field.whoHasFlag,
					field.value
				);
			});

			return form;
		}
	}

	public ngOnDestroy() {
		this.alive.next();
		this.alive.complete();
		this.alive.unsubscribe();
	}

	// -------------------------------------------------------------------------------------
	public getTabsData(
		tabName: string,
		agreementKeys: number[],
		agreementOptimalRanks: AgreementOptimalRank[],
		isFilterd: boolean,
		criteria: SearchField[],
		smsColumns: SearchResultColumns[]
	): Observable<DerivzRestResponse<Agreement[]>> {
		console.debug("SearchService::getTabsData::");
		this.searchStarted.next(true);
		return this.http
			.postDefault(this.urlConfig.EP_SEARCH_TABS, {
				tabName,
				agreementKeys,
				agreementOptimalRanks,
				isFilterd,
				criteria,
				smsColumns
			})
			.pipe(
				takeUntil(this.filterCancelService.getSubject()),
				distinctUntilChanged(),
				catchError(err => {
					console.debug("SearchResultComponent::getTabsData::error: ", err);
					return err;
				}),
				finalize(() => this.searchStarted.next(false))
			);
		// TODO ^ Finally block will be replaced once we create subscribe functionality.
	}

	public filterFlagChangeNotification(): Observable<boolean> {
		return this.filterFlagChanged.asObservable();
	}

	public onFilterFlagChange(flag: boolean) {
		console.debug("SearchService::onFilterFlagChange::");
		this.filterFlagChanged.next(flag);
	}

	public getAgreementDetails(
		agreementKeys: number[]
	): Observable<DerivzRestResponse<Agreement[]>> {
		console.debug("SearchService::getAgreementDetails");
		return this.http
			.get(this.urlConfig.EP_GET_AGREEMENT_DETAILS + "/" + agreementKeys)
			.pipe(
				takeUntil(this.alive),
				distinctUntilChanged(),
				finalize(() => this.searchStarted.next(false))
			);
	}

	public getBatchReport(
		batchDate: number
	): Observable<DerivzRestResponse<BatchReport[]>> {
		console.debug("SearchService::getBatchReport");
		return this.http
			.get(this.urlConfig.EP_GET_BATCH_REPORT + "/" + batchDate)
			.pipe(
				takeUntil(this.alive),
				distinctUntilChanged(),
				finalize(() => this.searchStarted.next(false))
			);
	}

	public getAgreementCSADetails(
		ageementId: number,
		csaType: string
	): Observable<DerivzRestResponse<Agreement[]>> {
		console.debug("SearchService::getAgreementDetails");
		const url =
			this.urlConfig.EP_GET_CSA_TYPE_DETAILS + "/" + ageementId + "/" + csaType;
		return this.http.get(url).pipe(
			takeUntil(this.alive),
			debounceTime(300),
			distinctUntilChanged(),
			finalize(() => this.searchStarted.next(false))
		);
	}

	public getRatingRankings(): Observable<DerivzRestResponse<RatingRanking[]>> {
		console.debug("SearchService::getResultColumns");
		return this.http.get(this.urlConfig.EP_GET_REFERENCE_RATING_RANKINGS);
	}

	private addOrReplaceControl(form: FormGroup, name: string, value: any) {
		if (!!form.get(name)) {
			console.debug(
				"SearchService::addOrReplaceControl::: Setting existing control::",
				name,
				form.get(name)
			);
			// form.setControl(name, new FormControl(value))
			form.removeControl(name);
			// form.get(name).setValue(value);
			form.addControl(name, new FormControl(value));
		} else {
			console.debug(
				"SearchService::addOrReplaceControl::: Adding existing control::",
				name,
				form.get(name)
			);
			form.addControl(name, new FormControl(value));
		}
	}
}
