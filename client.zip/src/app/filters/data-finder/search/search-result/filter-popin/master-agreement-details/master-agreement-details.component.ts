import { AfterViewInit, Component, Input, OnInit } from "@angular/core";
import { MatTableDataSource } from "@angular/material";

@Component({
	selector: "ceft-master-agreement-details",
	templateUrl: "./master-agreement-details.component.html",
	styleUrls: ["./master-agreement-details.component.scss"]
})
export class MasterAgreementDetailsComponent implements OnInit, AfterViewInit {
	// @Input() public agreementDetailsList: any;
	@Input()
	public set agreementDetails(agreementDetails: any) {
		this._innerAgreementDetails = agreementDetails;
		console.debug(
			"MasterAgreementDetailsComponent::agreementDetails",
			this._innerAgreementDetails
		);

		this.coveredProductsDataSource = new MatTableDataSource<any>(
			agreementDetails ? agreementDetails.coveredProducts : []
		);

		// this.coveredProductsDataSource.paginator = this.coveredProductsPaginator;
		console.debug(
			"MasterAgreementDetailsComponent::agreementDetails:coveredProductsDataSource",
			this.coveredProductsDataSource
		);
	}

	public get agreementDetails() {
		return this._innerAgreementDetails;
	}

	public coveredProductsDataSource: MatTableDataSource<any>;

	public coveredProductList = [
		"includeExclude",
		"instrumentCode",
		"parentInstrCode",
		"covProdType",
		"instrumentName"
	];
	private _innerAgreementDetails: any;

	public getData(data: string): string {
		return data ? data : "N/A";
	}

	public ngAfterViewInit() {
		console.debug("MasterAgreementDetailsComponent::ngAfterViewInit", this);
	}

	public ngOnInit() {
		console.debug("MasterAgreementDetailsComponent::ngOnInit", this);
	}
}
