import {
	AfterViewInit,
	Component,
	EventEmitter,
	Input,
	OnDestroy,
	OnInit,
	Output,
	ViewChild
} from "@angular/core";
import { MatPaginator, MatTableDataSource } from "@angular/material";
import { SearchService } from "@aqua/filters/data-finder/search/search.service";
import { DerivzRestResponse } from "@aqua/filters/models";
import { VizNotificationService } from "@aqua/services";
import { Subject } from "rxjs";
import { catchError, finalize, takeUntil } from "rxjs/operators";
import { CSADetails } from "./../csa-details-model";

@Component({
	selector: "ceft-csa-agreement-details",
	templateUrl: "./csa-agreement-details.component.html",
	styleUrls: ["./csa-agreement-details.component.scss"]
})
export class CsaAgreementDetailsComponent
	implements OnInit, OnDestroy, AfterViewInit {
	@Input()
	public set csaDetails(_csaDetails: CSADetails) {
		this._csaDetails = _csaDetails;
		console.debug("CsaAgreementDetailsComponent::csaDetails", this._csaDetails);

		if (
			this._csaDetails &&
			this._csaDetails.agreementId &&
			this._csaDetails.csaDetailsName &&
			!this._isDataLoaded
		) {
			this.getAgreementCSADetails(this._csaDetails.agreementId, this._csaDetails.csaDetailsName);
		} else if (this._csaDetails && !this._csaDetails.agreementId && this._csaDetails.csaDetailsName) {
			// this.vizNotification.showWarning(
			// 	"Unfortunatly, We have not received any agreement id or csa name, Please contact support team!"
			// );
			console.warn(
				"CsaAgreementDetailsComponent::csaDetails::Unfortunatly, We have not received any agreement id or csa name, Please contact support team"
			);
		}
	}
	public agreementDetailsCSAList: any;
	@Output() public notify: EventEmitter<string> = new EventEmitter<string>();

	public thresholdList = ["type", "basis", "currency", "amount"];
	public scheduledThresholdList = ["type", "basis", "currency", "amount", "startDate", "endDate"];

	public creditThresholdList = ["type", "agency", "rating", "amount"];
	public publicRatingList = ["ratingDate", "agency", "rating"];
	public collatralResuseList = [];
	public coveredProductList = [
		"includeExclude",
		"instrumentCode",
		"parentInstrCode",
		"covProdType",
		"instrumentName"
	];

	public acceptableCollatareCashList = [
		"accCurrency",
		"accInterestMatrix",
		"accInterestSpread",
		"accCompounding",
		"accPaymentFrequency",
		"accResetFrequency",
		"accRanking"
	];

	public acceptableCollatarelHaircutList = [
		"achType",
		"achMinTerm",
		"achMaxTerm",
		"achHaicutPercentage",
		"achRating",
		"achIssuerRating",
		"achCollateralApplied",
		"collateralParty",
		"achRanking"
	];

	@ViewChild("hairCutPaginator") public hairCutPaginator: MatPaginator;
	public hairCutdataSource: MatTableDataSource<any>;

	@ViewChild("collateralPaginator") public collateralPaginator: MatPaginator;
	public collateralDataSource: MatTableDataSource<any>;

	@ViewChild("coveredProductsPaginator") public coveredProductsPaginator: MatPaginator;
	public coveredProductsDataSource: MatTableDataSource<any>;

	@ViewChild("cpCollateralReusePaginator")
	public cpCollateralReusePaginator: MatPaginator;
	public cpCollateralReuseDataSource: MatTableDataSource<any>;

	@ViewChild("cpPublicRatingPaginator") public cpPublicRatingPaginator: MatPaginator;
	public cpPublicRatingataSource: MatTableDataSource<any>;

	@ViewChild("cpCreditThresholdPaginator")
	public cpCreditThresholdPaginator: MatPaginator;
	public cpCreditThresholdSource: MatTableDataSource<any>;

	@ViewChild("cpThresholdListPaginator") public cpThresholdListPaginator: MatPaginator;
	public cpThresholdListSource: MatTableDataSource<any>;

	@ViewChild("partyCollateralReusePaginator")
	public partyCollateralReusePaginator: MatPaginator;
	public partyCollateralSource: MatTableDataSource<any>;

	@ViewChild("partyPublicRatingPaginator")
	public partyPublicRatingPaginator: MatPaginator;
	public partyPublicRatingSource: MatTableDataSource<any>;

	@ViewChild("partyCreditThresholdPaginator")
	public partyCreditThresholdPaginator: MatPaginator;
	public partyCreditThresholdSource: MatTableDataSource<any>;

	@ViewChild("partyThresholdPaginator") public partyThresholdPaginator: MatPaginator;
	public partyThresholdSource: MatTableDataSource<any>;

	@ViewChild("partyScheduledThresholdPaginator") public partyScheduledThresholdPaginator: MatPaginator;
	public partyScheduledThresholdSource: MatTableDataSource<any>;

	@ViewChild("cpScheduledThresholdPaginator") public cpScheduledThresholdPaginator: MatPaginator;
	public cpScheduledThresholdSource: MatTableDataSource<any>;

	public _isLoadingData = false;
	private alive: Subject<void> = new Subject();

	private _csaDetails: CSADetails;
	private _isDataLoaded: boolean = false;

	constructor(
		private searchService: SearchService,
		private vizNotification: VizNotificationService
	) { }

	public ngAfterViewInit() {
		console.debug("CsaAgreementDetailsComponent::ngAfterViewInit", this);
	}

	public ngOnInit() {
		// this.csaDetails = new CSADetails(37605, "CSA_NY_BISA");
		// this.getAgreementCSADetails();
		console.debug("CsaAgreementDetailsComponent::ngOnInit", this);
	}

	// agreementId, AgreementCsa
	public getAgreementCSADetails(userAgreementId, userAgreementCsa) {
		console.debug("CsaAgreementDetailsComponent::getAgreementCSADetails::", this._csaDetails);
		if (!this._isLoadingData) {

			this._isLoadingData = true;
			this.notify.emit('true');
			this.searchService
				.getAgreementCSADetails(
					/// this._csaDetails.agreementId,
					// this._csaDetails.csaDetailsName
					userAgreementId,
					userAgreementCsa
				)
				.pipe(
					takeUntil(this.alive),
					finalize(() => {
						this._isLoadingData = false;
						this._isDataLoaded = true;
					}),
					catchError(err => {
						console.error(
							"CsaAgreementDetailsComponent::getAgreementCSADetails::",
							err
						);
						this.vizNotification.showError(
							"Failed to load data for tab [" +
							this._csaDetails.csaDetailsName +
							"]"
						);
						return err;
					})
				)
				.subscribe((response: DerivzRestResponse<any>) => {
					if (response.responseStatus === 200) {
						this.vizNotification.showMessage(
							"Agreement " +
							this._csaDetails.csaDetailsName +
							" details fetched successfully"
						);
						this.updateDataSources(response);
						console.debug("CsaAgreementDetailsComponent::getAgreementCSADetails::", this._csaDetails);
					} else {
						this.vizNotification.showError(response.restError.errorMessage);
					}
				});
		}
	}

	public ngOnDestroy() {
		console.debug("CsaAgreementDetailsComponent::ngOnDestroy");
		this.alive.next();
		this.alive.complete();
		this.alive.unsubscribe();
	}
	public getData(data: string): string {
		return data ? data : "N/A";
	}

	private updateDataSources(response): void {
		this.agreementDetailsCSAList = response.responseData;

		this.hairCutdataSource = new MatTableDataSource<Element>(
			this.agreementDetailsCSAList.collateralHaircutScheduleList
				? this.agreementDetailsCSAList.collateralHaircutScheduleList
				: []
		);
		this.hairCutdataSource.paginator = this.hairCutPaginator;
		this.collateralDataSource = new MatTableDataSource<Element>(
			this.agreementDetailsCSAList.acceptableCollateralCashList
				? this.agreementDetailsCSAList.acceptableCollateralCashList
				: []
		);
		this.collateralDataSource.paginator = this.collateralPaginator;

		this.coveredProductsDataSource = new MatTableDataSource<Element>(
			this.agreementDetailsCSAList.coveredProducts
				? this.agreementDetailsCSAList.coveredProducts
				: []
		);
		this.coveredProductsDataSource.paginator = this.coveredProductsPaginator;

		// Counter Party data sources
		this.cpCollateralReuseDataSource = new MatTableDataSource<Element>(
			this.agreementDetailsCSAList.cpCollateralReuse
				? this.agreementDetailsCSAList.cpCollateralReuse
				: []
		);
		this.cpCollateralReuseDataSource.paginator = this.cpCollateralReusePaginator;

		this.cpPublicRatingataSource = new MatTableDataSource<Element>(
			this.agreementDetailsCSAList.cpPublicRatingList
				? this.agreementDetailsCSAList.cpPublicRatingList
				: []
		);
		this.cpPublicRatingataSource.paginator = this.cpPublicRatingPaginator;

		this.cpCreditThresholdSource = new MatTableDataSource<Element>(
			this.agreementDetailsCSAList.cpCreditThresholdList
				? this.agreementDetailsCSAList.cpCreditThresholdList
				: []
		);
		this.cpCreditThresholdSource.paginator = this.cpCreditThresholdPaginator;

		this.cpThresholdListSource = new MatTableDataSource<Element>(
			this.agreementDetailsCSAList.cpThresholdList
				? this.agreementDetailsCSAList.cpThresholdList
				: []
		);
		this.cpThresholdListSource.paginator = this.cpThresholdListPaginator;

		// Party data sources
		this.partyCollateralSource = new MatTableDataSource<Element>(
			this.agreementDetailsCSAList.partyCollateralReuse
				? this.agreementDetailsCSAList.partyCollateralReuse
				: []
		);
		this.partyCollateralSource.paginator = this.partyCollateralReusePaginator;

		this.partyPublicRatingSource = new MatTableDataSource<Element>(
			this.agreementDetailsCSAList.partyPublicRatingList
				? this.agreementDetailsCSAList.partyPublicRatingList
				: []
		);
		this.partyPublicRatingSource.paginator = this.partyPublicRatingPaginator;

		this.partyCreditThresholdSource = new MatTableDataSource<Element>(
			this.agreementDetailsCSAList.partyCreditThresholdList
				? this.agreementDetailsCSAList.partyCreditThresholdList
				: []
		);
		this.partyCreditThresholdSource.paginator = this.partyCreditThresholdPaginator;

		this.partyThresholdSource = new MatTableDataSource<Element>(
			this.agreementDetailsCSAList.partyThresholdList
				? this.agreementDetailsCSAList.partyThresholdList
				: []
		);
		this.partyThresholdSource.paginator = this.partyThresholdPaginator;

		//ScheduledThresholdSource
		this.partyScheduledThresholdSource = new MatTableDataSource<Element>(
			this.agreementDetailsCSAList.partyScheduledThreshold
				? this.agreementDetailsCSAList.partyScheduledThreshold
				: []
		);
		this.partyScheduledThresholdSource.paginator = this.partyScheduledThresholdPaginator;

		//ScheduledThresholdSource
		this.cpScheduledThresholdSource = new MatTableDataSource<Element>(
			this.agreementDetailsCSAList.cpScheduledThreshold
				? this.agreementDetailsCSAList.cpScheduledThreshold
				: []
		);
		this.cpScheduledThresholdSource.paginator = this.cpScheduledThresholdPaginator;
	}
}
