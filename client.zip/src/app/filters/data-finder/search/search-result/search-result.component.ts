import {
	Component,
	EventEmitter,
	Input,
	OnDestroy,
	OnInit,
	Output,
	ViewChild
} from "@angular/core";
import {
	MatDialog,
	MatSnackBarConfig,
	MatTabChangeEvent
} from "@angular/material";
import { AquaGrid } from "@aqua/aqua-component/aqua-grid";
import { ColumnsDefinationGrid } from "@aqua/aqua-component/aqua-grid/model";
import {
	ColumnDefaultGrid,
	GridUtils
} from "@aqua/aqua-component/aqua-grid/utils";
import { DataGridUtil } from "@aqua/aqua-component/grid-view/datagrid-util";
import {
	IncludeExcludeListModel,
	IncludeExcludeModel
} from "@aqua/aqua-component/models";
import {
	FilterDisplayService,
	SearchFieldStates
} from "@aqua/filters/data-finder/search/controls/filter-display/filter-display.service";
import { AggrementPopinComponent } from "@aqua/filters/data-finder/search/search-result/filter-popin/aggrement-popin.component";
import { SearchService } from "@aqua/filters/data-finder/search/search.service";
import {
	Agreement,
	ComponentType,
	DerivzRestResponse,
	FieldNames,
	SearchResultColumns
} from "@aqua/filters/models";
import { AgreementOptimalRank } from "@aqua/filters/models/agreement-optimal-rank";
import { SearchField } from "@aqua/filters/models/search-field";
import {
	FilterCancelService,
	SearchResultColumnService
} from "@aqua/filters/services";
import { SnackBarPosition, TabsInfo } from "@aqua/models";
import { VizNotificationService } from "@aqua/services";
import { Subject } from "rxjs";
import { debounceTime, distinctUntilChanged, takeUntil } from "rxjs/operators";

@Component({
	selector: "ceft-search-result",
	templateUrl: "./search-result.component.html",
	styleUrls: ["./search-result.component.scss"]
})
export class SearchResultComponent implements OnInit, OnDestroy {
	@Input()
	set filtersExpanded(_filterExpanded: boolean) {
		this.gridHeight = _filterExpanded ? 41.1 : 77.8;
	}

	set isFilterd(isFilterdData: boolean) {
		console.debug(
			"SearchResultComponent::isFilterd::",
			isFilterdData,
			this.activeTabName,
			this.isActualPostingCTNExist
		);
		this._isFilterd = isFilterdData;
		if (
			this.activeTabName === "Current Postings" &&
			this.isActualPostingCTNExist
		) {
			this.getData(this.activeTabName);
		}
	}
	get isFilterd(): boolean {
		return this._isFilterd;
	}
	public gotListed: boolean = false;
	public resultTabSelectedIndex: number = 0;

	@Output() public selectedAquaRows: EventEmitter<any[]> = new EventEmitter<
		any[]
	>();

	@Input() public resultsExpanded: boolean = false;
	public gridHeight: number = 41.1;

	public searchCriteria: SearchField[];
	public searchingStatus: boolean = false;

	public searchColumnsList: ColumnsDefinationGrid[];

	@Output() public activeTab: EventEmitter<string> = new EventEmitter<string>();
	public _isFilterd: boolean = false;
	public isCTNExist: boolean = false;

	// New variables
	public tabsList: TabsInfo[];
	public resultColumnsList: ColumnsDefinationGrid[];
	public finalColumnsList: ColumnsDefinationGrid[];
	public resultsDataSource = [[]];
	public resultDataSource = undefined;
	public listedTabResultDataSource = undefined;

	private alive: Subject<void> = new Subject();
	private activeTabName: string;
	private firstTabName: string;
	private isActualPostingCTNExist: boolean = false;

	private _selectedRows: any[];

	private smcColumns: SearchResultColumns[] = [];

	// Hold List ag grid reference
	private _listedAgGrid: AquaGrid;
	@ViewChild("listedAgGrid")
	private set listedAgGrid(listedAgGrid: AquaGrid) {
		console.debug("SearchResultComponent::listedAgGrid::", listedAgGrid);
		if (listedAgGrid) {
			this._listedAgGrid = listedAgGrid;
		}
	}
	private get listedAgGrid() {
		return this._listedAgGrid;
	}
	private _maxRecordLimit: number = 10000;
	constructor(
		private searchService: SearchService,
		private filterDisplayService: FilterDisplayService,
		private vizNotification: VizNotificationService,
		private filterCancelService: FilterCancelService,
		private searchResultColumnService: SearchResultColumnService,
		public dialog: MatDialog
	) {}
	public spinnerCancelled(event: Event, name?: string) {
		console.debug("SearchResultComponent::spinnerCancelled::", event, name);
		this.filterCancelService.cancelSubject();
	}

	public ngOnInit() {
		console.debug("SearchResultComponent::ngOnInit::");

		this.getAllTabs();

		this.listenResultDataChange();
		this.listenOnSearchTabAlert();
		this.listenStatusChange();
		this.listenCriteriaChange();
		this.searchResultColumnService.loadResultColumns();
		this.getTabColumns("Listed");
	}

	public ngOnDestroy() {
		console.debug("SearchResultComponent::ngOnDestroy");
		this.alive.next();
		this.alive.complete();
		this.alive.unsubscribe();
	}

	public getLastResultAgreementKeys(): number[] {
		const selectedRows = this.getSelectedRows();
		if (selectedRows && selectedRows.length > 0) {
			this._selectedRows = selectedRows;
		} else {
			this._selectedRows = this.listedTabResultDataSource;
			// this.resultsDataSource[this.firstTabName];
		}
		return (
			this._selectedRows &&
			this._selectedRows.map(result => result.agreement_key)
		);
	}

	public getLastResultAgreementKeysAndOptimalRank(): AgreementOptimalRank[] {
		const selectedRows = this.getSelectedRows();
		if (selectedRows && selectedRows.length > 0) {
			this._selectedRows = selectedRows;
		} else {
			this._selectedRows = this.listedTabResultDataSource;
			// this.resultsDataSource[this.firstTabName];
		}

		return (
			this._selectedRows &&
			this._selectedRows.map(result => {
				return {
					agreementKey: result.agreement_key,
					optimalRank: result.optimal_rank
				};
			})
		);
	}

	public onFiltered(event: Event): void {
		const element: Element = event.srcElement;
		const isDisabled: any = element.getAttribute("disabled");

		console.debug(
			"SearchResultComponent::onFiltered::",
			this.isFilterd,
			isDisabled
		);
		if (isDisabled) {
			return;
		}
		this.isFilterd = !this.isFilterd;
		this.searchService.onFilterFlagChange(this.isFilterd);
	}

	public onSelectedRows(_selectedRows: Agreement[]): void {
		this._selectedRows = _selectedRows;
	}

	public tabChanged(tabChangeEvent: MatTabChangeEvent): void {
		console.debug(
			"SearchResultComponent::tabChanged Tab Changed: ",
			tabChangeEvent,
			tabChangeEvent.tab.textLabel
		);
		this.activeTabName = tabChangeEvent.tab.textLabel;
		if (!this.firstTabName) {
			this.firstTabName = this.activeTabName;
		}
		this.activeTab.next(this.activeTabName);
		// this.searchingStatus = false;
		this.resultDataSource = undefined;
		this.getTabColumns(this.activeTabName);
		if (this.activeTabName !== "Listed") {
			setTimeout(() => {
				this.getData(this.activeTabName);
			}, 200);
		}
		// if (this.activeTabName === "Listed") {
		// 	this.searchingStatus = true;
		// 	// setTimeout(() => {
		// 	// 	this.searchingStatus = false;
		// 	// }, 500);
		// }
	}
	public getTabColumns(tabName: string): void {
		console.debug("SearchResultComponent::getTabColumns:: ");
		this.searchResultColumnService
			.getColumnsListByTab(tabName)
			.pipe(takeUntil(this.alive))
			.subscribe((columns: SearchResultColumns[]) => {
				console.debug(
					"SearchResultComponent::getTabColumns::",
					columns.filter(p => p.isDefaultDisplay && p.tabName === "Listed")
				);
				let finalColumns = [...columns];
				if (tabName === "Current Postings" || tabName === "Box") {
					finalColumns = GridUtils.mergeColumnsIfNotExistOtherwiseIgnore(
						this.smcColumns,
						finalColumns
					);
				}
				this.resultColumnsList = GridUtils.buildColumns2(finalColumns);
				if (tabName === "Listed") {
					this.resultColumnsList.push(ColumnDefaultGrid.checkbox);
				}
				console.debug(
					"SearchResultComponent::getTabColumns:: Result Column::",
					tabName,
					this.resultColumnsList.length
				);
			});
	}

	public getAllTabs(): void {
		// console.debug("SearchResultComponent::getAllTabs:: ");
		this.searchResultColumnService
			.getTabList()
			.pipe(takeUntil(this.alive))
			.subscribe(tabs => {
				console.debug("SearchResultComponent::getAllTabs:: ", tabs);
				this.tabsList = tabs;
			});
	}

	public getVoyagerTabs(): void {
		console.debug("SearchResultComponent::getVoyagerTabs:: ");
		this.searchResultColumnService
			.getVoyagerTabList()
			.pipe(takeUntil(this.alive))
			.subscribe(columns => {
				console.debug("SearchResultComponent::getVoyagerTabs::", columns);
			});
	}

	public onExportClick(source) {
		console.debug("SearchResultComponent::onExportClick " + source);
		const lastResultAgreementKeys: number[] = this.getLastResultAgreementKeys();
		if (
			this.searchCriteria &&
			lastResultAgreementKeys &&
			lastResultAgreementKeys.length > 0
		) {
			this.searchService
				.exportSearchResult(
					source,
					this.searchCriteria,
					this.getLastResultAgreementKeys()
				)
				.pipe(takeUntil(this.alive))
				.subscribe((response: any) => {
					if (response) {
						DataGridUtil.exportToExcel(response, source);
					} else {
						this.vizNotification.showError(response.restError.errorMessage);
					}
				});
		}
	}

	public onSelectedAggrement($event) {
		console.debug("SearchResult::onSelectedAggrement:: ", $event);
		const selectedAggrement = $event.data[FieldNames.AGREEMENT_KEY];
		const selectedAggrementId = $event.data[FieldNames.AGREEMENT_ID];

		if ($event.colDef.field === "agreement_id") {
			// aggrement popin start
			const dialogRef = this.dialog.open(AggrementPopinComponent, {
				width: "95%",
				height: "90%",
				data: {
					name: selectedAggrement,
					aggrementId: selectedAggrementId
				}
			});
			console.debug("SearchResult::onSelectedAggrement:: ", selectedAggrement);
			dialogRef.afterClosed().subscribe(result => {
				console.debug("SearchResult::afterClosed:: ");
			});
		}
	}
	private getSelectedRows(): any[] {
		if (this.listedAgGrid && this.listedAgGrid.gridApi) {
			this._selectedRows = this.listedAgGrid.gridApi.getSelectedRows();
		}
		return this._selectedRows;
	}

	private listenStatusChange(): void {
		this.searchService
			.searchingStatus()
			.pipe(takeUntil(this.alive))
			.subscribe(status => {
				this.searchingStatus = status;
			});
	}

	private listenCriteriaChange(): void {
		// listen current search criteria
		this.filterDisplayService
			.getAsObservable()
			.pipe(
				takeUntil(this.alive),
				debounceTime(500),
				distinctUntilChanged()
			)
			.subscribe((searchFieldStates: SearchFieldStates) => {
				if (
					searchFieldStates.dataWithoutEmptyValue &&
					searchFieldStates.dataWithoutEmptyValue.length > 0
				) {
					this.searchCriteria = searchFieldStates.dataWithoutEmptyValue;
					this.prepareColumnList();
					this.isActualPostingCTNExist = this.checkCollatralType(
						searchFieldStates.dataWithoutEmptyValue,
						false
					);
					// searchFieldStates.fields.filter(
					// 	field => field.whoHasFlag && field.value && field.value !== ""
					// ).length > 0;
					this.isCTNExist =
						this.checkCollatralType(searchFieldStates.dataWithoutEmptyValue) >
						0;
					console.debug(
						"SearchResultComponent::listenCriteriaChange::",
						this.isActualPostingCTNExist,
						this.isCTNExist
					);
					this.searchService.filterFlagChanged.next(
						this.isActualPostingCTNExist
					);
				}
			});
	}

	private prepareColumnList(): void {
		const smsSearchField = this.searchCriteria.filter(
			p => p.logicalGroupName === "SMC Attributes"
		);

		const smcColumns: SearchResultColumns[] = [];
		let count = 1000;
		for (const searchField of smsSearchField) {
			const src: SearchResultColumns = new SearchResultColumns();
			src.fieldName = searchField.fieldName;
			src.displayName = searchField.name;
			src.isDefaultDisplay = true;
			src.fieldType = searchField.dataType.toUpperCase();
			src.fieldOrder = count++;
			smcColumns.push(src);
		}
		this.smcColumns = smcColumns;
		// console.debug(
		// 	"SearchResultComponent::preapreColumnList::",
		// 	smsSearchField,
		// 	smcColumns
		// );
	}
	private listenResultDataChange() {
		console.debug("SearchResultComponent::listenResultDataChange");
		this.searchService
			.searchResultChangeNotification()
			.pipe(takeUntil(this.alive))
			.subscribe((result: any) => {
				console.debug(
					"SearchResultComponent::listenResultDataChange::Got new result::",
					result,
					this.firstTabName,
					this.resultTabSelectedIndex
				);
				// clear existing data from array
				// this.resultsDataSource = [[]];
				this.gotListed = result && result.count > 0;
				if (this.resultTabSelectedIndex !== 0) {
					this.resultTabSelectedIndex = 0;
				}
				if (this.listedTabResultDataSource !== undefined) {
					this.listedTabResultDataSource = undefined;
				}
				if (result && result.listOfRecords && result.listOfRecords.length > 0) {
					this.setFilter();
					// this.resultsDataSource[this.firstTabName] = result.listOfRecords;
					this.listedTabResultDataSource = result.listOfRecords;

					if (result.count > this._maxRecordLimit) {
						this.showRecordWarning(result.count);
					}
				} else if (result !== null) {
					// this.resultsDataSource[this.firstTabName] = [];
					this.listedTabResultDataSource = [];
				}
			});
	}
	private listenOnSearchTabAlert() {
		console.debug("SearchResultComponent::listenOnSearchTabAlert");
		this.searchService
			.onSearchTabNotification()
			.pipe(takeUntil(this.alive))
			.subscribe((result: any) => {
				console.debug(
					"SearchResultComponent::listenOnSearchTabAlert::Got new result::",
					result,
					this.firstTabName
				);
				// if (result) {
				// 	this.gotListed = false;
				// 	this.resultTabSelectedIndex = 0;
				// 	// this.resultsDataSource = [[]];
				// 	this.resultDataSource = undefined;
				// 	this.listedTabResultDataSource = undefined;
				// }
			});
	}

	private showRecordWarning(count: number): void {
		const snackBarConfig = new MatSnackBarConfig();
		snackBarConfig.horizontalPosition = SnackBarPosition.RIGHT;
		snackBarConfig.verticalPosition = SnackBarPosition.TOP;
		snackBarConfig.duration = 60000;
		this.vizNotification.showWarning(
			"**NOTIFICATION** User query returned " +
				count +
				" records , only " +
				this._maxRecordLimit +
				" records are displayed in the listed tab.",
			"Dismiss",
			snackBarConfig
		);
	}

	private setFilter(): void {
		if (this.isActualPostingCTNExist) {
			this._isFilterd = true;
		} else {
			this._isFilterd = false;
		}
		console.debug(
			"SearchResultComponent::setFilter::",
			this.isActualPostingCTNExist
		);
		this.searchService.filterFlagChanged.next(this.isActualPostingCTNExist);
	}

	private checkCollatralType(
		criteria: SearchField[],
		withContractualEligibilityOnly: boolean = true
	): any {
		return criteria.filter(
			field =>
				(withContractualEligibilityOnly
					? field.whoHasFlag === 0
					: field.whoHasFlag) &&
				field.componentType === ComponentType.MULTI_INCLUDE_EXCLUDE &&
				field.value
		).length;
	}

	private getCollaterTypeSearchCriteria(): string[] {
		const collateralTypeNames: Set<string> = new Set();
		const collateralTypeNameFields: SearchField[] = this.searchCriteria.filter(
			field => field.fieldName === "collateral_type_name" && field.value
		);
		collateralTypeNameFields.forEach(field => {
			const fieldIncludeExcludeValue: IncludeExcludeListModel = field.value;
			if (fieldIncludeExcludeValue) {
				fieldIncludeExcludeValue.valueList.forEach(
					(valueCTN: IncludeExcludeModel) => {
						if (valueCTN.value) {
							valueCTN.value.forEach(element => {
								collateralTypeNames.add(element.value);
							});
						}
					}
				);
			}
		});
		return Array.from(collateralTypeNames.values());
	}

	// ---------------------------------------------------------------------------------------------------------------------
	private getData(tabName: string) {
		console.debug(
			"SearchResultComponent::getData::",
			this.isActualPostingCTNExist,
			this._isFilterd,
			this.searchCriteria
		);
		const agreementKeys = this.getLastResultAgreementKeys();
		const agreementOptimalRanks: AgreementOptimalRank[] = this.getLastResultAgreementKeysAndOptimalRank();
		console.debug(
			"SearchResultComponent::getData::Agreement Keys::",
			agreementKeys
		);

		this.searchService
			.getTabsData(
				tabName,
				agreementKeys,
				agreementOptimalRanks,
				this._isFilterd,
				this.searchCriteria,
				this.smcColumns
			)
			.pipe(takeUntil(this.alive))
			.subscribe((response: DerivzRestResponse<Agreement[]>) => {
				console.debug("SearchResultComponent::getData::", response);
				if (response && response.responseStatus === 200) {
					this.vizNotification.showMessage(tabName + " fetched successfully");
					// this.resultsDataSource[tabName] = response.responseData.listOfRecords;
					this.resultDataSource = response.responseData.listOfRecords;
					if (tabName === "GSST") {
						this.showGSSTTabMessage(tabName, this.resultDataSource.length);
					}
				} else {
					if (response && response.restError) {
						this.vizNotification.showError(response.restError.errorMessage);
					} else {
						this.vizNotification.showInternalSystemError();
					}
				}
			});
	}

	private showGSSTTabMessage(tabName: string, resultLength: number) {
		// this.resultsDataSource[tabName].length
		if (this.getCollaterTypeSearchCriteria().length === 0 && resultLength > 0) {
			const snackBarConfig = new MatSnackBarConfig();
			snackBarConfig.horizontalPosition = SnackBarPosition.RIGHT;
			snackBarConfig.verticalPosition = SnackBarPosition.TOP;
			snackBarConfig.duration = 60000;
			this.vizNotification.showWarning(
				"GSST exposure is not calculated as collateral type name is not selected in contractual eligibility",
				"Dismiss",
				snackBarConfig
			);
		} else {
			this.vizNotification.showMessage("GSST Data fetched successfully");
		}
	}
	// private mergeDefaultAndSMCColumns(): void {
	// 	console.debug("SearchResultComponent::mergeDefaultAndSMCColumns::");
	// 	this.finalColumnsList = [...this.resultColumnsList];
	// 	console.debug(
	// 		"SearchResultComponent::mergeDefaultAndSMCColumns:: Final Column::",
	// 		this.finalColumnsList.length
	// 	);
	// }
}
