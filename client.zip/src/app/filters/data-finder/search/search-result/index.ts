export * from "./search-result.component";
