import { Component, OnInit, ViewChild } from "@angular/core";
import { FormGroup, NgForm } from "@angular/forms";
import { MatDialog, MatDialogRef } from "@angular/material";
import { ColumnsDefinationGrid } from "@aqua/aqua-component/aqua-grid/model";
import {
	ColumnDefaultGrid,
	GridUtils
} from "@aqua/aqua-component/aqua-grid/utils";
import { GridViewComponent } from "@aqua/aqua-component/grid-view/grid-view.component";
import { ConfirmationDialogComponent } from "@aqua/filters/data-finder/confirmation-dialog/confirmation-dialog.component";
import { SearchService } from "@aqua/filters/data-finder/search/search.service";
import { SearchField } from "@aqua/filters/models";
import { VizNotificationService } from "@aqua/services";
import { Subject, Subscription } from "rxjs";
import { takeUntil } from "rxjs/operators";

@Component({
	selector: "derivz-collateral-type-lookup",
	templateUrl: "./collateral-type-lookup.component.html",
	styleUrls: ["./collateral-type-lookup.component.scss"]
})
export class CollateralTypeLookupComponent implements OnInit {
	@ViewChild("collateralLookupForm")
	set setForm(myForm: FormGroup) {
		console.debug(
			"CollateralTypeLookupComponent::setForm::",
			myForm,
			this.formSubscription
		);
		if (myForm && this.previousForm !== myForm) {
			console.debug(
				"CollateralTypeLookupComponent::setting new Form Instance::"
			);
			if (this.formSubscription) {
				this.formSubscription.unsubscribe();
				this.formSubscription = undefined;
			}
			this.previousForm = myForm;
		}
	}
	public saveAsCriteriaName: string;
	public gridHeight: number = 40;
	public searchingStatus: boolean;
	public selectedRows: any[];
	public fields: SearchField[] = [];
	public displayColumn: ColumnsDefinationGrid[] = [];
	public columnsList: ColumnsDefinationGrid[];

	@ViewChild("lookupGrid") public lookupGrid: GridViewComponent;

	public payLoad = "";
	public form: FormGroup;

	public lookupResultData: any[];

	private alive: Subject<void> = new Subject<void>();

	/* REQUIRED: PERFORMANCE FIX: This is getting multiple times, so those many subscription are generating */
	private formSubscription: Subscription;
	private previousForm: FormGroup;

	constructor(
		private searchService: SearchService,
		private vizNotification: VizNotificationService,
		private dialogConfirmation: MatDialog,
		private dialogRef: MatDialogRef<CollateralTypeLookupComponent>
	) {}

	public trackByKey(index, item) {
		return item.key;
	}

	public ngOnInit() {
		this.loadCollateralTypeLookupColums();
		this.searchService
			.searchingStatus()
			.pipe(takeUntil(this.alive))
			.subscribe(status => (this.searchingStatus = status));
	}

	public loadCollateralTypeLookupColums() {
		console.debug("CollateralTypeLookupComponent::loadReferenceData");
		this.searchService
			.getCollateralTypeLookupColums()
			.pipe(takeUntil(this.alive))
			.subscribe(response => {
				if (response.responseStatus === 200) {
					this.fields = response.responseData;

					const selectColumn: any = new ColumnsDefinationGrid(
						"Collateral Type Name",
						"collateralTypeName"
					);
					selectColumn.defaultSelected = 1;
					selectColumn.width = 380;
					selectColumn.dataType = "STRING";

					let displayColumnHold: any[] = [];
					displayColumnHold.push(selectColumn);
					displayColumnHold = displayColumnHold.concat(this.fields);
					this.displayColumn = GridUtils.buildColumns(displayColumnHold);
					this.displayColumn.push(ColumnDefaultGrid.checkbox);
					console.debug(
						"CollateralTypeLookupComponent::loadReferenceData:: Data >> ",
						this.displayColumn,
						this.fields
					);
					this.renderSearchData(this.fields);
				} else {
					this.vizNotification.showError(response.restError.errorMessage);
				}
			});
	}

	public renderSearchData(responseData) {
		console.debug(
			"CollateralTypeLookupComponent::listenBookmark::renderSearchData"
		);

		if (this.form) {
			this.form.reset();
		}
		// If no fields exist in the resposne. Clear all the filters
		if (responseData.length === 0) {
			this.fields = [];
			return;
		}

		this.form = this.searchService.toFormGroup(responseData, this.form);
	}

	// ====================== Event Handlers ============================================

	// TODO : what about non standard values like exclude, range component
	// Needs to be further investigated as I did not create thie onSearch function. It does search with those filters though if you examine network traffic
	public onSearchClick(collateralLookupForm?: NgForm) {
		console.debug("CollateralTypeLookupComponent::onSearchClick");

		const critieria = this.getCurrentCriteria();
		this.payLoad = JSON.stringify(critieria);
		//  this.searchingStatus = true;
		this.searchService
			.lookupCollateralType(critieria)
			.pipe(takeUntil(this.alive))
			.subscribe(response => {
				//        this.searchingStatus = false;
				if (response.responseStatus === 200) {
					this.lookupResultData = response.responseData;
					this.vizNotification.showMessage(
						"Collateral Type Name lookup data fetched successfully"
					);
				} else {
					this.vizNotification.showError(response.restError.errorMessage);
				}
			});
	}

	public onResetClick() {
		this.userConfirmation("Are you sure you want to Reset ?", "resetCallBack");
	}

	public resetCallBack() {
		const group: any = {};
		this.fields.forEach(field => {
			group[field.fieldName + "-" + field.key] = null;
		});
		this.form.patchValue(group);
		this.form.markAsTouched();
		this.form.reset();
	}

	public onCancel(): void {
		this.userConfirmation(
			"Are you sure you want to Cancel ?",
			"cancelCallBack"
		);
	}

	public cancelCallBack() {
		this.dialogRef.close();
	}

	public userConfirmation(msg, callback) {
		let confimrationDialogRef: MatDialogRef<
			ConfirmationDialogComponent,
			null
		> = this.dialogConfirmation.open(ConfirmationDialogComponent, {
			width: "300px",
			data: { confirmationMessage: msg },
			disableClose: false
		});

		confimrationDialogRef
			.afterClosed()
			.pipe(takeUntil(this.alive))
			.subscribe(result => {
				if (result) {
					this[callback]();
				}
				confimrationDialogRef = null;
			});
	}

	public onApply(operation: string): void {
		if (this.selectedRows && this.selectedRows.length > 0) {
			const collateralTypeSet: Set<string> = new Set(
				this.selectedRows.map(item => item.collateralTypeName)
			);
			const result: any[] = [];
			result.push(operation);
			result.push(collateralTypeSet);
			this.dialogRef.close(result);
		}
	}

	public onSelectedRows(selectedRows: any[]): void {
		this.selectedRows = selectedRows;
	}

	// ========= helper methods=============================
	public getCurrentCriteria(): SearchField[] {
		return this.fields.filter(field => field.value);
	}

	public ngOnDestroy() {
		console.debug("CollateralTypeLookupComponent::ngOnDestroy::", this.payLoad);
		this.alive.next();
		this.alive.complete();
		this.alive.unsubscribe();
		this.alive = undefined;
	}
}
