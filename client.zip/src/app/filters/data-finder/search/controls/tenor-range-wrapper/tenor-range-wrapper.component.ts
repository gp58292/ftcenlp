import { Component, Input } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { SearchField } from "@aqua/filters/models/search-field";

@Component({
	selector: "ceft-tenor-range-wrapper",
	templateUrl: "./tenor-range-wrapper.component.html",
	styleUrls: ["./tenor-range-wrapper.component.scss"]
})
export class TenorRangeComponent {
	@Input("field") public field: SearchField;

	@Input() public form: FormGroup;
}
