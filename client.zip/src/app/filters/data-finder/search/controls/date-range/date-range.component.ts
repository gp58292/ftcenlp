import { Component, Input } from "@angular/core";
import { AbstractControl, FormGroup } from "@angular/forms";
import { SearchField } from "@aqua/filters/models/search-field";

@Component({
	selector: "derivz-date-range",
	templateUrl: "./date-range.component.html",
	styleUrls: ["./date-range.component.scss"]
})
export class DateRangeComponent {
	@Input("field")
	public field: SearchField;

	@Input()
	public form: FormGroup;

	public ngOnChanges(values) {
		console.debug("DateRangeComponent::ngOnChanges::", values);
	}

	public getErrorMessage() {
		// console.debug("NumberRangeComponent::getErrorMessage::");
		let msg: string = "";
		const numberRangeControl: AbstractControl = this.form.controls[
			this.field.fieldName + "_" + this.field.key + "_" + this.field.whoHasFlag
		];
		switch (true) {
			case numberRangeControl.hasError("validateDateRange"):
				msg = "You must enter a valid range";
				break;
			default:
				msg = "";
		}
		return msg;
	}

	public isErrorState(): boolean {
		const control: AbstractControl = this.form.controls[
			this.field.fieldName + "_" + this.field.key + "_" + this.field.whoHasFlag
		];
		return control && control.invalid && (control.dirty || control.touched);
	}
}
