import {
	ChangeDetectorRef,
	Component,
	Input,
	OnChanges,
	OnDestroy,
	OnInit
} from "@angular/core";
import { AbstractControl, FormGroup } from "@angular/forms";
import { RatingRankingModel } from "@aqua/aqua-component/dropdown-range";
import { SearchService } from "@aqua/filters/data-finder/search/search.service";
import { DerivzRestResponse } from "@aqua/filters/models";
import { SearchField } from "@aqua/filters/models/search-field";
import { Subject } from "rxjs";
import { takeUntil } from "rxjs/operators";

@Component({
	selector: "ceft-rating-ranking",
	templateUrl: "./rating-ranking.component.html",
	styleUrls: ["./rating-ranking.component.scss"]
	// changeDetection:ChangeDetectionStrategy.OnPush
})
export class RatingRankingComponent implements OnInit, OnDestroy, OnChanges {
	get isErrorState(): boolean {
		const control: AbstractControl = this.form.controls[
			this.field.fieldName + "_" + this.field.key + "_" + this.field.whoHasFlag
		];
		// console.debug(
		// 	"RatingRankingComponent::isErrorState::",
		// 	control,
		// 	control && control.invalid && (control.dirty || control.touched)
		// );
		return control && control.invalid && (control.dirty || control.touched);
	}
	@Input("field") public field: SearchField;
	@Input() public form: FormGroup;
	public ratingRanking: RatingRankingModel[];

	public data: string[] = [];

	private alive: Subject<void> = new Subject();
	constructor(
		private searchService: SearchService,
		private changeDetection: ChangeDetectorRef
	) {}

	public ngOnInit() {
		console.debug("RatingRankingComponent::ngOnInit");
		// this.changeDetection.detach();
		this.loadReferenceData();
	}

	public loadReferenceData() {
		console.debug("RatingRankingComponent::loadReferenceData", this.field);
		this.searchService
			.getRatingRankings()
			.pipe(takeUntil(this.alive))
			.subscribe((response: DerivzRestResponse<RatingRankingModel[]>) => {
				this.ratingRanking = response.responseData;
				console.debug(
					"RatingRankingComponent::loadReferenceData",
					this.ratingRanking
				);
				this.changeDetection.detectChanges();
				// this.changeDetection.markForCheck();
			});
	}
	public ngOnChanges(values) {
		console.debug(
			"RatingRankingComponent::ngOnChanges::",
			values,
			this.field,
			this.form
		);
		// this.changeDetection.detectChanges();
	}
	// ngAfterViewInit() {
	//   this.changeDetection.detectChanges();
	// }
	public ngOnDestroy() {
		this.alive.next();
		this.alive.complete();
		this.alive.unsubscribe();
	}

	public getErrorMessage(ratingRangeWrapper) {
		// console.debug("RatingRankingComponent::getErrorMessage::");
		let msg = "";
		const numberRangeControl: AbstractControl = this.form.controls[
			this.field.fieldName + "_" + this.field.key + "_" + this.field.whoHasFlag
		];
		switch (true) {
			case numberRangeControl.hasError("validateRatingRangeList"):
				msg = "You must enter a valid range";
				break;
			default:
				msg = "";
		}
		console.debug(
			"RatingRankingComponent::getErrorMessage::",
			msg,
			numberRangeControl,
			ratingRangeWrapper
		);
		return msg;
	}
}
