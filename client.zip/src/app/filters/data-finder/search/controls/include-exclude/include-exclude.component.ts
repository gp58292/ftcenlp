import { Component, Input, OnDestroy, OnInit } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { Subject } from "rxjs";

import { Options } from "@aqua/aqua-component/models";
import { SearchService } from "@aqua/filters/data-finder/search/search.service";
import { SearchField } from "@aqua/filters/models/search-field";
import { takeUntil } from "rxjs/operators";

@Component({
	selector: "derivz-include-exclude",
	templateUrl: "./include-exclude.component.html",
	styleUrls: ["./include-exclude.component.scss"]
})
export class IncludeExcludeComponent implements OnInit, OnDestroy {
	@Input("field")
	public field: SearchField;

	@Input() public form: FormGroup;

	public referenceData: Options[];
	private alive: Subject<void> = new Subject();

	constructor(private searchService: SearchService) {
		console.debug("IncludeExcludeComponent::constructor");
	}

	public ngOnInit() {
		console.debug("IncludeExcludeComponent::ngOnInit");
		this.loadReferenceData();
	}

	public loadReferenceData() {
		console.debug("IncludeExcludeComponent::loadReferenceData", this.field);
		this.searchService
			.getReferenceData(this.field)
			.pipe(takeUntil(this.alive))
			.subscribe((response: Options[]) => (this.referenceData = response));
	}

	public ngOnDestroy(): void {
		console.debug("IncludeExcludeComponent::ngOnDestroy::");
		this.alive.next();
		this.alive.complete();
		this.alive.unsubscribe();
	}
}
