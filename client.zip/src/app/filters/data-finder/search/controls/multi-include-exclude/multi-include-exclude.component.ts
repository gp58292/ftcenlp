import { Component, Input, OnDestroy, OnInit } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { Subject } from "rxjs";

import { Options } from "@aqua/aqua-component/models";
import { SearchService } from "@aqua/filters/data-finder/search/search.service";
import { SearchField } from "@aqua/filters/models/search-field";
import { takeUntil } from "rxjs/operators";

@Component({
	selector: "ceft-multi-include-exclude",
	templateUrl: "./multi-include-exclude.component.html",
	styleUrls: ["./multi-include-exclude.component.scss"]
})
export class MultiIncludeExcludeComponent implements OnInit, OnDestroy {
	@Input("field")
	public field: SearchField;

	@Input() public form: FormGroup;

	public referenceData: Options[];
	private alive: Subject<void> = new Subject();

	constructor(private searchService: SearchService) {
		console.debug("MultiIncludeExcludeComponent::constructor");
	}

	public ngOnInit() {
		console.debug("MultiIncludeExcludeComponent::ngOnInit");
		this.loadReferenceData();
	}

	public loadReferenceData() {
		console.debug(
			"MultiIncludeExcludeComponent::loadReferenceData",
			this.field
		);
		this.searchService
			.getReferenceData(this.field)
			.pipe(takeUntil(this.alive))
			.subscribe((response: Options[]) => (this.referenceData = response));
	}

	public ngOnDestroy(): void {
		console.debug("MultiIncludeExcludeComponent::ngOnDestroy::");
		this.alive.next();
		this.alive.complete();
		this.alive.unsubscribe();
	}
}
