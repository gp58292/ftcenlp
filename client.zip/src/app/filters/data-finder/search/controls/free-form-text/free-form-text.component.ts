import { Component, Input } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { SearchField } from "@aqua/filters/models/search-field";
@Component({
	selector: "dataviz-free-form-text",
	templateUrl: "./free-form-text.component.html",
	styleUrls: ["./free-form-text.component.scss"]
})
export class FreeFormTextComponent {
	@Input("field") public field: SearchField;
	@Input() public form: FormGroup;

	public trimSpaces() {
		console.debug("FreeFormTextComponent::trimSpaces");
		if (this.field.value) {
			this.field.value = this.field.value.trim();
		}
	}
}
