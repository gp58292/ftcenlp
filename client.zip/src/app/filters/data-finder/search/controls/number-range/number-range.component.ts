import { Component, Input, OnChanges, SimpleChanges } from "@angular/core";
import { AbstractControl, FormControl } from "@angular/forms";
import { FormGroup } from "@angular/forms";
import { SearchField } from "@aqua/filters/models/search-field";

@Component({
	selector: "derivz-number-range",
	templateUrl: "./number-range.component.html",
	styleUrls: ["./number-range.component.scss"]
})
export class NumberRangeComponent implements OnChanges {
	@Input("field") public field: SearchField;

	@Input() public form: FormGroup;

	public ngOnChanges(changes: SimpleChanges): void {
		console.debug(
			"NumberRangeComponent::ngOnChanges::",
			changes,
			this.form.controls[
				this.field.fieldName +
					"_" +
					this.field.key +
					"_" +
					this.field.whoHasFlag
			]
		);
	}

	public getErrorMessage() {
		// console.debug("NumberRangeComponent::getErrorMessage::");
		let msg: string = "";
		const numberRangeControl: AbstractControl = this.form.controls[
			this.field.fieldName + "_" + this.field.key + "_" + this.field.whoHasFlag
		];
		switch (true) {
			case numberRangeControl.hasError("validateNumberRange"):
				msg = "You must enter a valid range";
				break;
			default:
				msg = "";
		}
		// console.debug("NumberRangeComponent::getErrorMessage::",msg);
		return msg;
	}

	public isErrorState(): boolean {
		const control: AbstractControl = this.form.controls[
			this.field.fieldName + "_" + this.field.key + "_" + this.field.whoHasFlag
		];
		// console.debug("NumberRangeComponent::isErrorState::",control,(control && control.invalid && (control.dirty || control.touched)));
		return control && control.invalid && (control.dirty || control.touched);
	}
}
