import { Injectable } from "@angular/core";
import { Group } from "@aqua/filters/models/group";
import { SearchField } from "@aqua/filters/models/search-field";
import { FiltersUrlConfig } from "@aqua/filters/services/filters-url-config.service";
import { JsonHttp } from "@aqua/http-service";
import { AppHttpResponse } from "@aqua/models";
import { Observable } from "rxjs";
import { debounceTime, publishReplay, refCount } from "rxjs/operators";

@Injectable()
export class SettingsService {
	constructor(private http: JsonHttp, private urlConfig: FiltersUrlConfig) {}

	public getFilterListForFlatView(): Observable<
		AppHttpResponse<SearchField[]>
	> {
		console.debug("SettingsService::getFilterListForFlatView");
		return this.http.get(this.urlConfig.EP_SETTINGS_COLUMNS_LIST).pipe(
			publishReplay(1),
			refCount()
		);
	}

	public getFilterListForTreeView(): Observable<AppHttpResponse<Group[]>> {
		console.debug("SettingService::getFilterListForTreeView");
		console.debug(this.urlConfig.EP_SETTINGS_COLUMNS_TREE);
		return this.http.get(this.urlConfig.EP_SETTINGS_COLUMNS_TREE).pipe(
			publishReplay(1),
			refCount()
		);
	}

	public saveUserSettings(
		userId: string,
		settingsName: string,
		selectedFieldsKeys: string[]
	): Observable<any> {
		// const requestUrl: string = this.urlConfig.EP_SETTINGS_USER_COLUMNS + userId + '/' + settingsName + '/' + selectedFieldsKeys;
		console.debug("SettingService:: saveSettings ");
		return this.http
			.put(this.urlConfig.EP_SETTINGS_USER_COLUMNS, {
				userId,
				columnSettingName: settingsName,
				selectedFieldsKeys
			})
			.pipe(debounceTime(400));
	}
}
