import { Component, Inject } from "@angular/core";
import { MAT_DIALOG_DATA, MatDialogRef } from "@angular/material";

@Component({
	selector: "dataviz-dialog-save-as",
	templateUrl: "./dialog-save-as.component.html",
	styleUrls: ["./dialog-save-as.component.scss"]
})
export class DialogSaveAsComponent {
	constructor(
		public dialogRef: MatDialogRef<DialogSaveAsComponent>,
		@Inject(MAT_DIALOG_DATA) public data: any
	) {}

	public onNoClick(): void {
		this.dialogRef.close();
	}
}
