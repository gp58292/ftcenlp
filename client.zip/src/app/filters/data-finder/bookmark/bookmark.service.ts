import { Injectable, OnDestroy } from "@angular/core";
import { Bookmark, SearchField } from "@aqua/filters/models";
import { FiltersUrlConfig } from "@aqua/filters/services";
import { JsonHttp } from "@aqua/http-service";
import { AppHttpResponse } from "@aqua/models";
import { AuthService, VizNotificationService } from "@aqua/services";
import { CommonUtils } from "@aqua/util";
import * as lodash from "lodash";
import { BehaviorSubject, Observable, Subject } from "rxjs";
import { debounceTime, finalize, takeUntil } from "rxjs/operators";

import { BookmarkRequest } from "./bookmark-request.model";

const defalutSettingsName = "default";

@Injectable({ providedIn: "root" })
export class BookmarkService implements OnDestroy {
	public selectedBookmarkKeyChangeNotifier$: BehaviorSubject<
		number
	> = new BehaviorSubject(null);
	public bookmarkChanged$: BehaviorSubject<boolean> = new BehaviorSubject(
		false
	);
	private userId: string;

	private selectedBookmarkKey: number;

	// TO DO : If possilbe wrap or move SearFiled inside bookmark model as criteria Will be better while handling
	private selectedBookmarkCriteria: SearchField[];
	private bookmarkCriteria$: BehaviorSubject<
		SearchField[]
	> = new BehaviorSubject(null);

	private bookmarksList: Bookmark[];
	private bookmarkList$: BehaviorSubject<Bookmark[]> = new BehaviorSubject(
		null
	);

	private alive: Subject<void> = new Subject<void>();

	constructor(
		private http: JsonHttp,
		private urlConfig: FiltersUrlConfig,
		private authService: AuthService,
		private vizNotification: VizNotificationService
	) {
		this.userId = this.authService.getUserSoeId();
	}

	public ngOnDestroy() {
		this.alive.next();
		this.alive.complete();
		this.alive.unsubscribe();
	}

	// Load selected bookmark from rest service
	public loadBookmark(id: number) {
		console.debug("BookmarkService:: loadBookmark");
		// this.selectedBookmarkKey = id;
		if (id > 0) {
			this.getBookmark(this.userId, id)
				.pipe(takeUntil(this.alive))
				.subscribe((response: AppHttpResponse<SearchField[]>) => {
					console.debug(
						"BookmarkService:: loadBookmark :: ",
						response.responseData
					);
					if (response.responseStatus === 200) {
						this.selectedBookmarkCriteria = response.responseData;
						this.bookmarkCriteria$.next(this.selectedBookmarkCriteria);
					} else {
						this.vizNotification.showError(response.restError.errorMessage);
					}
				});
		}
	}

	// Load all bookmarks
	public loadAllBookmarks(isReloadBookmark: boolean = true): void {
		console.debug("BookmarkService:: loadAllBookmarks::", isReloadBookmark);
		this.getBookmarks()
			.pipe(takeUntil(this.alive))
			.subscribe((response: AppHttpResponse<Bookmark[]>) => {
				console.debug(
					"BookmarkService:: loadAllBookmarks :: this.selectedCriteria",
					response,
					response.responseStatus,
					response.responseStatus === 200
				);

				if (response.responseStatus === 200) {
					this.bookmarksList = response.responseData
						? response.responseData
						: [];
					this.informBookmarkListListener();
					// console.debug('BookmarkService:: loadAllBookmarks :: this.selectedCriteria' + this.selectedBookmarkKey);
				} else {
					this.bookmarkList$.next([]);
					this.bookmarksList = [];
					this.selectedBookmarkKey = -1;
					// this.vizNotification.showError(response.restError.errorMessage);
				}
			});
	}

	public isCurrentBookmarkModified(data: SearchField[]): boolean {
		const props: string[] = [
			"filtered",
			"distinctRequired",
			"key",
			"filterOnlyFlag"
		];
		const isObjectEqual = lodash.isEqual(
			CommonUtils.omitFalsyAndProps(
				this.selectedBookmarkCriteria || [],
				props,
				true
			),
			CommonUtils.omitFalsyAndProps(data, props, true)
		);
		// console.debug(
		// 	"BookmarkService:: isCurrentBookmarkModified ",
		// 	JSON.stringify(
		// 		CommonUtils.omitFalsyAndProps(
		// 			this.selectedBookmarkCriteria || [],
		// 			props,
		// 			true
		// 		)
		// 	),
		// 	JSON.stringify(CommonUtils.omitFalsyAndProps(data, props, true))
		// );
		return !isObjectEqual;
	}

	// On search bookmark creation and updation handling
	public onSearchCreateOrModifyBookmark(data: SearchField[]) {
		console.debug(
			"BookmarkService:: createOrModifyBookmark ",
			this.selectedBookmarkKey,
			this.bookmarksList
		);

		console.debug(
			"BookmarkService:: createOrModifyBookmark ",
			this.selectedBookmarkKey,
			!this.isAnyBookmarkExist(),
			this.isDefaultBookmarkSelected(),
			this.isCurrentBookmarkModified(data),
			this.isModifiedBookmarkTemporary()
		);

		if (
			!this.isAnyBookmarkExist() ||
			(!this.isDefaultBookmarkExist() && this.selectedBookmarkKey === -1)
		) {
			const bookmarkRequest: BookmarkRequest = new BookmarkRequest();
			bookmarkRequest.addSearchCriteria(data);
			bookmarkRequest.bookmarkName = defalutSettingsName;
			this.wrapperAddBookmark(bookmarkRequest);
		} else {
			if (this.isDefaultBookmarkSelected() || this.selectedBookmarkKey === -1) {
				// As we already checked, current selected bookmark is default, that means we can use same selected bookmark key which is pointing to default
				// And Even in selected default case, if bookmark modifed, we want to override it anyway.
				const bookmarkRequest: BookmarkRequest = new BookmarkRequest();
				bookmarkRequest.addSearchCriteria(data);
				bookmarkRequest.bookmarkId = this.getDefaultBookmarkKey();
				bookmarkRequest.isSilent = true;
				this.wrapperUpdateBookmark(bookmarkRequest);
				this.selectedBookmarkKey = this.getDefaultBookmarkKey();
			} else {
				// Now we need to check bookmark is modified or not
				if (this.isCurrentBookmarkModified(data)) {
					// const bookmarkRequest: BookmarkRequest = new BookmarkRequest();
					// bookmarkRequest.addSearchCriteria(data);
					// bookmarkRequest.bookmarkId = this.getDefaultBookmarkKey();
					// bookmarkRequest.isSilent = true;
					// this.wrapperUpdateBookmark(bookmarkRequest);
					// this.selectedBookmarkKey = this.getDefaultBookmarkKey();
					// Disabling temporary bookmark creation, as voyager integration has problems
					// DON"T REMOVE THIS COMMENTED CODE
					// If modifed bookmark is temporary, then simply update it
					if (this.isModifiedBookmarkTemporary()) {
						const bookmarkRequest: BookmarkRequest = new BookmarkRequest();
						bookmarkRequest.addSearchCriteria(data);
						bookmarkRequest.bookmarkId = this.selectedBookmarkKey;
						bookmarkRequest.isSilent = true;
						this.wrapperUpdateBookmark(bookmarkRequest);
					} else {
						const tempBookmark = this.getCorrespondingTempBookmark(
							this.selectedBookmarkKey
						);
						console.debug(
							"BookmarkService:: createOrModifyBookmark::tempBookmark:: ",
							tempBookmark
						);
						if (tempBookmark) {
							const bookmarkRequest: BookmarkRequest = new BookmarkRequest();
							bookmarkRequest.addSearchCriteria(data);
							bookmarkRequest.bookmarkId = tempBookmark.key;
							bookmarkRequest.isSilent = true;
							this.wrapperUpdateBookmark(bookmarkRequest);
							this.updateBookmarkKeyAndNotifyListener(tempBookmark.key);
						} else {
							// If modified bookmark is not temporary, then create new temporary bookmark.
							const bookmark = this.getBookmarkByKey(this.selectedBookmarkKey);
							const bookmarkRequest: BookmarkRequest = new BookmarkRequest();
							bookmarkRequest.addSearchCriteria(data);
							bookmarkRequest.parentBookmarkId = this.selectedBookmarkKey;
							bookmarkRequest.bookmarkName = bookmark.name + "_temp";
							this.wrapperAddBookmark(bookmarkRequest);
						}
					}
				} else {
					const bookmarkRequest: BookmarkRequest = new BookmarkRequest();
					bookmarkRequest.addSearchCriteria(data);
					bookmarkRequest.bookmarkId = this.selectedBookmarkKey;
					bookmarkRequest.isSilent = true;
					// If bookmark is not modifed, then simply update it
					this.wrapperUpdateBookmark(bookmarkRequest);
				}
			}
		}
	}

	// ==================Listen Bookmark and list of bookmark changes ==========================
	public getBookmarkDataNotification(): Observable<SearchField[]> {
		return this.bookmarkCriteria$.asObservable().pipe(debounceTime(500));
	}

	public getBookmarkListNotification(): Observable<Bookmark[]> {
		return this.bookmarkList$.asObservable().pipe(
			debounceTime(500),
			finalize(() => {
				console.debug(
					"BookmarkService:: getBookmarkListNotification :: Finally Arrived::"
				);
			})
		);
	}

	// =================== apis for add , delete , up date and retrive bookmark starts ===========================

	public updateSelectedBookmarkKey(key: number): void {
		this.selectedBookmarkKey = key;
	}
	public getSelectedBookmarkKey(): number {
		return this.selectedBookmarkKey;
	}

	public getBookmarks(): Observable<AppHttpResponse<Bookmark[]>> {
		const requestUrl: string = this.urlConfig.EP_BOOKMARK + "/" + this.userId;
		console.debug("BookmarkService:: getBookmarks " + requestUrl);
		return this.http.get(requestUrl);
	}

	public getBookmark(
		userId: string,
		bookmarkId: number
	): Observable<AppHttpResponse<SearchField[]>> {
		if (bookmarkId && bookmarkId != null) {
			const requestUrl: string =
				this.urlConfig.EP_BOOKMARK + "/" + userId + "/" + bookmarkId;
			console.debug("BookmarkService:: getBookmark" + requestUrl);
			return this.http.get(requestUrl);
		}
	}

	public updateBookmark(
		// data: SearchField[],
		// selectedKey: number,
		// name?: string
		bookmarkRequest: BookmarkRequest
	): Observable<AppHttpResponse<Bookmark>> {
		console.debug("BookmarkService::updateBookmark", bookmarkRequest);
		bookmarkRequest.userId = this.userId;
		return this.http.put(this.urlConfig.EP_BOOKMARK, bookmarkRequest);
	}
	public updateOriginalAndDeleteTemporaryBookmark(
		// data: SearchField[],
		// selectedKey: number
		bookmarkRequest: BookmarkRequest
	): void {
		bookmarkRequest.userId = this.userId;
		console.debug(
			"BookmarkService::updateOriginalAndDeleteTemporaryBookmark",
			bookmarkRequest
		);
		this.http
			.put(this.urlConfig.EP_BOOKMARK_REPLACE, bookmarkRequest)
			.subscribe(
				response => {
					const newBbookmark: Bookmark = response.responseData;
					let bookmarkFound = this.bookmarksList.findIndex(
						(bookmark: Bookmark) => bookmark.key === bookmarkRequest.bookmarkId
					);
					if (bookmarkFound !== -1) {
						this.bookmarksList.splice(bookmarkFound, 1);
						bookmarkFound = this.bookmarksList.findIndex(
							(bookmark: Bookmark) => bookmark.key === newBbookmark.key
						);
						this.bookmarksList[bookmarkFound] = newBbookmark;
						this.sortBookmarkList();
						// this.informBookmarkListListener();
						// if (bookmarkRequest.isReload) {
						// 	this.informBookmarkListListener();
						// }
						this.selectedBookmarkCriteria = bookmarkRequest.searchCriteria;
						this.updateBookmarkKeyAndNotifyListener(newBbookmark.key);
					}
					this.vizNotification.showMessage(
						"Successfully updated original bookmark and deleted temporary."
					);
				},
				error => {
					this.vizNotification.showError(
						"There is error while doing save on temporary functionality, Please contact AQUA CEFT Build Team."
					);
				}
			);
	}

	public wrapperUpdateBookmark(
		bookmarkRequest: BookmarkRequest
		// data: SearchField[],
		// selectedKey: number,
		// bookmarkName?: string,
		// isSilent: boolean = true
	) {
		this.updateBookmark(bookmarkRequest).subscribe(
			(response: AppHttpResponse<Bookmark>) => {
				if (response.responseStatus === 200) {
					if (!bookmarkRequest.isSilent) {
						this.vizNotification.showMessage("Successfully saved bookmark.");
					}

					const bookmarkFound = this.bookmarksList.findIndex(
						(bookmark: Bookmark) => bookmark.key === bookmarkRequest.bookmarkId
					);
					if (bookmarkFound !== -1) {
						const bookmark: Bookmark = response.responseData;
						this.bookmarksList[bookmarkFound] = bookmark;
						this.sortBookmarkList();
						// this.informBookmarkListListener();
						// if (bookmarkRequest.isReload) {
						// 	this.informBookmarkListListener();
						// }
						this.updateBookmarkKeyAndNotifyListener(bookmark.key);
						this.selectedBookmarkCriteria = bookmarkRequest.searchCriteria;
					}
				} else {
					this.vizNotification.showError(
						"Failed to save bookmark " + response.restError.errorMessage
					);
				}
			}
		);
	}

	public deleteBookmark(bookmarkId: number): void {
		const requestUrl: string =
			this.urlConfig.EP_BOOKMARK + "/" + this.userId + "/" + bookmarkId;
		console.debug("BookmarkService:: deleteBookmark " + requestUrl);
		this.http
			.delete(requestUrl)
			.subscribe((respone: AppHttpResponse<boolean>) => {
				console.debug("BookmarkComponent::deleteBookmark::", respone);
				if (respone.responseStatus === 200) {
					this.vizNotification.showMessage("Bookmark deleted successfully");
					const isTemporary: boolean = this.isCurrentBookmarkTemporary();
					const bookmark: Bookmark = this.getSelectedBookmark();

					// Remove successfully deleted bookmark from data base along with UI as well
					this.bookmarksList.splice(this.bookmarksList.indexOf(bookmark), 1);
					const tempBookmark: Bookmark = this.getCorrespondingTempBookmark(
						bookmark.key
					);
					if (tempBookmark) {
						this.bookmarksList.splice(
							this.bookmarksList.indexOf(tempBookmark),
							1
						);
					}
					this.sortBookmarkList();
					if (isTemporary) {
						this.updateBookmarkKeyAndNotifyListener(bookmark.parentId);
					} else {
						this.updateBookmarkKeyAndNotifyListener(
							this.bookmarksList && this.bookmarksList.length > 0
								? this.bookmarksList[0].key
								: -1
						);
					}
					this.bookmarkList$.next(this.bookmarksList);
				} else {
					this.vizNotification.showError(
						"Failed to delete bookmark" + respone.restError &&
							respone.restError.errorMessage
					);
				}
			});
	}

	// Add Bookmark to database
	public addBookmark(
		// name: string,
		// data: SearchField[],
		// parentId?: number
		bookmarkRequest: BookmarkRequest
	): Observable<AppHttpResponse<Bookmark>> {
		bookmarkRequest.userId = this.userId;
		console.debug("BookmarkService::addBookmark", bookmarkRequest);
		return this.http.post(this.urlConfig.EP_BOOKMARK, bookmarkRequest);
	}

	public wrapperAddBookmark(
		// name: string,
		// data: SearchField[],
		// parentId?: number,
		// isSilent: boolean = true,
		// isReload: boolean = true
		bookmarkRequest: BookmarkRequest
	) {
		this.addBookmark(bookmarkRequest).subscribe(
			(response: AppHttpResponse<Bookmark>) => {
				if (response.responseStatus === 200) {
					if (!bookmarkRequest.isSilent) {
						this.vizNotification.showMessage(
							"Successfully created new bookmark."
						);
					}
					const bookmark: Bookmark = response.responseData;
					this.bookmarksList.push(bookmark);
					this.sortBookmarkList();
					if (bookmarkRequest.isReload || this.bookmarksList.length < 2) {
						this.informBookmarkListListener();
					} else {
						this.updateBookmarkKeyAndNotifyListener(bookmark.key);
					}

					this.selectedBookmarkCriteria = bookmarkRequest.searchCriteria;
					console.debug(
						"BookmarkService::wrapperAddBookmark",
						this.bookmarksList
					);
					// this.currentBookmarkData = response.responseData;
				} else {
					this.vizNotification.showError(
						"Failed to add new bookmark" + response.restError.errorMessage
					);
				}
			}
		);
	}

	// Delete all temporary bookmark for specific user id
	public deleteAllTemporaryBookmarkByUserId(): Observable<
		AppHttpResponse<boolean>
	> {
		const url: string =
			this.urlConfig.EP_BOOKMARK_DELETE_ALL_TEMPORARY + "/" + this.userId;
		console.debug("BookmarkService::deleteAllTemporaryBookmarkByUserId::", url);
		return this.http.delete(url);
	}

	public deleteTempBookmarkWrapper(): void {
		this.deleteAllTemporaryBookmarkByUserId()
			.pipe(takeUntil(this.alive))
			.subscribe((response: AppHttpResponse<boolean>) => {
				if (response.responseStatus === 200) {
					this.vizNotification.showMessage(
						"All your temporary bookmark removed successfully."
					);
					const bookmark: Bookmark = this.getSelectedBookmark();
					const isTemporary: boolean = this.isCurrentBookmarkTemporary();
					console.debug(
						"BookmarkService::deleteTempBookmarkWrapper::",
						isTemporary,
						bookmark.parentId
					);
					this.removeTemporaryBookmarkFromUI();
					if (isTemporary) {
						this.updateBookmarkKeyAndNotifyListener(bookmark.parentId);
					}
					this.bookmarkList$.next(this.bookmarksList);
				} else {
					this.vizNotification.showError(
						"Interal error occured while removing temporary bookmark, please contact support team."
					);
				}
			});
	}

	// Delete all temporary bookmark for specific user id
	public restoreAllBookmarkByUserId(): void {
		const url: string =
			this.urlConfig.EP_BOOKMARK_RESTORE_ALL_DELETED + "/" + this.userId;
		console.debug("BookmarkService::restoreAllBookmarkByUserId::", url);
		this.http.get(url).subscribe((response: AppHttpResponse<Bookmark[]>) => {
			if (response.responseStatus === 200) {
				this.vizNotification.showMessage(
					"All your recently deleted bookmark restored successfully."
				);
				this.restoreBookmarkInUI(response.responseData);
			} else {
				this.vizNotification.showError(
					"Interal error occured while restoring bookmark," +
						response.restError && response.restError.errorMessage
				);
			}
		});
	}

	// get default bookmark if selected
	public getDefaultBookmarkIfSelected(): Bookmark {
		const selectedBookmark: Bookmark = this.getSelectedBookmark();
		return selectedBookmark && selectedBookmark.name === defalutSettingsName
			? selectedBookmark
			: undefined;
	}

	public getSelectedBookmark(): Bookmark {
		return this.getBookmarkByKey(this.selectedBookmarkKey);
	}
	public isBookmarkNameExist(name: string): boolean {
		const bookmarkFound: Bookmark = this.bookmarksList.find(
			bookmark => bookmark.name === name
		);
		return !!bookmarkFound;
	}

	// Find is any temporary bookmark exist
	public isAnyTemporaryBookmarkExist(): boolean {
		return (
			this.bookmarksList.filter(bookmark => !!bookmark.parentId).length > 0
		);
	}

	// Find is any temporary bookmark exist
	public isCurrentBookmarkTemporary(): boolean {
		const bookmarkFound: Bookmark = this.getBookmarkByKey(
			this.selectedBookmarkKey
		);
		return bookmarkFound && !!bookmarkFound.parentId;
	}

	// =================== apis for add , delete , up date and retrive bookmark Ends ===========================

	// Small interal API to know states of bookmark

	// Get default bookmark id
	private getDefaultBookmarkKey(): number {
		const deafultBookmark: Bookmark = this.bookmarksList.find(
			bookmark => bookmark.name && bookmark.name === defalutSettingsName
		);
		if (deafultBookmark) {
			return deafultBookmark.key;
		}
		return -1;
	}

	// Get corresponding temporary bookmark of givin parent id
	private getCorrespondingTempBookmark(key: number): Bookmark {
		const correspondingBookmark: Bookmark = this.bookmarksList.find(
			bookmark => bookmark.parentId && bookmark.parentId === key
		);
		return correspondingBookmark;
	}

	// Find is bookmark list is empty
	private isAnyBookmarkExist(): boolean {
		return this.bookmarksList ? this.bookmarksList.length > 0 : false;
	}

	// is Currently default bookmark selected
	private isModifiedBookmarkTemporary(): boolean {
		const selectedBookmark: Bookmark = this.getBookmarkByKey(
			this.selectedBookmarkKey
		);
		console.debug(
			"BookmarkService::isModifiedBookmarkTemporary",
			selectedBookmark,
			selectedBookmark && selectedBookmark.parentId
		);
		return selectedBookmark && selectedBookmark.parentId ? true : false;
	}

	// is Currently default bookmark selected
	private isDefaultBookmarkSelected(): boolean {
		const selectedBookmark: Bookmark = this.getBookmarkByKey(
			this.selectedBookmarkKey
		);
		return selectedBookmark && selectedBookmark.name === defalutSettingsName;
	}

	// is Currently default bookmark selected
	private isDefaultBookmarkExist(): boolean {
		const correspondingBookmark: Bookmark = this.bookmarksList.find(
			bookmark => bookmark && bookmark.name === defalutSettingsName
		);
		return correspondingBookmark ? true : false;
	}
	// Get bookmark by bookmark key
	private getBookmarkByKey(id: number): Bookmark {
		return this.bookmarksList.find(bookmark => bookmark.key === id);
	}

	// Sort bookmark list by updated timestamp
	private sortBookmarkList(): void {
		this.bookmarksList = this.bookmarksList.sort((a: Bookmark, b: Bookmark) => {
			if (a.updatedTime === b.updatedTime) {
				return 0;
			} else if (a.updatedTime < b.updatedTime) {
				return 1;
			} else {
				return -1;
			}
		});
	}

	private informBookmarkListListener(): void {
		this.bookmarkList$.next(this.bookmarksList);
		if (this.bookmarksList[0]) {
			this.selectedBookmarkKey = this.bookmarksList[0].key;
		}
	}

	private updateBookmarkKeyAndNotifyListener(key: number): void {
		this.selectedBookmarkKey = key;
		this.selectedBookmarkKeyChangeNotifier$.next(key);
	}

	// Remove temporary bookmark from UI
	private removeTemporaryBookmarkFromUI(): void {
		this.bookmarksList = this.bookmarksList.filter(
			(bookmark: Bookmark) => !bookmark.parentId
		);
		this.sortBookmarkList();
	}

	// Restore bookmark in UI
	private restoreBookmarkInUI(restoreBookmakrs: Bookmark[]): void {
		this.bookmarksList = this.bookmarksList.concat(restoreBookmakrs);
		this.sortBookmarkList();
		this.informBookmarkListListener();
	}
}
