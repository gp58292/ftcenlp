import {
	ChangeDetectionStrategy,
	ChangeDetectorRef,
	Component,
	OnInit,
	ViewEncapsulation
} from "@angular/core";
import { MatDialog, MatDialogRef, MatSelectChange } from "@angular/material";
import { ConfirmationDialogComponent } from "@aqua/filters/data-finder/confirmation-dialog/confirmation-dialog.component";
import { SearchService } from "@aqua/filters/data-finder/search/search.service";
import { Bookmark, SearchField } from "@aqua/filters/models";
import { DialogSaveAsComponent } from "app/filters/data-finder/bookmark/dialog-save-as/dialog-save-as.component";
import { DataTreeStorageService } from "app/filters/services/datatree-storage.service";
import { VizNotificationService } from "app/services/viz-notification.service";
import { Subject } from "rxjs";
import { distinctUntilChanged, takeUntil } from "rxjs/operators";

import {
	FilterDisplayService,
	SearchFieldStates
} from "../search/controls/filter-display";
import { BookmarkRequest } from "./bookmark-request.model";
import { BookmarkService } from "./bookmark.service";

@Component({
	selector: "bookmark-panel",
	templateUrl: "./bookmark.component.html",
	styleUrls: ["./bookmark.component.scss"],
	encapsulation: ViewEncapsulation.Emulated,
	changeDetection: ChangeDetectionStrategy.OnPush
})
export class BookmarkComponent implements OnInit {
	public bookmarks: any[];
	private alive: Subject<void> = new Subject<void>();

	private currentCriteria: SearchField[];

	private dialogRef: MatDialogRef<ConfirmationDialogComponent, null>;

	private _selectedBookmarkKey: number = -1;

	public get selectedBookmarkKey() {
		const key: number = this.bookmarkService.getSelectedBookmarkKey();
		if (this._selectedBookmarkKey !== key) {
			this._selectedBookmarkKey = key;
			this._changeDetectorRef.markForCheck();
		}
		return this._selectedBookmarkKey;
	}
	public set selectedBookmarkKey(key: number) {
		this.bookmarkService.updateSelectedBookmarkKey(key);
	}

	constructor(
		private bookmarkService: BookmarkService,
		private vizNotification: VizNotificationService,
		private dialog: MatDialog,
		private searchService: SearchService,
		private dataStorageTreeService: DataTreeStorageService,
		private filterDisplayService: FilterDisplayService,
		private _changeDetectorRef: ChangeDetectorRef
	) {
		console.debug("BookmarkComponent::constructor");
	}

	public openConfirmationDialog() {
		const isTemporary: boolean = this.bookmarkService.isCurrentBookmarkTemporary();
		this.dialogRef = this.dialog.open(ConfirmationDialogComponent, {
			panelClass: "confirm-dailog-container",
			data: {
				confirmationMessage: isTemporary
					? "Are you sure you want to delete temporary and load original"
					: "Are you sure you want to delete ?"
			},
			disableClose: false
		});

		this.dialogRef
			.afterClosed()
			.pipe(takeUntil(this.alive))
			.subscribe(result => {
				if (result) {
					// do confirmation actions
					if (this.selectedBookmarkKey !== -1) {
						this.deleteBookmark(this.selectedBookmarkKey);
					} else {
						this.vizNotification.showError(
							"Unable to delete bookmark as no bookmark is selected"
						);
					}
				}
				this.dialogRef = null;
			});
	}

	public ngOnInit() {
		console.debug("BookmarkComponent::ngOnInit");
		this.bookmarkService.loadAllBookmarks();
		this.listenBookmarks();
		this.monitorCriteriaChange();
		this.listenBookmarkKeyChange();
	}
	public ngOnDestroy() {
		console.debug("BookmarkComponent::ngOnDestroy");

		this.alive.next();
		this.alive.complete();
		this.alive.unsubscribe();
	}
	public listenBookmarks() {
		console.debug("BookmarkComponent::listenBookmark");
		this.bookmarkService
			.getBookmarkListNotification()
			.pipe(takeUntil(this.alive))
			.subscribe((bookmarks: Bookmark[]) => {
				console.debug(
					"BookmarkComponent::listenBookmarks::Got bookmark list ::",
					bookmarks
				);
				if (bookmarks) {
					if (bookmarks.length > 0) {
						this.bookmarks = bookmarks;
						this.bookmarkService.loadBookmark(this.selectedBookmarkKey);
					} else {
						this.clearBookmarkState();
						// navigate to settings
						if (this.bookmarks == null) {
							this.vizNotification.showMessage("Please select search fields");
							// this.selectedTabIndex = 1;
						} else {
							this.bookmarks = [];
						}
					}
				}
			});
	}

	public onBookmarkChange(matSelectChange: MatSelectChange) {
		console.debug(
			"BookmarkComponent::onSearchCriteriaChange : " + matSelectChange.value
		);
		this.searchService.clearSearchResult();
		// this.selectedBookmarkKey = matSelectChange.value;
		this.bookmarkService.loadBookmark(this.selectedBookmarkKey);
	}

	/*onDeleteBookmark() {
        console.debug("BookmarkComponent::onDeleteBookmark");
        if (this.selectedBookmarkKey != -1) {
            this.deleteBookmark(this.selectedBookmarkKey);
        }
        else {
            this.vizNotification.showError('Unable to delete bookmark as no bookmark is selected');

        }
    }*/

	public clearBookmarkState() {
		this.dataStorageTreeService.clearAllFilters();
		this.searchService.clearSearchResult();
		this.selectedBookmarkKey = -1;
		this.bookmarkService.loadBookmark(this.selectedBookmarkKey);
	}

	public onNewBookmark() {
		console.debug("BookmarkComponent::onNewBookmark");
		this.clearBookmarkState();
		this.selectedBookmarkKey = -1;
	}

	public deleteBookmark(id) {
		console.debug("BookmarkComponent::deleteBookmark");
		this.bookmarkService.deleteBookmark(id);
		// .pipe(takeUntil(this.alive))
		// .subscribe((respone: AppHttpResponse<boolean>) => {
		// 	console.debug("BookmarkComponent::deleteBookmark::", respone);
		// 	if (respone.responseStatus === 200) {
		// 		this.vizNotification.showMessage("Bookmark deleted successfully");
		// 		const isTemporary: boolean = this.bookmarkService.isCurrentBookmarkTemporary();
		// 		const bookmark: Bookmark = this.bookmarkService.getSelectedBookmark();
		// 		if (isTemporary) {
		// 			this.selectedBookmark = bookmark.parentId;
		// 		} else {
		// 			this.bookmarkService.loadAllBookmarks();
		// 		}
		// 	} else {
		// 		this.vizNotification.showError(
		// 			"Failed to delete bookmark" + respone.restError &&
		// 				respone.restError.errorMessage
		// 		);
		// 	}
		// });
	}
	public onSaveAs(
		title?: string,
		newBookmarkName?: string,
		isDefault: boolean = false
	) {
		console.debug("BookmarkComponent::onSaveAs");

		const dialogRef = this.dialog.open(DialogSaveAsComponent, {
			panelClass: "confirm-dailog-container",
			data: {
				name: "",
				bookmarkName: newBookmarkName,
				type: title ? title : "Save Bookmark As"
			}
		});

		dialogRef.afterClosed().subscribe((bookmarkName: string) => {
			console.debug(
				"BookmarkComponent::onSaveAs::The dialog was closed, user has enter criteriaName as :" +
					bookmarkName,
				this.bookmarkService.isBookmarkNameExist(bookmarkName)
			);
			if (bookmarkName) {
				bookmarkName = bookmarkName.trim();
				if (bookmarkName !== "") {
					if (this.bookmarkService.isBookmarkNameExist(bookmarkName)) {
						this.vizNotification.showError(
							"Bookmark name already exists, please choose another name."
						);
					} else {
						console.debug(
							"BookmarkComponent::onSaveAs::The dialog was closed, user has enter criteriaName as :",
							bookmarkName,
							this.bookmarkService.isBookmarkNameExist(bookmarkName)
						);
						if (!isDefault) {
							const bookmarkRequest: BookmarkRequest = new BookmarkRequest();
							bookmarkRequest.addSearchCriteria(this.currentCriteria);
							bookmarkRequest.bookmarkName = bookmarkName;

							this.bookmarkService.wrapperAddBookmark(bookmarkRequest);
						} else {
							const bookmarkRequest: BookmarkRequest = new BookmarkRequest();
							bookmarkRequest.addSearchCriteria(this.currentCriteria);
							bookmarkRequest.bookmarkId = this.selectedBookmarkKey;
							bookmarkRequest.bookmarkName = bookmarkName;
							bookmarkRequest.isReload = true;
							this.bookmarkService.wrapperUpdateBookmark(bookmarkRequest);
						}
					}
				} else {
					this.vizNotification.showError("Bookmark name can not be blank");
				}
			}
		});
	}
	public onSave() {
		console.debug("BookmarkComponent::onSave", this.currentCriteria);
		//  this.bookmarkService.createOrUpdateBookmark(this.fields);
		const bookmark: Bookmark = this.bookmarkService.getDefaultBookmarkIfSelected();

		console.debug(
			"BookmarkComponent::onSave",
			bookmark,
			this.selectedBookmarkKey,
			this.bookmarkService.isCurrentBookmarkTemporary()
		);
		if (bookmark) {
			this.onSaveAs("Save Bookmark", bookmark.name, true); // Show bookmark dialog so user can enter a name
		} else if (this.selectedBookmarkKey === -1) {
			this.onSaveAs("Save Bookmark", ""); // Show bookmark dialog so user can enter a name
		} else if (this.bookmarkService.isCurrentBookmarkTemporary()) {
			// TODO :: Write confirmation dialog before replacing original with temporary

			const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
				panelClass: "confirm-dailog-container",
				data: {
					confirmationMessage:
						"Do you want to override original version and delete temporary"
				},
				disableClose: false
			});

			dialogRef.afterClosed().subscribe((result: any) => {
				// console.debug("BookmarkComponent::onSave:: Bookmark Replace::", result);
				if (result) {
					const bookmarkRequest: BookmarkRequest = new BookmarkRequest();
					bookmarkRequest.addSearchCriteria(this.currentCriteria);
					bookmarkRequest.bookmarkId = this.selectedBookmarkKey;
					this.bookmarkService.updateOriginalAndDeleteTemporaryBookmark(
						bookmarkRequest
					);
				}
			});
		} else {
			const bookmarkRequest: BookmarkRequest = new BookmarkRequest();
			bookmarkRequest.addSearchCriteria(this.currentCriteria);
			bookmarkRequest.bookmarkId = this.selectedBookmarkKey;

			this.bookmarkService.wrapperUpdateBookmark(bookmarkRequest);
		}
	}

	// Delete temporary bookmarks
	public deleteTemporary(): void {
		console.debug("BookmarkComponent::deleteTemporary::");
		if (this.bookmarkService.isAnyTemporaryBookmarkExist()) {
			this.dialogRef = this.dialog.open(ConfirmationDialogComponent, {
				panelClass: "confirm-dailog-container",
				data: {
					confirmationMessage: "Do you really want to delete all temporary ?"
				},
				disableClose: false
			});

			this.dialogRef
				.afterClosed()
				.pipe(takeUntil(this.alive))
				.subscribe(result => {
					if (result) {
						this.bookmarkService.deleteTempBookmarkWrapper();
					}
					this.dialogRef = null;
				});
		} else {
			this.vizNotification.showError(
				"No temporary bookmarks available to delete"
			);
		}
	}

	// Restore temporary bookmarks
	public restoreTemporary(): void {
		console.debug("BookmarkComponent::restoreTemporary::");
		this.bookmarkService.restoreAllBookmarkByUserId();
	}

	// Listen data change
	private monitorCriteriaChange(): void {
		this.filterDisplayService
			.getAsObservable()
			.pipe(
				takeUntil(this.alive),
				distinctUntilChanged()
			)
			.subscribe((searchFieldStates: SearchFieldStates) => {
				// console.debug("BookmarkComponent::monitorCriteriaChange::", searchFieldStates);
				this.currentCriteria = searchFieldStates.fields;
			});
	}

	private listenBookmarkKeyChange(): void {
		this.bookmarkService.selectedBookmarkKeyChangeNotifier$
			.pipe(takeUntil(this.alive))
			.subscribe((key: number) => {
				console.debug(
					"BookmarkComponent::listenBookmarkKeyChange::selectedBookmarkKeyChangeNotifier$::",
					key
				);
				this._changeDetectorRef.detectChanges();
			});
	}
}
