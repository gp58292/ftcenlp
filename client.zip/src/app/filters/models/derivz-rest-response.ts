import { DerivzRestApiError } from "./derivz-rest-api-error";

export interface DerivzRestResponse<T> {
	responseStatus: number;
	restError: DerivzRestApiError;
	responseData: T | any;
}
