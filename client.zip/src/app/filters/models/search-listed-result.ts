import { Agreement } from "./agreement";

export interface SearchListedResult {
	count: number;
	cobDate: string;
	searchCriteriaResultList: Agreement[];
}
