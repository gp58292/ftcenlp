import { TableNode } from "@aqua/filters/models/table-node";

export interface Group {
	name: string;
	children: TableNode[];
}
