export interface RatingRanking {
	ratingRankingKey: number;

	moodyLongTerm: string;
	moodyLongTermRank: number;
	moodyShortTerm: string;
	moodyShortTermRank: string;

	spLongTerm: string;
	spLongTermRank: number;
	spShortTerm: string;
	spShortTermRank: string;

	fitchLongTerm: string;
	fitchLongTermRank: number;
	fitchShortTerm: string;
	fitchShortTermRank: string;
}
