export interface DerivzRestApiError {
	errorMessage: string;
	errorCode: string;
}
