import { Injectable, OnDestroy } from "@angular/core";
import { cloneDeep } from "lodash";

import { Group, SearchField } from "@aqua/filters/models";
import { AppHttpResponse } from "@aqua/models";
import { Observable, Subject } from "rxjs";
import { takeUntil } from "rxjs/operators";
import { SettingsService } from "../data-finder/settings/settings.service";

@Injectable()
export class DataTreeStorageService implements OnDestroy {
	public originalFlatCopy: any;
	public originalGroupedCopy: any;
	// Who can trees
	private flatTree: any[];
	private groupTree: any[];

	// Who has trees
	private flatTreeWhoHas: any[];
	private groupTreeWhoHas: any[];

	private whoCanWhoHas: "has" | "can" = "can";

	private flatTreeNotifier = new Subject<any[]>();
	private groupDataTreeNotifier = new Subject<any[]>();
	private filteredField = new Subject<any>();
	private whoCanWhoHasChanged = new Subject<"has" | "can">();

	private alive: Subject<void> = new Subject();
	private nodeUpdatedNotifier = new Subject<boolean>();
	private resetFormNotifier = new Subject<boolean>();

	/**
	 * @name  :constructor
	 * @description :
	 */
	constructor(private searchSettingService: SettingsService) {
		console.debug("DataTreeStorageService::constructor");
		this.getSettingsFlatData();
		this.getSettingsTreeData();
	}

	public ngOnDestroy() {
		this.alive.next();
		this.alive.complete();
		this.alive.unsubscribe();
	}
	/**
	 * @name  :getSettingsFlatData
	 * @description :
	 */
	public getSettingsFlatData() {
		console.debug("SearchSettingsComponent::getFilterListForTreeView");
		this.searchSettingService.getFilterListForFlatView().subscribe(
			(response: AppHttpResponse<SearchField[]>) => {
				this.originalFlatCopy = cloneDeep(response.responseData);
				this.flatTree = cloneDeep(response.responseData);
				this.setHasFields(cloneDeep(response.responseData), "flat");
				this.setCanFields(cloneDeep(response.responseData), "flat");
				this.flatTreeNotifier.next(this.flatTree);
			},
			() => {
				// fetch from static file
				fetch("data/TreeDataFlat.json")
					.then(resp => resp.json())
					.catch(err => err.essage)
					.then(values => {
						this.originalFlatCopy = cloneDeep(values);
						this.flatTree = cloneDeep(values);
						this.setCanFields(values, "flat");
						this.setHasFields(values, "flat");
						this.flatTreeNotifier.next(this.flatTree);
					});
			}
		);
	}

	/**
	 * @name  :getSettingsTreeData
	 * @description :
	 */
	public getSettingsTreeData() {
		console.debug("SearchSettingsComponent::getFilterListForTreeView");
		this.searchSettingService
			.getFilterListForTreeView()
			.pipe(takeUntil(this.alive))
			.subscribe(
				(response: AppHttpResponse<Group[]>) => {
					this.originalGroupedCopy = cloneDeep(response.responseData);
					this.groupTree = cloneDeep(response.responseData);
					this.setHasFields(cloneDeep(response.responseData), "grouped");
					this.setCanFields(cloneDeep(response.responseData), "grouped");
					this.groupDataTreeNotifier.next(this.groupTree);
				},
				() => {
					// fetch from static file
					// Get grouped DataTree and alert subscriber
					fetch("data/TreeData.json")
						.then(resp => resp.json())
						.catch(err => err.essage)
						.then(values => {
							this.originalGroupedCopy = cloneDeep(values);
							this.groupTree = cloneDeep(values);
							this.setCanFields(values, "grouped");
							this.setHasFields(values, "grouped");
							this.groupDataTreeNotifier.next(this.groupTree);
						});
				}
			);
	}

	/**
	 * @name  :getTree
	 * @description :
	 */
	public getTree(type?: "flat" | "grouped") {
		if (type === "grouped") {
			return this.getCurrentTreeStructureInView(
				"grouped",
				this.whoCanWhoHas === "can" ? 0 : 1
			);
		}
		return this.getCurrentTreeStructureInView(
			"flat",
			this.whoCanWhoHas === "can" ? 0 : 1
		);
	}

	/**
	 * @name  :updateNode
	 * @description : Given a given filterField it finds that field in both trees and toggles the
	 *                appropiate flag( 'exported || 'filtered')
	 */
	// TODO currently we check for matching key. We should also check the whocan whohas flags match up because a field can be in both sections
	public updateNode(filter: any, toggleFilterOrExport: "filter" | "export") {
		console.debug("DataTreeStorageService::updateNode filter", filter);

		// Update Flat Tree
		let myWorkNodeElement = this.getCurrentTreeStructureInView(
			"flat",
			filter.whoHasFlag
		) as any;
		myWorkNodeElement = myWorkNodeElement.find(obj => {
			return obj.name === filter.logicalGroupName;
		});
		console.debug(
			"DataTreeStorageService::updateNode flat parent",
			myWorkNodeElement,
			myWorkNodeElement.children
		);

		myWorkNodeElement = myWorkNodeElement.children.find(obj => {
			return obj.key === filter.key && obj.whoHasFlag === filter.whoHasFlag;
		});
		if (myWorkNodeElement) {
			console.debug(
				"DataTreeStorageService::updateNode flat itemFilter",
				myWorkNodeElement
			);
			myWorkNodeElement.filtered = !myWorkNodeElement.filtered;
			this.getCurrentTreeStructureInView("flat", filter.whoHasFlag);

			this.flatTreeNotifier.next(
				this.getCurrentTreeStructureInView(
					"flat",
					this.whoCanWhoHas === "can" ? 0 : 1
				)
			);
		}
		// Update grouped tree
		// Point the first node to the top of the tree.
		myWorkNodeElement = this.getCurrentTreeStructureInView(
			"grouped",
			filter.whoHasFlag
		) as any;
		/* Filter struct info
            - logicalGroupName: either MAC,SMC,or BOX  LEVEL 1
            - nodeName: the table name                 LEVEL 2
        */

		// Find filter and update the node. We must traverse the tree and update the bottom most child in question.
		let index = myWorkNodeElement.findIndex(obj => {
			return obj.name === filter.logicalGroupName;
		});
		console.debug("DataTreeStorageService::updateNode grouped", filter, index);
		// Next level. Pointed to the highest level
		myWorkNodeElement = myWorkNodeElement[index].children;
		console.debug(
			"DataTreeStorageService::updateNode grouped topNode found",
			myWorkNodeElement
		);
		// Find the table where the 'filter' var belongs.
		index = myWorkNodeElement.findIndex(obj => {
			return obj.name === filter.nodeDisplayName;
		});
		console.debug(
			"DataTreeStorageService::updateNode grouped index after topNode",
			index,
			myWorkNodeElement[index]
		);

		// Now set the myWorkNodeElement to that index. We are at the table level.
		myWorkNodeElement = myWorkNodeElement[index].children as any;
		console.debug(
			"DataTreeStorageService::updateNode grouped direct parent found"
		);
		// Next we must traverse all the columns in the table to find the table we want.
		index = myWorkNodeElement.findIndex(obj => {
			return obj.key === filter.key && obj.whoHasFlag === filter.whoHasFlag;
		});
		// Now we have reached the bottom most filter level and can now update the filter.
		myWorkNodeElement = myWorkNodeElement[index] as any;
		if (!myWorkNodeElement) {
			return;
		}
		console.debug(
			"DataTreeStorageService::updateNode grouped final node found"
		);
		if (toggleFilterOrExport === "filter") {
			myWorkNodeElement.filtered = !myWorkNodeElement.filtered;
		}
		const data = this.getCurrentTreeStructureInView(
			"grouped",
			filter.whoHasFlag
		);
		this.groupDataTreeNotifier.next(
			this.getCurrentTreeStructureInView(
				"grouped",
				this.whoCanWhoHas === "can" ? 0 : 1
			)
		);
		// console.debug('DataTreeStorageService::updateNode grouped final node found::',myWorkNodeElement['value'],filter.value);
		myWorkNodeElement.value = filter.value;
		// console.debug('DataTreeStorageService::updateNode final node updated value::',filter,myWorkNodeElement);
		this.filteredField.next({
			fieldIn: cloneDeep(myWorkNodeElement),
			section: myWorkNodeElement.whoHasFlag === 1 ? "has" : "can"
		});
	}

	public listenNodeUpdatedState(): Observable<boolean> {
		console.debug("DataTreeStorageService::listenNodeUpdatedState");
		return this.nodeUpdatedNotifier.asObservable();
	}

	public setNodeUpdated(status) {
		this.nodeUpdatedNotifier.next(status);
	}

	public listenResetFormState(): Observable<boolean> {
		console.debug("DataTreeStorageService::listenResetFormState");
		return this.resetFormNotifier.asObservable();
	}

	public setResetFormStatus(status) {
		this.resetFormNotifier.next(status);
	}

	/**
	 * @name  :listenState
	 * @description :
	 */
	public listenState(): Observable<any> {
		console.debug("DataTreeStorageService::listenState");
		return this.flatTreeNotifier.asObservable();
	}
	/**
	 * @name  :listenStateGroupTree
	 * @description :
	 */
	public listenStateGroupTree(): Observable<any> {
		console.debug("DataTreeStorageService::listenStateGroupTree");
		return this.groupDataTreeNotifier.asObservable();
	}
	/**
	 * @name  :listenForFilteredField
	 * @description :
	 */
	public listenForFilteredField(): Observable<any> {
		return this.filteredField.asObservable();
	}
	public listenForWhoHasWhoCanChanged(): Observable<any> {
		return this.whoCanWhoHasChanged.asObservable();
	}
	/**
	 * @name  :treeIterator
	 * @description :
	 */
	public treeIterator(
		searchCriteria: string,
		data: any[],
		ipath: string,
		filteredTree: any[],
		type?: "flat" | "grouped"
	) {
		// console.debug("DataTreeStorageService::treeIterator");
		if (searchCriteria === "") {
			if (type === "grouped") {
				filteredTree = data;
				return filteredTree;
			}
			return this.getCurrentTreeStructureInView(
				"flat",
				this.whoCanWhoHas === "can" ? 0 : 1
			);
		}
		const struct = false;

		for (const tNode of data) {
			let path = ipath;
			// console.debug("DataTreeStorageService::treeIterator tNode", tNode);
			if (tNode.children && tNode.children.length > 0) {
				path += path ? "|" + tNode.name : tNode.name;
				this.treeIterator(searchCriteria, tNode.children, path, filteredTree);
			} else {
				const match: boolean =
					tNode.name.toLowerCase().indexOf(searchCriteria.toLowerCase()) >= 0;
				// console.debug("DataTreeStorageService::treeIterator match", match);
				// Clone function
				if (match) {
					path += path ? "|" + tNode.name : tNode.name;
					this.cloneNode(tNode, path, filteredTree);
				}
			}
		}
		return struct;
	}
	// TODO look for improved way to do this
	// Improved from before but could maybe use more improvement

	/**
	 * @name  :clearAllFilters
	 * @description :
	 */
	public clearAllFilters() {
		console.debug("DataTreeStorageService::clearAllFilters");
		this.flatTree &&
			this.flatTree.forEach(topNode => {
				topNode.children.forEach(filter => {
					filter.filtered = false;
				});
			});
		this.flatTreeWhoHas &&
			this.flatTreeWhoHas.forEach(topNode => {
				topNode.children.forEach(filter => {
					filter.filtered = false;
				});
			});

		this.groupTree &&
			this.groupTree.forEach(topNode => {
				topNode.children.forEach(tableNode => {
					tableNode.children.forEach(filter => {
						filter.filtered = false;
					});
				});
			});
		this.groupTreeWhoHas &&
			this.groupTreeWhoHas.forEach(topNode => {
				topNode.children.forEach(tableNode => {
					tableNode.children.forEach(filter => {
						filter.filtered = false;
					});
				});
			});
		// TODO on reset do we want to reset only the selected section (Who Can / Who has fields) or reset all.
		// this.setCanFields(cloneDeep(this.originalFlatCopy),'flat')
		// this.setHasFields(cloneDeep(this.originalFlatCopy),'flat')
		// this.setCanFields(cloneDeep(this.originalGroupedCopy),'grouped')
		// this.setHasFields(cloneDeep(this.originalGroupedCopy),'grouped')

		this.filteredField.next("Clear All");

		this.flatTreeNotifier.next(
			this.getCurrentTreeStructureInView(
				"flat",
				this.whoCanWhoHas === "can" ? 0 : 1
			)
		);
		this.groupDataTreeNotifier.next(
			this.getCurrentTreeStructureInView(
				"grouped",
				this.whoCanWhoHas === "can" ? 0 : 1
			)
		);
	}

	/**
	 * @name  :setFiltersBasedOfBookmark
	 * @description :
	 */
	public setFiltersBasedOfBookmark(fields: any) {
		console.debug("DataTreeStorageService::setFiltersBasedOfBookmark", fields);
		this.clearAllFilters();
		fields.forEach(field => {
			console.debug("DataTreeStorageService::set filters");
			field.filtered = false;
			this.updateNode(field, "filter");
		});
	}

	public toggleWhoCanWhoHasTree(type: "can" | "has") {
		console.debug(
			"DataTreeStorageService::toggleWhoCanWhoHasTree",
			this.whoCanWhoHas,
			type
		);
		this.whoCanWhoHasChanged.next(type);
		if (this.whoCanWhoHas === type) {
			return;
		}
		this.whoCanWhoHas = type;
		this.flatTreeNotifier.next(
			this.getCurrentTreeStructureInView(
				"flat",
				this.whoCanWhoHas === "can" ? 0 : 1
			)
		);
		this.groupDataTreeNotifier.next(
			this.getCurrentTreeStructureInView(
				"grouped",
				this.whoCanWhoHas === "can" ? 0 : 1
			)
		);
	}

	/**
	 * @name  :cloneNode
	 * @description :
	 */
	private cloneNode(node: any, path: string, filteredTree: any[]) {
		const pathHeirachy = path.split("|");
		// console.debug("DataTreeStorageService::cloneNode", path, pathHeirachy);
		let myWorkNodeElement: any[] = filteredTree;
		// console.debug("DataTreeStorageService::cloneNode pointer", myWorkNodeElement);
		// 2. To go through path and create Nodes as needed
		for (const p of pathHeirachy) {
			// console.debug("DataTreeStorageService::cloneNode pathHeirachy p", p);
			// Get children on myWorkNodeElement if it exists:
			const index = myWorkNodeElement.findIndex(obj => {
				return obj.name === p;
			});
			// console.debug("DataTreeStorageService::cloneNode index p", index);
			// The heirachy does not exist so we must add it to the filteredTree
			if (index === -1) {
				// Last level of heiracrhy
				if (pathHeirachy.indexOf(p) === pathHeirachy.length - 1) {
					myWorkNodeElement.push(node);
				} else {
					myWorkNodeElement.push({ name: p, children: [] });
				}
				myWorkNodeElement =
					myWorkNodeElement[myWorkNodeElement.length - 1].children; // Points to the latest inserted element;
			} else {
				myWorkNodeElement = myWorkNodeElement[index].children;
			}
		}
		// Update subscriber
		// this.subject.next(filteredTree);
		return filteredTree;
	}

	private setHasFields(data, typeTree: "flat" | "grouped") {
		console.debug(
			"DataTreeStorageService::setHasFields",
			JSON.parse(JSON.stringify(data))
		);
		if (typeTree === "flat") {
			data.forEach(topNode => {
				topNode.children = topNode.children.filter(field => {
					// if (field.filterOnlyFlag === 0) return field.whoHasFlag === 1;
					// else return false;
					return field.whoHasFlag === 1;
				});
			});
			this.flatTreeWhoHas = data;
			console.debug(
				"DataTreeStorageService::setHasFields whohasflat",
				JSON.parse(JSON.stringify(data))
			);
		} else if (typeTree === "grouped") {
			data.forEach(node => {
				node.children.forEach(tableName => {
					tableName.children = tableName.children.filter(field => {
						return field.whoHasFlag === 1;
					});
				});
			});
			console.debug(
				"DataTreeStorageService::setHasFields whohasgroup",
				JSON.parse(JSON.stringify(data))
			);
			this.groupTreeWhoHas = data;
		}
	}

	private setCanFields(data, typeTree: "flat" | "grouped") {
		console.debug(
			"DataTreeStorageService::setCanFields",
			JSON.parse(JSON.stringify(data))
		);
		if (typeTree === "flat") {
			data.forEach(topNode => {
				topNode.children.forEach(field => {
					if (field.filterOnlyFlag === 0) {
						field.whoHasFlag = 0;
					}
				});
			});

			data.forEach(topNode => {
				topNode.children.forEach(field => {
					if (field.filterOnlyFlag === 0) {
						field.whoHasFlag = 0;
					}
				});
			});

			console.debug(
				"DataTreeStorageService::setCanFields flattree",
				JSON.parse(JSON.stringify(data))
			);
			this.flatTree = data;
		} else if (typeTree === "grouped") {
			data.forEach(topNode => {
				topNode.children.forEach(tableNode => {
					tableNode.children.forEach(filter => {
						if (filter.filterOnlyFlag === 0) {
							filter.whoHasFlag = 0;
						}
					});
				});
			});
			this.groupTree = data;
			console.debug(
				"DataTreeStorageService::setCanFields whocangroup",
				JSON.parse(JSON.stringify(data)),
				this.groupTree
			);
		}
	}
	private getCurrentTreeStructureInView(
		type: "grouped" | "flat",
		whoHasFlag: 0 | 1
	) {
		if (type === "flat") {
			return whoHasFlag === 0 ? this.flatTree : this.flatTreeWhoHas;
		}
		return whoHasFlag === 0 ? this.groupTree : this.groupTreeWhoHas;
	}
}
