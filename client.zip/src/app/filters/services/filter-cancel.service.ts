import { Injectable, OnDestroy } from "@angular/core";
import { VizNotificationService } from "@aqua/services";
import { Subject } from "rxjs";
import { Observable } from "rxjs";
import { debounceTime } from "rxjs/operators";

@Injectable()
export class FilterCancelService implements OnDestroy {
	private cancel: Subject<void> = new Subject();

	constructor(private vizNotificationService: VizNotificationService) {
		console.debug("CancelService::constructor");
		this.watchCancel();
	}
	public getSubject(): Observable<void> {
		return this.cancel;
	}
	public cancelSubject(): void {
		console.debug("CancelService::cancelSubject::", this.cancel);
		if (this.cancel && !this.cancel.isStopped) {
			this.cancel.next();
		}
	}
	public ngOnDestroy() {
		this.cancel.complete();
		this.cancel.unsubscribe();
		this.cancel = undefined;
	}

	public watchCancel(): void {
		this.cancel.pipe(debounceTime(200)).subscribe(() => {
			this.vizNotificationService.showMessage(
				"Cancelled search request successfully"
			);
		});
	}
}
