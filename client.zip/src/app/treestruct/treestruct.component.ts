import { Component, Input, OnChanges, OnInit } from "@angular/core";
import { ComponentType } from "@aqua/filters/models";
import { DataTreeStorageService } from "@aqua/filters/services";
import { EnvironmentVersion } from "@aqua/models/dto";
import { ReferencesDataService } from "@aqua/services";

/**
 * @name: TreeStructComponent
 * @description: Place where the components are dragged from the Dataset browser to get the latest specifications
 */
@Component({
	// tslint:disable-next-line:component-selector
	selector: "tree-struct",
	templateUrl: "./treestruct.component.html",
	styleUrls: ["./treestruct.component.scss"]
})
export class TreeStructComponent implements OnInit, OnChanges {
	@Input() public fieldObj: any;
	@Input() public parent?: string;
	@Input() public children: any[];
	@Input() public level: number;
	@Input() public filtering: boolean;
	@Input() public shrinkAll: boolean;
	@Input() public addedFilter: boolean = false;
	@Input() public whoCanWhoHas: "can" | "has";

	public componentType: any = ComponentType;

	private treeStructPadding: string;
	private nextLevel: number;
	private nodeFontSize: string;
	private hideChildList: boolean = false;
	private expandShrinkIcon: string;

	private childrenCount: number;
	private whoCanFlagsAgree: boolean;

	constructor(
		private dataStorageTreeService: DataTreeStorageService,
		private referencesDataService: ReferencesDataService
	) {
		// console.debug('TreeStructComponent::constructor');
	}

	/**
	 * @name ngOnInit()
	 * @description Called on the initialization of the component.
	 */
	public ngOnInit() {
		// console.debug('TreeStructComponent::ngOnInit');
	}

	public ngOnChanges() {
		// console.debug("TreeStructComponent::ngOnChanges showSelected",' shirnk',this.shrinkAll);
		this.nextLevel = this.level + 1;
		this.determinePadding(this.level);
		this.setFontSize(this.level);
		this.expandShrinkIcon = this.hideChildList
			? "fa caret-right"
			: "fa caret-down";
		this.determineViewableResultsDuringFiltering();
		if (this.fieldObj) {
			this.addedFilter = this.fieldObj.filtered;
		}

		// if(this.showSelected && !this.children)
		//     this.hideUnselected();

		// if(this.showSelected)
		//     this.hideParentsifNoVisibleChildren();
		// if(!this.showSelected && this.tempChildren){
		//     this.children=this.tempChildren;
		// }
		if (this.level === 1) {
			this.calculateChildrenCount();
		}

		this.whoCanFlagsAgree = this.children
			? true
			: this.whoCanWhoHas === "can"
			? true
			: this.whoCanWhoHas === "has" && this.fieldObj.whoHasFlag === 1
			? true
			: false;
		this.hideChildList = !this.whoCanFlagsAgree || this.shrinkAll;
		// if(this.filtering){
		//     this.shrinkAll=false;
		//     this.hideChildList=false;
		// }
	}

	public hideChild() {
		// console.debug("TreeStructComponent::hideChild");
		// If in shrunken state turn it off when expand carrot is click
		this.hideChildList = !this.hideChildList;
		if (this.shrinkAll) {
			if (this.level !== 1) {
				this.shrinkAll = false;
			} else if (this.level === 1) {
				this.hideChildList = false;
				this.shrinkAll = false;
			}
		}
		this.expandShrinkIcon = this.hideChildList
			? "keyboard_arrow_right"
			: "keyboard_arrow_down";
	}

	public isShowType(): boolean {
		return (
			!this.hideChildList &&
			!this.children &&
			this.fieldObj &&
			(this.getEnvName() === "windev" || this.getEnvName() === "dev")
		);
	}
	public getEnvName(): string {
		const env: EnvironmentVersion = this.referencesDataService.getEnvoirement();
		return env && env.envName;
	}

	private determinePadding(level: number) {
		// console.debug("TreeStructComponent::determinePadding");
		// if(!this.children || this.children.length==0){
		//     this.treeStructPadding=(level*3+15)+"px";
		// }
		// else
		if (level !== 0) {
			this.treeStructPadding = level * 2 + 5 + "px";
		}
	}
	private setFontSize(level: number) {
		this.nodeFontSize = (17 - level > 10 ? 16 - level : 10) + "px";
	}
	private determineViewableResultsDuringFiltering() {
		// console.debug("TreeStructComponent::determineViewableResultsDuringFiltering",this.level,this.filtering,this.children);
		// if(this.filtering && this.children && this.children.length>6){
		this.childrenCount = this.children ? this.children.length : 0;
		if (this.children && this.children.length > 10 && this.filtering) {
			this.hideChildList = true;
		}
		// console.debug("TreeStructComponent::determineViewableResultsDuringFiltering ",this.level,this.children,);
		// }
	}

	private onFilter(field) {
		console.debug("TreeStructComponent::onFilter", field,this.fieldObj);
		// if(this.whoCanWhoHas=='can'){
		//     field.whoHasFlag=0;
		// }
		// Use service to update node
		this.dataStorageTreeService.updateNode(this.fieldObj, "filter");
		this.addedFilter = !this.addedFilter;
	}

	// FIXME: This total count should be done on the server level

	private calculateChildrenCount() {
		console.debug("TreeStructComponent::calculateChildrenCount");

		if (
			this.children &&
			this.children.length > 0 &&
			!this.children[0].children
		) {
			if (this.whoCanWhoHas === "can") {
				this.childrenCount = this.children.length;
			} else if (this.whoCanWhoHas === "has") {
				// If the children do not have children then childrenCount = children.length
				this.childrenCount = this.children.filter(
					field => field.whoHasFlag === 1
				).length;
			}
		}
		return;
	}
}
