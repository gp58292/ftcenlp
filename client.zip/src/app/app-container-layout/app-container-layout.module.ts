import { CommonModule } from "@angular/common";
import { HttpClientModule } from "@angular/common/http";
import { NgModule } from "@angular/core";
import { FormsModule } from "@angular/forms";
import { AppContainerRoutingModule } from "@aqua/app-container-layout/app-conatiner.routing";
import { FooterComponent } from "@aqua/layouts/footer/footer.component";
import { HeaderComponent } from "@aqua/layouts/header/header.component";
import { MaterialModule } from "@aqua/material.module";

import { FiltersModule } from "../filters/filters.module";

@NgModule({
	declarations: [HeaderComponent, FooterComponent],
	imports: [
		CommonModule,
		AppContainerRoutingModule,
		MaterialModule,
		FiltersModule,
		FormsModule,
		HttpClientModule
	],
	exports: [HeaderComponent, FooterComponent]
})
export class AppContainerLayoutModule {}
