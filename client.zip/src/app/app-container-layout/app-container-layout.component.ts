import { Component } from "@angular/core";
@Component({
	selector: "derivz-app-container-layout",
	templateUrl: "./app-container-layout.component.html",
	styleUrls: ["./app-container-layout.component.scss"]
})
export class AppContainerLayoutComponent {
	public title = "AQUA Data Insight";
}
