import { Component, HostListener } from "@angular/core";

@Component({
	selector: "ceft-root",
	templateUrl: "./app.component.html",
	styleUrls: ["./app.component.scss"]
})
export class AppComponent {
	constructor() {
		console.debug(
			"AppComponent::constructor:: Data Viz Applicaiton has been loaded...."
		);
	}

	@HostListener("window:beforeunload")
	public onBrowserClose(event: Event): void {
		console.debug(
			"AppComponent::onBrowserClose:: Data Viz Applicaiton closing...."
		);
	}
}
