import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCommonModule } from '@angular/material/core';
import { OverlayModule } from '@angular/cdk/overlay';
import { MatFormFieldModule } from '@angular/material/form-field';
import { ErrorStateMatcher } from '@angular/material/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatTableModule, MatSortModule, MatOptionModule, 
        MatSelectModule, MatCardModule, MatPaginatorModule, MatCheckboxModule,
        MatInput } from '@angular/material';
import { GridViewComponent } from './grid-view.component';
import { MatInputModule } from '@angular/material/input';
import {NumberFormatPipe} from "app/aqua-component/pipes/number-formating-pipe";

@NgModule({
  imports: [
    CommonModule,
    OverlayModule,
    MatCommonModule, MatTableModule, MatSortModule, MatOptionModule, MatSelectModule, MatCardModule,MatPaginatorModule,
    MatInputModule,
    MatCheckboxModule,
    FormsModule,
    ReactiveFormsModule
  ],
  exports: [
    MatFormFieldModule, MatCommonModule, GridViewComponent
  ],
  declarations: [GridViewComponent,NumberFormatPipe],
  providers: [ErrorStateMatcher]
})
export class GridViewModule { }
