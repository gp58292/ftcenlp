export class DropDownModel {
	public static comparatorByKey(a: DropDownModel, b: DropDownModel): number {
		return a.key > b.key ? 1 : a.key < b.key ? -1 : 0;
	}
	constructor(public key: string | number, public value: any) {}
}
