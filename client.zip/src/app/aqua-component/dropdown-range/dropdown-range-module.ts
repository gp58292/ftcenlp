import { OverlayModule } from "@angular/cdk/overlay";
import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { MatSelectModule } from "@angular/material";
import { MatCommonModule, MatOptionModule } from "@angular/material/core";
import { ErrorStateMatcher } from "@angular/material/core";
import { MatFormFieldModule } from "@angular/material/form-field";
import { DropDownRange } from "./dropdown-range";

@NgModule({
	imports: [
		CommonModule,
		OverlayModule,
		MatCommonModule,
		FormsModule,
		ReactiveFormsModule,
		MatOptionModule,
		MatSelectModule
	],
	exports: [MatFormFieldModule, MatCommonModule, DropDownRange],
	declarations: [DropDownRange],
	providers: [ErrorStateMatcher]
})
export class DropDownRangeModule {}
