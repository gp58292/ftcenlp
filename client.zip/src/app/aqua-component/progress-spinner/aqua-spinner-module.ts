import { PlatformModule } from "@angular/cdk/platform";
import { CommonModule } from "@angular/common";
import { NO_ERRORS_SCHEMA } from "@angular/core";
import { NgModule } from "@angular/core";
import { MatProgressSpinnerModule } from "@angular/material";
import { MatCommonModule } from "@angular/material/core";
import { AquaSpinner } from "./aqua-spinner";

@NgModule({
	imports: [
		CommonModule,
		MatCommonModule,
		PlatformModule,
		MatProgressSpinnerModule
	],
	exports: [AquaSpinner],
	declarations: [AquaSpinner],
	schemas: [NO_ERRORS_SCHEMA]
})
export class AquaSpinnerModule {}
