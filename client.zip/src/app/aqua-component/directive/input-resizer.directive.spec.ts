import { InputResizerDirective } from "./input-resizer.directive";

describe("InputResizerDirective", () => {
	it("should create an instance", () => {
		const directive = new InputResizerDirective(null, null);
		expect(directive).toBeTruthy();
	});
});
