export * from "./rating-range-list";
export * from "./rating-range-list.module";
