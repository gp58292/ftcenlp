import { async, ComponentFixture, TestBed } from "@angular/core/testing";
import { RatingRangeList } from "@aqua/aqua-component/rating-range-list";

describe("IncludeExcludeComponent", () => {
	let component: RatingRangeList;
	let fixture: ComponentFixture<RatingRangeList>;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			declarations: [RatingRangeList]
		}).compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(RatingRangeList);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});
});
