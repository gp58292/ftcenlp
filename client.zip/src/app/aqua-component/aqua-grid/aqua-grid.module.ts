import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { MatOptionModule, MatSelectModule } from "@angular/material";
import { AquaSpinnerModule } from "@aqua/aqua-component/progress-spinner";
import { AgGridModule } from "ag-grid-angular";
import { AquaGrid } from "./aqua-grid";
import { DateComponent } from "./date-component/date.component";
import { GridHeaderComponent } from "./grid-header-component/grid-header.component";

import {
	CustomLoadingOverlay,
	CustomNoRowsOverlay
} from "@aqua/aqua-component/aqua-grid/utils";

// Cell Renderer
import {
	HyperlinkRenderer,
	NumberRenderer,
	TooltipRenderer
} from "./inline-cell-renderer";

// import "ag-grid-enterprise/main";

@NgModule({
	imports: [
		CommonModule,
		FormsModule,
		ReactiveFormsModule,
		MatOptionModule,
		MatSelectModule,
		AgGridModule.withComponents([
			/*optional Angular Components to be used in the grid*/
			DateComponent,
			GridHeaderComponent,
			NumberRenderer,
			TooltipRenderer,
			HyperlinkRenderer
		]),
		AquaSpinnerModule
	],
	exports: [AquaGrid],
	declarations: [
		DateComponent,
		GridHeaderComponent,
		NumberRenderer,
		HyperlinkRenderer,
		TooltipRenderer,
		AquaGrid,
		CustomLoadingOverlay,
		CustomNoRowsOverlay
	],
	entryComponents: [CustomLoadingOverlay, CustomNoRowsOverlay]
})
export class AquaGridModule {}
