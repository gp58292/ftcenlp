import { Component, ElementRef } from "@angular/core";
import { IHeaderAngularComp } from "ag-grid-angular/main";
import { IHeaderParams } from "ag-grid-community";

interface MyParams extends IHeaderParams {
	menuIcon: string;
}

@Component({
	templateUrl: "grid-header.component.html",
	styleUrls: ["grid-header.component.css"]
})
export class GridHeaderComponent implements IHeaderAngularComp {
	public params: MyParams;
	public sorted: string;
	private elementRef: ElementRef;

	constructor(elementRef: ElementRef) {
		this.elementRef = elementRef;
	}

	public agInit(params: MyParams): void {
		this.params = params;
		this.params.column.addEventListener(
			"sortChanged",
			this.onSortChanged.bind(this)
		);
		this.onSortChanged();
	}

	public ngOnDestroy() {
		console.debug(`Destroying HeaderComponent`);
	}

	public onMenuClick() {
		this.params.showColumnMenu(this.querySelector(".customHeaderMenuButton"));
	}

	public onSortRequested(order, event) {
		this.params.setSort(order, event.shiftKey);
	}

	public onSortChanged() {
		if (this.params.column.isSortAscending()) {
			this.sorted = "asc";
		} else if (this.params.column.isSortDescending()) {
			this.sorted = "desc";
		} else {
			this.sorted = "";
		}
	}

	private querySelector(selector: string) {
		return this.elementRef.nativeElement.querySelector(
			".customHeaderMenuButton",
			selector
		) as HTMLElement;
	}
}
