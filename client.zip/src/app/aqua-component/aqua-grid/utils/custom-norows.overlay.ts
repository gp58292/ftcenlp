import { Component } from "@angular/core";
import { INoRowsOverlayAngularComp } from "ag-grid-angular";

@Component({
	selector: "aqua-grid-norows-overlay",
	template:
		'<div class="ag-overlay-loading-center" style="background-color: #fbfbeb; height: 9%">' +
		"<h4>No data exists for the selected criteria. </h4>" +
		"</div>"
})
export class CustomNoRowsOverlay implements INoRowsOverlayAngularComp {
	public getGui(): HTMLElement {
		throw new Error("Method not implemented.");
	}

	// tslint:disable-next-line:no-empty
	public agInit(): void {}
}
