import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { AquaGridComponent } from "./aqua-grid.component";

describe("AquaGridComponent", () => {
	let component: AquaGridComponent;
	let fixture: ComponentFixture<AquaGridComponent>;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			declarations: [AquaGridComponent]
		}).compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(AquaGridComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});
});
