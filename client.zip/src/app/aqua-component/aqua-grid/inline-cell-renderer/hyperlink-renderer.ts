import { Component } from "@angular/core";
import { ICellRendererAngularComp } from "ag-grid-angular";

@Component({
	// tslint:disable-next-line:component-selector
	selector: "aqua-hyperlink-renderer",
	template: `
		<span>{{ params.value }} </span>
	`,
	styles: [
		`
			span {
				cursor: pointer;
				border-bottom: 1px solid #285da3;
				color: #285da3;
			}
		`
	]
})
// tslint:disable-next-line:component-class-suffix
export class HyperlinkRenderer implements ICellRendererAngularComp {
	public params: any;

	public agInit(params: any): void {
		this.params = params;
		// console.debug("HyperlinkRenderer::agInit::", params);
	}

	public refresh(): boolean {
		return false;
	}
}
