import { FocusMonitor } from "@angular/cdk/a11y";
import { DatePipe } from "@angular/common";
import {
	ChangeDetectionStrategy,
	ChangeDetectorRef,
	Component,
	ElementRef,
	Input,
	Renderer2
} from "@angular/core";
import { FormBuilder, FormGroup } from "@angular/forms";

import { NgModelCommon } from "@aqua/aqua-component/common";
import { RangeValue } from "@aqua/aqua-component/models/range-value";
import { DateRangeValidator } from "@aqua/aqua-component/validations";
import { debounceTime, distinctUntilChanged, takeUntil } from "rxjs/operators";

@Component({
	selector: "aqua-date-range",
	templateUrl: "./date-range.html",
	styleUrls: ["./date-range.scss"],
	providers: [
		NgModelCommon.CUSTOM_CONTROL_VALUE_ACCESSOR(DateRange),
		NgModelCommon.CUSTOM_MAT_FORM_FIELD(DateRange)
	],
	host: {
		"[class.floating]": "shouldLabelFloat",
		"[id]": "id",
		"[attr.aria-describedby]": "describedBy"
	},
	changeDetection: ChangeDetectionStrategy.OnPush
})
export class DateRange extends NgModelCommon<RangeValue<string>> {
	@Input()
	get value(): RangeValue<string> | null {
		// console.debug("DateRange::get Value::["+this.id+"]::",this.dateRangeFormGroup.value);
		const n = this.dateRangeFormGroup.value;
		if (n.start || n.end) {
			return new RangeValue<string>(n.start, n.end);
		}
		return null;
	}
	set value(dateRange: RangeValue<string> | null) {
		dateRange = dateRange || new RangeValue<string>();
		// console.debug("DateRange::Set Value::["+this.id+"]::",dateRange);
		if (
			this.value !== dateRange ||
			this.value.start !== dateRange.start ||
			this.value.end !== dateRange.end
		) {
			let range: RangeValue<string> = this.formatDate(dateRange);
			range = RangeValue.undefineValuesIfNull(range); // This will remove value if null
			// console.debug('DateRange::value::After',dateRange,range,JSON.stringify(range));
			this.errorState = DateRangeValidator.isValid(range);
			this.onChangedCallback(range);
			this.stateChanges && this.stateChanges.next();
		}
	}
	get empty() {
		return !this.value || (!this.value.start && !this.value.end);
	}
	public dateRangeFormGroup: FormGroup;
	private datePipe: DatePipe = new DatePipe("en-US");

	constructor(
		public fb: FormBuilder,
		private fm: FocusMonitor,
		private elRef: ElementRef,
		private render2: Renderer2,
		private _changeDetection: ChangeDetectorRef
	) {
		super(elRef, render2);
		// console.debug("DateRange::constructor::["+this.id+"]::");
		if (fm && elRef) {
			fm.monitor(elRef.nativeElement, true)
				.pipe(takeUntil(this.alive))
				.subscribe(origin => {
					this.focused = !!origin;
					this.stateChanges.next();
				});
		}
		this.updateControlType("aqua-date-range");
		this.dateRangeFormGroup = this.fb.group({
			start: undefined,
			end: undefined
		});
		this.dateRangeFormGroup.valueChanges
			.pipe(
				takeUntil(this.alive),
				debounceTime(300),
				distinctUntilChanged()
			)
			.subscribe(value => (this.value = value));
	}

	public writeValue(newValue: RangeValue<string>) {
		// console.debug("DateRange::writeValue::Writing new value form:BEFORE::["+this.id+"]::",newValue);
		if (
			(newValue &&
				newValue !== this.dateRangeFormGroup.value &&
				newValue.start != null &&
				newValue.end != null) ||
			(newValue !== undefined && newValue != null)
		) {
			this.dateRangeFormGroup.setValue(this.initDate(newValue));
		} else {
			this.dateRangeFormGroup.setValue({ start: null, end: null });
		}
	}
	public ngOnChanges(values) {
		// console.debug('DateRange::ngOnChanges::',values);
		// this._changeDetection.detectChanges();
	}
	// Focus first child input element
	public onContainerClick(event: MouseEvent, from?: string) {
		// console.debug("DateRange::Set Value::["+this.id+"]::",event);
		if (event && (event.srcElement as any).name !== "end") {
			const startInput: HTMLElement = this.elRef.nativeElement.querySelector(
				'[name="start"]'
			);
			startInput.focus();
		} else if (from === "start") {
			const startInput: HTMLElement = this.elRef.nativeElement.querySelector(
				'[name="start"]'
			);
			// console.debug("DateRange::Set Value::["+this.id+"]::",from,startInput);
			startInput.focus();
		} else if (from === "end") {
			const startInput: HTMLElement = this.elRef.nativeElement.querySelector(
				'[name="end"]'
			);
			// console.debug("DateRange::Set Value::["+this.id+"]::",from,startInput);
			startInput.focus();
		}
		super.onContainerClick(event);
	}

	public ngOnDestroy() {
		// console.debug('DateRange::ngOnDestroy::');
		this.fm.stopMonitoring(this.elRef.nativeElement);
		super.ngOnDestroy();
	}
	private formatDate(range: RangeValue<string>): RangeValue<string> {
		// console.debug('DateRange::formatDate::Before',JSON.stringify(range));
		const newRange = new RangeValue<string>();
		if (range.start) {
			newRange.start = this.datePipe.transform(range.start, "yyyy-MM-dd");
		}
		if (range.end) {
			newRange.end = this.datePipe.transform(range.end, "yyyy-MM-dd");
		}
		// console.debug('DateRange::formatDate::After',JSON.stringify(newRange));
		return newRange;
	}
	private initDate(range: RangeValue<string>): RangeValue<any> {
		// console.debug('DateRange::initDate::Before',JSON.stringify(range));
		const newRange = new RangeValue<any>();
		newRange.start = range.start ? new Date(Date.parse(range.start)) : null;
		newRange.end = range.end ? new Date(Date.parse(range.end)) : null;
		// console.debug('DateRange::initDate::After',JSON.stringify(newRange));
		return newRange;
	}
}
