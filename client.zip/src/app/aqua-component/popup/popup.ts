import { CdkOverlayOrigin } from "@angular/cdk/overlay";
import {
	ChangeDetectorRef,
	Component,
	ElementRef,
	EventEmitter,
	OnInit,
	Output,
	ViewChild
} from "@angular/core";
import { fromEvent, Subject } from "rxjs";
import {
	debounceTime,
	filter,
	share,
	startWith,
	switchMap,
	switchMapTo,
	takeUntil
} from "rxjs/operators";

@Component({
	selector: "popop-content",
	template: "<ng-content></ng-content>"
})
export class PopopContent {}
// tslint:disable-next-line:max-classes-per-file
@Component({
	selector: "popop-hover-content",
	template: "<ng-content></ng-content>"
})
export class PopopHoverContent {}

// tslint:disable-next-line:max-classes-per-file
@Component({
	selector: "aqua-popup",
	templateUrl: "./popup.html",
	styleUrls: ["./popup.scss"]
})
export class Popup implements OnInit {
	@ViewChild("popOverlayOrigin") public overlayOrigin: CdkOverlayOrigin;
	@Output() public close = new EventEmitter<any>();
	@Output() public open = new EventEmitter<any>();

	@ViewChild("dialog") public dialog: ElementRef;
	public isOpened = false;
	public destroy$ = new Subject<any>();

	constructor(private changeDetectorRef: ChangeDetectorRef) {}

	public ngOnInit(): void {
		const overlayOriginEl: HTMLElement = this.overlayOrigin.elementRef
			.nativeElement;
		// open popup if mouse stopped in overlayOriginEl (for short time).
		// If user just quickly got over overlayOriginEl element - do not open
		const open$ = fromEvent(overlayOriginEl as any, "mouseenter").pipe(
			filter(() => !this.isOpened),
			switchMap(enterEvent =>
				fromEvent(document, "mousemove").pipe(
					startWith(enterEvent),
					debounceTime(300),
					filter((event: any) => {
						// console.debug("Popup::ngOnInit::open$::",overlayOriginEl.children[0], event['target']);
						return overlayOriginEl.children[0] === event.target;
					})
				)
			),
			share()
		);
		open$
			.pipe(takeUntil(this.destroy$))
			.subscribe(() => this.changeState(true));

		// close if mouse left the overlayOriginEl and dialog(after short delay)
		const close$ = fromEvent(document, "mousemove").pipe(
			takeUntil(this.destroy$),
			debounceTime(100),
			filter(() => this.isOpened),
			filter(event => this.isMovedOutside(overlayOriginEl, this.dialog, event))
		);

		open$
			.pipe(
				takeUntil(this.destroy$),
				switchMapTo(close$)
			)
			.subscribe(() => {
				this.changeState(false);
			});
		console.debug("Popup::ngOnInit::After::", open$, close$);
	}

	public ngOnDestroy(): void {
		this.destroy$.next();
		this.destroy$.complete();
		this.destroy$.unsubscribe();
	}

	public connectedOverlayDetach() {
		this.changeState(false);
	}

	private changeState(isOpened: boolean) {
		this.isOpened = isOpened;
		isOpened ? this.open.emit() : this.close.emit();
		console.debug("Popup:changeState::", isOpened);
		this.changeDetectorRef.markForCheck();
	}

	private isMovedOutside(overlayOriginEl, dialog, event): boolean {
		return !(
			overlayOriginEl.contains(event.target) ||
			dialog.nativeElement.contains(event.target)
		);
	}
}
