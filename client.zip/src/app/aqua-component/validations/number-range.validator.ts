import { Directive, forwardRef } from "@angular/core";
import { AbstractControl, NG_VALIDATORS, Validator } from "@angular/forms";
import { RangeValue } from "@aqua/aqua-component/models";

@Directive({
	selector: "[validateNumberRange][ngModel],[validateNumberRange][formControl]",
	providers: [
		{
			provide: NG_VALIDATORS,
			useExisting: forwardRef(() => NumberRangeValidator),
			multi: true
		}
	]
})
export class NumberRangeValidator implements Validator {
	public static validateNumberRange() {
		return (c: AbstractControl) => {
			const range: RangeValue<any> = c.value;
			// console.debug("NumberRangeValidator::validateRange::value",range,!NumberRangeValidator.isValid(range));
			if (NumberRangeValidator.isValid(range)) {
				c.markAsTouched();
				c.markAsDirty();
				return { validateNumberRange: { valid: false } };
			}

			return null;
		};
	}

	public static isValid(range: RangeValue<number>): boolean {
		return range && range.start && range.end && range.start > range.end;
	}
	// tslint:disable-next-line:ban-types
	public validator: Function;

	constructor() {
		this.validator = NumberRangeValidator.validateNumberRange();
		// console.debug("NumberRangeValidator::constructor:: initializing ");
	}

	public validate(c: AbstractControl) {
		return this.validator(c);
	}
}
