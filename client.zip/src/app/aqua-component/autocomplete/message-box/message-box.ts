import { Component, Inject } from "@angular/core";
import {
	MAT_DIALOG_DATA,
	MAT_DIALOG_DEFAULT_OPTIONS,
	MatDialogRef
} from "@angular/material";

@Component({
	selector: "dataviz-message-box",
	template: `
		<div class="pasted-container">
			<div class="flex-row line-height">
				<h5 mat-dialog-title>Only maximum 5K records allowed to paste</h5>
			</div>
			<div class="flex-row" style="justify-content: flex-end;">
				<button class="field-button" (click)="closeDialog()">Ok</button>
			</div>
		</div>
	`,
	styleUrls: [
		"./../auto-complete.scss",
		"./../pasted-not-macthing/pasted-not-macthing.scss"
	],
	providers: [
		{ provide: MAT_DIALOG_DEFAULT_OPTIONS, useValue: { hasBackdrop: false } }
	]
})
// tslint:disable-next-line:component-class-suffix
export class MessageBox {
	constructor(
		public dialogRef: MatDialogRef<MessageBox>,
		@Inject(MAT_DIALOG_DATA) public data: any
	) {}

	public closeDialog() {
		console.debug(
			"PastedNotMacthingComponent::closeDialog:: You closed pasted value not macthing dialog.."
		);
		this.dialogRef.close();
	}
}
