import {
	AfterViewInit,
	ChangeDetectionStrategy,
	ChangeDetectorRef,
	Component,
	ElementRef,
	EventEmitter,
	HostBinding,
	Input,
	OnChanges,
	OnDestroy,
	OnInit,
	Optional,
	Output,
	Renderer2,
	SimpleChanges,
	ViewChild,
  ViewEncapsulation
} from "@angular/core";
import {
	MatDialog,
	MatFormField,
	MatListOption,
	matSelectAnimations,
	MatSelectionListChange
} from "@angular/material";
import { MessageBox } from "@aqua/aqua-component/autocomplete/message-box/message-box";
import { PastedNotMacthing } from "./pasted-not-macthing/pasted-not-macthing";

import { FocusMonitor } from "@angular/cdk/a11y";
import { COMMA, ENTER } from "@angular/cdk/keycodes";

import { CdkConnectedOverlay } from "@angular/cdk/overlay";
import { FormControl } from "@angular/forms";
import { NgModelCommon } from "@aqua/aqua-component/common";
import { Options } from "@aqua/aqua-component/models";
import { fromEvent, Subject } from "rxjs";

import * as lodash from "lodash";
import { distinctUntilChanged, filter, takeUntil } from "rxjs/operators";
import { PastedData } from "./pasted-data.model";

@Component({
	// tslint:disable-next-line:component-selector
	selector: "aqua-auto-complete",
	exportAs: "aquaAutoComplete",
	templateUrl: "./auto-complete.html",
  styleUrls: ["./auto-complete.scss"],
  encapsulation: ViewEncapsulation.Emulated,
	preserveWhitespaces: false,
	providers: [
		NgModelCommon.CUSTOM_CONTROL_VALUE_ACCESSOR(AquaAutoComplete),
		NgModelCommon.CUSTOM_MAT_FORM_FIELD(AquaAutoComplete)
	],
	// tslint:disable-next-line:use-host-property-decorator
	host: {
		"[class.floating]": "shouldLabelFloat",
		"[id]": "id",
		"[attr.aria-describedby]": "describedBy"
	},
	changeDetection: ChangeDetectionStrategy.OnPush,
	animations: [
		matSelectAnimations.transformPanel,
		matSelectAnimations.fadeInContent
	]
})
// tslint:disable-next-line:component-class-suffix
export class AquaAutoComplete extends NgModelCommon<string[]>
	implements AfterViewInit, OnDestroy, OnChanges {
	@Input()
	set data(sourceData: Options[]) {
		this._data = sourceData;
		// console.debug("AquaAutoComplete::data::", this._data, this.empty);
		this.restoreSelection(this._data);
	}
	get data(): Options[] {
		return this._data;
	}

	get empty() {
		return !(this._selectedData && this._selectedData.length > 0);
	}

	@Input()
	get value(): Options[] | undefined {
		// console.debug("AquaAutoComplete::get Value::["+this.id+"]::",this._innerValue);
		if (this._innerValue) {
			return this._innerValue;
		}
		return undefined;
	}
	set value(newValue: Options[] | null) {
		newValue = newValue && newValue.length !== 0 ? newValue : undefined;
		/// console.debug("AquaAutoComplete::Set Value::["+this.id+"]::",newValue);
		this.onChangedCallback(newValue);
		this.stateChanges && this.stateChanges.next();
		this._emtChangeDetectorRef.markForCheck();
	}
	//  Hold the original source data for chips and update selections
	get selectedData() {
		return this._selectedData;
	}
	@Input()
	get autoCompleteText() {
		return this._autoCompleteText;
	}
	set autoCompleteText(text: string) {
		console.debug("AquaAutoComplete::autoCompleteText::", text);
		this._autoCompleteText = text;
		// this.calculateWidth();
		if (text !== undefined) {
			console.debug("AquaAutoComplete::listenTextChange::", text);
			this.autoCompleteTextChange.next(text);
			this.calculateWidth();
		}
	}

	// ---------------------------------------------------------------------------------------------------
	get isDataSourceEmpty() {
		return !this._selectedData;
	}
	/** Whether or not the overlay panel is open. */
	get panelOpen(): boolean {
		return this._panelOpen;
	}
	@Input()
	set pastedData(sourceData: PastedData) {
		this._pastedData = sourceData;
		console.debug(
			"AquaAutoComplete::pastedData::",
			this._pastedData,
			this.empty
		);
		if (this._pastedData && this._pastedData.FOUND) {
			this.addSelection(this._pastedData.FOUND);
			this.updateValue();
		}
		if (
			this._pastedData &&
			this._pastedData.NOT_FOUND &&
			this._pastedData.NOT_FOUND.length > 0
		) {
			this.dialog.open(PastedNotMacthing, {
				width: "auto",
				data: { NOT_FOUND: this._pastedData.NOT_FOUND }
			});
		}
	}
	get isPasted(): boolean {
		return this._isPasted;
	}
	get notMatching(): Options[] {
		return this._pastedData && this._pastedData.NOT_FOUND;
	}
	// tslint:disable-next-line:adjacent-overload-signatures
	get pastedData(): PastedData {
		return this._pastedData;
	}
	public static nextId = 0;
	public controlType = "aqua-auto-complete";
	@HostBinding() public id = `aqua-auto-complete-${AquaAutoComplete.nextId++}`;

	public inputFocus: boolean = true;

	public typingMessage: string = "Please start typing....";

	public _data: Options[];
	public _selectedData: Options[];
	@Input() public datatype: string;

	// Enter, comma
	public separatorKeysCodes = [ENTER, COMMA];

	public _autoCompleteWidth: number;
	public _autoCompleteLength: number;
	public _autoCompleteText: string;
	@Output() public autoCompleteTextChange: EventEmitter<
		string
	> = new EventEmitter();
	@ViewChild("autoText") public inputText: any;

	/** Whether the component should show chips or not. */
	@Input() public chips: boolean = false;

	/** Trigger that opens the select. */
	@ViewChild("trigger") public trigger: ElementRef;

	/** Panel containing the select options. */
	@ViewChild("panel") public panel: ElementRef;

	/** Overlay pane containing the options. */
	@ViewChild(CdkConnectedOverlay) public overlayDir: CdkConnectedOverlay;

	/** Classes to be passed to the select panel. Supports the same syntax as `ngClass`. */
	@Input() public panelClass:
		| string
		| string[]
		| Set<string>
		| { [key: string]: any };

	/** Whether the panel's animation is done. */
	public _panelDoneAnimating: boolean = false;

	/** The value of the select panel's transform-origin property. */
	public _transformOrigin: string = "top";
	// Below code is for handling pasted values
	// tslint:disable-next-line:member-ordering
	@Output() public pastedValueChange: EventEmitter<
		string[]
	> = new EventEmitter();

	public _pastedData: { FOUND: Options[]; NOT_FOUND: Options[] };

	/** Emits when the panel element is finished transforming in. */
	public _panelDoneAnimatingStream = new Subject<string>();

	private autoTextControl: FormControl = new FormControl();
	/** Specify chips maximum width  */
	private truncChipsBy: number = 0;

	/** Whether or not the overlay panel is open. */
	private _panelOpen = false;

	private _isPasted: boolean = false;
	constructor(
		private _emtChangeDetectorRef: ChangeDetectorRef,
		private _emtElementRef: ElementRef,
		private fm: FocusMonitor,
		private render2: Renderer2,
		@Optional() private _parentFormField: MatFormField,
		public dialog: MatDialog
	) {
		super(_emtElementRef, render2);
		if (fm && _emtElementRef) {
			fm.monitor(_emtElementRef.nativeElement, true)
				.pipe(takeUntil(this.alive))
				.subscribe(origin => {
					this.focused = !!origin;
					this.stateChanges.next();
				});
		}
	}

	public ngOnInit() {
		// We need `distinctUntilChanged` here, because some browsers will
		// fire the animation end event twice for the same animation. See:
		// https://github.com/angular/angular/issues/24084
		this._panelDoneAnimatingStream
			.pipe(
				distinctUntilChanged(),
				takeUntil(this.alive)
			)
			.subscribe(() => {
				if (this.panelOpen) {
					// this._scrollTop = 0;
					// this.openedChange.emit(true);
				} else {
					// this.openedChange.emit(false);
					this.overlayDir.offsetX = 0;
					this._emtChangeDetectorRef.markForCheck();
				}
			});
	}

	/**
	 * When the panel element is finished transforming in (though not fading in), it
	 * emits an event and focuses an option if the panel is open.
	 */
	// public _onPanelDone(): void {
	// 	if (this.panelOpen) {
	// 		// this._scrollTop = 0;
	// 		// this.openedChange.emit(true);
	// 	} else {
	// 		// this.openedChange.emit(false);
	// 		this._panelDoneAnimating = false;
	// 		this.overlayDir.offsetX = 0;
	// 		this._emtChangeDetectorRef.markForCheck();
	// 	}
	// }

	public writeValue(newValue: string[]) {
		// console.debug("AquaAutoComplete::writeValue::", newValue);
		if (
			(newValue &&
				this._innerValue &&
				newValue.length !== this._innerValue.length) ||
			(newValue !== undefined && newValue != null)
		) {
			this._innerValue = newValue;
			this.updateSelection();
			this._emtChangeDetectorRef.markForCheck();
		} else {
			this.clearAll();
		}
	}
	public onContainerClick(event: MouseEvent) {
		console.debug("AquaAutoComplete::onContainerClick:", event, this.inputText);
		this.focusonText();
		super.onContainerClick(event);
	}

	public ngOnDestroy() {
		this.fm.stopMonitoring(this._emtElementRef.nativeElement);
		super.ngOnDestroy();
	}

	public displayFn(value: any): string {
		return value && typeof value === "object" ? value.key : value;
	}
	public ngOnChanges(changes: SimpleChanges) {
		// changes.prop contains the old and the new value...
		// console.debug("AquaAutoComplete::ngOnChanges::",changes);
		for (const propName of Object.keys(changes)) {
			const change = changes[propName];
			const curVal = JSON.stringify(change.currentValue);
			const prevVal = JSON.stringify(change.previousValue);

			// console.debug("AquaAutoComplete::ngOnChanges::["+propName+"]",curVal,prevVal);
		}
	}
	public selectOption(event: MatSelectionListChange): void {
		const matOption: MatListOption = event.option;
		// console.debug(
		// 	"AquaAutoComplete::selectOption::",
		// 	matOption.value,
		// 	matOption.selected
		// );
		if (event.option) {
			const item: Options = {
				key: matOption.value.key,
				value: matOption.value.value
			};
			this.addOrRemoveItemFromSelect(item);
			this.updateValue();
			// console.debug("AquaAutoComplete::selectOption::Final::", this._data);
			// this._emtChangeDetectorRef.markForCheck();
			// this.autoText.value=undefined;

			return;
		}
	}
	public addOrRemoveItemFromSelect(item: Options): void {
		let foudItemIndex: number = -1;
		if (this._selectedData) {
			foudItemIndex = this._selectedData.findIndex(
				data => data.value === item.value
			);
		} else {
			this._selectedData = [];
		}
		if (foudItemIndex !== -1) {
			this._selectedData.splice(foudItemIndex, 1);
		} else {
			this._selectedData.push(item);
		}
		// console.debug(
		// 	"AquaAutoComplete::addOrRemoveItemFromSelect::",
		// 	foudItemIndex,
		// 	this._selectedData
		// );
	}

	// Remove selected value on click of close icon in chips remove
	public removeSelected(itemOptions: Options, event: Event): void {
		// console.debug("AquaAutoComplete::removeSelected::", itemOptions, event);
		const item: Options = this._selectedData.find(
			f => f.value === itemOptions.value
		);
		// console.debug("AquaAutoComplete::removeSelected::", itemOptions, item);
		if (item) {
			item.selected = false;
			this.addOrRemoveItemFromSelect(item);
		}
		this.updateValue();
		event.preventDefault();
		event.stopPropagation();
		return;
	}
	public clearAll(event?: Event): void {
		delete this._selectedData;
		this._selectedData = [];
		this._data.map(option => (option.selected = false));
		this.autoCompleteText = undefined;
		this.value = undefined;
		this._pastedData = undefined;
		// this._emtChangeDetectorRef.markForCheck();
	}
	public focusonText(): void {
		this.inputText && this.inputText.nativeElement.focus();
	}

	/** Toggles the overlay panel open or closed. */
	public toggle(): void {
		this.panelOpen ? this.close() : this.open();
	}

	/** Opens the overlay panel. */
	public open(): void {
		if (this.disabled || this._panelOpen) {
			return;
		}

		this._panelOpen = true;
	}

	/** Closes the overlay panel and focuses the host element. */
	public close(): void {
		if (this._panelOpen) {
			this._panelOpen = false;
			this._emtChangeDetectorRef.markForCheck();
			this.autoCompleteText = undefined;
			this._data = [];
		}
	}

	/**
	 * Callback that is invoked when the overlay panel has been attached.
	 */
	// tslint:disable-next-line:no-empty
	public _onAttached(): void {}

	/**
	 * When the panel content is done fading in, the _panelDoneAnimating property is
	 * set so the proper class can be added to the panel.
	 */
	public _onFadeInDone(): void {
		this._panelDoneAnimating = this.panelOpen;
		this._emtChangeDetectorRef.markForCheck();
	}

	/** Returns the theme to be used on the panel. */
	public _getPanelTheme(): string {
		return this._parentFormField ? `mat-${this._parentFormField.color}` : "";
	}

	public trackByKey(item: Options, index: number) {
		return item.key;
	}

	// We are using this for method to display the formatted number which are in exponential format like 1.1e+007
	// TODO : This does not help when we have type ahead search as its not able to search the value
	public formatDisplayNumber(value) {
		// console.debug("AquaAutoComplete::formatDisplayNumber::", parseFloat(value))
		if (this.datatype && this.datatype === "NUMERIC") {
			return parseFloat(value);
		} else {
			return value;
		}
	}
	public pastedValue(event: any): void {
		this._isPasted = true;
		const rawData: string = event.clipboardData.getData("text/plain");

		console.debug("AquaAutoComplete::pastedValue::", this.autoCompleteText);
		const columnData = rawData.split("\n");
		if (columnData && columnData.length > 5000) {
			this.dialog.open(MessageBox, {
				width: "auto"
			});
		} else {
			this.pastedValueChange.next(columnData);
		}

		console.debug("AquaAutoComplete::pastedValue::", columnData);
	}
	public ngAfterViewInit() {
		this.listenInputFocusOut();
	}

	// Remove selected value on click of close icon in chips remove
	public removeNotMatching(itemOptions: Options, event: Event): void {
		// console.debug("AquaAutoComplete::removeSelected::", itemOptions, event);
		const item: Options = this.notMatching.find(
			f => f.value === itemOptions.value
		);
		console.debug("AquaAutoComplete::removeSelected::", itemOptions, item);
		if (item) {
			item.selected = false;
			let foudItemIndex = -1;
			foudItemIndex = this.notMatching.findIndex(
				data => data.value === item.value
			);
			if (foudItemIndex !== -1) {
				this.notMatching.splice(foudItemIndex, 1);
			}
		}
		event.preventDefault();
		event.stopPropagation();
		return;
	}

	private restoreSelection(data: Options[]): void {
		lodash
			.filter(data, (options: Options) =>
				lodash.some(
					this._selectedData,
					(dataRec: Options) => options.value === dataRec.value
				)
			)
			.map((dataRec: Options) => (dataRec.selected = true));
	}

	private updateSelection(): void {
		if (this._innerValue && this._innerValue.length > 0) {
			this._selectedData = this._innerValue;
		}
	}

	private updateValue(): void {
		this.value =
			this._selectedData || this._selectedData.length > 0
				? this._selectedData
				: undefined;
	}

	private calculateWidth(): void {
		if (!this._autoCompleteText) {
			this._autoCompleteWidth = 35;
			return;
		}
		if (this._autoCompleteText.length === this._autoCompleteLength) {
			return;
		}

		if (this._autoCompleteText.length > 3) {
			if (this._autoCompleteText.length > this._autoCompleteLength) {
				this._autoCompleteWidth = 8 * this._autoCompleteText.length;
			} else {
				this._autoCompleteWidth = 8 * this._autoCompleteText.length;
			}

			this._autoCompleteLength = this._autoCompleteText.length;
		} else {
			this._autoCompleteWidth = 35;
			this._autoCompleteLength = this._autoCompleteText
				? this._autoCompleteText.length
				: 0;
		}
	}
	private listenInputFocusOut(): void {
		fromEvent(this.inputText.nativeElement, "blur")
			.pipe(filter(() => !this.panelOpen))
			.subscribe(event => {
				console.debug("AquaAutoComplete::listenInputFocusOut::");
				this._isPasted = false;
				this.autoCompleteText = "";
				this.inputText.value = "";
				this.autoTextControl.setValue("");
				this._emtChangeDetectorRef.markForCheck();
			});
	}
	private addSelection(data: Options[]): void {
		console.debug("AquaAutoComplete::addSelection::", this._selectedData, data);

		if (!this._selectedData && data && data.length) {
			this._selectedData = [];
		}
		lodash
			.filter(
				data,
				(options: Options) =>
					this._selectedData.findIndex(
						val => val.key === options.key && val.value === options.value
					) === -1
			)
			.map((dataRec: Options) => {
				dataRec.selected = true;
				this._selectedData.push(dataRec);
			});
	}
}
