import {
	ChangeDetectionStrategy,
	Component,
	Input,
	OnDestroy
} from "@angular/core";
import { AbstractControl, FormArray, FormGroup } from "@angular/forms";
import { MatDialog, MatDialogRef } from "@angular/material";
import {
	IncludeExcludeModel,
	OPERATOR,
	Options
} from "@aqua/aqua-component/models";
import { CollateralTypeLookupComponent } from "@aqua/filters/data-finder/search/collateral-type-lookup/collateral-type-lookup.component";
import { CommonUtils } from "@aqua/util";
import { Subject } from "rxjs";
import { takeUntil } from "rxjs/operators";

@Component({
	// tslint:disable-next-line:component-selector
	selector: "aqua-core-multi-include-exclude",
	templateUrl: "./core-multi-include-exclude.html",
	styleUrls: ["./core-multi-include-exclude.scss"],
	changeDetection: ChangeDetectionStrategy.OnPush
})
// tslint:disable-next-line:component-class-suffix
export class CoreMultiIncludeExclude implements OnDestroy {
	@Input()
	set referenceData(data: Options[]) {
		// console.debug("CoreMultiIncludeExclude::referenceData::", data);
		this._startReferenceData = CommonUtils.deepClone(data);
		this._endReferenceData = CommonUtils.deepClone(data);
	}
	@Input()
	public index: number;
	@Input()
	public valueList: FormArray;

	@Input()
	public form: FormGroup;

	public ENUMOPER: any = OPERATOR;
	public _startReferenceData: Options[];
	public _endReferenceData: Options[];

	@Input() public label: string;
	public alive: Subject<void> = new Subject();
	private lookupDialogRef: MatDialogRef<CollateralTypeLookupComponent, null>;

	constructor(private dialog: MatDialog) {}

	public onLookUp() {
		console.debug("IncludeExclude::onLookUp::for Reset ");
		this.lookupDialogRef = this.dialog.open(CollateralTypeLookupComponent, {
			disableClose: true,
			data: { isOpened: true }
		});
		this.lookupDialogRef
			.afterClosed()
			.pipe(takeUntil(this.alive))
			.subscribe((result: any[]) => {
				console.debug(
					" IncludeExclude::onLookUp::referenceDataItems::lookupDialogRef::Set Values:: ",
					result
				);
				if (result) {
					const operation = result[0];
					const selectedItems: Set<any> = result[1];
					const selectedValues: any[] = [];
					// tslint:disable-next-line:forin
					console.debug(
						" IncludeExclude::onLookUp::referenceDataItems::lookupDialogRef::Set Values:: ",
						selectedItems.values()
					);
					for (const item of selectedItems.values()) {
						// console.debug(
						// 	" IncludeExclude::onLookUp::referenceDataItems::lookupDialogRef::item:: ",
						// 	item
						// );
						const referenceDataItems = this.getReferenceDataByName(
							item,
							operation
						);
						if (referenceDataItems) {
							selectedValues.push(referenceDataItems);
						}
					}
					const formList: FormArray = this.form.get("valueList") as FormArray;
					const controls: AbstractControl[] = formList.controls;
					const formControl: AbstractControl = controls[this.index];
					console.debug(
						" IncludeExclude::onLookUp::referenceDataItems::lookupDialogRef ",
						selectedValues,
						result,
						formControl
					);
					const model: IncludeExcludeModel = CommonUtils.deepClone(
						formControl.value
					);
					if ("BUT-NOT" === operation) {
						this.copyDataFromOneToOtherCTN(
							model,
							selectedValues,
							"butNotValue"
						);
					} else {
						this.copyDataFromOneToOtherCTN(model, selectedValues, "value");
					}
					formControl.patchValue(model);
					console.debug(
						" IncludeExclude::onLookUp::referenceDataItems::lookupDialogRef ",
						model
					);
				}
			});
	}

	public ngOnDestroy(): void {
		console.debug("IncludeExclude::ngOnDestroy::");
		if (this.lookupDialogRef) {
			this.lookupDialogRef.close();
		}
		this.lookupDialogRef = null;
	}

	private getReferenceDataByName(value, operation: string) {
		// console.debug("MultiIncludeExclude::getReferenceDataByName", value);
		return "BUT-NOT" === operation
			? this._endReferenceData.find(item => item.value === value)
			: this._startReferenceData.find(item => item.value === value);
	}

	private copyDataFromOneToOtherCTN(
		model: IncludeExcludeModel,
		selectedValues: any[],
		arrayName: string
	): void {
		// model.butNotValue = model.butNotValue.concat(selectedValues);
		selectedValues.forEach((keyValue: Options) => {
			model[arrayName] = model[arrayName] || [];
			const item: Options = model[arrayName].find(
				butNotValue => butNotValue.key === keyValue.key
			);
			if (item) {
				item.selected = true;
			} else {
				keyValue.selected = true;
				model[arrayName].push(keyValue);
			}
		});
	}
}
