import { coerceBooleanProperty } from "@angular/cdk/coercion";
import {
	ElementRef,
	forwardRef,
	HostBinding,
	HostListener,
	Input,
	OnDestroy,
	Renderer2
} from "@angular/core";
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from "@angular/forms";
import { MatFormFieldControl } from "@angular/material";
import { Subject } from "rxjs";

// tslint:disable-next-line:no-empty
const noop = () => {};

export class NgModelCommon<T>
	implements OnDestroy, ControlValueAccessor, MatFormFieldControl<T> {
	// Common code of Angular and Material
	@Input()
	get value(): any | any[] | null {
		const n = this._innerValue;
		if (n || Array.isArray(n)) {
			return n;
		}
		return null;
	}
	set value(value: any | any[] | null) {
		if (value !== this._innerValue) {
			this._innerValue = value;
			this.onChangedCallback(value);
			this.stateChanges && this.stateChanges.next();
		}
	}

	get empty() {
		return !this._innerValue;
	}

	@Input()
	get placeholder() {
		return this._placeholder;
	}
	set placeholder(plh: string) {
		this._placeholder = plh;
		this.stateChanges.next();
	}

	@Input()
	get required() {
		return this._required;
	}
	set required(req) {
		this._required = coerceBooleanProperty(req);
		this.stateChanges.next();
	}

	@Input()
	get disabled() {
		return this._disabled;
	}
	set disabled(dis) {
		this._disabled = coerceBooleanProperty(dis);
		this.stateChanges.next();
	}

	@HostBinding("class.floating")
	get shouldLabelFloat() {
		return this.focused || !this.empty;
	}

	public static nextId = 0;
	public static CUSTOM_CONTROL_VALUE_ACCESSOR(instance: any): any {
		return {
			provide: NG_VALUE_ACCESSOR,
			useExisting: forwardRef(() => instance),
			multi: true
		};
	}
	public static CUSTOM_MAT_FORM_FIELD(instance: any): any {
		return { provide: MatFormFieldControl, useExisting: instance };
	}

	public _innerValue: any | any[];

	// Angular Custom component methods
	public onTouchedCallback: () => void = noop;
	public onChangedCallback: (_: any) => void = noop;

	// Material Custom Component methods...
	public stateChanges = new Subject<void>();
	public alive: Subject<void> = new Subject();
	public focused = false;
	public ngControl = null;
	public errorState = false;

	public controlType = "aqua";
	@HostBinding() public id = `${this.controlType}-${NgModelCommon.nextId++}`;

	@HostBinding("attr.aria-describedby")
	public describedBy = "";
	public isActive: boolean = false;
	private _placeholder: string;
	private _required = false;
	private _disabled = false;
	// -------------------------------------------------------------------------------------------------

	constructor(private elementRef?: ElementRef, public renderer?: Renderer2) {}

	public onBlur() {
		this.onTouchedCallback();
	}
	public writeValue(newValue: any) {
		this.value = newValue;
	}
	public registerOnChange(fn: any) {
		this.onChangedCallback = fn;
	}
	public registerOnTouched(fn: any) {
		this.onTouchedCallback = fn;
	}
	public updateControlType(controlType: string): void {
		this.controlType = controlType;
	}
	public setDescribedByIds(ids: string[]) {
		this.describedBy = ids.join(" ");
	}

	// Below code add porxy class on focus
	// and based on proxy class selector using :host selector other class get activated
	public onContainerClick(event: MouseEvent) {
		this.isActive = true;
		this.hostProxyClass();
		// console.debug("AquaAutoComplete::onContainerClick::",this.isActive);
	}
	@HostListener("focusout", ["$event.target"])
	public onFocusOut(target: any) {
		this.isActive = false;
		this.hostProxyClass();
		// console.debug("AquaAutoComplete::onFocusOut::",this.isActive);
	}

	public hostProxyClass(): void {
		if (this.elementRef && this.renderer) {
			if (this.isActive) {
				this.renderer.addClass(this.elementRef.nativeElement, "host-active");
			} else {
				this.renderer.removeClass(this.elementRef.nativeElement, "host-active");
			}
		}
	}

	public ngOnDestroy() {
		this.stateChanges.complete();
		this.stateChanges.unsubscribe();
		this.stateChanges = undefined;
		this.alive.next();
		this.alive.complete();
		this.alive.unsubscribe();
		this.alive = undefined;
	}
}
