import { DropDownModel } from "../dropdown-range";

export class Options extends DropDownModel {
	public id?: string;
	public selected?: boolean;
}
