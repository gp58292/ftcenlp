export class RangeValue<T> {
	public static undefineValuesIfNull(range: RangeValue<any>): RangeValue<any> {
		if (!range || range === null) {
			return undefined;
		}
		if (
			(range.start == null || range.start === undefined) &&
			(range.end == null || range.end === undefined)
		) {
			range = undefined;
		} else if (range.start == null) {
			range.start = undefined;
		} else if (range.end == null) {
			range.end = undefined;
		}

		return range;
	}
	constructor(public start?: T, public end?: T) {}
}
