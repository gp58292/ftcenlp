import { Component } from "@angular/core";

@Component({
	selector: "aqua-tree-view",
	templateUrl: "./tree-view.component.html",
	styleUrls: ["./tree-view.component.scss"]
})
export class TreeViewComponent {
	public selected: boolean = false;

	public permissions: any = [
		{
			type: "Authenticated Users",
			expanded: true,
			rights: [
				{
					name: "Read",
					enable: true
				},
				{
					name: "Modify",
					enable: true
				},
				{
					name: "Create",
					enable: false
				},
				{
					name: "Delete",
					enable: false
				}
			]
		},
		{
			type: "Owners",
			expanded: false,
			rights: [
				{
					name: "Read",
					enable: true
				},
				{
					name: "Modify",
					enable: true
				},
				{
					name: "Create",
					enable: true
				},
				{
					name: "Delete",
					enable: true
				}
			]
		}
	];
}
