/**
 * Copyright (c) 2016-2017 VMware, Inc. All Rights Reserved.
 * This software is released under MIT license.
 * The full license information can be found in LICENSE in the root directory of this project.
 */

import { CommonModule } from "@angular/common";
import { NgModule, NO_ERRORS_SCHEMA } from "@angular/core";
import { FormsModule } from "@angular/forms";

// import {ClrFormsModule} from "../../forms/forms.module";
// import {ClrIconModule} from "../../icon/icon.module";
// import {ClrIfExpandModule} from "../../utils/expand/if-expand.module";

import { ClrIfExpandModule } from "@aqua/aqua-component/expand/if-expand.module";
import { ClrFormsModule } from "@aqua/aqua-component/forms/forms.module";
import { ClrIconModule } from "@aqua/aqua-component/icon/icon.module";
import { TREE_VIEW_DIRECTIVES, TreeViewRecursiveComponent } from "./index";

@NgModule({
	imports: [CommonModule, FormsModule, ClrFormsModule, ClrIfExpandModule],
	declarations: [TREE_VIEW_DIRECTIVES, TreeViewRecursiveComponent],
	exports: [
		TREE_VIEW_DIRECTIVES,
		ClrIfExpandModule,
		TreeViewRecursiveComponent
	],
	schemas: [NO_ERRORS_SCHEMA]
})
export class ClrTreeViewModule {}
