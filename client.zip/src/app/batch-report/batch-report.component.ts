import { MatPaginator, MatTableDataSource, MAT_DIALOG_DATA, MatDialog, MatDialogRef } from "@angular/material";
import { Component, ViewChild } from "@angular/core";
import { SearchService } from "@aqua/filters/data-finder/search/search.service";
import { BatchReport } from "@aqua/filters/models/batch-report";
import { VizNotificationService } from "@aqua/services";
import { Subject } from "rxjs";
import { catchError, finalize, takeUntil } from "rxjs/operators";
import { DerivzRestResponse } from "@aqua/filters/models";


@Component({
    selector: "ceft-batch-report",
    templateUrl: "./batch-report.component.html",
    styleUrls: ["./batch-report.component.scss"]
})

export class BatchReportComponent {
    batchReportDate;
    batchStatusResponse;
    batchDate;
    public spinnerStatus: boolean = true;
    private alive: Subject<void> = new Subject();

    public batchReportList = [
        "sourceData",
        "bau",
        "sla",
        "dbBusinessDate",
        "uiBusinessDate",
        "dataExist"
    ];

    public batchReportDataSource: MatTableDataSource<any>;
    public onCancel(): void {
        this.dialogRef.close();
    }

    constructor(private searchService: SearchService, private vizNotification: VizNotificationService, public dialogRef: MatDialogRef<BatchReportComponent>, ) {
        dialogRef.disableClose = true;
    }
    private getBatchReport() {
        this.batchReportDate = this.searchService.batchReportDate;
        this.batchDate = this.batchReportDate.replace(/-/g, "");
        console.debug("BatchReportComponent::getBOXData");
        this.searchService
            .getBatchReport(this.batchDate)
            .pipe(takeUntil(this.alive))
            .subscribe((response: DerivzRestResponse<BatchReport[]>) => {
                if (response.responseStatus === 200) {
                    this.vizNotification.showMessage(
                        "Batch report fetched successfully"
                    );
                    console.debug(
                        "BatchReportComponent::getBatchReport::",
                        response.responseData
                    );
                    this.batchReportDataSource = response.responseData;
                    this.spinnerStatus = false;
                } else {
                    this.vizNotification.showError(response.restError.errorMessage);
                }
            });
    }

    public ngOnInit() {
        this.getBatchReport();
        console.debug("BatchReportComponent:batchReportDataSource", this.batchReportDate, this.batchDate);
    }

    classForRow(value) {
        console.debug("classForRow", value);
    }
}
