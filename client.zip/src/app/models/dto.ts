export interface EnvironmentVersion {
	envName: string;
	buildVersion: string;
}

export interface UserParams {
	soeid?: string;
	name?: string;
	password?: string;
	newpassword?: string;
	ssoSessionID?: string;
	statusCode?: any;
	statusMessage?: string;
	email?: string;
	isAuthorized?: boolean;
	redirectURI?: string;
	role?: string;
	isAccessible?: boolean;
	isAuthenticated?: boolean;
	accessList?: Set<string>;
	// Below are not in use
	geid?: any;
	JSESSIONID?: any;
	token?: string;
	tokenValid?: boolean;
}

export interface UserToken {
	token?: string;
	tokenValid?: boolean;
}
