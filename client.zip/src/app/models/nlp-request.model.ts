export class NLPRequest {
	public baseUrl: string = "http://169.172.242.217:5003/python/collateral?";
	public whoCanPost: string = "uscorp";
	public butNotPost: string = "usmuni";
	public whoHasPosted: string = "cgmi";
	public butNotPosted: string = "cgmi";
}
