import { Component, OnDestroy, OnInit } from "@angular/core";
import { ActivatedRoute, Router } from "@angular/router";
import { UserParams } from "@aqua/models/dto";
import { AuthService, VizNotificationService } from "@aqua/services";
import { Subject } from "rxjs";
import { takeUntil } from "rxjs/operators";
import { User } from "./user.model";

@Component({
	selector: "derivz-login",
	templateUrl: "./login.component.html",
	styleUrls: ["./login.component.scss"]
})
export class LoginComponent implements OnInit, OnDestroy {
	// FIXME: Bring this data from configuration file during initalization somehow
	public APP_HEADER = "Welcome to AQUA CEFT";
	public APP_VERSION = "0.1-alpha";

	public user = new User("", "", "", "");
	public isLogin: boolean = true;
	public isHidePass: boolean = true;
	public logingIn: boolean = false;
	public loadingPage: boolean = true;

	private alive: Subject<void> = new Subject();

	constructor(
		private router: Router,
		private authService: AuthService,
		// private appStateService:AppStateService,
		// private refDataService: ReferenceDataService,
		private vizNotification: VizNotificationService,
		private route: ActivatedRoute
	) {
		console.debug("LoginComponent::constructor", router, route);
		this.loadingPage = true;
		setTimeout(() => (this.loadingPage = false), 5000);
	}

	public ngOnInit() {
		console.debug("LoginComponent::ngOnInit");
		// TODO: Insert LOCAL CACHE GLOBAL CLEAN HERE
		this.authService.clearUserData();
		console.debug(
			"LoginComponent::ngOnInit ",
			this.route.snapshot.params,
			this.route
		);
		this.loadingPage = true;
		setTimeout(() => {
			this.loadingPage = false;
		}, 2000);
	}

	public ngOnDestroy() {
		this.alive.next();
		this.alive.complete();
		this.alive.unsubscribe();
	}

	public login() {
		console.debug("LoginComponent::login", this.user.soeid);
		if (this.user.soeid && this.user.password) {
			this.logingIn = true;
			this.authService
				.login(this.user.soeid, btoa(this.user.password))
				.pipe(takeUntil(this.alive))
				.subscribe((res: UserParams) => {
					console.debug("LoginComponent::login::got response ::", res);
					if (res.statusCode === "EWS_1000") {
						this.clear();
						this.isLogin = false;
						this.logingIn = false;
						this.vizNotification.showWarning("Please change your password");
					} else {
						// Create new app state store on each login
						//   if(this.refDataService.env && this.refDataService.env.envName){
						//       this.appStateService.createAppState(this.refDataService.env.buildVersion);
						//   }
						// Navigate to link user was trying to access directly like email link
						if (res.redirectURI) {
							// redirecting
							console.debug("LoginComponent::REDIRECTING");
							this.router.navigate([(res as any).redirectURI]);
						} else {
							console.debug(
								"LoginComponent::login::got response :: Redirecting to main page",
								res
							);
							// If no redirect, go to default
							this.router.navigate(["/acl"]);
						}
						this.logingIn = false;
					}
				}, this.handleError);
		} else {
			const msg: string =
				`Please enter ` +
				(!this.user.soeid ? `User name` : ``) +
				(!this.user.soeid && !this.user.password ? ` and ` : ``) +
				(!this.user.password ? ` Single Sign-On Password` : ``) +
				``;
			this.vizNotification.showWarning(msg);
		}
	}

	public changePwd() {
		console.debug("LoginComponent::changePwd");
		const soeid = this.user.soeid;
		const oldPassword = this.user.password;
		const newPassword = this.user.newPassword;
		const confirmPassword = this.user.confirmPassword;

		if (!soeid || !oldPassword || !newPassword || !confirmPassword) {
			let msg: string =
				`Please enter valid values in ` +
				(!soeid ? ` SOEID,` : ``) +
				(!oldPassword ? ` Old Password,` : ``) +
				(!newPassword ? ` New Password,` : ``) +
				(!confirmPassword ? ` Confirm New Password` : ``);

			if (msg.charAt(msg.length - 1) === ",") {
				msg = msg.substring(0, msg.length - 1);
			}

			this.vizNotification.showWarning(msg + " feilds");
			return false;
		} else if (confirmPassword !== newPassword) {
			this.vizNotification.showWarning(
				"New Password and Confirm New Password not matching"
			);
			return false;
		} else {
			// this.vizNotification.showMessage("Your new password will be set successfully");
			this.authService
				.changePwd(soeid, btoa(oldPassword), btoa(newPassword))
				.pipe(takeUntil(this.alive))
				.subscribe(data => {
					if ((data as any).isAuthenticated) {
						this.clear();
						this.vizNotification.showMessage("Change password successful");
						this.isLogin = true;
					} else {
						this.vizNotification
							.showError(`Password Change Unsuccessful. Please confirm your current password
                                        and new password format is correct.`);
					}
				});
		}
	}

	public toggleLoginChangePwd(event) {
		console.debug("LoginComponent::toggleLoginChangePwd");
		this.isLogin = !this.isLogin;
		this.clear();
		event.preventDefault();
	}

	public clear() {
		console.debug("LoginComponent::clear");
		this.user = new User("", "", "", "");
	}

	public handleError(error) {
		console.debug("LoginComponent::handleError", error);
		switch (error.status) {
			case 401:
				this.vizNotification.showError("User name or password is invalid.");
				this.logingIn = false;
		}
	}

	public mailToSupport() {
		console.debug("LoginComponent::mailToSupport");
		window.location.href = AuthService.dataVizSupportMail;
	}
	private getLoadingText() {
		if (this.logingIn) {
			return "Signing into AQUA CEFT";
		}
		return "Loading AQUA CEFT";
	}
}
