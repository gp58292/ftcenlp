export class User {
	constructor(
		public soeid: string,
		public password: string,
		public newPassword: string,
		public confirmPassword: string
	) {}
}
