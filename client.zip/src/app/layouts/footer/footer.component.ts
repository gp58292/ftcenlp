import { Component, OnDestroy, OnInit } from "@angular/core";
import { ReferencesDataService } from "@aqua/services";
import { Subject } from "rxjs";
import { takeUntil } from "rxjs/operators";
import { EnvironmentVersion } from "../../models/dto";

@Component({
	selector: "app-footer",
	styleUrls: ["./footer.component.scss"],
	templateUrl: "./footer.component.html"
})
export class FooterComponent implements OnInit, OnDestroy {
	public name = "footer";
	public env: EnvironmentVersion;
	private alive: Subject<void> = new Subject();

	constructor(private refDataService: ReferencesDataService) {
		console.debug("FooterComponent::constructor");
	}

	public ngOnInit() {
		console.debug("FooterComponent::ngOnInit ");
		this.refDataService
			.subscribeEnvDetails()
			.pipe(takeUntil(this.alive))
			.subscribe((env: EnvironmentVersion) => {
				this.env = env;
			});
	}
	public ngOnDestroy() {
		this.alive.next();
		this.alive.complete();
		this.alive.unsubscribe();
	}
}
