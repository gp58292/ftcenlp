import { HttpClient } from "@angular/common/http";
import { Component, ElementRef, OnDestroy, OnInit } from "@angular/core";
import { MatDialog } from "@angular/material";
import { BatchReportComponent } from "@aqua/batch-report/batch-report.component";
import { BookmarkService } from "@aqua/filters/data-finder/bookmark";
import { ConfirmationDialogComponent } from "@aqua/filters/data-finder/confirmation-dialog/confirmation-dialog.component";
import { SearchField } from "@aqua/filters/models";
import { DataTreeStorageService } from "@aqua/filters/services";
import { AppHttpResponse, NLPRequest } from "@aqua/models";
import { EnvironmentVersion, UserParams } from "@aqua/models/dto";
import {
	AuthService,
	ReferencesDataService,
	UrlConfig,
	VizNotificationService
} from "@aqua/services";
import { Subject } from "rxjs";
import { finalize, takeUntil } from "rxjs/operators";

declare var $: any;
declare function startRecording(): void;
declare function pauseRecording(): void;
declare function stopRecording(renderComponent, any): void;

@Component({
	selector: "app-header",
	templateUrl: "./header.component.html",
	styleUrls: ["./header.component.scss"]
})
export class HeaderComponent implements OnInit, OnDestroy {
	public userImageSrc: string;
	public userName: string;
	public env: EnvironmentVersion;
	public showUserMenu: boolean = false;

	public nlpRequest: NLPRequest = new NLPRequest();
	public response: any;

	public isStartDisable: boolean;
	public isStopDisable: boolean;
	public audioBlob: Blob;
	public soeId: any;

	private alive: Subject<void> = new Subject();
	private feildsData: any[];

	private timeLeft: number = 10;
	private interval;

	constructor(
		public dialog: MatDialog,
		private authService: AuthService,
		private urlConfig: UrlConfig,
		private referencesData: ReferencesDataService,
		private vizNotification: VizNotificationService,
		private bookmarkService: BookmarkService,
		private http: HttpClient,
		private dataStorageTreeService: DataTreeStorageService,
		private elRef: ElementRef
	) {
		this.authService
			.subscribeToGEIDUpdate()
			.pipe(takeUntil(this.alive))
			.subscribe((geid: any) => {
				this.setUserPic(geid);
			});
		this.isStartDisable = false;
		this.isStopDisable = true;
	}

	public ngOnInit() {
		console.debug("HeaderComponent::ngOnInit");
		this.authService
			.subscribeToUserChange()
			.pipe(takeUntil(this.alive))
			.subscribe((user: UserParams) => {
				this.toggleUserName(user);
			});
		if (this.authService.isSignedIn()) {
			this.toggleUserName(this.authService.getUserParams());
		}
		this.referencesData
			.subscribeEnvDetails()
			.pipe(takeUntil(this.alive))
			.subscribe((env: EnvironmentVersion) => {
				if (env.envName.indexOf("prod") === -1) {
					this.env = env;
				}
			});
		this.dataStorageTreeService
			.listenState()
			.pipe(takeUntil(this.alive))
			.subscribe(state => {
				this.feildsData = state;
			});
	}

	public logout() {
		console.debug("HeaderComponent::logout");

		if (this.bookmarkService.isAnyTemporaryBookmarkExist()) {
			const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
				width: "300px",
				minWidth: "27rem",
				panelClass: "confirm-dailog-container",
				data: {
					confirmationMessage: `Do you want to delete your temporary bookmarks ?
            \n Post any action you will be logged out`
				},
				disableClose: true
			});

			dialogRef
				.afterClosed()
				.pipe(takeUntil(this.alive))
				.subscribe(result => {
					if (result) {
						this.bookmarkService
							.deleteAllTemporaryBookmarkByUserId()
							.pipe(
								takeUntil(this.alive),
								finalize(() => {
									this.authService.logout();
									this.toggleUserName(this.authService.getUserParams());
								})
							)
							.subscribe((response: AppHttpResponse<boolean>) => {
								if (response.responseStatus === 200) {
									this.vizNotification.showMessage(
										"All your temporary bookmark removed successfully."
									);
								} else {
									this.vizNotification.showError(
										"Interal error occured while removing temporary bookmark, please contact support team."
									);
								}
							});
					} else {
						this.authService.logout();
						this.toggleUserName(this.authService.getUserParams());
					}
				});
		} else {
			this.authService.logout();
			this.toggleUserName(this.authService.getUserParams());
		}
	}
	public openBatchStatus(): void {
		const dialogRef = this.dialog.open(BatchReportComponent, {
			width: "95%",
			height: "95%"
		});

		dialogRef.afterClosed().subscribe(result => {
			console.debug("HeaderComponent::openBatchStatus::The dialog was closed");
		});
	}

	public setUserPic(geid): void {
		console.debug("HeaderComponent::setUserPic ", geid);
		if (geid) {
			this.userImageSrc = this.urlConfig.EP_CITI_REMOTE_USER_PIC.replace(
				"{#geid}",
				geid
			);
		}
	}

	public toggleUserName(userParams: UserParams) {
		console.debug("HeaderComponent::toggleUserName subscribed: ", userParams);
		if (!userParams || userParams == null) {
			this.userName = "";
			this.showUserMenu = false;
		} else {
			console.debug("Welcome %s", userParams.name);
			this.userName = userParams.name;
			this.showUserMenu = true;
			this.setUserPic(userParams.geid);
			this.soeId = userParams.soeid;
		}
	}

	public ngOnDestroy() {
		this.alive.next();
		this.alive.complete();
		this.alive.unsubscribe();
	}

	/*############## Start: Connecting to Python ############### */

	public start() {
		startRecording();
		this.isStartDisable = true;
		this.isStopDisable = false;
	}

	public stop() {
		this.isStartDisable = false;
		this.isStopDisable = true;
		stopRecording(this.renderComponent, this);
	}

	public renderComponent(data) {
		console.debug("HeaderComponent::renderComponent: data:", data);
		this.response = data;
		this.buildFields(data);
	}

	private buildFields(data: SearchField[]): void {
		for (let i = 0; i < data.length; i++) {
			const field = this.findFields(this.feildsData, data[i].fieldName);
			if (field) {
				field.value = data[i].value;
				field.whoHasFlag = data[i].whoHasFlag;
				console.debug("HeaderComponent::buildFields:: ", field);
				this.dataStorageTreeService.updateNode(field, "filter");
			}
		}
		setTimeout(() => {
			this.dataStorageTreeService.setNodeUpdated(true);
		}, 2000);
	}

	private findFields(listOfField: any[], fName: string): SearchField {
		// tslint:disable-next-line:prefer-for-of
		for (let i = 0; i < listOfField.length; i++) {
			const arrayOfFields = listOfField[i].children as SearchField[];
			const finalFiled: SearchField[] = arrayOfFields.filter(
				f => f.fieldName === fName
			);
			console.debug(
				"HeaderComponent::findFields:: ",
				finalFiled,
				arrayOfFields
			);
			if (finalFiled && finalFiled.length > 0) {
				return finalFiled[0];
			}
		}
		return undefined;
	}

	/*############## Stop: Connecting to Python ############### */
}
