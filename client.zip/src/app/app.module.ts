import { HttpClientJsonpModule, HttpClientModule } from "@angular/common/http";
import { NgModule } from "@angular/core";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { BrowserModule } from "@angular/platform-browser";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { AppRoutingModule } from "./app-routing.module";
import { MaterialModule } from "./material.module";

import { AppContainerLayoutComponent } from "@aqua/app-container-layout/app-container-layout.component";
import { LoginComponent } from "@aqua/login";
import { AppComponent } from "./app.component";

import {
	AuthService,
	PrivatePageGuard,
	ReferencesDataService,
	UrlConfig,
	VizNotificationService
} from "@aqua/services";

import { AppContainerLayoutModule } from "@aqua/app-container-layout/app-container-layout.module";

import { JsonpModule } from "@angular/http"; // This is old http jsonp module., we are using for fetching image of user
import {
	ErrorHandlerService,
	httpInterceptorProviders,
	JsonHttp,
	LOGGING_ERROR_HANDLER_PROVIDERS
} from "@aqua/http-service";
// from global directory. We need to find new alternative which is not wroking now.

@NgModule({
	declarations: [AppComponent, LoginComponent, AppContainerLayoutComponent],
	imports: [
		BrowserModule,
		BrowserAnimationsModule,
		MaterialModule,
		HttpClientModule,
		HttpClientJsonpModule,
		JsonpModule,
		FormsModule,
		ReactiveFormsModule,
		AppRoutingModule,
		// DndModule.forRoot(),
		AppContainerLayoutModule,
	],
	providers: [
		AuthService,
		UrlConfig,
		VizNotificationService,
		JsonHttp,
		ErrorHandlerService,
		httpInterceptorProviders,
		LOGGING_ERROR_HANDLER_PROVIDERS,
		PrivatePageGuard,
		ReferencesDataService
	],
	bootstrap: [AppComponent]
})
export class AppModule { }
