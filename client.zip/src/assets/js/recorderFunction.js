//webkitURL is deprecated but nevertheless
URL = window.URL || window.webkitURL;

var gumStream; //stream from getUserMedia()
var rec; //Recorder.js object
var input; //MediaStreamAudioSourceNode we'll be recording

var AudioContext = window.AudioContext || window.webkitAudioContext;
var audioContext //audio context to help us record

function startRecording() {
  console.log("recordButton clicked");

  var constraints = {
    audio: true,
    video: false
  }

  navigator.mediaDevices.getUserMedia(constraints).then(function (stream) {
    console.log("getUserMedia() success, stream created, initializing Recorder.js ...");
    //create an audio context after getUserMedia is called, sampleRate might change after getUserMedia is called
    audioContext = new AudioContext;

    /*  assign to gumStream for later use  */
    gumStream = stream;

    /* use the stream */
    input = audioContext.createMediaStreamSource(stream);

    /*
    	Create the Recorder object and configure to record mono sound (1 channel)
    	Recording 2 channels  will double the file size
    */
    rec = new Recorder(input, {
      numChannels: 1
    })

    //start the recording process
    rec.record()
    console.log("Recording started");
  }).catch(function (err) {
    console.error(err);
  });
}

function stopRecording(renderComponent, angularThis) {
  console.log("stopButton clicked");
  //tell the recorder to stop the recording
  rec.stop();

  //stop microphone access
  gumStream.getAudioTracks()[0].stop();

  rec.exportWAV(function (blob) {
    console.debug("Recorder Function:: Export WAV Blob:", blob);
    const formData = new FormData();
    formData.append("audioBlob", blob);
    let httpRequest = new XMLHttpRequest();
    httpRequest.open('POST', 'python/collateral');
    httpRequest.setRequestHeader("Content-type", "audio/wav");
    httpRequest.send(blob);
    httpRequest.onreadystatechange = () => {
      if (httpRequest.readyState === 4 && httpRequest.status === 200) {
        let result = JSON.parse(httpRequest.responseText);
        console.debug("Deep Speech json result: " + httpRequest.responseText);
        console.debug("Parsed Result:", result)
        angularThis.renderComponent(result);
      }
    };
  });
}
