# -*- coding: utf-8 -*-
"""
Created on Tue Apr  2 17:50:05 2019

@author: ab57286
"""

import json
from collections import OrderedDict
from flask import Flask, jsonify,request
import tkinter 
from tkinter import *
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.cluster import KMeans
from sklearn.metrics import adjusted_rand_score
import re
import nltk
from nltk.corpus import stopwords
from nltk.stem.porter import PorterStemmer
#import requests

def minfun(x,y,z):
        return min(min(x,y),z)
    
def editDistance(str1,str2,m,n):
        dp = []
        for i in range (m+1):
            dp.append([])
            for j in range(n+1):
                dp[i].append(0)
               
        
        for i in range(0,m+1):
            for j in range(0,n+1):
                if(i==0):
                    dp[i][j]=j
                elif(j==0):
                    dp[i][j]=i
                elif(str1[i-1]==str2[j-1]):
                    dp[i][j]=dp[i-1][j-1]
                else:
                    dp[i][j]=1+minfun(dp[i][j-1],dp[i-1][j],dp[i-1][j-1])
                    
            
        return dp[m][n]
    
app = Flask(__name__)

@app.route('/python/collateral', methods=['GET'])
def get_tasks():
    coll_id_actual = request.args.get('coll_id_actual')
    coll_id_posted = request.args.get('coll_id_posted')
    leg_party_entity1 = request.args.get('leg_party_entity1')
    leg_party_entity2 = request.args.get('leg_party_entity2')
    '''
    list1=coll_id_actual.split(",")
    list2=coll_id_posted.split(",")
    list3=leg_party_entity1.split(",")
    list4=leg_party_entity2.split(",")
    '''
    list1=re.split(',|;|\*|\n',coll_id_actual)
    list2=re.split(',|;|\*|\n',coll_id_posted)
    list3=re.split(',|;|\*|\n',leg_party_entity1)
    list4=re.split(',|;|\*|\n',leg_party_entity2)
    
    dataset = pd.read_csv('Collateral_name.csv')
    dataset2 = pd.read_csv('Party_legal_entity.csv')

    representative_collateral_id1 = []
    representative_collateral_id2 = []
    representative_collateral_id3 = []
    representative_collateral_id4 = []
    percent_match1=0
    percent_match2=0
    percent_match3=0
    percent_match4=0
    for item1 in list1:
        flag = False
        match_distance1=10000
        for i in range(0, 185):
            review = re.sub('[^a-zA-Z_-]', ' ', dataset['Review'][i])
            review = review.lower()
            
            edit_distance1=editDistance(item1,review,len(item1),len(review))
          
            if(edit_distance1<=match_distance1):
                match_distance1=edit_distance1
           
                   
        for i in range(0, 185):
            review = re.sub('[^a-zA-Z_-]', ' ', dataset['Review'][i])
            review = review.lower()
               
                
            edit_distance1=editDistance(item1,review,len(item1),len(review))
            
            if(edit_distance1==match_distance1):
                curr_match=(max(len(item1),len(review))-match_distance1)/max(len(item1),len(review))
                if(curr_match>0.4) and representative_collateral_id1.count(review)==0:
                    flag=True
                    representative_collateral_id1.append(review)
        if(len(representative_collateral_id1)>=1) and flag==True:
            percent_match1 += (max(len(item1),len(representative_collateral_id1[-1]))-match_distance1)/max(len(item1),len(representative_collateral_id1[-1])) 
        
    for item2 in list2:
        flag=False
        match_distance2=10000
        for i in range(0, 185):
            review = re.sub('[^a-zA-Z_-]', ' ', dataset['Review'][i])
            review = review.lower()
                
            edit_distance2=editDistance(item2,review,len(item2),len(review))
               
            if(edit_distance2<=match_distance2):
                match_distance2=edit_distance2
                
                   
        for i in range(0, 185):
            review = re.sub('[^a-zA-Z_-]', ' ', dataset['Review'][i])
            review = review.lower()
                
            edit_distance2=editDistance(item2,review,len(item2),len(review))
                
            if(edit_distance2==match_distance2):
                curr_match=(max(len(item2),len(review))-match_distance2)/max(len(item2),len(review))
                if(curr_match>0.4) and representative_collateral_id2.count(review)==0:
                    flag=True
                    representative_collateral_id2.append(review)
        if(len(representative_collateral_id2)>=1) and flag==True:   
            percent_match2 += (max(len(item2),len(representative_collateral_id2[-1]))-match_distance2)/max(len(item2),len(representative_collateral_id2[-1])) 
    
    for item3 in list3:
        flag=False
        match_distance3=10000
        for i in range(0, 179):
            review2 = re.sub('[^a-zA-Z_-]', ' ', dataset2['Review'][i])
            review2 = review2.lower()
               
            edit_distance3=editDistance(item3,review2,len(item3),len(review2))
            
            if(edit_distance3<=match_distance3):
                match_distance3=edit_distance3
            
        
               
        for i in range(0, 179):
            review2 = re.sub('[^a-zA-Z_-]', ' ', dataset2['Review'][i])
            review2 = review2.lower()
                
            edit_distance3=editDistance(item3,review2,len(item3),len(review2))
           
            if(edit_distance3==match_distance3):
                curr_match=(max(len(item3),len(review2))-match_distance3)/max(len(item3),len(review2))
                if(curr_match>0.4) and representative_collateral_id3.count(review2)==0:
                    flag=True
                    representative_collateral_id3.append(review2)
        if(len(representative_collateral_id3)>=1) and flag==True:   
            percent_match3 += (max(len(item3),len(representative_collateral_id3[-1]))-match_distance3)/max(len(item3),len(representative_collateral_id3[-1])) 
     
    for item4 in list4:
        flag=False
        match_distance4=10000
        for i in range(0, 179):
            review2 = re.sub('[^a-zA-Z_-]', ' ', dataset2['Review'][i])
            review2 = review2.lower()
                
            edit_distance4=editDistance(item4,review2,len(item4),len(review2))
            
            if(edit_distance4<=match_distance4):
                match_distance4=edit_distance4
        for i in range(0, 179):
            review2 = re.sub('[^a-zA-Z_-]', ' ', dataset2['Review'][i])
            review2 = review2.lower()
               
            edit_distance4=editDistance(item4,review2,len(item4),len(review2))
               
            if(edit_distance4==match_distance4):
                curr_match=(max(len(item4),len(review2))-match_distance4)/max(len(item4),len(review2))
                if(curr_match>0.4) and representative_collateral_id4.count(review2)==0:
                    flag=True
                    representative_collateral_id4.append(review2)
        if(len(representative_collateral_id4)>=1) and flag==True:                       
            percent_match4 += (max(len(item4),len(representative_collateral_id4[-1]))-match_distance4)/max(len(item4),len(representative_collateral_id4[-1])) 
        
    for i in range(len(representative_collateral_id1)):
        print("Representative collateral id 1 is: " + representative_collateral_id1[i])
    if(len(representative_collateral_id1)>=1):                           
        print('Average Matching Percentage for Representative Collateral_id1 is = ',(percent_match1*100.00)/len(representative_collateral_id1 ))      
    else:
        print('Average Matching Percentage for Representative Collateral_id1 has not crossed threshold of 40 percent')
    for i in range(len(representative_collateral_id2)):
        print("Representative collateral id 2 is: " + representative_collateral_id2[i])
    if(len(representative_collateral_id2)>=1):                           
        print('Average Matching Percentage for Representative Collateral_id2 is = ',(percent_match2*100.00)/len(representative_collateral_id2 ))      
    else:
        print('Average Matching Percentage for Representative Collateral_id2 has not crossed threshold of 40 percent')
        
    for i in range(len(representative_collateral_id3)):
        print(" Legal_Party_Entity1: " + representative_collateral_id3[i])
    if(len(representative_collateral_id3)>=1):                       
        print('Average Matching Percentage for Legal_Party_Entity1 is = ',(percent_match3*100.00)/len(representative_collateral_id3 ))      
    else:
        print('Average Matching Percentage for Legal_Party_Entity1 has not crossed threshold of 40 percent')
    for i in range(len(representative_collateral_id4)):
        print(" Legal_Party_Entity2 is: " + representative_collateral_id4[i])
    if(len(representative_collateral_id4)>=1):                       
        print('Average Matching Percentage for Legal_Party_Entity2 is = ',(percent_match4*100.00)/len(representative_collateral_id4 ))      
    else:
        print('Average Matching Percentage for Legal_Party_Entity2 has not crossed threshold of 40 percent')
    '''
    return jsonify({'Collateral_id_Actual': [cia for cia in representative_collateral_id1],
                    'Collateral_id_Posted': [cip for cip in representative_collateral_id2],
                    'Legal_Party_entity1': [lpe1 for lpe1 in representative_collateral_id3],
                    'Legal_Party_entity2':[lpe2 for lpe2 in representative_collateral_id4]
      
                                               })'''
    dic = {
            #'bomber': [1, 2, 3, 4, 5],
            #'irritation': [1, 3, 5, 7, 8]
            'coll_names': [c for c in representative_collateral_id1],
          }
    dic1 = {
            #'bomber': [1, 2, 3, 4, 5],
            #'irritation': [1, 3, 5, 7, 8]
            'coll_names': [c for c in representative_collateral_id2],
          }
    
    json_dict = OrderedDict([
                  ('fieldName', 'collateral_type_name'),
                  ('componentType', 'MULTI_INCLUDE_EXCLUDE'),
                  ('dataType', 'string'),
                  ('key',-1),
                  ('whoHasFlag',0),
                  ('value', [ OrderedDict([
                                            #('keyword', k),
                                            #('term_freq', len(v)),
                                            ('valueList',  [ OrderedDict([
                                            ('operation', 'or'),
                                            #('term_freq', len(v)),
                                            ('value', [{'value': i,'selected':True,'key':-1} for i in v]),
                                            ('butnotvalue',[{'value': u,'selected':True,'key':-1} for u in v1])
                                                            ]) for k, v in dic1.items()])
                                         ]) for k1, v1 in dic.items()])
                ])
    json_dict1 = OrderedDict([
                    ('responseStatus',200)                
                    ])
    
    with open('abc.json', 'w') as outfile:
        json.dump(json_dict, outfile)
    #with open('abc.json','a') as outfile:
        #json.dump(json_dict1,outfile)
    # Now to read the orderer json file
    
    with open('abc.json', 'r') as handle:
        new_json_dict = json.load(handle, object_pairs_hook=OrderedDict)
        print(json.dumps(json_dict, indent=4))
        return (json.dumps(json_dict, indent=4))
        #data = str(json.dumps(json_dict, indent=4))
        #return jsonify({"responseStatus":200,
                        #"resposeData":data
                        #})
        #return jsonify(someData)

if __name__ == '__main__':
    app.run(host='10.106.18.128',port=5003)