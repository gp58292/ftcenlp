package com.citi.aqua.derivz.security.model;

public enum AuthorityList {
    ROLE_USER, ROLE_ADMIN
}
