package com.citi.aqua.derivz.security.ping.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import com.citi.aqua.derivz.security.constants.AuthConstants;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Configuration
@ConfigurationProperties(prefix = AuthConstants.CITI_PINGFEDERATION_SERVICE, ignoreUnknownFields = true,ignoreInvalidFields = true)
@Getter
@Setter
@ToString
public class CitiFederationKeys {

	CitiFederationKeys() {}
	
	String soapRequestTemplatePath;
	String isenabled;
	String url;
	Integer timeout;
	
	JKSStore keystore;
	JKSStore truststore;
	
	@Getter
	@Setter
	@ToString
	public static class JKSStore {
		String path;
		String type;
		String password;
	}
}
