package com.citi.aqua.derivz.security;

import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.CacheManager;
import org.springframework.stereotype.Service;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.citi.aqua.derivz.model.User;
import com.citi.aqua.derivz.model.UserToken;
import com.citi.aqua.derivz.security.constants.AuthConstants;
import com.citi.aqua.derivz.security.manager.SingleSignOnManager;

@Service
public class AuthenticationService {
	private static final Logger LOGGER = LoggerFactory.getLogger(AuthenticationService.class);

	@Autowired
	private SingleSignOnManager singleSignOnManager;

	@Autowired
	public CacheManager cacheManager;

	public void clearCache() {
		 cacheManager.getCacheNames().parallelStream().forEach(name -> {
			 cacheManager.getCache(name).clear();
		 });
	}

	public User authenticateUser(HttpSession session, User inputUser) {
		LOGGER.debug("AuthenticationService:: authenticateUser method invoked");
		User user = null;
		clearCache();
		if (null == session.getAttribute(AuthConstants.ISLOGGED_IN) || session.getAttribute(AuthConstants.SOE_ID) != inputUser.getSoeid()) {
			if (null != inputUser && StringUtils.isNotBlank(inputUser.getSoeid()) && StringUtils.isNotBlank(inputUser.getPassword())) {
				user = singleSignOnManager.authenticateUser(StringUtils.trim(inputUser.getSoeid()),	StringUtils.trim(inputUser.getPassword()));
				if (user.getIsAuthenticated()) {
					session.setAttribute(AuthConstants.ISLOGGED_IN, Boolean.TRUE);
					user.setName(StringUtils.trim(user.getName()));
					session.setAttribute(AuthConstants.USER_NAME, user.getName());
					session.setAttribute(AuthConstants.SOE_ID, user.getSoeid());
					user.setPassword(null);
					user.setAuthorized(AuthConstants.BOOLEAN_TRUE);
					user.setAuthenticated(AuthConstants.BOOLEAN_TRUE);
					session.setAttribute(AuthConstants.USER, user);
					session.setAttribute(AuthConstants.EMAIL, user.getEmail());
				}
			}
		} else {
			user = (User) session.getAttribute(AuthConstants.USER);
		}
		return user;
	}

	public static User getUser() {
		User user = null;
		final ServletRequestAttributes attr = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
		final HttpSession session = attr.getRequest().getSession();
		if (null != session && null != session.getAttribute(AuthConstants.ISLOGGED_IN)	&& null != session.getAttribute(AuthConstants.USER)) {
			user = (User) session.getAttribute(AuthConstants.USER);
		}
		return user;
	}

	public User getUser(final HttpSession session) {
		User user = null;
		if (null != session.getAttribute(AuthConstants.ISLOGGED_IN)) {
			user = (User) session.getAttribute(AuthConstants.USER);
		}
		return user;
	}

	public void killSession(HttpSession session) {
		if (null != session.getAttribute(AuthConstants.ISLOGGED_IN)) {
			session.removeAttribute(AuthConstants.USER);
			session.invalidate();
		}
	}

	public boolean validateUserToken(String token) {
		return singleSignOnManager.isUserTokenValid(token);
	}

	public UserToken getUserToken(String userId, String password) {
		return singleSignOnManager.getUserToken(userId, password);
	}

}
