package com.citi.aqua.derivz.security.model;

/**
 * @name SecurityConstant
 *
 */
public class SecurityConstant {

	public static final String AQUA_SSL="aqua.ssl";
	
	//Java SSL Constant
	public static final String SSO_CITI_URL="citi.sso.url";
	public static final String KEYSOTRE="javax.net.ssl.keyStore";
	public static final String TRUSTSOTRE="javax.net.ssl.trustStore";
	public static final String KEYSOTRE_PASS="javax.net.ssl.keyStorePassword";
	public static final String TRUSTSOTRE_PASS="javax.net.ssl.trustStorePassword";
	public static final String KEYSOTRE_TYPE="javax.net.ssl.keyStoreType";
	public static final String TRUSTSOTRE_TYPE="javax.net.ssl.trustStoreType";
	
	//For @Value in Aqua SSL
	public static final String PROP_SSO_CITI_URL="${"+AQUA_SSL+"."+SSO_CITI_URL+"}";
	
	private SecurityConstant() {}
}
