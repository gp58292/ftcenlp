package com.citi.aqua.derivz.security.manager;

import java.sql.SQLException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import com.citi.aqua.derivz.commons.constants.DerivzBeanConstants;
import com.citi.aqua.derivz.data.jdbc.UserSearchDAO;
import com.citi.aqua.derivz.data.repository.AppUserLoggingRepository;
import com.citi.aqua.derivz.data.repository.UserRepository;
import com.citi.aqua.derivz.model.AppUserLogging;
import com.citi.aqua.derivz.model.CEFTUser;
import com.citi.aqua.derivz.model.DerivzDBConstants;
import com.citi.aqua.derivz.model.LoginStatusEnum;
import com.citi.aqua.derivz.model.PropertyConstants;
import com.citi.aqua.derivz.model.User;
import com.citi.aqua.derivz.model.UserToken;
import com.citi.aqua.derivz.security.constants.AuthConstants;
import com.citi.aqua.derivz.security.ping.core.UserAuthenticationResolver;
import com.citi.aqua.derivz.security.ping.util.RandomStringUtil;
import com.citi.citisso.ws.UserAuthenticationResponseObj;

@Service
public class SingleSignOnManager {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(SingleSignOnManager.class);

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private UserSearchDAO userDAO;

	@Autowired
	private AppUserLoggingRepository appUserLoggingRepository;
	
	@Autowired
	private UserAuthenticationResolver userAuthenticationResolver;
	
	@Autowired
	private Environment env;
	
	public User authenticateUser(final String userName, final String password) {
		// Create Profile Object with incoming Data
		final User profile = new User();
		try {
			UserAuthenticationResponseObj ssoResponse = new UserAuthenticationResponseObj();
			// Create Profile Object with incoming Data
			profile.setSoeid(userName);
			Map<String, String> userAuthenticationResult = new HashMap<>();
			LOGGER.debug("SingleSignOnManager::authenticateUser:: Executing...");
			// If disable is set in property, application will by pass authentication but authorization will still happen.
			Boolean isDisable=env.getProperty(PropertyConstants.CEFT_AUTHENTICATION_DISABLE, Boolean.class);
			
			if(isDisable!=null && isDisable) {
				RandomStringUtil gen = new RandomStringUtil(28, ThreadLocalRandom.current());
				String next = gen.nextString();
				userAuthenticationResult.put(AuthConstants.STATUS_CODE, AuthConstants.STATUS_CODE_ZERO);
				userAuthenticationResult.put(AuthConstants.STATUS_MESSAGE, AuthConstants.STATUS_MESSAGE_RETURN);
				userAuthenticationResult.put(AuthConstants.IS_TOKEN_VALID, Boolean.toString(true));
				userAuthenticationResult.put(AuthConstants.TOKEN, next);
			} else {
				userAuthenticationResult=userAuthenticationResolver.validateUserIdentify(userName, password);
			}
			
			
			ssoResponse.setStatusCode(Integer.parseInt(String.valueOf(userAuthenticationResult.get(AuthConstants.STATUS_CODE))));
			//Get token
			profile.setToken(userAuthenticationResult.get(AuthConstants.TOKEN));
			profile.setTokenValid(Boolean.parseBoolean(userAuthenticationResult.get(AuthConstants.IS_TOKEN_VALID)));
			
			if (0 == ssoResponse.getStatusCode()) {
				profile.setSsoSessionID(UUID.randomUUID().toString());
				profile.setStatusCode(com.citi.aqua.derivz.model.LoginStatusEnum.DVIZ_200);
				profile.setAuthenticated(Boolean.TRUE);

				// Authorize user in CEFT table
				authorizeUserInAQUA(profile, userName);
			} else {
				updateLoginStatus(profile, ssoResponse.getStatusCode(), ssoResponse.getMessage());
			}
		} catch (Exception e) {
			profile.setStatusCode(LoginStatusEnum.DVIZ_800);
			profile.setStatusMessage(e.getMessage());
			LOGGER.error("Error occured while doing authentication :: User Id{}",userName,e);
		}
		auditUserAction(DerivzBeanConstants.LOGIN_ACTIVITY, profile);
		return profile;
	}

	public void updateLoginStatus(final User profile, final int responseCode, final String message) {
		switch (responseCode) {
			case 0:
				profile.setStatus(LoginStatusEnum.DVIZ_200);
				break;
			case -1:
				profile.setStatusMessage(message);
				profile.setStatus(AuthConstants.FORCE_CHANGE_PASS.equalsIgnoreCase(message) ? LoginStatusEnum.DVIZ_1000: LoginStatusEnum.DVIZ_401);
				break;
			case -2:
				profile.setStatus(LoginStatusEnum.DVIZ_401);
				break;
			case -3:
				profile.setStatus(LoginStatusEnum.DVIZ_401);
				break;
			case 400:
				profile.setStatus(LoginStatusEnum.DVIZ_400);
				break;
			case 900:
				profile.setStatus(LoginStatusEnum.DVIZ_900);
				break;
			default:
				profile.setStatus(LoginStatusEnum.DVIZ_800);
		}
	}

	private User authorizeUserInAQUA(User inputProfile, String soeId) {
		User profile = inputProfile;
		try {
			List<CEFTUser> userEntitlements = fetchUserProfile(soeId);
			if (userEntitlements.isEmpty() || userEntitlements.contains(null)) {
				updateLoginStatus(profile, 400, AuthConstants.NOT_AUTHORIZED_IN_AQUA);
				profile.setAuthorized(false);
			} else {
				for (CEFTUser entitlement : userEntitlements) {
					profile.setName(userRepository.findFriendlyNameBySoeid(soeId));
					profile.setAssignmentGroupId(userRepository.findGroupNameBySoeid(soeId));
					profile.setEmail(entitlement.getEmail());
					profile.getAccessList().add(entitlement.getCeftAccess());
				}
			}
		} catch (Exception e) {
			updateLoginStatus(profile, 900, e.getLocalizedMessage());
		}
		return profile;
	}

	private List<CEFTUser> fetchUserProfile(String soeId) throws SQLException {
		return userDAO.getUserListEntitlement(soeId);
	}

	private boolean auditUserAction(final String loginActivity, final User profile) {
		final AppUserLogging appUserLog = new AppUserLogging();
		appUserLog.setSoeid(profile.getSoeid());
		appUserLog.setAppType(DerivzDBConstants.DASHBOARD_TYPE_CEFT);
		appUserLog.setActivity(loginActivity);
		appUserLog.setCreatedTime(new Date());
		appUserLog.setUserName(profile.getName());

		AppUserLogging savedUserLoging = appUserLoggingRepository.save(appUserLog);
		return (null != savedUserLoging);
	}
	
	public boolean isUserTokenValid(String token) {
		return userAuthenticationResolver.validateUserIdentify(token);
	}

	public UserToken getUserToken(String userId, String password) {
		Map<String, String> userAuthenticationResult = userAuthenticationResolver.validateUserIdentify(userId, password);
		UserToken userToken = new UserToken();
		userToken.setToken(userAuthenticationResult.get(AuthConstants.TOKEN));
		return userToken;
	}

}