
package com.citi.aqua.derivz.security;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.core.env.Environment;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.context.junit4.SpringRunner;
import com.citi.aqua.derivz.data.repository.AppUserLoggingRepository;
import com.citi.aqua.derivz.model.AppUserLogging;
import com.citi.aqua.derivz.model.LoginStatusEnum;
import com.citi.aqua.derivz.model.PropertyConstants;
import com.citi.aqua.derivz.model.User;
import com.citi.aqua.derivz.security.constants.AuthConstants;
import com.citi.aqua.derivz.security.manager.SingleSignOnManager;
import com.citi.aqua.derivz.security.ping.core.UserAuthenticationResolver;
import com.citi.aqua.derivz.security.ping.util.RandomStringUtil;

@RunWith(SpringRunner.class)
public class SingleSignOnManagerTest {

	@InjectMocks
	SingleSignOnManager singleSignOnManager;

	
	@Mock
	private AppUserLoggingRepository appUserLoggingRepository;
	
	@Mock
	private UserAuthenticationResolver userAuthenticationResolver;
	MockHttpSession session = new MockHttpSession();
	
	@Mock
	private Environment env;
	
	private static final String USER_NAME="sa98695";
	private static final String PASS="test";
	
	private static final String TRUE="true";
	private static final String ZERO="0";
	private static final String MINUS_TWO="-2";
	
	private static final String TOKEN= new RandomStringUtil(28, ThreadLocalRandom.current()).nextString();

	@Before
	public void setup() {
		MockitoAnnotations.initMocks(this);

	}

	@Test
	public void testAuthenticateUser() {
		User user = new User();
		user.setAuthenticated(true);
		user.setSoeid(USER_NAME);
		user.setPassword(PASS);
		user.setStatusCode(LoginStatusEnum.DVIZ_200);
		Map<String, String>  map= new HashMap<>();
		map.put(AuthConstants.STATUS_CODE, ZERO);
		map.put(AuthConstants.IS_TOKEN_VALID,TRUE);
		map.put(AuthConstants.TOKEN,TOKEN);
		when(env.getProperty(PropertyConstants.CEFT_AUTHENTICATION_DISABLE, Boolean.class)).thenReturn(false);
		when(userAuthenticationResolver.validateUserIdentify(USER_NAME, PASS)).thenReturn(map);
		when(appUserLoggingRepository.save(Matchers.any(AppUserLogging.class))).thenReturn(null);
		assertEquals(USER_NAME, singleSignOnManager.authenticateUser(USER_NAME, PASS).getSoeid());
	}

	@Test
	public void testAuthenticateUserForUpdate() {
		User user = new User();
		user.setAuthenticated(true);
		user.setSoeid(USER_NAME);
		user.setPassword(PASS);
		user.setStatusCode(LoginStatusEnum.DVIZ_200);
		 Map<String, String>  map= new HashMap<>();
		 map.put(AuthConstants.STATUS_CODE, MINUS_TWO);
		 map.put(AuthConstants.IS_TOKEN_VALID,TRUE);
		 map.put(AuthConstants.TOKEN,TOKEN);
			
		when(env.getProperty(PropertyConstants.CEFT_AUTHENTICATION_DISABLE, Boolean.class)).thenReturn(false);
		when(userAuthenticationResolver.validateUserIdentify(USER_NAME, PASS)).thenReturn(map);
		when(appUserLoggingRepository.save(Matchers.any(AppUserLogging.class))).thenReturn(null);
		assertEquals(LoginStatusEnum.DVIZ_401, singleSignOnManager.authenticateUser(USER_NAME, PASS).getStatusCode());

	}
	@Test
	public void testGetUserToken() {
		 Map<String, String>  map= new HashMap<>();
		 map.put(AuthConstants.STATUS_CODE, MINUS_TWO);
		 map.put(AuthConstants.IS_TOKEN_VALID,TRUE);
		 map.put(AuthConstants.TOKEN,TOKEN);
		when(userAuthenticationResolver.validateUserIdentify(USER_NAME, PASS)).thenReturn(map);
		assertEquals(TOKEN, singleSignOnManager.getUserToken(USER_NAME, PASS).getToken());
	}

	@Test
	public void testValidateUserToken() {
		when(userAuthenticationResolver.validateUserIdentify(USER_NAME)).thenReturn(true);
		assertEquals(true, singleSignOnManager.isUserTokenValid(USER_NAME));
	}
	
	@Test
	public void testUpdateLoginStatus() {
		User user = new User();
		user.setAuthenticated(true);
		user.setSoeid(USER_NAME);
		user.setPassword(PASS);
		user.setStatusCode(LoginStatusEnum.DVIZ_200);
		singleSignOnManager.updateLoginStatus(user, 0, "Success");
		singleSignOnManager.updateLoginStatus(user, -1, "fail");
		singleSignOnManager.updateLoginStatus(user, -2, "fail");
		singleSignOnManager.updateLoginStatus(user, -3, "fail");
		singleSignOnManager.updateLoginStatus(user, 400, "fail");
		singleSignOnManager.updateLoginStatus(user, 900, "fail");
		singleSignOnManager.updateLoginStatus(user, 500, "fail");
	}
	
}
