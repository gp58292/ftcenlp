
package com.citi.aqua.derivz.security;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import java.util.LinkedList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.CacheManager;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.citi.aqua.derivz.data.repository.DistinctValuesRepository;
import com.citi.aqua.derivz.data.repository.SelectionFiltersRepository;
import com.citi.aqua.derivz.model.DistinctValues;
import com.citi.aqua.derivz.model.LoginStatusEnum;
import com.citi.aqua.derivz.model.SelectionFilters;
import com.citi.aqua.derivz.model.User;
import com.citi.aqua.derivz.model.UserToken;
import com.citi.aqua.derivz.security.constants.AuthConstants;
import com.citi.aqua.derivz.security.manager.SingleSignOnManager;
import com.citi.aqua.derivz.vo.ReferenceDataVO;

@RunWith(SpringRunner.class)
public class AuthenticationServiceTest {

	@InjectMocks
	AuthenticationService authenticationService;

	@Mock
	private SingleSignOnManager singleSignOnManager;
@Mock RequestContextHolder requestContextHolder;
	@Mock
	public CacheManager cacheManager;
	MockHttpSession session = new MockHttpSession();

	@Before
	public void setup() {
		MockitoAnnotations.initMocks(this);

	}

	@Test
	public void testKillSession() {
		session.setAttribute(AuthConstants.ISLOGGED_IN, "");
		authenticationService.killSession(session);
		assertEquals(true, session.isInvalid());
	}
	
	@Test
	public void testKillSessionConditional() {
		authenticationService.killSession(session);
	}

	@Test
	public void testAuthenticateUser() {
		User user = new User();
		user.setAuthenticated(true);
		user.setSoeid("sa98695");
		user.setPassword("test");
		user.setStatusCode(LoginStatusEnum.DVIZ_200);
		when(singleSignOnManager.authenticateUser(Matchers.anyString(), Matchers.anyString())).thenReturn(user);
		authenticationService.authenticateUser(session, user);
		assertEquals(true, user.getIsAuthenticated());
	}
	
	@Test
	public void testAuthenticateUserConditional1() {
		User user = new User();
		user.setAuthenticated(true);
		user.setSoeid("sa98695");
		user.setPassword("test");
		user.setStatusCode(LoginStatusEnum.DVIZ_200);
		session.setAttribute(AuthConstants.ISLOGGED_IN, user);
		session.setAttribute(AuthConstants.SOE_ID, "sa98695");
		when(singleSignOnManager.authenticateUser(Matchers.anyString(), Matchers.anyString())).thenReturn(user);
		authenticationService.authenticateUser(session, user);
		assertEquals(true, user.getIsAuthenticated());
	}
	
	@Test
	public void testAuthenticateUserConditional2() {
		authenticationService.authenticateUser(session, null);
	}

	@Test
	public void tesGetUser() {
		User user = new User();
		user.setAuthenticated(true);
		user.setSoeid("sa98695");
		user.setPassword("test");
		user.setStatusCode(LoginStatusEnum.DVIZ_200);
		session.setAttribute(AuthConstants.ISLOGGED_IN, "");
		session.setAttribute(AuthConstants.USER, user);
		assertEquals("sa98695", authenticationService.getUser(session).getSoeid());
	}
	
	@Test
	public void tesGetUserConditional() {
		authenticationService.getUser(session);
	}

	@Test
	public void testGetUserToken() {
		UserToken userToken = new UserToken();
		userToken.setToken("sa98695");
		when(singleSignOnManager.getUserToken("sa98695", "test")).thenReturn(userToken);
		assertEquals("sa98695", authenticationService.getUserToken("sa98695", "test").getToken());
	}
	@Test
	public void testValidateUserToken() {
		when(singleSignOnManager.isUserTokenValid("sa98695")).thenReturn(true);
		assertEquals(true, authenticationService.validateUserToken("sa98695"));
	}
}
