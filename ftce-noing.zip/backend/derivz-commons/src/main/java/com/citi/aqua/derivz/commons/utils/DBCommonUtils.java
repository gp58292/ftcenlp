package com.citi.aqua.derivz.commons.utils;


import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.citi.aqua.derivz.commons.constants.DerivzCommonConstants;

@Component
public class DBCommonUtils {

	private static final Logger LOGGER = LoggerFactory.getLogger(DBCommonUtils.class);

	/**
	 * @name convertDateToString
	 * @param Date
	 * @return String
	 */
	@SuppressWarnings("hiding")
	public <T> String convertDateToString(T endRangeValue) {
		LOGGER.debug("CommonUtils:: convertDateToString() ");
		SimpleDateFormat sdfr = new SimpleDateFormat(DerivzCommonConstants.YYYYMMDD_FORMAT);
		return sdfr.format(endRangeValue);
	}

	/**
	 * @name createFieldValueForProc
	 * @param valueList
	 * @return String
	 */
	public String createInValueForProc(final List<String> valueList) {
		LOGGER.debug("CommonUtils:: createInValueForProc() ");
		String value = "";
		try {
			final StringBuilder stringBuilder = new StringBuilder();
			for (String indValue : valueList) {
				stringBuilder.append("'");
				if (indValue.contains("'")) {
					stringBuilder.append(indValue.replace("'", "''"));
				} else {
					stringBuilder.append(indValue);
				}
				stringBuilder.append("'");
				stringBuilder.append(",");
			}
			stringBuilder.setCharAt(stringBuilder.lastIndexOf(","), '|');
			stringBuilder.append('~');
			value = stringBuilder.toString();
		} catch (Exception e) {
			LOGGER.error("CommonUtils:: createInValueForProc() :: Error occured " + e, e);
			throw e;
		}
		return value;
	}

	/**
	 * @name createFieldValueForProc
	 * @param long
	 * @param long
	 * @return String
	 */
	@SuppressWarnings("hiding")
	public <T> String creatRangeValueForProc(final T startRangeValue, final T endRangeValue) {
		LOGGER.debug("CommonUtils:: createNumberRangeValueForProc() ");
		String value = "";
		try {
			final StringBuilder stringBuilder = new StringBuilder();
			if (null != startRangeValue) {
				if(startRangeValue instanceof Date)
					stringBuilder.append("'").append(convertDateToString(startRangeValue)).append("'");
				else
					stringBuilder.append(startRangeValue);
				stringBuilder.append(DerivzCommonConstants.QUERY_DELIMETER);
			}
			if (null != endRangeValue) {
				if(startRangeValue instanceof Date)
						stringBuilder.append("'").append(convertDateToString(endRangeValue)).append("'");
					else
						stringBuilder.append(endRangeValue);
				stringBuilder.append(DerivzCommonConstants.QUERY_DELIMETER);
			}

			value = stringBuilder.toString();
		} catch (Exception e) {
			LOGGER.error("CommonUtils:: createNumberRangeValueForProc() :: Error occured " + e, e);
			throw e;
		}
		return value;
	}
	
	public <T> String createNumberRangeConditioneForProc(final T numberStartRangeValue, final T numberEndRangeValue) {
		LOGGER.debug("CommonUtils:: createNumberRangeConditioneForProc() ");
		String value = "";
		try {
			final StringBuilder stringBuilder = new StringBuilder();
			if (null != numberStartRangeValue) {
				stringBuilder.append(">=").append(DerivzCommonConstants.QUERY_DELIMETER);
			}
			if (null != numberEndRangeValue) {
				stringBuilder.append("<=").append(DerivzCommonConstants.QUERY_DELIMETER);
			}
			value = stringBuilder.toString();
		} catch (Exception e) {
			LOGGER.error("CommonUtils:: createNumberRangeConditioneForProc() :: Error occured " + e, e);
			throw e;
		}
		return value;
	}

	
	/**
	 * @name createNumberRangeConditioneForProc
	 * @param long
	 * @param long
	 * @return String
	 */
	public <T> String createRangeConditioneForProc(final T startRangeValue, final T endRangeValue) {
		LOGGER.debug("CommonUtils:: createNumberRangeConditioneForProc() ");
		String value = "";
		try {
			final StringBuilder stringBuilder = new StringBuilder();
			if (null != startRangeValue) {
				stringBuilder.append(">=").append(DerivzCommonConstants.QUERY_DELIMETER);
			}
			if (null != endRangeValue) {
				stringBuilder.append("<=").append(DerivzCommonConstants.QUERY_DELIMETER);
			}
			value = stringBuilder.toString();
		} catch (Exception e) {
			LOGGER.error("CommonUtils:: createNumberRangeConditioneForProc() :: Error occured " + e, e);
			throw e;
		}
		return value;
	}

	/**
	 * @name convertTimeStamptoDateFormat
	 * @param Timestamp
	 * @return Date
	 * @throws ParseException 
	 */
	public Date convertTimeStamptoDateFormat(final Timestamp timestamp) throws ParseException {
		LOGGER.debug("CommonUtils:: convertTimeStamptoDateFormat() ");
		final Date date = new Date(timestamp.getTime());
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy");
		final String timeStampToString = simpleDateFormat.format(date);
		return simpleDateFormat.parse(timeStampToString);
	}

	/**
	 * @name formattingString
	 * @param input
	 * @return
	 */
	public static String formattingString(final String input) {
		// In case s_m_e, the name of the entity is not in regular order like the camel
		// Case one , then the case is handled this way.
		List<String> formattedString = Arrays.stream(input.split("_")).filter(item -> item.length() == 1)
				.collect(Collectors.toList());
		if (formattedString.size() == (input.split("_")).length) {
			return input.replace("_", "");
		}

		final String bactrianCamel = Stream.of(input.split("[^a-zA-Z0-9]"))
				.map(v -> v.substring(0, 1).toUpperCase() + v.substring(1).toLowerCase()).collect(Collectors.joining());
		return bactrianCamel.toLowerCase().substring(0, 1) + bactrianCamel.substring(1);
	}

	public static String replaceCamelCaseToUnderscoreSeparated(final String input) {
		// This method is to change strings like currencyCode to currency_code
		// this case is used in collateral search type name
		String replaceString = "";
		if (null != input)
			replaceString = input.replaceAll("([A-Z]+)", "\\_$1").toLowerCase();
		return replaceString;

	}
	
	private void appendAndReplace(List<String> valueList,StringBuilder stringBuilder) {
		
		for (final String value : valueList) {
			stringBuilder.append("'");
			if (value.contains("'")) {
				stringBuilder.append(value.replace("'", "''"));
			} else {
				stringBuilder.append(value);
			}
			stringBuilder.append("'");
			stringBuilder.append(",");
		}
		stringBuilder.setCharAt(stringBuilder.lastIndexOf(","), '|');
		stringBuilder.append('~');
	}

	public String createIncludeExcludeValue(final List<String> andValueList, final List<String> orValuesList,final List<String> butNotValuesList) {
		LOGGER.debug("CommonUtils:: createIncludeExcludeValue() ");
		String value = "";
		final StringBuilder stringBuilder = new StringBuilder();
		if (null != andValueList && !andValueList.isEmpty()) {
			appendAndReplace(andValueList,stringBuilder);
		} else if (null != orValuesList && !orValuesList.isEmpty()) {
			appendAndReplace(orValuesList,stringBuilder);
		}
		if (null != butNotValuesList && !butNotValuesList.isEmpty()) {
			appendAndReplace(butNotValuesList,stringBuilder);
		}
		value = stringBuilder.toString();
		return value;
	}

	public String createIncludeExcludeCondition(final List<String> andValueList, List<String> orValuesList,List<String> butNotValuesList) {
		LOGGER.debug("CommonUtils:: createIncludeExcludeCondition() ");
		String value = "";
		final StringBuilder stringBuilder = new StringBuilder();

		if (!andValueList.isEmpty() && !butNotValuesList.isEmpty()) {
			stringBuilder.append(DerivzCommonConstants.AND).append(DerivzCommonConstants.QUERY_DELIMETER).append(DerivzCommonConstants.NOT_IN).append(DerivzCommonConstants.QUERY_DELIMETER);
		} else if (!orValuesList.isEmpty() && !butNotValuesList.isEmpty()) {
			stringBuilder.append(DerivzCommonConstants.OR).append(DerivzCommonConstants.QUERY_DELIMETER).append(DerivzCommonConstants.NOT_IN).append(DerivzCommonConstants.QUERY_DELIMETER);
		} else if (!andValueList.isEmpty() && butNotValuesList.isEmpty()) {
			stringBuilder.append(DerivzCommonConstants.AND).append(DerivzCommonConstants.QUERY_DELIMETER);
		} else if (!orValuesList.isEmpty()  && butNotValuesList.isEmpty()) {
			stringBuilder.append(DerivzCommonConstants.IN).append(DerivzCommonConstants.QUERY_DELIMETER);
		} else if (!butNotValuesList.isEmpty() && (orValuesList.isEmpty() || andValueList.isEmpty())) {
			stringBuilder.append(DerivzCommonConstants.NOT_IN).append(DerivzCommonConstants.QUERY_DELIMETER);
		}

		value = stringBuilder.toString();
		return value;

	}

}