package com.citi.aqua.derivz.commons.constants;

public interface DerivzCommonConstants {

	String APP_MNEMONIC = "CEFT";
	
	String FLAT_VIEW = "FLAT";

	String TREE_VIEW = "TREE";

	String SETTINGS_TYPE_LIST = "Settings";

	String SEARCH_TYPE_LIST = "Search";

	String DEFAULT_SEARCH_LIST_NAME = "Default";

	String DROPDOWN_COMPONENT_TYPE = "DROPDOWN";

	String INCLUDE_EXCLUDE_COMPONENT_TYPE = "INCLUDE_EXCLUDE";

	int PREVIOUS_SELECTED_FLAG = 0;
	
	int LAST_SELECTED_FLAG = 1;

	int INTERGER_ONE = 1;

	String DIM_AGREEMENT_NODE_NAME = "dim_agreement";

	String SUCCESS_KEYWORD = "SUCCESS";
	
	String MAC_MODULE = "MAC";
	
	String DDMMYYYY_FORMAT="dd/MM/yyyy";
	
	String YYYYMMDD_FORMAT="yyyy-MM-dd";
	
	String QUERY_DELIMETER = "|~";
	
	String LISTED = "Listed";
	
	String CURRENT_POSTINGS = "Current Postings";
	
	String BOX = "Box";
	
	String CAPACITY = "Capacity";
	
	String LOGOUT_MESSAGE="User Logged out successfully";
	
	
	// INLCUDE EXCLUDE OPERATOR
	String NOT_IN = "NOT IN";	
	String AND = "AND";	
	String IN = "IN";
	String OR = "OR";

}