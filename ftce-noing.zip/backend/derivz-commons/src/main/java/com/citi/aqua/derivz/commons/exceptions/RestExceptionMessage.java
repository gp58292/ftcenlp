package com.citi.aqua.derivz.commons.exceptions;

public enum RestExceptionMessage implements ExceptionMessageDescriptor {

	// Exception Summary ESXXX
	FAILED_DATASET_GET_DATA("DS001", "Failed to retrieve dataset {0} data."), FAILED_AUTH_SSL_CONFIG_LOAD("ATH0001",
			"Failed to SSL Configuration from property."), FAILED_TABLE_GET_DATA("TBL001",
					"Failed to retrieve fields for the table"), FAILED_UNIQUE_REFERENCE_RETRIEVAL("DS002",
							"Failed to retrieve reference data"), GENERIC_MESSAGE_FOR_FAILURE("GM001",
									"Reason unknown for failure"), FAILED_TREE_VIEW_LOAD("DS004",
											"Failed to load Tree View"), FAILED_FLAT_VIEW_LOAD("DS005",
													"Failed to load Tree View");

	private String messageCode;
	private String messageDescription;

	RestExceptionMessage(String messageCode, String messageDescription) {
		this.messageCode = messageCode;
		this.messageDescription = messageDescription;
	}

	public String getMessageCode() {
		return messageCode;
	}

	public String getMessageDescription() {
		return messageDescription;
	}

}
