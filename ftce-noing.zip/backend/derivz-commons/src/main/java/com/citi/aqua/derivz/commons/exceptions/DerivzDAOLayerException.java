package com.citi.aqua.derivz.commons.exceptions;

import lombok.Getter;

@Getter
public enum DerivzDAOLayerException implements ExceptionMessageDescriptor {

	// Exception Summary ESXXX
	FAILED_DATASET_GET_DATA("DS001", "Failed to retrieve dataset {0} data."), 
	FAILED_TABLE_GET_DATA("TBL001","Failed to retrieve fields for the table"),
	FAILED_UNIQUE_REFERENCE_RETRIEVAL("DS002","Failed to retrieve reference data"), 
	FAILED_REFERENCE_GET_DATA("RDF001","Failed to retrieve reference data"),
	FAILED_STATIC_GET_DATA("RDF002","Failed to retrieve static data"),
	FAILED_SETTINGS_LIST_RETRIEVAL("DS003","Failed to retrieve settings list "),
	FAILED_SETTINGS_GET_DATA("RDF002","Failed to retrieve settings list"),
	FAILED_SETTINGS_LIST_SAVE("DS003","Failed to save user's settings list"), 
	FAILED_SETTINGS_SAVE_LIST("RDF003","Failed to retrieve settings list"),
	FAILED_SEARCH_LIST_DELETE("DS004","Failed to delete user's search list"),
	FAILED_SEARCH_DELETE_LIST("RDF004","Failed to delete search list"),
	FAILED_SEARCH_LIST_GET("DS005","Failed to get user's search list"),
	FAILED_UPDATE_BOOKMARK("DS006","Failed to update user's bookmark"),
	FAILED_RETRIEVE_BOOKMARKS("DS007","No Bookmarks Exists for the given user"),
	FAILED_RETRIEVE_FACTORY("DS008","Failed to retrieve the factory data "),
	FAILED_SEARCH_PROCEDURE("DS009","Failed to retrieve search from list procedure"),
	FAILED_SHARING_BOOKMARK_DATA("RDF005","Failed to share bookmark data");

	private String messageCode;
	private String messageDescription;

	DerivzDAOLayerException(String messageCode, String messageDescription) {
		this.messageCode = messageCode;
		this.messageDescription = messageDescription;
	}

}
