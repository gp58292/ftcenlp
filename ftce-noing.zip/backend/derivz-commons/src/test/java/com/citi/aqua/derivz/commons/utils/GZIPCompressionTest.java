package com.citi.aqua.derivz.commons.utils;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;

public class GZIPCompressionTest {
	GZIPCompression gZIPCompression = new GZIPCompression();
			 

	@Test
	public void testCompress() {		
		String stringToCompress = "test";		
		assertNotNull(gZIPCompression.compress(stringToCompress));			
	}

	@Test
	public void testDecompress() {
		byte[] compressed = new byte[] {1,2};
		assertNotNull(gZIPCompression.decompress(compressed));			
	}

	@Test
	public void testIsCompressed() {
		byte[] compressed = new byte[] {1,2};
		assertNotNull(gZIPCompression.isCompressed(compressed));				
	}

}
