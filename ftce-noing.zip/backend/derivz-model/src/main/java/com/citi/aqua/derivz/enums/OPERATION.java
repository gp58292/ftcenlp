package com.citi.aqua.derivz.enums;

import java.util.function.Function;

public enum OPERATION {

	AND("and"),
	OR("or"),
	OR_N("or_n");
	
	private final String name;
	private OPERATION(String name) {this.name=name;}
	public String getName() {return this.name;}
	
	private static final Function<String, OPERATION> func =EnumUtils.lookupMap(OPERATION.class, e -> e.getName());
	public static OPERATION valueOfByName(String name) {return func.apply(name);}
}
