package com.citi.aqua.derivz.model;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Entity
@Table(name = DerivzDBConstants.TBL_CEFT_APP_USER_LOG, schema = DerivzDBConstants.SCHEMA_CEFT)
public class AppUserLogging extends BaseEntity {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "log_id")
	private Long logId;

	@Column(name = "soeid")
	private String soeid;

	@Column(name = "activity")
	private String activity;

	@Column(name = "user_name")
	private String userName;

	@Column(name = "create_time")
	private Date createdTime;

	@Column(name = "app_type")
	private String appType;

}