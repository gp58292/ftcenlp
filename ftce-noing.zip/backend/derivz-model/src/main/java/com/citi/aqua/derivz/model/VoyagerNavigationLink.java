package com.citi.aqua.derivz.model;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Service;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@ToString
@ConfigurationProperties("voyager.application")
@Service
public class VoyagerNavigationLink {

    @Getter @Setter private String hostname;
    @Getter @Setter private Integer port;
   
}
