package com.citi.aqua.derivz.vo;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@JsonInclude(Include.NON_NULL)
public class PostingDataVO {

	private Long agreementId;
	private Long collateralPosting;
	private Long mtmUsd;

	private String segNonSeg;
	private String postedRecieved;
	private String imVm;
	private String collateralType;
	private String collateralCurrency;
	private String positionType;
	private String collateralSourceSystem;

	private Double collateralAmtUsdPostHc;
	private Double collateralAmtUsdPreHc;
	private Double collateralAmtCcyPreHc;
	private Double collateralAmtCcyPostHc;

	private String liquidityType;
	private String sme;
	private String cusip;
	private String rightOfReuse;
	private String collateralCategory;
	private String isin;
	private String partyLegalEntity;
	private String typeOfCollateral;
	
	private String clearingAgreement;
	private String consentToSubstitution;
	private String counterPartyName;
	private String cpMarginType;
	private String csaDescription;
	private String csaMarginType;
	private String csaStatusType;
	private String csaStatus;
	private String custodianRequired;
	private String customerName;
	
	private String exchangeClearedAgreement;
	private String gfcid;
	private String gfcidType;
	private String gfcidTypeDescription;
	private String governingLaw;
	private String incorporatedCountry;
	private String industrySector;
	private String mandatoryMarkFrequency;
	private String masterAgreement;
	private String masterAgreementStatus;
	private String mgdSegLevel5Desc;
	private String pledgor;
	private String triggerEvent;
	private String saTriggerEvent;
	private String interCompanyAgreement;
	
	private String clearedHouseActivity;
	private String clientClearingActivity;
	private String issuerCurrency;
	private String espLevel4;
	private String espLevel5;
	private String lcrAssetLevel;
	private String tLevel2;
	
	private String partyCustodianRequired;
	private String counterPartyCustodianRequired;
	
	private String  issuerName;
	private String descriptionSecurity;
}