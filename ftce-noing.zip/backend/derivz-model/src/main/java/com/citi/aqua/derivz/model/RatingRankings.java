package com.citi.aqua.derivz.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Builder
@Getter
@Setter
@EqualsAndHashCode(callSuper=false)
@Entity
@Table(name = DBConstants.TBL_RATING_RANKING, schema = DBConstants.SCHEMA_CEFT)
public class RatingRankings extends BaseEntity {

  private static final long serialVersionUID = 1L;
  
  @Id
  @Column(name = "uniq_id") 
  @EqualsAndHashCode.Exclude				private Long   ratingRankingKey;
  
  @Column(name = "agency_name")       	   	private String agencyName;
  @Column(name = "term")       	   			private String term;
  @Column(name = "rating")       	   		private String rating;
  @Column(name = "rank")                	private Long   rank;
  
}
