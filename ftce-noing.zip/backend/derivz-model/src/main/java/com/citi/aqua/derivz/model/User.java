package com.citi.aqua.derivz.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class User implements Serializable {

	private static final long serialVersionUID = 1L;

	private String soeid;
	private String name;
	private String password;
	private String newpassword;
	private String ssoSessionID;
	private LoginStatusEnum statusCode;
	private String statusMessage;
	private String email;
	@SuppressWarnings("unused")
	private boolean isAuthorized;
	private String redirectURI;
	@SuppressWarnings("unused")
	private boolean isAuthenticated;
	private List<String> accessList = new ArrayList<>();
	private String assignmentGroupId;
	private String token;
	private boolean isTokenValid;
	
	public boolean isAuthorized() {
		return statusCode.equals(LoginStatusEnum.DVIZ_200);
	}
	public boolean getIsAuthenticated() {
		return null != statusCode && statusCode.equals(LoginStatusEnum.DVIZ_200);
	}

	public void setStatus(LoginStatusEnum statusCode) {
		this.statusCode = statusCode;
		this.statusMessage = statusCode.getStatusMsg();
	}

}