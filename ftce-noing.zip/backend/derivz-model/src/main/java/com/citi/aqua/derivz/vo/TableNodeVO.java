package com.citi.aqua.derivz.vo;

import java.io.Serializable;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class TableNodeVO implements Serializable {

	private static final long serialVersionUID = 1L;

	private String name;

	@SuppressWarnings("rawtypes")
	private List<SearchFieldVO> children;

}