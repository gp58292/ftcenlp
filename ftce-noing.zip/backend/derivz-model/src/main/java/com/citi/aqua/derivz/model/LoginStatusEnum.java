package com.citi.aqua.derivz.model;

public enum LoginStatusEnum {

	DVIZ_200("Success"), 
	DVIZ_401("Not Authenticated"),
	DVIZ_400("Not Authorized in AQUA"), 
	DVIZ_500("Password Expired"),
	DVIZ_600("Account Locked"),
	DVIZ_700("Session Invalidated"),
	DVIZ_800("CITI SSO Service Communication Error"),
	DVIZ_900("AQUA SSO Service Communication Error"),
	DVIZ_1000("Force password change requested for user");

	private String statusMsg;

	LoginStatusEnum(String statusMsg) {
		this.statusMsg = statusMsg;
	}

	public String getStatusMsg() {
		return statusMsg;
	}
}