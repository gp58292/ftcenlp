package com.citi.aqua.derivz.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Entity
@Table(name = DerivzDBConstants.TBL_STATIC_COMPONENT, schema = DerivzDBConstants.SCHEMA_CEFT)
public class SelectionFilters extends BaseEntity {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "composite_key")
	private Long filterKey;

	@Column(name = "data_type")
	private String attributeDatatype;

	@Column(name = "component_type")
	private String componentType;

	@Column(name = "display_name")
	private String displayName;

	@Column(name = "schema_name")
	private String schemaName;

	@Column(name = "node_name")
	private String nodeName;

	@Column(name = "field_name")
	private String fieldName;

	// @Column(name = "logical_group") - JIRA 7072 -- Now this column used by DB for internal processing.
	@Column(name = "log_grp_display_name")
	private String logicalGroup;

	@Column(name = "is_distinct_required")
	private int distinctRequired;

	@Column(name = "node_display_name")
	private String nodeDisplayName;

	@Column(name = "is_displayed")
	private Integer isDisplayed;

	@Column(name = "defualt_selected")
	private Integer defaultSelected;

	@Column(name = "who_has_flag")
	private Integer whoHasFlag;
	
	@Column(name = "collateral_lookup_field")
	private Integer collateralLookup;
	
	@Column(name = "filter_only_flag")
	private Integer filterOnlyFlag;

}