package com.citi.aqua.derivz.vo;

import java.io.IOException;
import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class ConditionCriteriaVO<T> implements Serializable {

	private static final long serialVersionUID = 1L;

	private T start;

	private T end;

	private String[] inValue;

	private String[] andValue;

	private String[] orValue;

	private String[] butNotValue;
	
    private void writeObject(java.io.ObjectOutputStream stream) throws IOException {
        stream.writeObject(start);
        stream.writeObject(end);
    }

    @SuppressWarnings("unchecked")
	private void readObject(java.io.ObjectInputStream stream)  throws IOException, ClassNotFoundException {
    	start = (T) stream.readObject();
        end = (T) stream.readObject();
    }

}