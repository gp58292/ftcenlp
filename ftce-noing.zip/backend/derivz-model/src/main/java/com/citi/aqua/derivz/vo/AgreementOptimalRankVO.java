package com.citi.aqua.derivz.vo;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AgreementOptimalRankVO {
	
	private Long agreementKey;
	
	private String optimalRank;

}
