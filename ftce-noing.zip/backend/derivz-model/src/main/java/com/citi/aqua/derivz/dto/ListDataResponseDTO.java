package com.citi.aqua.derivz.dto;

import java.util.List;
import java.util.Map;
import com.citi.aqua.derivz.model.DimAgreement;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class ListDataResponseDTO {

	private List<DimAgreement> dimAgreementList;
    
    private List<Map<String,Object>> listOfRecords;
	private String cobDate;
	private Long count;

}