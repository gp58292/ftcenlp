package com.citi.aqua.derivz.enums;

import java.util.function.Function;

public enum ComponentType {

	DROPDOWN("DROPDOWN"),
	TYPEAHEAD_TEXTBOX("TYPEAHEAD_TEXTBOX"),
	INCLUDE_EXCLUDE("INCLUDE_EXCLUDE"),
	NUMERIC_RANGE_FILTER("NUMERIC_RANGE_FILTER"),
	DATE_RANGE_FILTER("DATE_RANGE_FILTER"),
    FREE_FORM_TEXT("FREE_FORM_TEXT"),
    RATING_RANGE("RATING_RANGE"),
    TENOR_RANGE("TENOR_RANGE"),
    MULTI_INCLUDE_EXCLUDE("MULTI_INCLUDE_EXCLUDE");
	
	
	private final String name;
	private ComponentType(String name) {this.name=name;}
	public String getName() {return this.name;}
	
	private static final Function<String, ComponentType> func =EnumUtils.lookupMap(ComponentType.class, e -> e.getName());
	public static ComponentType valueOfByName(String name) {return func.apply(name);}
}
