package com.citi.aqua.derivz.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedStoredProcedureQueries;
import javax.persistence.NamedStoredProcedureQuery;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureParameter;
import javax.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
/**
 * The persistent class for the dim_agreement database table.
 * 
 */
@Getter
@Setter
@ToString
@NoArgsConstructor
@Entity
@Table(name = DerivzDBConstants.DIM_AGREEMENT, schema = DerivzDBConstants.SCHEMA_DZ)
@NamedStoredProcedureQueries({
		@NamedStoredProcedureQuery(name = "in_only_test", procedureName = "dz.usp_deriv_mac_data_retrieval", resultClasses = {
				DimAgreement.class }, parameters = {
						@StoredProcedureParameter(name = "@input", type = List.class, mode = ParameterMode.IN) }) })
public class DimAgreement implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "agreement_key")
	private long agreementKey;

	private String address;

	@Column(name = "agreement_ccy")
	private String agreementCcy;

	@Column(name = "agreement_id")
	private int agreementId;

	private String alco;

	@Column(name = "auto_early_termination_flag")
	private String autoEarlyTerminationFlag;

	private String bankruptcy;

	private String basis;

	@Column(name = "calculation_agent")
	private String calculationAgent;

	@Column(name = "call_frequency")
	private String callFrequency;

	@Column(name = "call_month")
	private int callMonth;

	@Column(name = "callday1_eom")
	private String callday1Eom;

	@Column(name = "callday1_ofmonth")
	private int callday1Ofmonth;

	@Column(name = "callday2_eom")
	private String callday2Eom;

	@Column(name = "callday2_ofmonth")
	private int callday2Ofmonth;

	@Column(name = "capfloor_addendum")
	private String capfloorAddendum;

	@Column(name = "cash_coll_delivery_deadline")
	private int cashCollDeliveryDeadline;

	@Column(name = "cash_collateral_index_time")
	private int cashCollateralIndexTime;

	@Column(name = "cash_delivery_banking_days")
	private int cashDeliveryBankingDays;

	private String chain;

	@Column(name = "citi_threshold")
	private String citiThreshold;

	@Column(name = "cleared_activity")
	private String clearedActivity;

	@Column(name = "cleared_house_activity")
	private String clearedHouseActivity;

	@Column(name = "clearing_agreement")
	private String clearingAgreement;

	@Column(name = "client_clearing_activity")
	private String clientClearingActivity;

	@Column(name = "closeout_amount_protocol")
	private String closeoutAmountProtocol;

	@Column(name = "closeout_netting_enforcability_flag")
	private String closeoutNettingEnforcabilityFlag;

	@Column(name = "collateral_calculation_agent")
	private String collateralCalculationAgent;

	@Column(name = "collateral_call_deadline")
	private String collateralCallDeadline;

	@Column(name = "collateral_notification_region")
	private String collateralNotificationRegion;

	@Column(name = "collateral_securities_term")
	private String collateralSecuritiesTerm;

	@Column(name = "collateral_valuation_frequency")
	private String collateralValuationFrequency;

	@Column(name = "common_custodian")
	private String commonCustodian;

	@Column(name = "consent_to_substitution")
	private String consentToSubstitution;

	private String contact;

	@Column(name = "counter_party_key")
	private long counterPartyKey;

	@Column(name = "counter_party_reporting_key")
	private long counterPartyReportingKey;

	@Column(name = "counterparty_multibranch")
	private String counterpartyMultibranch;

	@Column(name = "counterparty_name")
	private String counterpartyName;

	@Column(name = "country_name")
	private String countryName;

	@Column(name = "cp_borrowing_threshold")
	private double cpBorrowingThreshold;

	@Column(name = "cp_credit_based_threshold_amount")
	private String cpCreditBasedThresholdAmount;

	@Column(name = "cp_custodian_required")
	private String cpCustodianRequired;

	@Column(name = "cp_margin_type")
	private String cpMarginType;

	@Column(name = "cp_minimum_call_threshold_amount")
	private double cpMinimumCallThresholdAmount;

	@Column(name = "cp_minimum_return_threshold_amount")
	private double cpMinimumReturnThresholdAmount;

	@Column(name = "cp_rating")
	private String cpRating;

	@Column(name = "cp_rating_agency")
	private String cpRatingAgency;

	@Column(name = "cp_specified_entities")
	private String cpSpecifiedEntities;

	@Column(name = "cp_specified_indebtedness")
	private String cpSpecifiedIndebtedness;

	@Column(name = "cp_specified_transactions")
	private String cpSpecifiedTransactions;

	@Column(name = "cp_termination_currency")
	private String cpTerminationCurrency;

	@Column(name = "cp_threshold")
	private double cpThreshold;

	@Column(name = "cp_threshold_basis")
	private String cpThresholdBasis;

	@Column(name = "cp_threshold_threshold_amount")
	private double cpThresholdThresholdAmount;

	@Column(name = "cp_transaction_threshold")
	private double cpTransactionThreshold;

	@Column(name = "cp_type_of_borrowing_threshold")
	private String cpTypeOfBorrowingThreshold;

	@Column(name = "cpincremental_movement_amount")
	private double cpincrementalMovementAmount;

	@Column(name = "csa_code")
	private int csaCode;

	@Column(name = "csa_description")
	private String csaDescription;

	@Column(name = "csa_margin_type")
	private String csaMarginType;

	@Column(name = "csa_status")
	private String csaStatus;

	private String currency;

	@Column(name = "custodian_required")
	private String custodianRequired;

	@Column(name = "custody_bank_name")
	private String custodyBankName;

	@Column(name = "customer_name")
	private String customerName;

	@Column(name = "deleted_flag")
	private int deletedFlag;

	@Column(name = "derivs_provision")
	private String derivsProvision;

	@Column(name = "dispute_mechanism")
	private String disputeMechanism;

	@Column(name = "end_date_sys_aq")
	private Timestamp endDateSysAq;

	private String entity;

	@Column(name = "entry_date")
	private Timestamp entryDate;

	@Column(name = "exchangecleared_agreement")
	private String exchangeclearedAgreement;

	private String extension;

	private String fatca;

	private String fax;

	@Column(name = "file_number")
	private String fileNumber;

	@Column(name = "firm_address")
	private String firmAddress;

	@Column(name = "firm_contact")
	private String firmContact;

	@Column(name = "firm_custody_bank_name")
	private String firmCustodyBankName;

	@Column(name = "firm_fax")
	private String firmFax;

	@Column(name = "firm_telephone")
	private String firmTelephone;

	@Column(name = "fx_provision")
	private String fxProvision;

	@Column(name = "fxo_provision")
	private String fxoProvision;

	@Column(name = "governing_law")
	private String governingLaw;

	@Column(name = "ia_threshold")
	private BigDecimal iaThreshold;

	@Column(name = "im_floor")
	private double imFloor;

	private BigDecimal imcap;

	@Column(name = "incorporated_country")
	private String incorporatedCountry;

	@Column(name = "incremental_movement_amount")
	private double incrementalMovementAmount;

	@Column(name = "inter_company_agreement")
	private String interCompanyAgreement;

	@Column(name = "intercompany_type")
	private String intercompanyType;

	@Column(name = "is_key_only")
	private short isKeyOnly;

	@Column(name = "last_modified")
	private Timestamp lastModified;

	@Column(name = "link_mrnccd_outofscope_trades")
	private String linkMrnccdOutofscopeTrades;

	@Column(name = "ma_date")
	private Timestamp maDate;

	@Column(name = "mandatory_mark_frequency")
	private String mandatoryMarkFrequency;

	@Column(name = "margin_effective_date")
	private Timestamp marginEffectiveDate;

	@Column(name = "marktomarket_agent")
	private String marktomarketAgent;

	@Column(name = "master_agreement")
	private String masterAgreement;

	@Column(name = "master_agreement_status")
	private String masterAgreementStatus;

	@Column(name = "master_agreement_version")
	private String masterAgreementVersion;

	@Column(name = "master_role")
	private String masterRole;

	@Column(name = "mini_transfer_amt")
	private double miniTransferAmt;

	@Column(name = "mirror_agreementid")
	private int mirrorAgreementid;

	private String mnemonic;

	@Column(name = "mrnccd_compliance")
	private String mrnccdCompliance;

	@Column(name = "mtm_currency")
	private String mtmCurrency;

	@Column(name = "multi_branch_margining")
	private String multiBranchMargining;

	@Column(name = "multi_currency_margining")
	private String multiCurrencyMargining;

	@Column(name = "negotiation_startdate")
	private Timestamp negotiationStartdate;

	private String netting;

	@Column(name = "parent_child")
	private String parentChild;

	@Column(name = "party_associate")
	private String partyAssociate;

	@Column(name = "party_borrowing_threshold")
	private double partyBorrowingThreshold;

	@Column(name = "party_creditbased_threshold_amount")
	private String partyCreditbasedThresholdAmount;

	@Column(name = "party_custodian_required")
	private String partyCustodianRequired;

	@Column(name = "party_key")
	private long partyKey;

	@Column(name = "party_legal_entity")
	private String partyLegalEntity;

	@Column(name = "party_margin_type")
	private String partyMarginType;

	@Column(name = "party_minimum_call_threshold_amount")
	private double partyMinimumCallThresholdAmount;

	@Column(name = "party_minimum_return_threshold_amount")
	private double partyMinimumReturnThresholdAmount;

	@Column(name = "party_multibranch")
	private String partyMultibranch;

	@Column(name = "party_pse_margin_reduction")
	private String partyPseMarginReduction;

	@Column(name = "party_rating")
	private String partyRating;

	@Column(name = "party_rating_agency")
	private String partyRatingAgency;

	@Column(name = "party_reporting_key")
	private long partyReportingKey;

	@Column(name = "party_specified_entities")
	private String partySpecifiedEntities;

	@Column(name = "party_specified_indebtedness")
	private String partySpecifiedIndebtedness;

	@Column(name = "party_specified_transactions")
	private String partySpecifiedTransactions;

	@Column(name = "party_termination_currency")
	private String partyTerminationCurrency;

	@Column(name = "party_threshold_basis")
	private String partyThresholdBasis;

	@Column(name = "party_threshold_threshold_amount")
	private double partyThresholdThresholdAmount;

	@Column(name = "party_transaction_threshold")
	private double partyTransactionThreshold;

	@Column(name = "party_type_of_borrowing_threshold")
	private String partyTypeOfBorrowingThreshold;

	@Column(name = "pbg_indicator")
	private String pbgIndicator;

	private String pledgor;

	@Column(name = "pse_margin_last_modified")
	private Timestamp pseMarginLastModified;

	@Column(name = "pse_margin_reduction")
	private String pseMarginReduction;

	@Column(name = "pse_margin_reduction_flag")
	private String pseMarginReductionFlag;

	@Column(name = "restrictions_on_collateral")
	private String restrictionsOnCollateral;

	@Column(name = "sa_trigger_event")
	private String saTriggerEvent;

	@Column(name = "securities_delivery_banking_days")
	private int securitiesDeliveryBankingDays;

	@Column(name = "security_agreementdate")
	private Date securityAgreementdate;

	@Column(name = "security_call_day_Of_week")
	private String securityCallDayOfWeek;

	@Column(name = "security_counterparty_name")
	private String securityCounterpartyName;

	@Column(name = "security_governing_law")
	private String securityGoverningLaw;

	@Column(name = "security_type_of_account")
	private String securityTypeOfAccount;

	@Column(name = "service_representative")
	private String serviceRepresentative;

	@Column(name = "sft_basel_netting")
	private String sftBaselNetting;

	private String shelf;

	@Column(name = "six_c_applies")
	private String sixCApplies;

	@Column(name = "sixc_applied")
	private String sixcApplied;

	@Column(name = "source_system")
	private String sourceSystem;

	@Column(name = "start_date_sys_aq")
	private Timestamp startDateSysAq;

	private String telephone;

	@Column(name = "tend_applies")
	private String tendApplies;

	@Column(name = "termination_date")
	private Date terminationDate;

	@Column(name = "termination_timing")
	private String terminationTiming;

	@Column(name = "termination_type")
	private String terminationType;

	@Column(name = "third_party_cust_flag")
	private String thirdPartyCustFlag;

	@Column(name = "threshold_amount")
	private double thresholdAmount;

	@Column(name = "threshold_basis")
	private String thresholdBasis;

	@Column(name = "threshold_currency")
	private String thresholdCurrency;

	@Column(name = "trigger_event")
	private String triggerEvent;

	private String triparty;

	@Column(name = "true_segregation")
	private String trueSegregation;

	@Column(name = "use_billingfee_as_collateral")
	private String useBillingfeeAsCollateral;

	@Column(name = "use_coupon_as_collateral")
	private String useCouponAsCollateral;

	@Column(name = "use_excess_vm_as_im_collateral")
	private String useExcessVmAsImCollateral;

	@Column(name = "use_fee_as_collateral")
	private String useFeeAsCollateral;

	@Column(name = "use_pai_as_collateral")
	private String usePaiAsCollateral;

	@Column(name = "usenscnew_rules")
	private String usenscnewRules;

	@Column(name = "var_eligible")
	private String varEligible;

	@Column(name = "vm_collateral_in_cash_only")
	private String vmCollateralInCashOnly;

	@Column(name = "s_m_e")
	private String sme;

}