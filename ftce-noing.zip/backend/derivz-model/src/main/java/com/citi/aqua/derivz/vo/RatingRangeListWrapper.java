package com.citi.aqua.derivz.vo;

import java.io.IOException;
import java.io.Serializable;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;


@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Builder
@Getter
@Setter
@JsonDeserialize(using = RatingRangeListWrapperDeserializer.class)
public class RatingRangeListWrapper<T> implements Serializable {

	private static final long serialVersionUID = 1L;
	
	
	private RatingRangeList<T> inValueList;
	
	private RatingRangeList<T> notInValueList;
	
    private void writeObject(java.io.ObjectOutputStream stream) throws IOException {
        stream.writeObject(inValueList);
        stream.writeObject(notInValueList);
    }

	@SuppressWarnings("unchecked")
	private void readObject(java.io.ObjectInputStream stream)  throws IOException, ClassNotFoundException {
		inValueList = (RatingRangeList<T>) stream.readObject();
		notInValueList=(RatingRangeList<T>) stream.readObject();
    }
}
