package com.citi.aqua.derivz.vo;

import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.aqua.derivz.enums.ComponentType;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;
import com.fasterxml.jackson.databind.type.TypeFactory;

public class SearchVODeserializer<T> extends StdDeserializer<SearchFieldVO<T>> {
	
	private static Logger log = LoggerFactory.getLogger(SearchVODeserializer.class);

	static ObjectMapper objectMapper = new ObjectMapper();
	static TypeFactory typeFactory = objectMapper.getTypeFactory();

	public SearchVODeserializer() {
		this(null);
	}

	protected SearchVODeserializer(Class<?> vc) {
		super(vc);
	}

	private static final long serialVersionUID = 1L;

	@Override
	public SearchFieldVO<T> deserialize(JsonParser p, DeserializationContext ctxt)
			throws IOException {
		JsonNode node = p.getCodec().readTree(p);
		SearchFieldVO.SearchFieldVOBuilder<T> scvb = SearchFieldVO.builder();

		if (node.get("fieldName") != null)
			scvb.fieldName(node.get("fieldName").asText());
		if (node.get("nodeName") != null)
			scvb.nodeName(node.get("nodeName").asText());
		if (node.get("dataType") != null)
			scvb.dataType(node.get("dataType").asText());
		if (node.get("logicalGroupName") != null)
			scvb.logicalGroupName(node.get("logicalGroupName").asText());
		if (node.get("displayName") != null)
			scvb.name(node.get("displayName").asText());
		if (node.get("schemaName") != null)
			scvb.schemaName(node.get("schemaName").asText());
		if (node.get("nodeDisplayName") != null)
			scvb.nodeDisplayName(node.get("nodeDisplayName").asText());
		if (node.get("distinctRequired") != null)
			scvb.distinctRequired(node.get("distinctRequired").asInt());
		if (node.get("key") != null)
			scvb.key(node.get("key").asLong());
		if (node.get("whoHasFlag") != null)
			scvb.whoHasFlag(node.get("whoHasFlag").asInt());
		String nameOfComp = node.get("componentType").asText();
		ComponentType compType = ComponentType.valueOf(nameOfComp);
		scvb.componentType(compType);

		T val;
		val = buildValue(node.get("value"), compType);
		scvb.value(val);

		return scvb.build();
	}

	@SuppressWarnings("unchecked")
	private T buildValue(JsonNode nodeValue, ComponentType compType) throws IOException {
		objectMapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
		T returnValue = null;
		if (null != nodeValue && !"".equals(nodeValue.toString())) {
			switch (compType) {
			case DROPDOWN:
				returnValue = objectMapper.readValue(nodeValue.toString(),
						typeFactory.constructArrayType(ReferenceDataVO.class));
				break;
			case TYPEAHEAD_TEXTBOX:
				returnValue = objectMapper.readValue(nodeValue.toString(),
						typeFactory.constructArrayType(ReferenceDataVO.class));
				break;
			case FREE_FORM_TEXT: {
				returnValue = objectMapper.readValue(nodeValue.toString(), typeFactory.constructType(String.class));
				break;
			}
			case INCLUDE_EXCLUDE: {
				JavaType includeType = typeFactory.constructArrayType(Long.class);
				returnValue = objectMapper.readValue(nodeValue.toString(),
						typeFactory.constructParametricType(IncludeExcludeVO.class, includeType));
				break;
			}
			case MULTI_INCLUDE_EXCLUDE: {
				JavaType includeType = typeFactory.constructArrayType(Long.class);
				returnValue = objectMapper.readValue(nodeValue.toString(),
						typeFactory.constructParametricType(IncludeExcludeListWrapper.class, includeType));
				break;
			}
			case DATE_RANGE_FILTER: {
				JavaType dateType = typeFactory.constructType(String.class);
				final DateFormat df = new SimpleDateFormat("yyyy-MM-dd");

				RangeVO<String> dateStringVal = objectMapper.readValue(nodeValue.toString(),
						typeFactory.constructParametricType(RangeVO.class, dateType));
				RangeVO<Date> dateVal = new RangeVO<>();
				try {
					if (null != dateStringVal.getStart()) {
						dateVal.setStart(df.parse(dateStringVal.getStart()));
					}
					if (null != dateStringVal.getEnd()) {
						dateVal.setEnd(df.parse(dateStringVal.getEnd()));
					}
				} catch (ParseException e) {
					log.error("SearchVODeserialized: buildValue:: Exception Occured", e);
				}
				returnValue = (T) dateVal;
				break;
			}
			case NUMERIC_RANGE_FILTER: {
				JavaType longType = typeFactory.constructType(Double.class);
				returnValue = objectMapper.readValue(nodeValue.toString(),
						typeFactory.constructParametricType(RangeVO.class, longType));
				break;
			}
			case RATING_RANGE: {
              JavaType stringType = typeFactory.constructType(String.class);
              returnValue = objectMapper.readValue(nodeValue.toString(),typeFactory.constructParametricType(RatingRangeListWrapper.class, stringType));
              break;
			}
			case TENOR_RANGE: {
              returnValue = objectMapper.readValue(nodeValue.toString(),typeFactory.constructType(TenorRangeList.class));
              break;
			}

			default:
				log.debug("Invalid component type...");
				break;
			}
		}
		return returnValue;
	}

}
