package com.citi.aqua.derivz.vo;

import java.io.IOException;
import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Getter;
import lombok.Setter;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
@Getter
@Setter
public class BookmarkVO implements Serializable {

	private static final long serialVersionUID = 1L;

	private Long key;
	
	private Object value;

	private Integer whoHasFlag;

    private void writeObject(java.io.ObjectOutputStream stream) throws IOException {
        stream.writeObject(value);
    }

	private void readObject(java.io.ObjectInputStream stream)  throws IOException, ClassNotFoundException {
    	value = stream.readObject();
    }

}