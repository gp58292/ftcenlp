package com.citi.aqua.derivz.vo;

import java.io.IOException;
import java.io.Serializable;

import com.citi.aqua.derivz.enums.ComponentType;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.type.TypeFactory;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * @name SearchFieldVO
 * @description Class is used to get the information corresponding to the
 *              attributes defined as filters
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Builder
@Getter
@Setter
@JsonDeserialize(using = SearchVODeserializer.class)
public class SearchFieldVO<T> implements Serializable {

	private static final long serialVersionUID = 1L;
	
	static ObjectMapper objectMapper = new ObjectMapper();
	static TypeFactory typeFactory = objectMapper.getTypeFactory();

	private String fieldName;

	private String nodeName;

	private ComponentType componentType;

	private String dataType;

	private String logicalGroupName;

	private String name;

	private String schemaName;

	private String nodeDisplayName;

	private int distinctRequired;

	private Long key;

	private T value;

	private Integer defaultSelected;

	private Integer whoHasFlag;
	
	private Integer filterOnlyFlag;
	
    private void writeObject(java.io.ObjectOutputStream stream) throws IOException {
        stream.writeObject(value);
    }

    @SuppressWarnings("unchecked")
	private void readObject(java.io.ObjectInputStream stream)  throws IOException, ClassNotFoundException {
    	value = (T) stream.readObject();
    }
	
}