package com.citi.aqua.derivz.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.Date;

import org.junit.Before;
import org.junit.Test;

public class BookmarkTest {

	private static final String TEST = "test";
	private Bookmark bookmark;
	
	@Before
	public void setUp() throws Exception {
		bookmark=new Bookmark();
	}

	@Test
	public void testGetKey() {
		bookmark.setKey(0);
		assertEquals(0, bookmark.getKey());
	}

	@Test
	public void testGetLastSelected() {
		bookmark.setLastSelected(0);
		assertEquals(0, bookmark.getLastSelected());
	}

	@Test
	public void testGetName() {
		bookmark.setName(TEST);
		assertEquals(TEST, bookmark.getName());
	}

	@Test
	public void testGetUserId() {
		bookmark.setUserId(TEST);
		assertEquals(TEST, bookmark.getUserId());
	}

	@Test
	public void testGetType() {
		bookmark.setType(TEST);
		assertEquals(TEST, bookmark.getType());
	}

	@Test
	public void testGetCriteria() {
		bookmark.setCriteria(TEST);
		assertEquals(TEST, bookmark.getCriteria());
	}

	@Test
	public void testGetUpdatedTime() {
		Date date=new Date();
		bookmark.setUpdatedTime(date);
		assertEquals(date, bookmark.getUpdatedTime());
	}

	@Test
	public void testToString() {
		assertNotNull(bookmark.toString());
	}
}
