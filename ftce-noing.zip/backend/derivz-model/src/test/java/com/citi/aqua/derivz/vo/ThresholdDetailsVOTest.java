package com.citi.aqua.derivz.vo;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class ThresholdDetailsVOTest {
	
	ThresholdDetailsVO thresholdDetailsVO;

	@Before
	public void setUp() throws Exception {
		thresholdDetailsVO= new ThresholdDetailsVO();
	}

	@Test
	public void test() {
		ThresholdDetailsVO vo= new ThresholdDetailsVO();
		vo.setAgency("TEST");
		thresholdDetailsVO.setAgency(vo.getAgency());
		thresholdDetailsVO.setAmount(vo.getAmount());
		thresholdDetailsVO.setBasis(vo.getBasis());
		thresholdDetailsVO.setCurrency(vo.getCurrency());
		thresholdDetailsVO.setRating(vo.getRating());
		thresholdDetailsVO.setRatingDate(vo.getRatingDate());
		thresholdDetailsVO.setStartDate(vo.getStartDate());
		thresholdDetailsVO.setEndDate(vo.getEndDate());
		thresholdDetailsVO.setType(vo.getType());
		thresholdDetailsVO.toString();
		thresholdDetailsVO.hashCode();
		thresholdDetailsVO.equals(vo);
		assertEquals("TEST",thresholdDetailsVO.getAgency());
	}

}
