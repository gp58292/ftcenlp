package com.citi.aqua.derivz.dto;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class ListedResponseDTOTest {
	
	private ListedResponseDTO listedResponseDTO;

	@Before
	public void setUp() throws Exception {
		listedResponseDTO= new ListedResponseDTO();
	}

	@Test
	public void testGetCobDate() {
		ListedResponseDTO dto= new ListedResponseDTO();
		listedResponseDTO.setCobDate("20180101");
		listedResponseDTO.setCount(dto.getCount());
		listedResponseDTO.setSearchCriteriaResultList(dto.getSearchCriteriaResultList());
		assertEquals("20180101",listedResponseDTO.getCobDate());
	}

}
