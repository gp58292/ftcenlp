package com.citi.aqua.derivz.vo;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class PostingDataVOTest {
	private PostingDataVO postingDataVO;
	
	@Before
	public void setUp() throws Exception {
		postingDataVO = new PostingDataVO();
	}

	@Test
	public void testGettLevel2() {
		PostingDataVO postingObj = new PostingDataVO();
		
		Long agreementId = new Long(1);
		postingObj.setAgreementId(agreementId);
		postingDataVO.setAgreementId(postingObj.getAgreementId());
				 
		postingDataVO.setClearedHouseActivity(postingObj.getClearedHouseActivity());
		postingDataVO.setClearingAgreement(postingObj.getClearingAgreement());
		postingDataVO.setClientClearingActivity(postingObj.getClientClearingActivity());
		postingDataVO.setCollateralAmtCcyPostHc(postingObj.getCollateralAmtCcyPostHc());
		postingDataVO.setCollateralAmtCcyPreHc(postingObj.getCollateralAmtCcyPreHc());					
		postingDataVO.setCollateralAmtUsdPostHc(postingObj.getCollateralAmtUsdPostHc());				
		postingDataVO.setCollateralAmtUsdPreHc(postingObj.getCollateralAmtUsdPreHc());
		postingDataVO.setCollateralCategory(postingObj.getCollateralCategory());
		postingDataVO.setCollateralCurrency(postingObj.getCollateralCurrency());		
		postingDataVO.setCollateralPosting(postingObj.getCollateralPosting());
		postingDataVO.setCollateralSourceSystem(postingObj.getCollateralSourceSystem());
		postingDataVO.setCollateralType(postingObj.getCollateralType());
		postingDataVO.setConsentToSubstitution(postingObj.getConsentToSubstitution());
		postingDataVO.setCounterPartyCustodianRequired( postingObj.getCounterPartyCustodianRequired());
		postingDataVO.setCounterPartyName( postingObj.getCounterPartyName());		 
		postingDataVO.setCpMarginType(postingObj.getCpMarginType());		 
		postingDataVO.setCsaDescription(postingObj.getCsaDescription());		 
		postingDataVO.setCsaMarginType(postingObj.getCsaMarginType());		 
		postingDataVO.setCsaStatus(postingObj.getCsaStatus());		 
		postingDataVO.setCsaStatusType(postingObj.getCsaStatusType());		 
		postingDataVO.setCusip(postingObj.getCusip());		 
		postingDataVO.setCustodianRequired(postingObj.getCustodianRequired());		 
		postingDataVO.setCustomerName(postingObj.getCustomerName());		 
		postingDataVO.setDescriptionSecurity(postingObj.getDescriptionSecurity());		 
		postingDataVO.setEspLevel4(postingObj.getEspLevel4());		 
		postingDataVO.setEspLevel5(postingObj.getEspLevel5());		
		postingDataVO.setExchangeClearedAgreement(postingObj.getExchangeClearedAgreement());			
		postingDataVO.setGfcid(postingObj.getGfcid());		 		
		postingDataVO.setGfcidType(postingObj.getGfcidType());
		postingDataVO.setGfcidTypeDescription(postingObj.getGfcidTypeDescription());
		postingDataVO.setGoverningLaw(postingObj.getGoverningLaw());
		postingDataVO.setImVm(postingObj.getImVm());
		postingDataVO.setIncorporatedCountry(postingObj.getIncorporatedCountry());
		postingDataVO.setIndustrySector(postingObj.getIndustrySector());		 
		postingDataVO.setInterCompanyAgreement(postingObj.getInterCompanyAgreement());
		postingDataVO.setIsin(postingObj.getIsin());
		postingDataVO.setIssuerCurrency(postingObj.getIssuerCurrency());
		postingDataVO.setIssuerName(postingObj.getIssuerName());
		postingDataVO.setLcrAssetLevel(postingObj.getLcrAssetLevel());
		postingDataVO.setLiquidityType(postingObj.getLiquidityType());				
		postingDataVO.setMandatoryMarkFrequency(postingObj.getMandatoryMarkFrequency());				
		postingDataVO.setMasterAgreement(postingObj.getMasterAgreement());		 			
		postingDataVO.setMasterAgreementStatus(postingObj.getMasterAgreementStatus());			
		postingDataVO.setMgdSegLevel5Desc(postingObj.getMgdSegLevel5Desc());			
		postingDataVO.setPartyCustodianRequired(postingObj.getPartyCustodianRequired());
		postingDataVO.setPartyLegalEntity(postingObj.getPartyLegalEntity());
		postingDataVO.setMtmUsd(postingObj.getMtmUsd());
		postingDataVO.setPledgor(postingObj.getPledgor());
		postingDataVO.setPositionType(postingObj.getPositionType());
		postingDataVO.setPostedRecieved(postingObj.getPostedRecieved());
		postingDataVO.setRightOfReuse(postingObj.getRightOfReuse());
		postingDataVO.setSaTriggerEvent(postingObj.getSaTriggerEvent());
		postingDataVO.setSegNonSeg(postingObj.getSegNonSeg());
		postingDataVO.setSme(postingObj.getSme());
		postingDataVO.setTLevel2(postingObj.getTLevel2());
		postingDataVO.setTriggerEvent(postingObj.getTriggerEvent());
		postingDataVO.setTypeOfCollateral(postingObj.getTypeOfCollateral());
		postingDataVO.toString(); 
		 
		
		assertEquals(agreementId, postingDataVO.getAgreementId());		
	}

}
