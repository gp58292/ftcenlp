package com.citi.aqua.derivz.vo;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

public class ReferenceDataVOTest {

	private ReferenceDataVO referenceDataVO;

	@Before
	public void setUp() throws Exception {
		referenceDataVO= new ReferenceDataVO<>();
	}

	@Test
	public void testSetValue() {
		ReferenceDataVO vo= new ReferenceDataVO(new Long(1),"");
		referenceDataVO.setKey(vo.getKey());
		referenceDataVO.setValue(vo.getValue());
		referenceDataVO.toString();
		referenceDataVO.hashCode();
		referenceDataVO.equals(vo);
		assertEquals(new Long(1),referenceDataVO.getKey());
	}
	
	@Test
	public void testSetValueConditional() {
		ReferenceDataVO vo= new ReferenceDataVO(new Long(1));
		referenceDataVO.setKey(vo.getKey());
		assertEquals(new Long(1),referenceDataVO.getKey());
	}

}
