package com.citi.aqua.derivz.dto;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class ListDataResponseDTOTest {
	
	ListDataResponseDTO listDataResponseDTO;

	@Before
	public void setUp() throws Exception {
		listDataResponseDTO= new ListDataResponseDTO();
	}

	@Test
	public void testGetDimAgreementList() {
		ListDataResponseDTO dto = new ListDataResponseDTO();
		listDataResponseDTO.setCobDate("20180101");
		listDataResponseDTO.setCount(dto.getCount());
		listDataResponseDTO.setDimAgreementList(dto.getDimAgreementList());
		assertEquals("20180101",listDataResponseDTO.getCobDate());
	}

}
