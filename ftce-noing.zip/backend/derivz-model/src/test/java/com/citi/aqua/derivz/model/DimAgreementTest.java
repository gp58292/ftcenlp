package com.citi.aqua.derivz.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Before;
import org.junit.Test;

public class DimAgreementTest {

	private static final String TEST = "test";
	private static final Long KEY = new Long(0);
	private DimAgreement dimAgreement;

	@Before
	public void setUp() throws Exception {
		dimAgreement= new DimAgreement();
	}

	@Test
	public void testGetAgreementKey() {
		dimAgreement.setAgreementKey(KEY);
		assertEquals(0, dimAgreement.getAgreementKey());
	}

	@Test
	public void testGetAddress() {
		dimAgreement.setAddress(TEST);
		assertEquals(TEST, dimAgreement.getAddress());
	}

	@Test
	public void testGetAgreementCcy() {
		dimAgreement.setAgreementCcy(TEST);
		assertEquals(TEST, dimAgreement.getAgreementCcy());
	}

	@Test
	public void testGetAgreementId() {
		dimAgreement.setAgreementId(0);
		assertEquals(0, dimAgreement.getAgreementId());
	}

	@Test
	public void testGetAlco() {
		dimAgreement.setAlco(TEST);
		assertEquals(TEST, dimAgreement.getAlco());
	}

	@Test
	public void testGetAutoEarlyTerminationFlag() {
		dimAgreement.setAutoEarlyTerminationFlag(TEST);
		assertEquals(TEST, dimAgreement.getAutoEarlyTerminationFlag());
	}

	@Test
	public void testGetBankruptcy() {
		dimAgreement.setBankruptcy(TEST);
		assertEquals(TEST, dimAgreement.getBankruptcy());
	}

	@Test
	public void testGetBasis() {
		dimAgreement.setBasis(TEST);
		assertEquals(TEST, dimAgreement.getBasis());
	}

	@Test
	public void testGetCalculationAgent() {
		dimAgreement.setCalculationAgent(TEST);
		assertEquals(TEST, dimAgreement.getCalculationAgent());
	}

	@Test
	public void testGetCallFrequency() {
		dimAgreement.setCallFrequency(TEST);
		assertEquals(TEST, dimAgreement.getCallFrequency());
	}

	@Test
	public void testGetCallMonth() {
		dimAgreement.setCallMonth(0);
		assertEquals(0, dimAgreement.getCallMonth());
	}

	@Test
	public void testGetCallday1Eom() {
		dimAgreement.setCallday1Eom(TEST);
		assertEquals(TEST, dimAgreement.getCallday1Eom());
	}

	@Test
	public void testGetCallday1Ofmonth() {
		dimAgreement.setCallday1Ofmonth(1);
		assertEquals(1, dimAgreement.getCallday1Ofmonth());
	}

	@Test
	public void testGetCallday2Eom() {
		dimAgreement.setCallday2Eom(TEST);
		assertEquals(TEST, dimAgreement.getCallday2Eom());
	}

	@Test
	public void testGetCallday2Ofmonth() {
		dimAgreement.setCallday2Ofmonth(1);
		assertEquals(1, dimAgreement.getCallday2Ofmonth());
	}

	@Test
	public void testGetCapfloorAddendum() {
		dimAgreement.setCapfloorAddendum(TEST);
		assertEquals(TEST, dimAgreement.getCapfloorAddendum());
	}

	@Test
	public void testGetCashCollDeliveryDeadline() {
		dimAgreement.setCashCollDeliveryDeadline(1);
		assertEquals(1, dimAgreement.getCashCollDeliveryDeadline());
	}

	@Test
	public void testGetCashCollateralIndexTime() {
		dimAgreement.setCashCollateralIndexTime(1);
		assertEquals(1, dimAgreement.getCashCollateralIndexTime());
	}

	@Test
	public void testGetCashDeliveryBankingDays() {
		dimAgreement.setCashDeliveryBankingDays(1);
		assertEquals(1, dimAgreement.getCashDeliveryBankingDays());
	}

	@Test
	public void testGetChain() {
		dimAgreement.setChain(TEST);
		assertEquals(TEST, dimAgreement.getChain());
	}

	@Test
	public void testGetCitiThreshold() {
		dimAgreement.setCitiThreshold(TEST);
		assertEquals(TEST, dimAgreement.getCitiThreshold());
	}

	@Test
	public void testGetClearedActivity() {
		dimAgreement.setClearedActivity(TEST);
		assertEquals(TEST, dimAgreement.getClearedActivity());
	}

	@Test
	public void testGetClearedHouseActivity() {
		dimAgreement.setClearedHouseActivity(TEST);
		assertEquals(TEST, dimAgreement.getClearedHouseActivity());
	}

	@Test
	public void testGetClearingAgreement() {
		dimAgreement.setClearingAgreement(TEST);
		assertEquals(TEST, dimAgreement.getClearingAgreement());
	}

	@Test
	public void testGetClientClearingActivity() {
		dimAgreement.setClientClearingActivity(TEST);
		assertEquals(TEST, dimAgreement.getClientClearingActivity());
	}

	@Test
	public void testGetCloseoutAmountProtocol() {
		dimAgreement.setCloseoutAmountProtocol(TEST);
		assertEquals(TEST, dimAgreement.getCloseoutAmountProtocol());
	}

	@Test
	public void testGetCloseoutNettingEnforcabilityFlag() {
	DimAgreement dim = new DimAgreement();
		dimAgreement.setCloseoutNettingEnforcabilityFlag(TEST);
		dimAgreement.setCpThreshold(dim.getCpThreshold());
	
	dimAgreement.setCpTransactionThreshold(dim.getCpTransactionThreshold());
	dimAgreement.setImcap(dim.getImcap());
	dimAgreement.setMiniTransferAmt(dim.getMiniTransferAmt());
	dimAgreement.setMirrorAgreementid(dim.getMirrorAgreementid());
	dimAgreement.setMnemonic(dim.getMnemonic());
	dimAgreement.setMrnccdCompliance(dim.getMrnccdCompliance());
	dimAgreement.setMtmCurrency(dim.getMtmCurrency());
	dimAgreement.setMultiBranchMargining(dim.getMultiBranchMargining());
	dimAgreement.setMultiCurrencyMargining(dim.getMultiCurrencyMargining());
	dimAgreement.setNegotiationStartdate(dim.getNegotiationStartdate());
	dimAgreement.setNetting(dim.getNetting());
	dimAgreement.setParentChild(dim.getParentChild());
	dimAgreement.setPartyAssociate(dim.getPartyAssociate());
	dimAgreement.setPartyBorrowingThreshold(dim.getPartyBorrowingThreshold());
	dimAgreement.setPartyCreditbasedThresholdAmount(dim.getPartyCreditbasedThresholdAmount());
	dimAgreement.setPartyCustodianRequired(dim.getPartyCustodianRequired());
	dimAgreement.setPartyKey(dim.getPartyKey());
	dimAgreement.setRestrictionsOnCollateral(dim.getRestrictionsOnCollateral());
	dimAgreement.setSaTriggerEvent(dim.getSaTriggerEvent());
	dimAgreement.setSecuritiesDeliveryBankingDays(dim.getSecuritiesDeliveryBankingDays());
	dimAgreement.setSecurityAgreementdate(dim.getSecurityAgreementdate());
	dimAgreement.setSecurityCallDayOfWeek(dim.getSecurityCallDayOfWeek());
	dimAgreement.setSecurityCounterpartyName(dim.getSecurityCounterpartyName());
	dimAgreement.setSecurityGoverningLaw(dim.getSecurityGoverningLaw());
	dimAgreement.setSecurityTypeOfAccount(dim.getSecurityTypeOfAccount());
	dimAgreement.setServiceRepresentative(dim.getServiceRepresentative());
	dimAgreement.setSftBaselNetting(dim.getSftBaselNetting());
	dimAgreement.setShelf(dim.getShelf());
	dimAgreement.setSixcApplied(dim.getSixcApplied());
	dimAgreement.setSixCApplies(dim.getSixCApplies());
	dimAgreement.setSme(dim.getSme());
	dimAgreement.setSourceSystem(dim.getSourceSystem());
	dimAgreement.setStartDateSysAq(dim.getStartDateSysAq());
	dimAgreement.setTelephone(dim.getTelephone());
	dimAgreement.setTendApplies(dim.getTendApplies());
	dimAgreement.setTerminationDate(dim.getTerminationDate());
	dimAgreement.setTerminationTiming(dim.getTerminationTiming());
	dimAgreement.setTerminationType(dim.getTerminationType());
	dimAgreement.setThirdPartyCustFlag(dim.getThirdPartyCustFlag());
	dimAgreement.setThresholdAmount(dim.getThresholdAmount());
	dimAgreement.setThresholdBasis(dim.getThresholdBasis());
	dimAgreement.setThresholdCurrency(dim.getThresholdCurrency());
	dimAgreement.setTriggerEvent(dim.getTriggerEvent());
	dimAgreement.setTriparty(dim.getTriparty());
	dimAgreement.setTrueSegregation(dim.getTrueSegregation());
	dimAgreement.setUseBillingfeeAsCollateral(dim.getUseBillingfeeAsCollateral());
	dimAgreement.setUseCouponAsCollateral(dim.getUseCouponAsCollateral());
	dimAgreement.setUseExcessVmAsImCollateral(dim.getUseExcessVmAsImCollateral());
	dimAgreement.setUseFeeAsCollateral(dim.getUseFeeAsCollateral());
	dimAgreement.setUsenscnewRules(dim.getUsenscnewRules());
	dimAgreement.setUsePaiAsCollateral(dim.getUsePaiAsCollateral());
	dimAgreement.setVarEligible(dim.getVarEligible());
	dimAgreement.setVmCollateralInCashOnly(dim.getVmCollateralInCashOnly());

		assertEquals(TEST, dimAgreement.getCloseoutNettingEnforcabilityFlag());
	}

	@Test
	public void testGetCollateralCalculationAgent() {
		dimAgreement.setCollateralCalculationAgent(TEST);
		assertEquals(TEST, dimAgreement.getCollateralCalculationAgent());
	}

	@Test
	public void testGetCollateralCallDeadline() {
		dimAgreement.setCollateralCallDeadline(TEST);
		assertEquals(TEST, dimAgreement.getCollateralCallDeadline());
	}

	@Test
	public void testGetCollateralNotificationRegion() {
		dimAgreement.setCollateralNotificationRegion(TEST);
		assertEquals(TEST, dimAgreement.getCollateralNotificationRegion());
	}

	@Test
	public void testGetCollateralSecuritiesTerm() {
		dimAgreement.setCollateralSecuritiesTerm(TEST);
		assertEquals(TEST, dimAgreement.getCollateralSecuritiesTerm());
	}

	@Test
	public void testGetCollateralValuationFrequency() {
		dimAgreement.setCollateralValuationFrequency(TEST);
		assertEquals(TEST, dimAgreement.getCollateralValuationFrequency());
	}

	@Test
	public void testGetCommonCustodian() {
		dimAgreement.setCommonCustodian(TEST);
		DimAgreement dim = new DimAgreement();
		dimAgreement.setPartyLegalEntity(dim.getPartyLegalEntity());
		dimAgreement.setPartyMarginType(dim.getPartyMarginType());
		dimAgreement.setPartyMinimumCallThresholdAmount(dim.getPartyMinimumCallThresholdAmount());
		dimAgreement.setPartyMinimumReturnThresholdAmount(dim.getPartyMinimumReturnThresholdAmount());
		dimAgreement.setPartyMultibranch(dim.getPartyMultibranch());
		dimAgreement.setPartyPseMarginReduction(dim.getPartyPseMarginReduction());
		dimAgreement.setPartyRating(dim.getPartyRating());
		dimAgreement.setPartyRatingAgency(dim.getPartyRatingAgency());
		dimAgreement.setPartyReportingKey(dim.getPartyReportingKey());
		dimAgreement.setPartySpecifiedEntities(dim.getPartySpecifiedEntities());
		dimAgreement.setPartySpecifiedIndebtedness(dim.getPartySpecifiedIndebtedness());
		dimAgreement.setPartySpecifiedTransactions(dim.getPartySpecifiedTransactions());
		dimAgreement.setPartyTerminationCurrency(dim.getPartyTerminationCurrency());
		dimAgreement.setPartyThresholdBasis(dim.getPartyThresholdBasis());
		dimAgreement.setPartyThresholdThresholdAmount(dim.getPartyThresholdThresholdAmount());
		dimAgreement.setPartyTransactionThreshold(dim.getPartyTransactionThreshold());
		dimAgreement.setPartyTypeOfBorrowingThreshold(dim.getPartyTypeOfBorrowingThreshold());
		dimAgreement.setPbgIndicator(dim.getPbgIndicator());
		dimAgreement.setPledgor(dim.getPledgor());
		dimAgreement.setPseMarginLastModified(dim.getPseMarginLastModified());
		dimAgreement.setPseMarginReduction(dim.getPseMarginReduction());
		dimAgreement.setPseMarginReductionFlag(dim.getPseMarginReductionFlag());

		assertEquals(TEST, dimAgreement.getCommonCustodian());
	}

	@Test
	public void testGetConsentToSubstitution() {
		dimAgreement.setConsentToSubstitution(TEST);
		assertEquals(TEST, dimAgreement.getConsentToSubstitution());
	}

	@Test
	public void testGetContact() {
		dimAgreement.setContact(TEST);
		assertEquals(TEST, dimAgreement.getContact());
	}

	@Test
	public void testGetCounterPartyKey() throws Exception {
		dimAgreement.setCounterPartyKey(1);
		assertEquals(1, dimAgreement.getCounterPartyKey());
	}

	@Test
	public void testGetCounterPartyReportingKey() {
		dimAgreement.setCounterPartyReportingKey(1);
		assertEquals(1, dimAgreement.getCounterPartyReportingKey());
	}

	@Test
	public void testGetCounterpartyMultibranch() {
		dimAgreement.setCounterpartyMultibranch(TEST);
		assertEquals(TEST, dimAgreement.getCounterpartyMultibranch());
	}

	@Test
	public void testGetCounterpartyName() {
		dimAgreement.setCounterpartyName(TEST);
		assertEquals(TEST, dimAgreement.getCounterpartyName());
	}

	@Test
	public void testGetCountryName() {
		dimAgreement.setCountryName(TEST);
		assertEquals(TEST, dimAgreement.getCountryName());
	}

	@Test
	public void testGetCpBorrowingThreshold() {
		dimAgreement.setCpBorrowingThreshold(1);
		assertEquals(1,(int) dimAgreement.getCpBorrowingThreshold());
	}

	@Test
	public void testGetCpCreditBasedThresholdAmount() {
		dimAgreement.setCpCreditBasedThresholdAmount(TEST);
		assertEquals(TEST, dimAgreement.getCpCreditBasedThresholdAmount());
	}

	@Test
	public void testGetCpCustodianRequired() {
		dimAgreement.setCpCustodianRequired(TEST);;
		assertEquals(TEST, dimAgreement.getCpCustodianRequired());
	}

	@Test
	public void testGetCpMarginType() {
		dimAgreement.setCpMarginType(TEST);
		assertEquals(TEST, dimAgreement.getCpMarginType());
	}

	@Test
	public void testGetCpMinimumCallThresholdAmount() {
		dimAgreement.setCpMinimumCallThresholdAmount(1);
		assertEquals(1, (int)dimAgreement.getCpMinimumCallThresholdAmount());
	}

	@Test
	public void testGetCpMinimumReturnThresholdAmount() {
		dimAgreement.setCpMinimumReturnThresholdAmount(1);
		assertEquals(1, (int)dimAgreement.getCpMinimumReturnThresholdAmount());
	}

	@Test
	public void testGetCpRating() {
		dimAgreement.setCpRating(TEST);
		assertEquals(TEST, dimAgreement.getCpRating());
	}

	@Test
	public void testGetCpRatingAgency() {
		dimAgreement.setCpRatingAgency(TEST);
		assertEquals(TEST, dimAgreement.getCpRatingAgency());
	}

	@Test
	public void testGetCpSpecifiedEntities() {
		DimAgreement dim= new DimAgreement();
		dimAgreement.setCpSpecifiedIndebtedness(dim.getCpSpecifiedIndebtedness());
		dimAgreement.setCpSpecifiedTransactions(dim.getCpSpecifiedTransactions());
		dimAgreement.setCpTerminationCurrency(dim.getCpTerminationCurrency());
		dimAgreement.setCpThresholdBasis(dim.getCpThresholdBasis());
		dimAgreement.setCpThresholdThresholdAmount(dim.getCpThresholdThresholdAmount());
		dimAgreement.setCpTypeOfBorrowingThreshold(dim.getCpTypeOfBorrowingThreshold());
		dimAgreement.setCpincrementalMovementAmount(dim.getCpincrementalMovementAmount());
		dimAgreement.setCsaCode(dim.getCsaCode());
		dimAgreement.setCsaDescription(dim.getCsaDescription());
		dimAgreement.setCsaMarginType(dim.getCsaMarginType());
		dimAgreement.setCsaStatus(dim.getCsaStatus());
		dimAgreement.setCurrency(dim.getCurrency());
		dimAgreement.setCustodianRequired(dim.getCustodianRequired());
		dimAgreement.setCustodyBankName(dim.getCustodyBankName());
		dimAgreement.setCustomerName(dim.getCustomerName());
		dimAgreement.setDeletedFlag(dim.getDeletedFlag());
		dimAgreement.setDerivsProvision(dim.getDerivsProvision());
		dimAgreement.setDisputeMechanism(dim.getDisputeMechanism());
		dimAgreement.setEndDateSysAq(dim.getEndDateSysAq());
		dimAgreement.setEntity(dim.getEntity());
		dimAgreement.setCpSpecifiedEntities(TEST);
		assertEquals(TEST, dimAgreement.getCpSpecifiedEntities());
	}

	@Test
	public void testGetCpSpecifiedIndebtedness() {
		DimAgreement dim= new DimAgreement();
		dimAgreement.setEntryDate(dim.getEntryDate());
		dimAgreement.setExchangeclearedAgreement(dim.getExchangeclearedAgreement());
		dimAgreement.setExtension(dim.getExtension());
		dimAgreement.setFatca(dim.getFatca());
		dimAgreement.setFax(dim.getFax());
		dimAgreement.setFileNumber(dim.getFileNumber());
		dimAgreement.setFirmAddress(dim.getFirmAddress());
		dimAgreement.setFirmContact(dim.getFirmContact());
		dimAgreement.setFirmCustodyBankName(dim.getFirmCustodyBankName());
		dimAgreement.setFirmFax(dim.getFirmFax());
		dimAgreement.setFirmTelephone(dim.getFirmTelephone());
		dimAgreement.setFxProvision(dim.getFxProvision());
		dimAgreement.setFxoProvision(dim.getFxoProvision());
		dimAgreement.setGoverningLaw(dim.getGoverningLaw());
		dimAgreement.setIaThreshold(dim.getIaThreshold());
		dimAgreement.setImFloor(dim.getImFloor());
		dimAgreement.setIncorporatedCountry(dim.getIncorporatedCountry());
		dimAgreement.setIncrementalMovementAmount(dim.getIncrementalMovementAmount());
		dimAgreement.setInterCompanyAgreement(dim.getInterCompanyAgreement());
		dimAgreement.setIntercompanyType(dim.getIntercompanyType());
		dimAgreement.setIsKeyOnly(dim.getIsKeyOnly());
		dimAgreement.setLastModified(dim.getLastModified());
		dimAgreement.setLinkMrnccdOutofscopeTrades(dim.getLinkMrnccdOutofscopeTrades());
		dimAgreement.setMaDate(dim.getMaDate());
		dimAgreement.setMandatoryMarkFrequency(dim.getMandatoryMarkFrequency());
		dimAgreement.setMarginEffectiveDate(dim.getMarginEffectiveDate());
		dimAgreement.setMarktomarketAgent(dim.getMarktomarketAgent());
		dimAgreement.setMasterAgreement(dim.getMasterAgreement());
		dimAgreement.setMasterAgreementStatus(dim.getMasterAgreementStatus());
		dimAgreement.setMasterAgreementVersion(dim.getMasterAgreementVersion());
		dimAgreement.setMasterRole(dim.getMasterRole());
		assertNotNull(dimAgreement);
	}
	@Test
	public void testToString() {
		assertNotNull(TEST, dimAgreement.toString());
	}

}
