package com.citi.aqua.derivz.model;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.Before;
import org.junit.Test;

public class UserTest {

	private static final String DUMMY = "DUMMY";
	private User user;

	@Before
	public void setUp() throws Exception {
		user = new User();
		user.setStatusCode(LoginStatusEnum.DVIZ_200);
		user.setStatus(user.getStatusCode());
	}

	@Test
	public void testIsAuthorized() {
		User userObj = new User();
		userObj.setAccessList(new ArrayList<>());
		userObj.setStatusCode(LoginStatusEnum.DVIZ_200);
		userObj.setAccessList(new ArrayList<>());
		userObj.setAssignmentGroupId(DUMMY);
		userObj.setAuthenticated(true);
		userObj.setAuthorized(true);
		userObj.setEmail(DUMMY);
		userObj.setName(DUMMY);
		userObj.setNewpassword(DUMMY);
		userObj.setPassword(DUMMY);
		userObj.setRedirectURI(DUMMY);
		userObj.setSoeid(DUMMY);
		userObj.setSsoSessionID(DUMMY);
		userObj.setStatusMessage(DUMMY);
		userObj.setToken(DUMMY);
		userObj.setTokenValid(userObj.isTokenValid());
		
		user.setAccessList(userObj.getAccessList());
		user.setAssignmentGroupId(userObj.getAssignmentGroupId());
		user.setAuthenticated(userObj.getIsAuthenticated());
		user.setAuthorized(userObj.isAuthorized());
		user.setEmail(userObj.getEmail());
		user.setName(userObj.getName());
		user.setNewpassword(userObj.getNewpassword());
		user.setPassword(userObj.getPassword());
		user.setRedirectURI(userObj.getRedirectURI());
		user.setSoeid(userObj.getSoeid());
		user.setSsoSessionID(userObj.getSsoSessionID());
		user.setStatusMessage(userObj.getStatusMessage());
		user.setToken(userObj.getToken());
		user.setTokenValid(userObj.isTokenValid());
		user.equals(userObj);
		assertEquals(true, user.getIsAuthenticated());
	}

	@Test
	public void testSetStatus() {
		assertEquals(LoginStatusEnum.DVIZ_200, user.getStatusCode());
	}

}
