package com.citi.aqua.derivz.vo;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class SearchCriteriaResultVOTest {
	private SearchCriteriaResultVO searchCriteriaResultVO;

	@Before
	public void setUp() throws Exception {
		searchCriteriaResultVO = new SearchCriteriaResultVO();
	}

	@Test
	public void testGetAddress() {
		SearchCriteriaResultVO vo = new SearchCriteriaResultVO();
		searchCriteriaResultVO.setAddress("TEST");
		searchCriteriaResultVO.setAgreementCcy(vo.getAgreementCcy());
		searchCriteriaResultVO.setAgreementId(vo.getAgreementId());
		searchCriteriaResultVO.setAgreementKey(vo.getAgreementKey());
		searchCriteriaResultVO.setAlco(vo.getAlco());
		searchCriteriaResultVO.setAutoEarlyTerminationFlag(vo.getAutoEarlyTerminationFlag());
		searchCriteriaResultVO.setBankruptcy(vo.getBankruptcy());
		searchCriteriaResultVO.setBasis(vo.getBasis());
		searchCriteriaResultVO.setCalculationAgent(vo.getCalculationAgent());
		searchCriteriaResultVO.setCallday1Eom(vo.getCallday1Eom());
		searchCriteriaResultVO.setCallday1Ofmonth(vo.getCallday1Ofmonth());
		searchCriteriaResultVO.setCallday2Eom(vo.getCallday2Eom());
		searchCriteriaResultVO.setCallday2Ofmonth(vo.getCallday2Ofmonth());
		searchCriteriaResultVO.setCallFrequency(vo.getCallFrequency());
		searchCriteriaResultVO.setCallMonth(vo.getCallMonth());
		searchCriteriaResultVO.setCapfloorAddendum(vo.getCapfloorAddendum());
		searchCriteriaResultVO.setCashCollateralIndexTime(vo.getCashCollateralIndexTime());
		searchCriteriaResultVO.setCashCollDeliveryDeadline(vo.getCashCollDeliveryDeadline());
		searchCriteriaResultVO.setCashDeliveryBankingDays(vo.getCashDeliveryBankingDays());
		searchCriteriaResultVO.setChain(vo.getChain());
		searchCriteriaResultVO.setCitiThreshold(vo.getCitiThreshold());
		searchCriteriaResultVO.setClearedActivity(vo.getClearedActivity());
		searchCriteriaResultVO.setClearedHouseActivity(vo.getClearedHouseActivity());
		searchCriteriaResultVO.setClearingAgreement(vo.getClearingAgreement());
		searchCriteriaResultVO.setClientClearingActivity(vo.getClientClearingActivity());
		searchCriteriaResultVO.setCloseoutAmountProtocol(vo.getCloseoutAmountProtocol());
		searchCriteriaResultVO.setCloseoutNettingEnforcabilityFlag(vo.getCloseoutNettingEnforcabilityFlag());
		searchCriteriaResultVO.setCollateralCalculationAgent(vo.getCollateralCalculationAgent());
		searchCriteriaResultVO.setCollateralCallDeadline(vo.getCollateralCallDeadline());
		searchCriteriaResultVO.setCollateralNotificationRegion(vo.getCollateralNotificationRegion());
		searchCriteriaResultVO.setCollateralSecuritiesTerm(vo.getCollateralSecuritiesTerm());
		searchCriteriaResultVO.setCollateralValuationFrequency(vo.getCollateralValuationFrequency());
		searchCriteriaResultVO.setCommonCustodian(vo.getCommonCustodian());
		searchCriteriaResultVO.setConsentToSubstitution(vo.getConsentToSubstitution());
		searchCriteriaResultVO.setContact(vo.getContact());
		assertEquals("TEST", searchCriteriaResultVO.getAddress());
	}

	@Test
	public void testGetFirmFax() {
		
		SearchCriteriaResultVO vo = new SearchCriteriaResultVO();
		vo.setFirmFax("TEST");
		searchCriteriaResultVO.setFax(vo.getFax());
		searchCriteriaResultVO.setFileNumber(vo.getFileNumber());
		searchCriteriaResultVO.setFirmAddress(vo.getFirmAddress());
		searchCriteriaResultVO.setFirmContact(vo.getFirmContact());
		searchCriteriaResultVO.setFirmCustodyBankName(vo.getFirmCustodyBankName());
		searchCriteriaResultVO.setFirmFax(vo.getFirmFax());
		searchCriteriaResultVO.setFirmTelephone(vo.getFirmTelephone());
		searchCriteriaResultVO.setFxoProvision(vo.getFxoProvision());
		searchCriteriaResultVO.setFxProvision(vo.getFxProvision());
		searchCriteriaResultVO.setGoverningLaw(vo.getGoverningLaw());
		searchCriteriaResultVO.setIaThreshold(vo.getIaThreshold());
		searchCriteriaResultVO.setImcap(vo.getImcap());
		searchCriteriaResultVO.setImFloor(vo.getImFloor());
		searchCriteriaResultVO.setIncorporatedCountry(vo.getIncorporatedCountry());
		searchCriteriaResultVO.setIncrementalMovementAmount(vo.getIncrementalMovementAmount());
		searchCriteriaResultVO.setInterCompanyAgreement(vo.getInterCompanyAgreement());
		searchCriteriaResultVO.setIntercompanyType(vo.getIntercompanyType());
		searchCriteriaResultVO.setIsKeyOnly(vo.getIsKeyOnly());
		searchCriteriaResultVO.setLastModified(vo.getLastModified());
		searchCriteriaResultVO.setLinkMrnccdOutofscopeTrades(vo.getLinkMrnccdOutofscopeTrades());
		searchCriteriaResultVO.setMaDate(vo.getMaDate());
		searchCriteriaResultVO.setMandatoryMarkFrequency(vo.getMandatoryMarkFrequency());
		searchCriteriaResultVO.setMarginEffectiveDate(vo.getMarginEffectiveDate());
		searchCriteriaResultVO.setMarktomarketAgent(vo.getMarktomarketAgent());
		searchCriteriaResultVO.setMasterAgreement(vo.getMasterAgreement());
		searchCriteriaResultVO.setMasterAgreementStatus(vo.getMasterAgreementStatus());
		searchCriteriaResultVO.setMasterAgreementVersion(vo.getMasterAgreementVersion());
		searchCriteriaResultVO.setMasterRole(vo.getMasterRole());
		searchCriteriaResultVO.setMiniTransferAmt(vo.getMiniTransferAmt());
		searchCriteriaResultVO.setMirrorAgreementid(vo.getMirrorAgreementid());
		searchCriteriaResultVO.setMnemonic(vo.getMnemonic());
		searchCriteriaResultVO.setMrnccdCompliance(vo.getMrnccdCompliance());
		searchCriteriaResultVO.setMtmCurrency(vo.getMtmCurrency());
		searchCriteriaResultVO.setMultiBranchMargining(vo.getMultiBranchMargining());
		searchCriteriaResultVO.setMultiCurrencyMargining(vo.getMultiCurrencyMargining());
		searchCriteriaResultVO.setNegotiationStartDate(vo.getNegotiationStartDate());
		searchCriteriaResultVO.setNetting(vo.getNetting());
		searchCriteriaResultVO.setParentChild(vo.getParentChild());
		searchCriteriaResultVO.setPartyAssociate(vo.getPartyAssociate());
		searchCriteriaResultVO.setPartyBorrowingThreshold(vo.getPartyBorrowingThreshold());
		searchCriteriaResultVO.setPartyCreditbasedThresholdAmount(vo.getPartyCreditbasedThresholdAmount());
		searchCriteriaResultVO.setPartyCustodianRequired(vo.getPartyCustodianRequired());
		searchCriteriaResultVO.setPartyKey(vo.getPartyKey());
		searchCriteriaResultVO.setPartyLegalEntity(vo.getPartyLegalEntity());
		searchCriteriaResultVO.setPartyMarginType(vo.getPartyMarginType());
		searchCriteriaResultVO.setPartyMinimumCallThresholdAmount(vo.getPartyMinimumCallThresholdAmount());
		searchCriteriaResultVO.setPartyMinimumReturnThresholdAmount(vo.getPartyMinimumReturnThresholdAmount());
		searchCriteriaResultVO.setPartyMultibranch(vo.getPartyMultibranch());
		searchCriteriaResultVO.setPartyPseMarginReduction(vo.getPartyPseMarginReduction());
		searchCriteriaResultVO.setPartyRating(vo.getPartyRating());
		searchCriteriaResultVO.setPartyRatingAgency(vo.getPartyRatingAgency());
		searchCriteriaResultVO.setPartyReportingKey(vo.getPartyReportingKey());
		searchCriteriaResultVO.setPartySpecifiedEntities(vo.getPartySpecifiedEntities());
		searchCriteriaResultVO.setPartySpecifiedIndebtedness(vo.getPartySpecifiedIndebtedness());
		searchCriteriaResultVO.setPartySpecifiedTransactions(vo.getPartySpecifiedTransactions());
		searchCriteriaResultVO.setPartyTerminationCurrency(vo.getPartyTerminationCurrency());
		searchCriteriaResultVO.setPartyThresholdBasis(vo.getPartyThresholdBasis());
		searchCriteriaResultVO.setPartyThresholdThresholdAmount(vo.getPartyThresholdThresholdAmount());
		searchCriteriaResultVO.setPartyTransactionThreshold(vo.getPartyTransactionThreshold());
		searchCriteriaResultVO.setPartyTypeOfBorrowingThreshold(vo.getPartyTypeOfBorrowingThreshold());
		searchCriteriaResultVO.setPbgIndicator(vo.getPbgIndicator());
		searchCriteriaResultVO.setPledgor(vo.getPledgor());
		searchCriteriaResultVO.setPseMarginLastModified(vo.getPseMarginLastModified());
		searchCriteriaResultVO.setPseMarginReduction(vo.getPseMarginReduction());
		searchCriteriaResultVO.setPseMarginReductionFlag(vo.getPseMarginReductionFlag());
		searchCriteriaResultVO.setRestrictionsOnCollateral(vo.getRestrictionsOnCollateral());
		searchCriteriaResultVO.setSaTriggerEvent(vo.getSaTriggerEvent());
		
		
		assertEquals("TEST",searchCriteriaResultVO.getFirmFax());
	}

	@Test
	public void testGetSME() {
		SearchCriteriaResultVO vo = new SearchCriteriaResultVO();
		vo.setSME("TEST");
		searchCriteriaResultVO.setSME(vo.getSME());
		searchCriteriaResultVO.setSourceSystem(vo.getSourceSystem());
		searchCriteriaResultVO.setStartDateSysAq(vo.getStartDateSysAq());
		searchCriteriaResultVO.setTelephone(vo.getTelephone());
		searchCriteriaResultVO.setTendApplies(vo.getTendApplies());
		searchCriteriaResultVO.setTerminationDate(vo.getTerminationDate());
		searchCriteriaResultVO.setTerminationTiming(vo.getTerminationTiming());
		searchCriteriaResultVO.setTerminationType(vo.getTerminationType());
		searchCriteriaResultVO.setThirdPartyCustFlag(vo.getThirdPartyCustFlag());
		searchCriteriaResultVO.setThresholdAmount(vo.getThresholdAmount());
		searchCriteriaResultVO.setThresholdBasis(vo.getThresholdBasis());
		searchCriteriaResultVO.setThresholdCurrency(vo.getThresholdCurrency());
		searchCriteriaResultVO.setTriggerEvent(vo.getTriggerEvent());
		searchCriteriaResultVO.setTriparty(vo.getTriparty());
		searchCriteriaResultVO.setTrueSegregation(vo.getTrueSegregation());
		searchCriteriaResultVO.setUseBillingfeeAsCollateral(vo.getUseBillingfeeAsCollateral());
		searchCriteriaResultVO.setUseCouponAsCollateral(vo.getUseCouponAsCollateral());
		searchCriteriaResultVO.setUseExcessVmAsImCollateral(vo.getUseExcessVmAsImCollateral());
		searchCriteriaResultVO.setUseFeeAsCollateral(vo.getUseFeeAsCollateral());
		searchCriteriaResultVO.setUsenscnewRules(vo.getUsenscnewRules());
		searchCriteriaResultVO.setUsePaiAsCollateral(vo.getUsePaiAsCollateral());
		searchCriteriaResultVO.setVarEligible(vo.getVarEligible());
		searchCriteriaResultVO.setVmCollateralInCashOnly(vo.getVmCollateralInCashOnly());
		searchCriteriaResultVO.setSecuritiesDeliveryBankingDays(vo.getSecuritiesDeliveryBankingDays());
		searchCriteriaResultVO.setSecurityAgreementdate(vo.getSecurityAgreementdate());
		searchCriteriaResultVO.setSecurityCallDayOfWeek(vo.getSecurityCallDayOfWeek());
		searchCriteriaResultVO.setSecurityCounterpartyName(vo.getSecurityCounterpartyName());
		searchCriteriaResultVO.setSecurityGoverningLaw(vo.getSecurityGoverningLaw());
		searchCriteriaResultVO.setSecurityTypeOfAccount(vo.getSecurityTypeOfAccount());
		searchCriteriaResultVO.setServiceRepresentative(vo.getServiceRepresentative());
		searchCriteriaResultVO.setSftBaselNetting(vo.getSftBaselNetting());
		searchCriteriaResultVO.setShelf(vo.getShelf());
		searchCriteriaResultVO.setSixcApplied(vo.getSixcApplied());
		searchCriteriaResultVO.setSixCApplies(vo.getSixCApplies());
		assertEquals("TEST",searchCriteriaResultVO.getSME());
	}

	@Test
	public void testGetAlco() {
		SearchCriteriaResultVO vo = new SearchCriteriaResultVO();
		vo.setCpMarginType("TEST");
		searchCriteriaResultVO.setCounterPartyKey(vo.getCounterPartyKey());
		searchCriteriaResultVO.setCounterpartyMultibranch(vo.getCounterpartyMultibranch());
		searchCriteriaResultVO.setCounterpartyName(vo.getCounterpartyName());
		searchCriteriaResultVO.setCounterPartyReportingKey(vo.getCounterPartyReportingKey());
		searchCriteriaResultVO.setCountryName(vo.getCountryName());
		searchCriteriaResultVO.setCpBorrowingThreshold(vo.getCpBorrowingThreshold());
		searchCriteriaResultVO.setCpCreditBasedThresholdAmount(vo.getCpCreditBasedThresholdAmount());
		searchCriteriaResultVO.setCpCustodianRequired(vo.getCpCustodianRequired());
		searchCriteriaResultVO.setCpincrementalMovementAmount(vo.getCpincrementalMovementAmount());
		searchCriteriaResultVO.setCpMarginType(vo.getCpMarginType());
		searchCriteriaResultVO.setCpMinimumCallThresholdAmount(vo.getCpMinimumCallThresholdAmount());
		searchCriteriaResultVO.setCpMinimumReturnThresholdAmount(vo.getCpMinimumReturnThresholdAmount());
		searchCriteriaResultVO.setCpRating(vo.getCpRating());
		searchCriteriaResultVO.setCpRatingAgency(vo.getCpRatingAgency());
		searchCriteriaResultVO.setCpSpecifiedEntities(vo.getCpSpecifiedEntities());
		searchCriteriaResultVO.setCpSpecifiedIndebtedness(vo.getCpSpecifiedIndebtedness());
		searchCriteriaResultVO.setCpSpecifiedTransactions(vo.getCpSpecifiedTransactions());
		searchCriteriaResultVO.setCpTerminationCurrency(vo.getCpTerminationCurrency());
		searchCriteriaResultVO.setCpThreshold(vo.getCpThreshold());
		searchCriteriaResultVO.setCpThresholdBasis(vo.getCpThresholdBasis());
		searchCriteriaResultVO.setCpThresholdThresholdAmount(vo.getCpThresholdThresholdAmount());
		searchCriteriaResultVO.setCpTransactionThreshold(vo.getCpTransactionThreshold());
		searchCriteriaResultVO.setCpTypeOfBorrowingThreshold(vo.getCpTypeOfBorrowingThreshold());
		searchCriteriaResultVO.setCsaCode(vo.getCsaCode());
		searchCriteriaResultVO.setCsaDescription(vo.getCsaDescription());
		searchCriteriaResultVO.setCsaMarginType(vo.getCsaMarginType());
		searchCriteriaResultVO.setCsaStatus(vo.getCsaStatus());
		searchCriteriaResultVO.setCurrency(vo.getCurrency());
		searchCriteriaResultVO.setCustodianRequired(vo.getCustodianRequired());
		searchCriteriaResultVO.setCustodyBankName(vo.getCustodyBankName());
		searchCriteriaResultVO.setCustomerName(vo.getCustomerName());
		searchCriteriaResultVO.setDeletedFlag(vo.getDeletedFlag());
		searchCriteriaResultVO.setDerivsProvision(vo.getDerivsProvision());
		searchCriteriaResultVO.setDisputeMechanism(vo.getDisputeMechanism());
		searchCriteriaResultVO.setEndDateSysAq(vo.getEndDateSysAq());
		searchCriteriaResultVO.setEntity(vo.getEntity());
		searchCriteriaResultVO.setEntryDate(vo.getEntryDate());
		searchCriteriaResultVO.setExchangeclearedAgreement(vo.getExchangeclearedAgreement());
		searchCriteriaResultVO.setExtension(vo.getExtension());
		searchCriteriaResultVO.setFatca(vo.getFatca());
		
		assertEquals("TEST",searchCriteriaResultVO.getCpMarginType());
	}

}
