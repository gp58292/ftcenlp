package com.citi.aqua.derivz.web;

import java.util.concurrent.TimeUnit;

import javax.servlet.Filter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.CacheControl;
import org.springframework.web.filter.ShallowEtagHeaderFilter;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import org.springframework.web.servlet.resource.VersionResourceResolver;

@Configuration
public class CEFTWebRestConfig extends WebMvcConfigurerAdapter  {
	private static final Logger LOGGER = LoggerFactory.getLogger(CEFTWebRestConfig.class);
	
	 

	// Set the caching mechanism on js, css and resource files ....
	@Override
	public void addResourceHandlers(ResourceHandlerRegistry registry) {
		LOGGER.debug("Adding static resource for cache control......................");
		CacheControl cacheCacontrol=CacheControl.noCache()
											  .mustRevalidate()
											  .proxyRevalidate()
											  .sMaxAge(-1,TimeUnit.SECONDS);
	    registry
	    		.addResourceHandler("*.css", "*.js","*.woff","*.svg","*.ttf","*.eot","*.html","*.png","*.woff2")
	            .addResourceLocations("classpath:/static/")
	            .setCacheControl(cacheCacontrol)
	            .resourceChain(false)
	            .addResolver(new VersionResourceResolver().addContentVersionStrategy("/**"));
	    registry
	    		.addResourceHandler("/assets/**")
	    		.addResourceLocations("classpath:/static/assets/")
	    		.setCacheControl(cacheCacontrol);
	    /*registry
				.addResourceHandler("*.css", "*.js","*.woff","*.svg","*.ttf","*.eot","*.html","*.png","*.woff2")
		        .addResourceLocations("/assets/**")
		        .setCacheControl(cacheCacontrol)
		        .resourceChain(false)
	            .addResolver(new VersionResourceResolver().addContentVersionStrategy("/**"));*/
	}
	
	//Below ShalllowEtagHeaderFilter generate ETag on cached data
	@Bean
    public Filter shallowEtagHeaderFilter() {
        return new ShallowEtagHeaderFilter();
    }
}
