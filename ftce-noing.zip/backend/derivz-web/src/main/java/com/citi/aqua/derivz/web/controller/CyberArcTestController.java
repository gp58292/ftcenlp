package com.citi.aqua.derivz.web.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.citi.aqua.derivz.commons.constants.DerivzAPIUriConstants;
import com.citi.aqua.derivz.data.cyberark.CyberArkFactory;

@Controller
@RequestMapping(DerivzAPIUriConstants.CYBERARK_API_URI)
public class CyberArcTestController {

	private static final Logger LOGGER = LoggerFactory.getLogger(CyberArcTestController.class);

	@GetMapping(value = "/test/{appId}/{safe}/{object}")
	public @ResponseBody String checkConnection(@PathVariable String appId, @PathVariable String safe,@PathVariable String object) {
		
		LOGGER.debug("CyberArcTestController.checkConnection() ::starts ");
		try {
			return CyberArkFactory.getPassword(appId, safe, object, "Test Connection");
		} catch (Exception e) {
			LOGGER.error("CyberArcTestController.checkConnection() ::error " + e, e);
			return "Error in getting connection as " + e;
		}
	}
}
