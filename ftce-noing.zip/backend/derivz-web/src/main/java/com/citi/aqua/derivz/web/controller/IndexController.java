package com.citi.aqua.derivz.web.controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Map;
import java.util.Map.Entry;
import javax.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/")
public class IndexController {


    private static final Logger LOGGER = LoggerFactory.getLogger(IndexController.class);


    @GetMapping(value = "/redirectTo")
    public ModelAndView indexRedirectURI(HttpServletRequest request) {
        ModelAndView result = index();
        Map<String, String[]> parameters = request.getParameterMap();

        for(Entry<String, String[]> entry : parameters.entrySet()) {
            final String key = entry.getKey();
            LOGGER.debug("Redirect attributes key[{}] = ", key);
            String[] valArray = parameters.get(key);
            final ArrayList<String> vals=new ArrayList<String>();
            Collections.addAll(vals, valArray);
            // Store redirect URI inside the active session scope, so it can be accessed in Login Controller
            request.getSession().setAttribute("redirectURI", vals);

            for(String val : vals)
                LOGGER.debug(" -> {}",  val);
        }

        // Set it in the initial index.html queryParameters, in case we need it in JavaScript for trace/debug reason
        // Example: http://localhost:9070/clientoverview;client=EMSO%20ASSET%20MANAGEMENT;fund=ALL
        result.addAllObjects(parameters);
        return result;
    }

    @GetMapping(value = "/")
    public ModelAndView index() {
        return new ModelAndView("/index.html");
    }

    @GetMapping(value = "/acl/dashboard")
    public ModelAndView login() {
        // return index.html - as login url is handled by Angular
        return index();
    }
}