package com.citi.aqua.derivz.web.controller;

import java.util.List;

import org.apache.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.citi.aqua.derivz.commons.constants.DerivzAPIUriConstants;
import com.citi.aqua.derivz.commons.exceptions.DerivzApplicationException;
import com.citi.aqua.derivz.dto.BatchStatusResponseDTO;
import com.citi.aqua.derivz.services.service.BatchStatusService;
import com.citi.aqua.derivz.web.utils.DerivzRestResponse;
import com.citi.aqua.derivz.web.utils.ResponseBuilder;

@RestController
@RequestMapping(DerivzAPIUriConstants.BATCHSTATUS_API_URI)
public class BatchStatusController {

	private static final Logger LOGGER = LoggerFactory.getLogger(BatchStatusController.class);

	@Autowired
	BatchStatusService batchStatusService;

	@RequestMapping(value = DerivzAPIUriConstants.BATCH_STATUS_REPORT_URI, method = RequestMethod.GET)
	public @ResponseBody DerivzRestResponse<List<BatchStatusResponseDTO>> getBatchStatusReport(@PathVariable("cobDate") final String cobDate) {
		try {
			return ResponseBuilder.build(batchStatusService.getStatusReport(cobDate), HttpStatus.SC_OK);
		} catch (DerivzApplicationException de) {
			LOGGER.error("BatchStatusController::getBatchStatusReport() :: Error " + de, de);
			return ResponseBuilder.build(null, HttpStatus.SC_NOT_FOUND,	"Failed to get Batch Status report for COB Date.", "DS100");
		} 
	}
	
}
