package com.citi.aqua.derivz.web.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.citi.aqua.derivz.commons.constants.DerivzCommonConstants;
import com.citi.aqua.derivz.model.User;
import com.citi.aqua.derivz.model.UserToken;
import com.citi.aqua.derivz.security.AuthenticationService;
import com.citi.aqua.derivz.web.utils.DerivzRestResponse;
import com.citi.aqua.derivz.web.utils.ResponseBuilder;

@RestController()
@RequestMapping("/api/sso")
public class LoginController extends BaseController {

	@Autowired
	private AuthenticationService authenticationService;
	private static final Logger LOGGER = LoggerFactory.getLogger(LoginController.class);
	private static final String URI_REDIRECT = "redirectURI";

	@RequestMapping(value = "/authenticate", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public DerivzRestResponse<User> validateUser(final HttpServletRequest request, final HttpServletResponse response,
			final @RequestBody User user) {
		LOGGER.debug("LoginController::validateUser() ::User is {}:", user.getName());
		final HttpSession session = request.getSession(true);
		session.setMaxInactiveInterval(60*120);
		final User authenticUser = authenticationService.authenticateUser(session, user);
		final Object redirectAttribute = session.getAttribute(URI_REDIRECT);
		if (null != redirectAttribute) {
			@SuppressWarnings("unchecked")
			final List<String> redirectAttrList = (ArrayList<String>) redirectAttribute;
			final String redirectURI = redirectAttrList.get(0);
			if (null != redirectURI && 0 < redirectURI.length())
				authenticUser.setRedirectURI(redirectURI);
			session.removeAttribute(URI_REDIRECT);
		}
		if(authenticUser.getIsAuthenticated()) {
			return ResponseBuilder.build(authenticUser,HttpStatus.SC_OK);
		} else {
			return ResponseBuilder.build(authenticUser, HttpStatus.SC_UNAUTHORIZED);
		}
	}

	@RequestMapping(value = "/getuser", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public DerivzRestResponse<User> getUser(final HttpServletRequest request, final HttpServletResponse response) {
		HttpSession session = request.getSession(false);
		User user = null;
		if (session != null) {
			user=authenticationService.getUser(session);
		}
		return ResponseBuilder.build(user,HttpStatus.SC_OK);
	}

	@RequestMapping(value = "/changePassword", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public DerivzRestResponse<User> changePassword(final HttpServletRequest request, final HttpServletResponse response,
			@RequestBody final User user) {
		return ResponseBuilder.build("", HttpStatus.SC_OK);
	}

	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	@ResponseBody
	public DerivzRestResponse<String> logout(final HttpServletRequest request, final HttpServletResponse response,
			final HttpSession session) {
		if (session != null) {
			LOGGER.info("[Invalidating session] {}", session.getId());
			authenticationService.killSession(session);
		}
		return ResponseBuilder.build(DerivzCommonConstants.LOGOUT_MESSAGE,HttpStatus.SC_OK);
	}
	
	@RequestMapping(value = "/getUserToken", method = RequestMethod.POST)
	public DerivzRestResponse<UserToken> getUserToken(final HttpServletRequest request, final HttpServletResponse response, @RequestBody final User user) {
		UserToken userToken = authenticationService.getUserToken(user.getSoeid(), user.getPassword());
		return ResponseBuilder.build(userToken, HttpStatus.SC_OK);
	}
	
	@RequestMapping(value = "/validateUserToken", method = RequestMethod.POST)
	public DerivzRestResponse<UserToken> validateUserToken(final HttpServletRequest request, final HttpServletResponse response, @RequestBody final User user) {
		UserToken userToken = new UserToken();
		userToken.setTokenValid(authenticationService.validateUserToken(user.getToken()));
		userToken.setToken(user.getToken());
		return ResponseBuilder.build(userToken, HttpStatus.SC_OK);
	}

}
