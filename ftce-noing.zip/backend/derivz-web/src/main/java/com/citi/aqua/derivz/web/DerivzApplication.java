package com.citi.aqua.derivz.web;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import javax.annotation.Resource;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.Banner;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.core.env.Environment;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import com.citi.aqua.derivz.data.cache.eh.StaticCacheKeys;
import com.citi.aqua.derivz.services.service.CacheService;
import com.citi.aqua.derivz.web.utils.ManifestReader;
import com.ulisesbocchio.jasyptspringboot.annotation.EnableEncryptableProperties;

//@Configuration
@SpringBootApplication
@ComponentScan({ "com.citi.aqua" })
@EnableCaching
@EnableAutoConfiguration
@EnableJpaRepositories(basePackages = {"com.citi.aqua.derivz.data.repository","com.citi.aqua.derivz.data.cache.repository"})
@EntityScan(basePackages = "com.citi.aqua.derivz.model")
@EnableTransactionManagement
@EnableConfigurationProperties
@EnableEncryptableProperties
public class DerivzApplication {

	@Resource
	private Environment env;
	private static String envName = "";
	private static String buildNumber = "n/a";

	public static final Logger LOGGER = LoggerFactory.getLogger(DerivzApplication.class);
	private static final String BUILD_NUMBER = "Implementation-Version";
	
	@Autowired
	CacheService cacheService;

	public static void main(String[] args) {

		// Add uncaught
		Thread.currentThread().setUncaughtExceptionHandler((t, e) -> LOGGER.error(" throws uncaughtException: ", e));

		SpringApplication app = new SpringApplication(DerivzApplication.class);
		ApplicationContext applicationContext = app.run(args);
		app.setBannerMode(Banner.Mode.OFF);
		LOGGER.info("########################## Spring Boot Application Context Loaded: ###########################",
				applicationContext.getApplicationName());

		if (null != applicationContext.getEnvironment()) {
			final List<String> profiles = Arrays.asList(applicationContext.getEnvironment().getActiveProfiles());
			if (!profiles.isEmpty()) {
				envName = StringUtils.lowerCase(profiles.get(0));
			}
		}

		Map<String, String> map = (new ManifestReader()).readAll();
		buildNumber = map.get(BUILD_NUMBER);
	}
	
	@Bean
	CommandLineRunner runner(){
		return args -> {
			LOGGER.debug("CommandLineRunner running in the UnsplashApplication class...");
			
			LOGGER.info("########################## Start: Inside Spring Boot CommandLineRunner: ###########################");
			cacheService.findStaticComponentData(StaticCacheKeys.STATIC_COMPONENT_DATA);
			cacheService.getAllSearchResultColumns(StaticCacheKeys.RESULT_COLUMNS);
			LOGGER.info("####### Successfully Cached Static Data: Inside Spring Boot CommandLineRunner: #####");
			
			cacheService.loadReferenceData();
			LOGGER.info("###### Successfully Cached Reference Data: Inside Spring Boot CommandLineRunner: #####");
			//cacheService.loadAllReferenceData(ReferenceCacheKeys.ALL_REFRENCE);
			LOGGER.info("########################## End: Inside Spring Boot CommandLineRunner: ###########################");
		};
	}

	public static String getEnvName() {
		return envName;
	}

	public static String getBuildNumber() {
		return buildNumber;
	}
}