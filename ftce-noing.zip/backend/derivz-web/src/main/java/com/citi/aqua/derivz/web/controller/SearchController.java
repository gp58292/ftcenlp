package com.citi.aqua.derivz.web.controller;

import java.io.IOException;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import com.citi.aqua.derivz.commons.constants.DerivzAPIUriConstants;
import com.citi.aqua.derivz.commons.exceptions.CEFTException;
import com.citi.aqua.derivz.commons.exceptions.DerivzApplicationException;
import com.citi.aqua.derivz.dto.CollateralResponseDTO;
import com.citi.aqua.derivz.dto.ListDataResponseDTO;
import com.citi.aqua.derivz.dto.ListedResponseDTO;
import com.citi.aqua.derivz.model.User;
import com.citi.aqua.derivz.model.VoyagerLinkResponse;
import com.citi.aqua.derivz.model.VoyagerNavigationData;
import com.citi.aqua.derivz.security.constants.AuthConstants;
import com.citi.aqua.derivz.services.service.BookmarkService;
import com.citi.aqua.derivz.services.service.CacheService;
import com.citi.aqua.derivz.services.service.ExportService;
import com.citi.aqua.derivz.services.service.UserSearchCriteriaService;
import com.citi.aqua.derivz.vo.SearchFieldVO;
import com.citi.aqua.derivz.web.utils.DatasetIdGetRequest;
import com.citi.aqua.derivz.web.utils.DerivzExportResultRestRequest;
import com.citi.aqua.derivz.web.utils.DerivzListSearchRestRequest;
import com.citi.aqua.derivz.web.utils.DerivzNonListSearchRestRequest;
import com.citi.aqua.derivz.web.utils.DerivzRestResponse;
import com.citi.aqua.derivz.web.utils.ResponseBuilder;

@RestController
@RequestMapping(DerivzAPIUriConstants.SEARCH_API_URI)
public class SearchController {

	private static final Logger LOGGER = LoggerFactory.getLogger(SearchController.class);

	@Autowired
	UserSearchCriteriaService userSearchCriteriaService;

	@Autowired
	BookmarkService bookmarkService;

	@Autowired
	CacheService cacheService;

	@Autowired
	ExportService exportService;

	@RequestMapping(value = DerivzAPIUriConstants.SEARCH_COLLATERAL_URI, method = RequestMethod.POST)
	public @ResponseBody DerivzRestResponse<ListedResponseDTO> searchCollateralByCriteria(
			@RequestBody final DerivzListSearchRestRequest searchSaveCriteriaRequest) {
		LOGGER.debug("SearchController::searchCollateralByCriteria() ");
		ListedResponseDTO macListingsResponseDTO = null;
		try {
			macListingsResponseDTO = userSearchCriteriaService
					.findUserFilterSearch(searchSaveCriteriaRequest.getCriteria());
			return ResponseBuilder.build(macListingsResponseDTO, HttpStatus.SC_OK);
		} catch (DerivzApplicationException de) {
			LOGGER.error("SearchController::searchCollateralByCriteria() :: Error " + de, de);
			return ResponseBuilder.build(macListingsResponseDTO, HttpStatus.SC_NOT_FOUND, "Failed to retrieve search from list procedure", "DS119");
		}
	}

	@SuppressWarnings({ "rawtypes" })
	@RequestMapping(value = DerivzAPIUriConstants.SEARCH_RESULT_LISTED_COLUMNS_URI, method = RequestMethod.GET)
	public @ResponseBody DerivzRestResponse<List> findPredefinedColumns() {
		LOGGER.debug("SearchController::findPredefinedColumns()");
		List<SearchFieldVO> searchCriteriaVOList = null;
		try {
			searchCriteriaVOList = userSearchCriteriaService.findPredefinedResultSet();
			return ResponseBuilder.build(searchCriteriaVOList, HttpStatus.SC_OK);
		} catch (DerivzApplicationException de) {
			LOGGER.error("SearchController::findPredefinedColumns() :: Error " + de, de);
			return ResponseBuilder.build(searchCriteriaVOList, HttpStatus.SC_NOT_FOUND, "Exception Occured in findPredefinedColumns", "DS114");
		} 
	}


	@RequestMapping(value = DerivzAPIUriConstants.SEARCH_RESULT_EXPORT_URI, method = RequestMethod.POST)
	public @ResponseBody void exportToExcel(final HttpServletRequest request, final HttpServletResponse response,
			@RequestBody final DerivzExportResultRestRequest derivzExportResultRestRequest) {
		try {
			exportService.exportToExcel(response, derivzExportResultRestRequest.getSource(),
					derivzExportResultRestRequest.getCriteria(), derivzExportResultRestRequest.getAgreementKeys());
		} catch (DerivzApplicationException | IOException de) {
			LOGGER.error("SearchController::exportToExcel() :: Error " + de, de);
		} 
	}

	@SuppressWarnings({ "rawtypes" })
	@RequestMapping(value = DerivzAPIUriConstants.SEARCH_COLLATERAL_TYPE_LOOKUP, method = RequestMethod.GET)
	public @ResponseBody DerivzRestResponse<List> getCollateralLookupColumns() {
		List<SearchFieldVO> searchCriteriaVOList = null;
		try {
			searchCriteriaVOList = userSearchCriteriaService.getCollateralLookupColumns();
			return ResponseBuilder.build(searchCriteriaVOList, HttpStatus.SC_OK);
		} catch (DerivzApplicationException de) {
			LOGGER.error("SearchController::getCollateralLookupColumns() :: Error " + de, de);
			return ResponseBuilder.build(searchCriteriaVOList, HttpStatus.SC_NOT_FOUND,	"Exception Occured in getCollateralLookupColumns", "DS004");
		} 
	}

	@RequestMapping(value = DerivzAPIUriConstants.SEARCH_COLLATERAL_TYPE_LOOKUP, method = RequestMethod.POST)
	public @ResponseBody DerivzRestResponse<List<CollateralResponseDTO>> searchCollateralLookup(
			@RequestBody final DerivzListSearchRestRequest searchSaveCriteriaRequest) {
		List<CollateralResponseDTO> collateralResponseDTO = null;
		try {
			collateralResponseDTO = userSearchCriteriaService
					.findCollateralFilterSearch(searchSaveCriteriaRequest.getCriteria());
			return ResponseBuilder.build(collateralResponseDTO, HttpStatus.SC_OK);
		} catch (DerivzApplicationException de) {
			LOGGER.error("SearchController::searchCollateralLookup() :: Error " + de, de);
			return ResponseBuilder.build(collateralResponseDTO, HttpStatus.SC_NOT_FOUND,"Failed to retrieve search from list procedure", "DS111");
		} 
	}
	
	@SuppressWarnings({ "rawtypes" })
	@RequestMapping(value = DerivzAPIUriConstants.GET_DATASET_ID_FOR_VOYAGER_LINK, method = RequestMethod.POST)
	public @ResponseBody  DerivzRestResponse searchDatasetIdLookup(final HttpServletRequest request,
			@RequestBody final DatasetIdGetRequest searchGetDatasetRequest) {
		VoyagerLinkResponse voyagerLinkResponse=new VoyagerLinkResponse("",0,"","-1",-1);
		final HttpSession session = request.getSession(true);
		User user= (User) session.getAttribute(AuthConstants.USER);
		try {
			voyagerLinkResponse = bookmarkService.getDatasetId(user,searchGetDatasetRequest.getDatasetTypeName());
			return ResponseBuilder.build(voyagerLinkResponse,HttpStatus.SC_OK);
		} catch (DerivzApplicationException de) {
			LOGGER.error("SearchController::searchDatasetIdLookup() :: Error " + de, de);
			return ResponseBuilder.build(voyagerLinkResponse, HttpStatus.SC_NOT_FOUND,	"Failed to get datasetId for dataset type.", "DS110");
		} 
	}
	
	@RequestMapping(value = DerivzAPIUriConstants.GET_USER_DATASET_FOR_VOYAGER_LINK, method = RequestMethod.GET)
	public @ResponseBody DerivzRestResponse<List<VoyagerNavigationData>> getUserDatasetIds(final HttpServletRequest request) {
		LOGGER.debug("SearchController::getUserDatasetIds()");
		final HttpSession session = request.getSession(true);
		User user= (User) session.getAttribute(AuthConstants.USER);
		try {
			List<VoyagerNavigationData> response = userSearchCriteriaService.loadUserDatasetIds(user);
			return ResponseBuilder.build(response, HttpStatus.SC_OK);
		} catch (DerivzApplicationException de) {
			LOGGER.error("SearchController::getUserDatasetIds() :: Error " + de, de);
			return ResponseBuilder.build(null, HttpStatus.SC_NOT_FOUND,	"Failed to get dataset for user.", "DS009");
		} 
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@RequestMapping(value = DerivzAPIUriConstants.LOAD_TABS_DATA_URI, method = RequestMethod.POST)
	public @ResponseBody DerivzRestResponse<ListDataResponseDTO> loadTabsData(
			@RequestBody final DerivzNonListSearchRestRequest searchSaveCriteriaRequest) {
	  ListDataResponseDTO tabDataList = null;
		try {
			tabDataList = userSearchCriteriaService.loadTabsData(
					searchSaveCriteriaRequest.getTabName(),
					searchSaveCriteriaRequest.getAgreementKeys(),
					searchSaveCriteriaRequest.getAgreementOptimalRanks(),
					searchSaveCriteriaRequest.getIsFilterd(),
					searchSaveCriteriaRequest.getCriteria(),
					searchSaveCriteriaRequest.getSmsColumns());
			
			return ResponseBuilder.build(tabDataList, HttpStatus.SC_OK);
		} catch (CEFTException de) {
			LOGGER.error("SearchController::loadingData() :: Error " + de, de);
			return ResponseBuilder.build(tabDataList, HttpStatus.SC_NOT_FOUND, "Exception Occured while loading "+searchSaveCriteriaRequest.getTabName()+" data", "DS024");
		}
	}
	
}
