package com.citi.aqua.derivz.web.filter;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.AntPathMatcher;
import org.springframework.util.PathMatcher;
import org.springframework.web.filter.OncePerRequestFilter;
import org.springframework.web.util.UrlPathHelper;

import com.citi.aqua.derivz.model.User;
import com.citi.aqua.derivz.security.AuthenticationService;
import com.citi.aqua.derivz.security.constants.AuthConstants;
import com.citi.aqua.derivz.web.DerivzApplication;
import com.citi.aqua.derivz.web.resources.ResourcesReference;
import com.citi.aqua.derivz.web.resources.StaticResources;

@Component
public class DvizAuthFilter extends OncePerRequestFilter {

	private final PathMatcher pathMatcher = new AntPathMatcher();

	private UrlPathHelper urlHelper;

	private static final Logger log = LoggerFactory.getLogger(DvizAuthFilter.class);

	@Autowired
	DvizAuthFilter(AuthenticationService authenticationService) {
		setUrlHelper(new UrlPathHelper());
	}

	@Override
	protected void doFilterInternal(final HttpServletRequest request, final HttpServletResponse response, final FilterChain filterChain) throws ServletException, IOException {

		final HttpSession session = request.getSession(false);
		final boolean sessionIsValid = (null != session	&& null != session.getAttribute(AuthConstants.ISLOGGED_IN));

		final String uri = request.getRequestURI();
		boolean skip = StaticResources.getExcludeResources().stream().anyMatch(pattern -> pathMatcher.match(pattern, uri));

		if ((uri.startsWith(StaticResources.URI_CACHE_ADMIN)) && (!(AuthConstants.PROD_ENV_NAME).equalsIgnoreCase(DerivzApplication.getEnvName()))) {
			skip = true;
		}

		if (!skip) {
			final String path = urlHelper.getPathWithinApplication(request);

			if (!StaticResources.getExcludeURIS().stream().anyMatch(pattern -> pathMatcher.match(pattern, path)) && !path.equals("/")) {
				if (sessionIsValid) {
					final User userProfile = (User) session.getAttribute(AuthConstants.USER);
					if (null != userProfile) {
						// check if redirect is required
						if ((!uri.startsWith(AuthConstants.API_CALL)) && (ResourcesReference.getDynamicURI().stream().anyMatch(pattern -> pathMatcher.match(pattern, uri)))) {
							setRedirect(response, request.getContextPath(), uri);
							return;
						}
					} else {
						if (!AuthConstants.HOME_PAGE.equals(path)) {
							response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
							log.error("UNAUTHORIZED REQUEST:: Invalid User: trying to access resource : {}", path);
							return;
						}
					}
				} else {
					response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
					log.info("UNAUTHORIZED REQUEST:: Invalid session, User not logged In. Trying to access resource :{} redirecting to login", path);
					// IF API call and no valid session - error - session timed-out
					if (path.startsWith("/api/")) {
						return;
					}

					if (!path.equals("/index.html") && !path.startsWith("/login")) {
						// We need to indicate to LoginController that resource needs Authorization, so
						// status is UNAUTHORIZED
						setRedirect(response, request.getContextPath(), uri);
						return;
					}
				}
			}
		}
		filterChain.doFilter(request, response);
	}

	private void setUrlHelper(UrlPathHelper urlHelper) {
		this.urlHelper = urlHelper;
	}

	protected void setRedirect(HttpServletResponse response, String context, String path) throws IOException {
		log.debug("Redirecting to {}=={}", path,context);
		response.setHeader("redirectURI", path);
		response.sendRedirect("/");
		// This doesn't working with Angular application, as Angular framework try to find {baseHostname}/redirectTo?redirectURI=/acl/dashboard in router
		// Definition and which is not there, causes problem
		
		//response.sendRedirect(context + "/redirectTo?redirectURI=" + response.encodeRedirectURL(path));
	}
}
