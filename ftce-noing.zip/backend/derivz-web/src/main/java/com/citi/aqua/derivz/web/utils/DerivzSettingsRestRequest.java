package com.citi.aqua.derivz.web.utils;

public class DerivzSettingsRestRequest<T> {

	private String userId;

	private String columnSettingName;

	private String[] selectedFieldsKeys;

	/**
	 * @return the selectedFieldsKeys
	 */
	public String[] getSelectedFieldsKeys() {
		return selectedFieldsKeys;
	}

	/**
	 * @param selectedFieldsKeys
	 *            the selectedFieldsKeys to set
	 */
	public void setSelectedFieldsKeys(String[] selectedFieldsKeys) {
		this.selectedFieldsKeys = selectedFieldsKeys;
	}

	/**
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}

	/**
	 * @param userId
	 *            the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

	/**
	 * @return the columnSettingName
	 */
	public String getColumnSettingName() {
		return columnSettingName;
	}

	/**
	 * @param columnSettingName
	 *            the columnSettingName to set
	 */
	public void setColumnSettingName(String columnSettingName) {
		this.columnSettingName = columnSettingName;
	}

}
