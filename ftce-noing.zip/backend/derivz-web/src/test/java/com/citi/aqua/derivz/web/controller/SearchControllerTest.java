package com.citi.aqua.derivz.web.controller;

import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;
import org.powermock.api.support.membermodification.MemberModifier;
import com.citi.aqua.derivz.dto.CollateralResponseDTO;
import com.citi.aqua.derivz.dto.ListedResponseDTO;
import com.citi.aqua.derivz.model.User;
import com.citi.aqua.derivz.model.VoyagerLinkResponse;
import com.citi.aqua.derivz.model.VoyagerNavigationData;
import com.citi.aqua.derivz.services.service.BookmarkService;
import com.citi.aqua.derivz.services.service.ExportService;
import com.citi.aqua.derivz.services.service.UserSearchCriteriaService;
import com.citi.aqua.derivz.services.service.impl.BookmarkServiceImpl;
import com.citi.aqua.derivz.services.service.impl.ExportServiceImpl;
import com.citi.aqua.derivz.services.service.impl.UserSearchCriteriaServiceImpl;
import com.citi.aqua.derivz.vo.SearchFieldVO;
import com.citi.aqua.derivz.web.utils.DatasetIdGetRequest;
import com.citi.aqua.derivz.web.utils.DerivzBookmarkRestRequest;
import com.citi.aqua.derivz.web.utils.DerivzListSearchRestRequest;
import com.citi.aqua.derivz.web.utils.DerivzNonListSearchRestRequest;
import com.citi.aqua.derivz.web.utils.DerivzRestResponse;
import junit.framework.TestCase;

public class SearchControllerTest extends TestCase {

	private SearchController searchController;

	private UserSearchCriteriaService userSearchCriteriaService;
	private BookmarkService bookmarkService;
	private ExportService exportService;

	private DerivzBookmarkRestRequest bookmarkRequest;
	private HttpServletResponse response;
	private HttpServletRequest request;
	private DerivzListSearchRestRequest searchSaveCriteriaRequest;
	private DerivzNonListSearchRestRequest searchSaveCriteriaNonListRequest;
	private User user;

	public SearchControllerTest() {
	}

	@Before
	public void setUp() throws Exception {
		bookmarkService = EasyMock.createMockBuilder(BookmarkServiceImpl.class).createMock();
		searchController = EasyMock.createMockBuilder(SearchController.class).createMock();
		userSearchCriteriaService = EasyMock.createMockBuilder(UserSearchCriteriaServiceImpl.class).createMock();
		exportService = EasyMock.createMockBuilder(ExportServiceImpl.class).createMock();
		searchSaveCriteriaRequest = EasyMock.createMockBuilder(DerivzListSearchRestRequest.class).createMock();
		request = EasyMock.createMock(HttpServletRequest.class);
		response = EasyMock.createMock(HttpServletResponse.class);
		user = EasyMock.createMock(User.class);
		searchSaveCriteriaNonListRequest = EasyMock.createMockBuilder(DerivzNonListSearchRestRequest.class)
				.createMock();
		userSearchCriteriaService = EasyMock.mock(UserSearchCriteriaServiceImpl.class);
		MemberModifier.field(SearchController.class, "userSearchCriteriaService").set(searchController,
				userSearchCriteriaService);
		bookmarkService = EasyMock.mock(BookmarkServiceImpl.class);
		MemberModifier.field(SearchController.class, "bookmarkService").set(searchController, bookmarkService);
	}

	@Test
	public void testSearchCollateralByCriteria() throws Exception {

		ListedResponseDTO listedResponseDTO = createMockListedResponseDTO();
		EasyMock.expect(userSearchCriteriaService.findUserFilterSearch(searchSaveCriteriaRequest.getCriteria()))
				.andReturn(listedResponseDTO);
		EasyMock.replay(userSearchCriteriaService);

		EasyMock.replay(searchController);
		DerivzRestResponse<ListedResponseDTO> actualBuilder = searchController
				.searchCollateralByCriteria(searchSaveCriteriaRequest);
		EasyMock.verify(searchController);
		assertEquals("20180101", actualBuilder.getResponseData().getCobDate());

	}

	@Test
	public void testFindPredefinedColumns() throws Exception {

		List<SearchFieldVO> searchCriteriaVOList = createMockSearchCriteriaVO();

		EasyMock.expect(userSearchCriteriaService.findPredefinedResultSet()).andReturn(searchCriteriaVOList);
		EasyMock.replay(userSearchCriteriaService);

		EasyMock.replay(searchController);
		DerivzRestResponse<List> actualBuilder = searchController.findPredefinedColumns();
		EasyMock.verify(searchController);
		assertEquals(1, actualBuilder.getResponseData().size());

	}


	@Test
	public void testGetCollateralLookupColumns() throws Exception {

		List<SearchFieldVO> searchFieldVOList = new ArrayList<>();
		SearchFieldVO seachFieldVO = new SearchFieldVO();
		searchFieldVOList.add(seachFieldVO);
		EasyMock.expect(userSearchCriteriaService.getCollateralLookupColumns()).andReturn(searchFieldVOList);
		EasyMock.replay(userSearchCriteriaService);

		EasyMock.replay(searchController);
		DerivzRestResponse<List> actualBuilder = searchController.getCollateralLookupColumns();
		EasyMock.verify(searchController);
		assertEquals(1, actualBuilder.getResponseData().size());
	}

	@Test
	public void testSearchCollateralLookup() throws Exception {

		List<CollateralResponseDTO> collateralResponseList = new ArrayList<>();
		CollateralResponseDTO collateralResponseDTO = new CollateralResponseDTO();
		collateralResponseList.add(collateralResponseDTO);
		EasyMock.expect(userSearchCriteriaService.findCollateralFilterSearch(searchSaveCriteriaRequest.getCriteria()))
				.andReturn(collateralResponseList);
		EasyMock.replay(userSearchCriteriaService);

		EasyMock.replay(searchController);
		DerivzRestResponse<List<CollateralResponseDTO>> actualBuilder = searchController
				.searchCollateralLookup(searchSaveCriteriaRequest);
		EasyMock.verify(searchController);
		assertEquals(1, actualBuilder.getResponseData().size());
	}

	@Test
	public void testSearchDatasetIdLookup() throws Exception {

		VoyagerLinkResponse voyagerLinkResponse = EasyMock.createMock(VoyagerLinkResponse.class);
		DatasetIdGetRequest searchGetDatasetRequest = EasyMock.createMock(DatasetIdGetRequest.class);
		EasyMock.expect(bookmarkService.getDatasetId(null, null)).andReturn(voyagerLinkResponse);
		HttpSession session = EasyMock.mock(HttpSession.class);
		EasyMock.expect((HttpSession) request.getSession(true)).andReturn(session);
		EasyMock.replay(request);
		EasyMock.replay(bookmarkService);

		EasyMock.replay(searchController);
		DerivzRestResponse actualBuilder = searchController.searchDatasetIdLookup(request, searchGetDatasetRequest);
		EasyMock.verify(searchController);
		assertNotNull(actualBuilder.getResponseData());
	}

	@Test
	public void testGetUserDatasetIds() throws Exception {

		List<VoyagerNavigationData> voyagerNavigationDataList = new ArrayList<>();
		VoyagerNavigationData e = new VoyagerNavigationData();
		voyagerNavigationDataList.add(e);
		HttpSession session = EasyMock.mock(HttpSession.class);
		EasyMock.expect((HttpSession) request.getSession(true)).andReturn(session);
		EasyMock.replay(request);

		EasyMock.expect(userSearchCriteriaService.loadUserDatasetIds(null)).andReturn(voyagerNavigationDataList);
		EasyMock.replay(userSearchCriteriaService);

		EasyMock.replay(searchController);
		DerivzRestResponse<List<VoyagerNavigationData>> actualBuilder = searchController.getUserDatasetIds(request);
		EasyMock.verify(searchController);
		assertEquals(1, actualBuilder.getResponseData().size());
	}

	private List<SearchFieldVO> createMockSearchCriteriaVO() {
		List<SearchFieldVO> searchCriteriaVOList = new ArrayList<>();
		SearchFieldVO e = new SearchFieldVO<>();
		e.setFieldName("TestField");
		e.setNodeName("TestNode");
		searchCriteriaVOList.add(e);

		return searchCriteriaVOList;
	}

	private ListedResponseDTO createMockListedResponseDTO() {
		ListedResponseDTO listedResponseDTO = new ListedResponseDTO();
		listedResponseDTO.setCobDate("20180101");
		return listedResponseDTO;
	}
}
