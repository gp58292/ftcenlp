package com.citi.aqua.derivz.web.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;
import org.powermock.api.support.membermodification.MemberModifier;

import com.citi.aqua.derivz.commons.constants.DerivzCommonConstants;
import com.citi.aqua.derivz.model.LoginStatusEnum;
import com.citi.aqua.derivz.model.User;
import com.citi.aqua.derivz.model.UserToken;
import com.citi.aqua.derivz.security.AuthenticationService;
import com.citi.aqua.derivz.web.utils.DerivzRestResponse;

public class LoginControllerTest {

	private AuthenticationService authenticationService;
	private LoginController loginController;
	private HttpServletRequest request;
	private HttpServletResponse response;
	HttpSession session;
	private User goodUser,badUser;
	private UserToken userToken;
	
	public LoginControllerTest() {
		goodUser=new User();
		goodUser.setName("Viraj Nimbalkar");
		goodUser.setPassword("CEFT1234");
		goodUser.setSoeid("VN06956");
		goodUser.setAuthenticated(true);
		goodUser.setStatus(LoginStatusEnum.DVIZ_200);
		goodUser.setToken(UUID.randomUUID().toString());
		
		badUser=new User();
		badUser.setName("Viraj Nimbalkar");
		badUser.setSoeid("VN06956");
		badUser.setAuthenticated(false);
		badUser.setStatus(LoginStatusEnum.DVIZ_401);
		
		userToken=new UserToken();
		userToken.setToken(goodUser.getToken());
		userToken.setTokenValid(true);
	}
	
	@Before
	public void setUp() throws Exception {
		authenticationService = EasyMock.createMockBuilder(AuthenticationService.class).createMock();
		loginController = EasyMock.createMockBuilder(LoginController.class).createMock();;
		request = EasyMock.createMock(HttpServletRequest.class);
		response = EasyMock.createMock(HttpServletResponse.class);
	}
	
	@Test
	public void testValidateUserGoodUser() throws Exception {
		authenticationService = EasyMock.mock(AuthenticationService.class);
		MemberModifier.field(LoginController.class, "authenticationService").set(loginController, authenticationService);
		request = EasyMock.mock(HttpServletRequest.class);
		
		HttpSession session = EasyMock.mock(HttpSession.class);
		EasyMock.expect(request.getSession(true)).andReturn(session);
		EasyMock.replay(request);
		EasyMock.expect(authenticationService.authenticateUser(session, goodUser)).andReturn(goodUser);
		EasyMock.replay(authenticationService);
		
		
		EasyMock.replay(loginController);
		DerivzRestResponse<User> actualBuilder = loginController.validateUser(request, response, goodUser);
		EasyMock.verify(loginController);
		assertEquals(true, actualBuilder.getResponseData().getIsAuthenticated());
	}
	
	@Test
	public void testValidateUserBadUser() throws Exception {
		authenticationService = EasyMock.mock(AuthenticationService.class);
		MemberModifier.field(LoginController.class, "authenticationService").set(loginController, authenticationService);
		request = EasyMock.mock(HttpServletRequest.class);
		
		HttpSession session = EasyMock.mock(HttpSession.class);
		EasyMock.expect(request.getSession(true)).andReturn(session);
		EasyMock.replay(request);
		EasyMock.expect(authenticationService.authenticateUser(session, badUser)).andReturn(badUser);
		EasyMock.replay(authenticationService);
		
		
		EasyMock.replay(loginController);
		DerivzRestResponse<User> actualBuilder = loginController.validateUser(request, response, badUser);
		EasyMock.verify(loginController);
		assertEquals(false, actualBuilder.getResponseData().getIsAuthenticated());
	}
	
	
	@Test
	public void testGetUser() throws Exception {
		authenticationService = EasyMock.mock(AuthenticationService.class);
		MemberModifier.field(LoginController.class, "authenticationService").set(loginController, authenticationService);
		request = EasyMock.mock(HttpServletRequest.class);
		
		HttpSession session = EasyMock.mock(HttpSession.class);
		EasyMock.expect(request.getSession(false)).andReturn(session);
		EasyMock.replay(request);
		EasyMock.expect(authenticationService.getUser(session)).andReturn(goodUser);
		EasyMock.replay(authenticationService);
		
		EasyMock.replay(loginController);
		DerivzRestResponse<User> actualBuilder = loginController.getUser(request, response);
		EasyMock.verify(loginController);
		assertEquals(goodUser.hashCode(), actualBuilder.getResponseData().hashCode());
	}
	
	@Test
	public void testChangePassword() throws Exception {
		EasyMock.replay(loginController);
		DerivzRestResponse<User> actualBuilder = loginController.changePassword(request, response,goodUser);
		EasyMock.verify(loginController);
		assertEquals(null, actualBuilder.getResponseData());
	}
	
	@Test
	public void testLogout() throws Exception {
		authenticationService = EasyMock.mock(AuthenticationService.class);
		MemberModifier.field(LoginController.class, "authenticationService").set(loginController, authenticationService);
		request = EasyMock.mock(HttpServletRequest.class);
		
		HttpSession session = EasyMock.mock(HttpSession.class);
		EasyMock.expect(session.getId()).andReturn("I am Testing Id Temporary...");
		EasyMock.replay(session);
		
		EasyMock.replay(request);
		authenticationService.killSession(session);
		EasyMock.replay(authenticationService);
		
		
		EasyMock.replay(loginController);
		DerivzRestResponse<String> actualBuilder = loginController.logout(request, response,session);
	
		EasyMock.verify(loginController);
		assertEquals(DerivzCommonConstants.LOGOUT_MESSAGE, actualBuilder.getMessage());
	}
	
	@Test
	public void testGetUserToken() throws Exception {
		authenticationService = EasyMock.mock(AuthenticationService.class);
		MemberModifier.field(LoginController.class, "authenticationService").set(loginController, authenticationService);
		request = EasyMock.mock(HttpServletRequest.class);
		EasyMock.replay(request);
		
		EasyMock.expect(authenticationService.getUserToken(goodUser.getSoeid(),goodUser.getPassword())).andReturn(userToken);
		EasyMock.replay(authenticationService);
		
		EasyMock.replay(loginController);
		DerivzRestResponse<UserToken> actualBuilder = loginController.getUserToken(request, response,goodUser);
	
		EasyMock.verify(loginController);
		assertNotNull(userToken.hashCode());
		assertNotNull(actualBuilder.getResponseData());
	}
	
	@Test
	public void testValidateUserToken() throws Exception {
		authenticationService = EasyMock.mock(AuthenticationService.class);
		MemberModifier.field(LoginController.class, "authenticationService").set(loginController, authenticationService);
		request = EasyMock.mock(HttpServletRequest.class);
		EasyMock.replay(request);
		
		EasyMock.expect(authenticationService.validateUserToken(userToken.getToken())).andReturn(true);
		
		EasyMock.replay(loginController);
		DerivzRestResponse<UserToken> actualBuilder = loginController.validateUserToken(request, response, goodUser);
	
		EasyMock.verify(loginController);
		assertNotNull(userToken.hashCode());
		assertNotNull(actualBuilder.getResponseData());
	}
	
}
