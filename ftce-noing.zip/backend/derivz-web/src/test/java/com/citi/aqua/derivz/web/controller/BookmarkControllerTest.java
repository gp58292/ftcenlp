package com.citi.aqua.derivz.web.controller;

import java.util.LinkedList;
import java.util.List;
import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;
import org.powermock.api.support.membermodification.MemberModifier;
import com.citi.aqua.derivz.commons.constants.DerivzCommonConstants;
import com.citi.aqua.derivz.enums.ComponentType;
import com.citi.aqua.derivz.model.Bookmark;
import com.citi.aqua.derivz.services.service.BookmarkService;
import com.citi.aqua.derivz.services.service.impl.BookmarkServiceImpl;
import com.citi.aqua.derivz.vo.SearchFieldVO;
import com.citi.aqua.derivz.web.utils.DerivzBookmarkRestRequest;
import com.citi.aqua.derivz.web.utils.DerivzRestResponse;
import junit.framework.TestCase;

public class BookmarkControllerTest extends TestCase {

	private BookmarkController bookmarkController;
	private BookmarkService bookmarkService;
	private DerivzBookmarkRestRequest bookmarkRequest;

	public BookmarkControllerTest() {
		
	}

	@Before
	public void setUp() throws Exception {
		bookmarkService = EasyMock.createMockBuilder(BookmarkServiceImpl.class).createMock();
		bookmarkController = EasyMock.createMockBuilder(BookmarkController.class).createMock();
		bookmarkRequest = EasyMock.createMockBuilder(DerivzBookmarkRestRequest.class).createMock();
	}
	
	
	@Test
	public void testGetBookmarkValue() throws Exception {
		List<SearchFieldVO> bookmarkData = mockDataForBookmark();
		bookmarkService = EasyMock.mock(BookmarkServiceImpl.class);
		MemberModifier.field(BookmarkController.class, "bookmarkService").set(bookmarkController, bookmarkService);

		EasyMock.expect(bookmarkService.getBookmarkForGivenId("vn06956",1l)).andReturn(bookmarkData);
		EasyMock.replay(bookmarkService);

		EasyMock.replay(bookmarkController);
		DerivzRestResponse<List<SearchFieldVO>> actualBuilder = bookmarkController.getBookmarkValue("vn06956",1l);
		EasyMock.verify(bookmarkController);
		assertEquals(true, actualBuilder.getResponseData().contains(bookmarkData.get(0)));

	}

	private List<SearchFieldVO> mockDataForBookmark() {

		List<SearchFieldVO> bookmarkData = new LinkedList<SearchFieldVO>();
		SearchFieldVO obj = new SearchFieldVO();
		obj.setValue("PENSION FUND");
		obj.setKey(90l);
		obj.setComponentType(ComponentType.FREE_FORM_TEXT);
		obj.setDataType("string");
		obj.setDefaultSelected(1);
		obj.setDistinctRequired(1);
		obj.setFieldName("customer_name");
		obj.setNodeName("vw_ceft_dim_agreement");
		obj.setLogicalGroupName("MAC Attributes");
		obj.setSchemaName("dz");
		obj.setName("Customer Name");
		bookmarkData.add(obj);
		return bookmarkData;

	}

	@Test
	public void testGetBookmarksForUser() throws Exception {
		List<Bookmark> bookmarkData = mockDataForBookmarkUser();
		bookmarkService = EasyMock.mock(BookmarkServiceImpl.class);
		MemberModifier.field(BookmarkController.class, "bookmarkService").set(bookmarkController, bookmarkService);

		EasyMock.expect(bookmarkService.getSearchCriteriaList("AK92283", DerivzCommonConstants.SEARCH_TYPE_LIST))
				.andReturn(bookmarkData);
		EasyMock.replay(bookmarkService);

		EasyMock.replay(bookmarkController);
		DerivzRestResponse<List<Bookmark>> actualBuilder = bookmarkController.getBookmarksForUser("AK92283");
		EasyMock.verify(bookmarkController);
		assertEquals(true, actualBuilder.getResponseData().contains(bookmarkData.get(0)));

	}

	private List<Bookmark> mockDataForBookmarkUser() {
		List<Bookmark> bookmarkData = new LinkedList<>();
		Bookmark obj = new Bookmark();
		obj.setCriteria("[{\"key\":90,\"value\":\"PENSION FUND\",\"whoHasFlag\":0}]");
		obj.setKey(1l);
		obj.setLastSelected(1);
		obj.setName("Test_Bookmark");
		obj.setType("Search");
		obj.setUserId("AK92283");
		bookmarkData.add(obj);
		return bookmarkData;
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testSaveUserBookmark() throws Exception {
		
		List<Bookmark> bookmarkData = mockDataForBookmarkUser();
		bookmarkService = EasyMock.mock(BookmarkServiceImpl.class);
		MemberModifier.field(BookmarkController.class, "bookmarkService").set(bookmarkController, bookmarkService);

		Bookmark bookmark= bookmarkData.get(0);
		EasyMock.expect(bookmarkService.saveUserBookmark(bookmarkRequest.getUserId(), bookmarkRequest.getBookmarkName(),
				bookmarkRequest.getBookmarkData(), bookmarkRequest.getSearchCriteria(),bookmarkRequest.getParentBookmarkId())).andReturn(bookmark);
		EasyMock.replay(bookmarkService);

		EasyMock.replay(bookmarkController);
		DerivzRestResponse<Bookmark> actualBuilder = bookmarkController.saveBookMark(bookmarkRequest);
		EasyMock.verify(bookmarkController);
		assertEquals(bookmark, actualBuilder.getResponseData());

	}

	@Test
	public void testDeleteBookmarksById() throws Exception {
		List<Bookmark> bookmarkData = mockDataForBookmarkUser();
		bookmarkService = EasyMock.mock(BookmarkServiceImpl.class);
		MemberModifier.field(BookmarkController.class, "bookmarkService").set(bookmarkController, bookmarkService);

		Long bookmarkId = new Long(99999);
		EasyMock.expect(bookmarkService.deleteBookmark("vn06956",bookmarkId)).andReturn(true);
		EasyMock.replay(bookmarkService);

		EasyMock.replay(bookmarkController);
		DerivzRestResponse<Boolean> actualBuilder = bookmarkController.deleteBookmarksById("vn06956",bookmarkId);
		EasyMock.verify(bookmarkController);
		assertEquals(true, actualBuilder.getResponseData().booleanValue());

	}

	@Test
	public void testUpdateBookmark() throws Exception {
		List<Bookmark> bookmarkData = mockDataForBookmarkUser();
		bookmarkService = EasyMock.mock(BookmarkServiceImpl.class);
		MemberModifier.field(BookmarkController.class, "bookmarkService").set(bookmarkController, bookmarkService);

		EasyMock.expect(bookmarkService.updateUserBookmark(bookmarkRequest.getBookmarkId(),
				bookmarkRequest.getBookmarkData(), bookmarkRequest.getUserId(), bookmarkRequest.getSearchCriteria(),null))
				.andReturn(bookmarkData.get(0));
		EasyMock.replay(bookmarkService);

		EasyMock.replay(bookmarkController);
		DerivzRestResponse<Bookmark> actualBuilder = bookmarkController.updateBookMark(bookmarkRequest);
		EasyMock.verify(bookmarkController);
		assertEquals("Search", actualBuilder.getResponseData().getType());

	}

	@Test
	public void testShareBookmark() throws Exception {
		bookmarkService = EasyMock.mock(BookmarkServiceImpl.class);
		MemberModifier.field(BookmarkController.class, "bookmarkService").set(bookmarkController, bookmarkService);
		Long sharedBookmarkId = new Long(99999);
		EasyMock.expect(bookmarkService.shareUserBookmark("sa98695", "Test", sharedBookmarkId)).andReturn(true);
		EasyMock.replay(bookmarkService);

		EasyMock.replay(bookmarkController);
		DerivzRestResponse<Boolean> actualBuilder = bookmarkController.shareBookmark(sharedBookmarkId, "sa98695",
				"Test");
		EasyMock.verify(bookmarkController);
		assertEquals(true, actualBuilder.getResponseData().booleanValue());

	}

}
