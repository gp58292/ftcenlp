package com.citi.aqua.derivz.web.controller;

import java.net.MalformedURLException;
import java.net.URL;

import org.junit.Before;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.security.web.FilterChainProxy;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

//@RunWith(SpringJUnit4ClassRunner.class)
//@ContextConfiguration
//@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT, value = { "spring.profiles.active=test" })
//@AutoConfigureMockMvc
public class BatchStatusControllerITest {

	@LocalServerPort
	private int port;

	private URL base;

	@Autowired
	private MockMvc mockMvc;

	@Autowired
	private FilterChainProxy springSecurityFilterChain;

	@Autowired
	private WebApplicationContext wac;

	protected MockHttpSession session;

	protected MockHttpServletRequest request;

	@Autowired
	private TestRestTemplate template;

	public BatchStatusControllerITest() {
	}

	public URL getBase() {
		return base;
	}

	// setting base
	public void setBase(URL base) {
		try {
			this.base = new URL("http:localhost:" + port + "/api/");
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
	}

	@Before
	public void setUp() throws Exception {
		this.mockMvc = MockMvcBuilders.webAppContextSetup(this.wac).addFilters(this.springSecurityFilterChain).build();
		if (template == null) {
			throw new Exception("Test rest template not defined");
		}
		this.getBase();
		session = new MockHttpSession();
	}

	/*@Test
	public void testGetStatusReport() throws Exception {
		mockMvc.perform(get(DerivzAPIUriConstants.BATCHSTATUS_API_URI + "/getReport/20181010")
				.contentType(MediaType.APPLICATION_JSON).session(session)).andExpect(status().isOk());
	}*/
	
}
