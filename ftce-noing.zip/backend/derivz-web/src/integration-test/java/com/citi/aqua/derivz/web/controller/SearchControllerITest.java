package com.citi.aqua.derivz.web.controller;

import static junit.framework.TestCase.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.security.web.FilterChainProxy;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.citi.aqua.derivz.commons.constants.DerivzAPIUriConstants;
import com.citi.aqua.derivz.enums.ComponentType;
import com.citi.aqua.derivz.services.service.BookmarkService;
import com.citi.aqua.derivz.services.service.CacheService;
import com.citi.aqua.derivz.services.service.UserSearchCriteriaService;
import com.citi.aqua.derivz.vo.ReferenceDataVO;
import com.citi.aqua.derivz.vo.SearchFieldVO;
import com.citi.aqua.derivz.web.utils.DerivzListSearchRestRequest;
import com.citi.aqua.derivz.web.utils.DerivzNonListSearchRestRequest;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT, value = { "spring.profiles.active=test" })
@AutoConfigureMockMvc
public class SearchControllerITest {

	@LocalServerPort
	private int port;

	private URL base;

	@Autowired
	private MockMvc mockMvc;

	@Autowired
	private FilterChainProxy springSecurityFilterChain;

	@Autowired
	private WebApplicationContext wac;

	protected MockHttpSession session;

	protected MockHttpServletRequest request;

	@Autowired
	private TestRestTemplate template;

	@Autowired
	UserSearchCriteriaService userSearchCriteriaService;

	@Autowired
	BookmarkService bookmarkService;

	@Autowired
	CacheService cacheService;

	public SearchControllerITest() {
	}

	public URL getBase() {
		return base;
	}

	// setting base
	public void setBase(URL base) {
		try {
			this.base = new URL("http:localhost:" + port + "/api/");
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
	}

	@Before
	public void setUp() throws Exception {
		this.mockMvc = MockMvcBuilders.webAppContextSetup(this.wac).addFilters(this.springSecurityFilterChain).build();
		if (template == null) {
			throw new Exception("Test rest template not defined");
		}
		this.getBase();
		session = new MockHttpSession();
	}

	@Test
	public void testSearchCollateralByCriteria() throws Exception {
		RequestBuilder requestBuilder = MockMvcRequestBuilders
				.post(DerivzAPIUriConstants.SEARCH_API_URI + DerivzAPIUriConstants.SEARCH_COLLATERAL_URI)
				.contentType(MediaType.APPLICATION_JSON).content(convertObjectToJsonBytes(prepareMockDataForMac()));

		mockMvc.perform(post(DerivzAPIUriConstants.SEARCH_API_URI + DerivzAPIUriConstants.SEARCH_COLLATERAL_URI)
				.contentType(MediaType.APPLICATION_JSON).content(convertObjectToJsonBytes(prepareMockDataForMac())))
				.andExpect(status().isOk());
	}

	@Test
	public void testFindPredefinedColumns() throws Exception {
		mockMvc.perform(
				get(DerivzAPIUriConstants.SEARCH_API_URI + DerivzAPIUriConstants.SEARCH_RESULT_LISTED_COLUMNS_URI)
						.accept(MediaType.APPLICATION_JSON).session(session))
				.andExpect(status().isOk());
	}

	@Test
	public void testFindPredefinedResultSets() throws Exception {
		List<SearchFieldVO> mockData = createMockDataForPredefinedColumns();
		List<SearchFieldVO> actualData = userSearchCriteriaService.findPredefinedResultSet();
		assertEquals(mockData.get(0).getName(), actualData.get(0).getName());
		assertEquals(mockData.get(0).getDataType(), actualData.get(0).getDataType());
		assertEquals(mockData.get(0).getKey(), actualData.get(0).getKey());
	}

	private List<SearchFieldVO> createMockDataForPredefinedColumns() {
		List<SearchFieldVO> predefinedColumnList = new LinkedList<>();
		final SearchFieldVO searchCriteriaVO = new SearchFieldVO();
		searchCriteriaVO.setFieldName("address");
		searchCriteriaVO.setName("Address");
		searchCriteriaVO.setSchemaName("dz");
		searchCriteriaVO.setNodeName("vw_ceft_dim_agreement");
		searchCriteriaVO.setLogicalGroupName("MAC Attributes");
		searchCriteriaVO.setDataType("string");
		searchCriteriaVO.setNodeDisplayName("Third Party Custody");
		searchCriteriaVO.setDistinctRequired(1);
		searchCriteriaVO.setKey(new Long(3));
		searchCriteriaVO.setDefaultSelected(null);
		predefinedColumnList.add(searchCriteriaVO);
		return predefinedColumnList;

	}

	public static byte[] convertObjectToJsonBytes(Object object) throws IOException {
		ObjectMapper mapper = new ObjectMapper();
		mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
		return mapper.writeValueAsBytes(object);
	}

	public static String convertObjectToJson(Object object) throws IOException {
		ObjectMapper mapper = new ObjectMapper();
		mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
		return mapper.writeValueAsString(object);
	}

	private DerivzListSearchRestRequest prepareMockDataForMac() {
		DerivzListSearchRestRequest request = new DerivzListSearchRestRequest();
		request.setUserId("AK92283");
		List<SearchFieldVO> criteria = new ArrayList<>();
		SearchFieldVO obj = new SearchFieldVO();
		obj.setComponentType(ComponentType.TYPEAHEAD_TEXTBOX);
		obj.setDataType("INTEGER");
		obj.setDefaultSelected(null);
		obj.setDistinctRequired(1);
		obj.setFieldName("agreement_id");
		obj.setKey(new Long(4));
		obj.setLogicalGroupName("MAC Attributes");
		obj.setName(null);
		obj.setNodeDisplayName("Master Agreement");
		obj.setSchemaName("dz");
		obj.setWhoHasFlag(0);
		ReferenceDataVO rf = new ReferenceDataVO();
		rf.setKey(new Long(109820));
		rf.setValue(new Long(100002));
		obj.setValue(rf);
		request.setCriteria(criteria);
		return request;
	}

	private DerivzNonListSearchRestRequest prepareMockDataForBox() {
		DerivzNonListSearchRestRequest req = new DerivzNonListSearchRestRequest();
		List<Long> agreementKeys = Arrays.asList(new Long(537458));
		req.setAgreementKeys(agreementKeys);
		return req;
	}

	private DerivzNonListSearchRestRequest prepareMockDataForPosting() {
		DerivzNonListSearchRestRequest req = new DerivzNonListSearchRestRequest();
		List<Long> agreementKeys = Arrays.asList(245808L, 245814L, 245821L, 245823L, 245826L, 245827L, 245828L, 245832L,
				245836L, 245837L, 245838L, 245839L, 245841L, 245846L, 245847L, 245849L, 245850L, 245851L, 245853L,
				245867L, 246035L, 246119L, 246337L, 246343L, 262988L, 262992L, 262993L, 265846L, 265851L, 265856L,
				267762L, 269302L, 271093L, 272790L, 274127L, 274128L, 274130L, 274131L, 274132L, 274141L, 274146L,
				274152L, 277230L, 277236L, 277237L, 279307L, 280972L, 282369L, 284757L, 298015L, 298158L, 299044L,
				299051L, 300084L, 301945L, 302681L, 302682L, 303657L, 304867L, 305572L, 309305L, 341357L, 341363L,
				341376L, 358075L, 358080L, 359732L, 369832L, 379975L, 382192L, 382193L, 382848L, 395554L, 396604L,
				396811L, 402265L, 405731L, 405734L, 408378L, 412772L, 412776L, 421448L, 421460L, 421484L, 421491L,
				421542L, 424010L, 424830L, 429764L, 429765L, 430240L, 430328L, 430358L, 430403L, 430411L, 430418L,
				430636L, 430857L, 431048L, 435939L, 440660L, 446689L, 450917L, 450918L, 450919L, 453672L, 453673L,
				453674L, 453728L, 453729L, 453730L, 453967L, 453968L, 453969L, 455582L, 455583L, 455584L, 457245L,
				457246L, 457247L, 459823L, 459824L, 459825L, 473018L, 473019L, 473020L, 483770L, 483771L, 483772L,
				483773L, 486330L, 486331L, 486332L, 487493L, 487494L, 487495L, 493952L, 493953L, 493954L, 493955L,
				496950L, 496951L, 496952L, 497677L, 497678L, 497679L, 500641L, 500642L, 500643L, 517679L, 517680L,
				517681L, 518854L, 518855L, 518856L, 519865L, 519866L, 519867L, 522130L, 522131L, 522132L, 545919L,
				545920L, 545921L, 545922L, 553328L, 553329L, 553330L, 563848L, 563849L, 563850L, 563851L, 563852L,
				567214L, 567215L, 567216L, 567217L, 578573L, 578574L, 578575L, 584832L, 584833L, 584834L, 593139L,
				593140L, 593141L, 617006L, 617007L, 621999L, 622000L, 622001L, 622002L, 622735L, 622736L, 622737L,
				622771L, 622772L, 622773L, 626654L, 626655L, 626656L, 640878L, 640879L, 640880L, 640881L, 642898L,
				642899L, 642900L, 642901L, 643623L, 643624L, 643625L, 643626L, 645495L, 645497L, 645498L, 684033L,
				684039L, 689917L, 689918L, 689919L, 693885L, 693886L, 693887L, 705283L, 705284L, 705285L, 705302L,
				705303L, 705304L, 705305L, 705398L, 705399L, 705400L, 705420L, 705421L, 705422L, 705466L, 705467L,
				705468L, 705492L, 705493L, 705494L, 705495L, 705496L, 705497L, 705498L, 705511L, 705512L, 705513L,
				705516L, 705517L, 705518L, 705528L, 705529L, 705530L, 705539L, 705540L, 705541L, 705542L, 705558L,
				705559L, 705560L, 705561L, 705562L, 705582L, 705583L, 705584L, 705585L, 705586L, 705587L, 705592L,
				705593L, 705594L, 705634L, 705635L, 705636L, 705637L, 705649L, 705650L, 705651L, 705652L, 705655L,
				705656L, 705657L, 705660L, 705661L, 705662L, 705683L, 705684L, 705685L, 705747L, 705748L, 705749L,
				705750L, 705782L, 705783L, 705784L, 705822L, 705823L, 705824L, 706274L, 706275L, 706276L, 706396L,
				706397L, 706398L, 706553L, 706554L, 706555L, 706627L, 706628L, 706629L, 706719L, 706720L, 706721L,
				706787L, 706788L, 706789L, 707455L, 707456L, 707457L, 707662L, 707663L, 707664L, 707665L, 707666L,
				707667L, 708203L, 708204L, 708205L, 709190L, 709191L, 709192L, 711362L, 711363L, 711364L, 711365L,
				711516L, 711517L, 711518L, 712563L, 712564L, 712565L, 714291L, 714292L, 714293L, 715729L, 715730L,
				715731L, 715732L, 715733L, 715734L, 715735L, 715736L, 715737L, 715738L, 716270L, 716271L, 716272L,
				716273L, 716274L, 722928L, 722929L, 722930L, 723582L, 723583L, 723584L, 723585L, 724576L, 724577L,
				724578L, 724579L, 726338L, 726339L, 726340L, 726341L, 726792L, 748325L, 748326L, 748327L, 748328L,
				749944L, 749945L, 749946L, 749947L, 751006L, 751007L, 751008L, 751679L, 751680L, 752702L, 756534L,
				756535L, 756536L, 760036L, 760037L, 760038L, 760039L, 760699L, 760700L, 760701L, 760702L, 761156L,
				761157L, 761158L, 764366L, 764367L, 764368L, 764369L, 764390L, 764391L, 764392L, 764987L, 764988L,
				764995L, 764996L, 764997L, 765014L, 765015L, 765016L, 765037L, 765038L, 765039L, 765040L, 765061L,
				765062L, 765063L, 765064L, 765076L, 765077L, 765078L, 765095L, 765096L, 765097L, 765139L, 765140L,
				765141L, 765164L, 765165L, 765166L, 765181L, 765182L, 765183L, 765206L, 765207L, 765208L, 765209L,
				765211L, 765212L, 765213L, 765214L, 765215L, 765219L, 765220L, 765221L, 765222L, 765223L, 765224L,
				765225L, 765226L, 765227L, 765228L, 765242L, 765243L, 765244L, 765289L, 765290L, 765291L, 765292L,
				765293L, 765294L, 765304L, 765305L, 765306L, 765307L, 765341L, 765342L, 765343L, 765348L, 765349L,
				765350L, 765357L, 765358L, 765359L, 765364L, 765365L, 765366L, 765393L, 765394L, 765395L, 765396L,
				765407L, 765408L, 765409L, 765410L, 765414L, 765415L, 765416L, 765504L, 765505L, 765506L, 765631L,
				765632L, 765633L, 766011L, 766012L, 766013L, 766029L, 766030L, 766031L, 766076L, 766077L, 766078L,
				766090L, 766091L, 766092L, 766417L, 766418L, 766419L, 766443L, 766444L, 766445L, 766504L, 766505L,
				766506L, 766507L, 766508L, 766509L, 766569L, 766570L, 766571L, 768080L, 768081L, 768082L, 768083L,
				768084L, 768085L, 768459L, 768460L, 768461L, 769105L, 769106L, 769107L, 769708L, 769709L, 769710L,
				769815L, 769816L, 769817L, 769839L, 769840L, 769841L, 769842L, 769862L, 769863L, 769864L, 769865L,
				769866L, 769867L, 769868L, 770048L, 770049L, 770050L, 770125L, 770126L, 998724L, 998725L, 998727L,
				998728L, 998729L, 998730L);
		req.setAgreementKeys(agreementKeys);
		return req;
	}
	
	@Test
	public void testGetCollateralLookupColumns() throws Exception {
		mockMvc.perform(get(DerivzAPIUriConstants.SEARCH_API_URI + DerivzAPIUriConstants.SEARCH_COLLATERAL_TYPE_LOOKUP)
				.accept(MediaType.APPLICATION_JSON).session(session)).andExpect(status().isOk());
	}
	
	
	@Test
	public void testSearchCollateralLookup() throws Exception {
		RequestBuilder requestBuilder = MockMvcRequestBuilders
				.post(DerivzAPIUriConstants.SEARCH_API_URI + DerivzAPIUriConstants.SEARCH_COLLATERAL_TYPE_LOOKUP)
				.contentType(MediaType.APPLICATION_JSON).content(convertObjectToJsonBytes(prepareMockDataForCollateralLookup()));

	}
	
	private DerivzListSearchRestRequest prepareMockDataForCollateralLookup() {
		DerivzListSearchRestRequest request = new DerivzListSearchRestRequest();
		request.setUserId("AK92283");
		List<SearchFieldVO> criteria = new ArrayList<>();
		SearchFieldVO obj = new SearchFieldVO();
		obj.setComponentType(ComponentType.DROPDOWN);
		obj.setDataType("string");
		obj.setDefaultSelected(null);
		obj.setDistinctRequired(1);
		obj.setFieldName("country_code");
		obj.setKey(new Long(63));
		obj.setLogicalGroupName("MAC Attributes");
		obj.setName("Country Code");
		obj.setNodeDisplayName("Collateral Issuer Country States");
		obj.setSchemaName("dz");
		obj.setWhoHasFlag(1);
		ReferenceDataVO rf = new ReferenceDataVO();
		rf.setKey(new Long(1992666));
		rf.setValue("AD");
		obj.setValue(rf);
		request.setCriteria(criteria);
		return request;
	}
	

}
