package com.citi.aqua.derivz.services.service.impl;


import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;

import com.citi.aqua.derivz.commons.constants.DerivzCommonConstants;
import com.citi.aqua.derivz.commons.exceptions.DerivzApplicationException;
import com.citi.aqua.derivz.commons.utils.DBCommonUtils;
import com.citi.aqua.derivz.data.jdbc.SearchDAO;
import com.citi.aqua.derivz.data.repository.BaseRepository;
import com.citi.aqua.derivz.data.repository.DimAgreementRepository;
import com.citi.aqua.derivz.data.repository.DistinctValuesRepository;
import com.citi.aqua.derivz.data.repository.SelectionFiltersRepository;
import com.citi.aqua.derivz.dto.CollateralResponseDTO;
import com.citi.aqua.derivz.dto.ListDataResponseDTO;
import com.citi.aqua.derivz.enums.ComponentType;
import com.citi.aqua.derivz.model.DimAgreement;
import com.citi.aqua.derivz.model.SelectionFilters;
import com.citi.aqua.derivz.model.User;
import com.citi.aqua.derivz.model.VoyagerNavigationLink;
import com.citi.aqua.derivz.services.service.CacheService;
import com.citi.aqua.derivz.vo.BoxDataVO;
import com.citi.aqua.derivz.vo.CapacityDataVO;
import com.citi.aqua.derivz.vo.FRTBDataVO;
import com.citi.aqua.derivz.vo.ForwardMtmDataVO;
import com.citi.aqua.derivz.vo.GSSTDataVO;
import com.citi.aqua.derivz.vo.MTMDataVO;
import com.citi.aqua.derivz.vo.PostingDataVO;
import com.citi.aqua.derivz.vo.ReferenceDataVO;
import com.citi.aqua.derivz.vo.SearchFieldVO;
import com.citi.aqua.derivz.vo.UserDatasetVO;

//@RunWith(SpringRunner.class)		
public class UserSearchCriteriaServiceImplTest {
	
	@InjectMocks
	UserSearchCriteriaServiceImpl userSearchCriteriaServiceImpl;

	@Mock
	SelectionFiltersRepository selectionFiltersRepository;
	
	@Mock
	DBCommonUtils commonUtils;

	@Mock
	BaseRepository baseRepository;

	@Mock
	DimAgreementRepository dimAgreementRepository;

	@Mock
	SearchDAO searchDAO;

	@Autowired
	DistinctValuesRepository distinctValuesRepository;

	@Autowired
	CacheService cachingService;

	
    @Autowired
    VoyagerNavigationLink voyagerConfig;

    List<SearchFieldVO> selectionFilterVOList;
    List<DimAgreement> agreementList;
	@Before
	public void setup() {
		MockitoAnnotations.initMocks(this);
		selectionFilterVOList=new ArrayList<>(10);
		for(int i=0;i<10;i++) {
			ReferenceDataVO [] arraOfVO= {new ReferenceDataVO(new Long(i),"value"+i),new ReferenceDataVO(new Long(i),"value"+i)};
			selectionFilterVOList.add(new SearchFieldVO("fieldName"+i, "nodeName"+i, ComponentType.DROPDOWN, "dataType"+i, "logicalGroupName"+i, "name"+i, "ceft", "nodeDisplayName"+i, i, new Long(i),arraOfVO , i, i,i));
		}
		agreementList=new ArrayList<>();
		DimAgreement dimAgreement = new DimAgreement();
		dimAgreement.setAgreementKey(1);
		dimAgreement.setAgreementId(1);
		agreementList.add(dimAgreement);
	}

	@Test
	public void testGetCollateralLookupColumns() {
		// Testing the logic for the call of the repository
		List<SelectionFilters> collateralLookupList = new LinkedList<>();
		SelectionFilters selectionFilters1 = new SelectionFilters();
		SelectionFilters selectionFilters2 = new SelectionFilters();
		SelectionFilters selectionFilters3 = new SelectionFilters();
		collateralLookupList.add(selectionFilters1);
		collateralLookupList.add(selectionFilters2);
		collateralLookupList.add(selectionFilters3);

		when(selectionFiltersRepository.findByCollateralLookup(1)).thenReturn(collateralLookupList);
		assertEquals(3, collateralLookupList.size());
		assertNotNull("The collateral lookup column list is not null", collateralLookupList.size());

		// Testing the logic after the return of the list from the repository call
		assertNotNull("The collateral lookup column list is not null",
				userSearchCriteriaServiceImpl.getCollateralLookupColumns());
		assertEquals(3, userSearchCriteriaServiceImpl.getCollateralLookupColumns().size());

	}
	
	
	@Test
	public void testFindUserFilterSearch() throws IllegalArgumentException, IllegalAccessException {
		// Testing the logic for the call of the repository
		String [] stringAraay= {"1","2"};
		List<String[]> stringArrayList=new ArrayList<>();
	 				stringArrayList.add(stringAraay);
	 	ListDataResponseDTO resultList=new ListDataResponseDTO();
	 	resultList.setCobDate("8-Oct-2018");
	 	resultList.setCount(1L);
	 	resultList.setDimAgreementList(agreementList);
	 	when(commonUtils.createInValueForProc(Matchers.anyList())).thenReturn("CONVERTED");
		when(searchDAO.callMacDataRetrivalProc(Matchers.anyList(),Matchers.anyList())).thenReturn(resultList);
		assertEquals(new Long(1), userSearchCriteriaServiceImpl.findUserFilterSearch(selectionFilterVOList).getCount());
	}
	@SuppressWarnings("unchecked")
	@Test(expected=DerivzApplicationException.class)
	public void testFindUserFilterSearchExp() throws IllegalArgumentException, IllegalAccessException {
		// Testing the logic for the call of the repository
		List<DimAgreement> agreementList=new ArrayList<>();
			DimAgreement dimAgreement = new DimAgreement();
			dimAgreement.setAgreementKey(1);
			dimAgreement.setAgreementId(1);
			agreementList.add(dimAgreement);

		String [] stringAraay= {"1","2"};
		List<String[]> stringArrayList=new ArrayList<>();
	 				stringArrayList.add(stringAraay);
	 	ListDataResponseDTO resultList=new ListDataResponseDTO();
	 	resultList.setCobDate("8-Oct-2018");
	 	resultList.setCount(1L);
	 	resultList.setDimAgreementList(agreementList);
	 	when(commonUtils.createInValueForProc(Matchers.anyList())).thenReturn("CONVERTED");
		when(searchDAO.callMacDataRetrivalProc(Matchers.anyList(),Matchers.anyList())).thenThrow(DerivzApplicationException.class);
		assertEquals(new Long(1), userSearchCriteriaServiceImpl.findUserFilterSearch(selectionFilterVOList).getCount());
	}
	
	@Test
	public void testFindPredefinedResultSet() {
		 List<SelectionFilters> list=Arrays.asList(new SelectionFilters());
		when(selectionFiltersRepository.findByIsDisplayed(DerivzCommonConstants.INTERGER_ONE)).thenReturn(list);
		assertEquals(1, userSearchCriteriaServiceImpl.findPredefinedResultSet().size());
	}
	@Test(expected=DerivzApplicationException.class)
	public void testFindPredefinedResultSetExp() {
		when(selectionFiltersRepository.findByIsDisplayed(DerivzCommonConstants.INTERGER_ONE)).thenThrow(IllegalArgumentException.class);
		assertEquals(1, userSearchCriteriaServiceImpl.findPredefinedResultSet().size());
	}
	/*@Test
	public void testLoadBoxData() {
		List<BoxDataVO> list= Arrays.asList(new BoxDataVO());
		when(searchDAO.callBoxDataRetrivalProc(Matchers.anyList())).thenReturn(list);
		assertEquals(1, userSearchCriteriaServiceImpl.loadBoxData(null).size());
	}
	@Test
	public void testLoadPostingData() {
		List<PostingDataVO> list= Arrays.asList(new PostingDataVO());
		when(searchDAO.callPostingDataRetrivalProc(Matchers.anyList(),Matchers.anyBoolean(),Matchers.anyList())).thenReturn(list);
		assertEquals(1, userSearchCriteriaServiceImpl.loadPostingData(null, true, selectionFilterVOList).size());
	}
	@Test
	public void testLoadCapacityData() {
		List<CapacityDataVO> list= Arrays.asList(new CapacityDataVO());
		when(searchDAO.callCapacityDataRetrivalProc(Matchers.anyList())).thenReturn(list);
		assertEquals(1, userSearchCriteriaServiceImpl.loadCapacityData(null).size());
	}
	@Test
	public void testLoadForwardMTMData() {
		List<ForwardMtmDataVO> list= Arrays.asList(new ForwardMtmDataVO());
		when(searchDAO.callForwardMTMDataRetrivalProc(null,"")).thenReturn(list);
		assertEquals(1, userSearchCriteriaServiceImpl.loadForwardMTMData(null,"").size());
	}
	@Test
	public void testLoadMTMData() {
		List<MTMDataVO> list= Arrays.asList(new MTMDataVO());
		when(searchDAO.callMTMDataRetrivalProc(null,"")).thenReturn(list);
		assertEquals(1, userSearchCriteriaServiceImpl.loadMTMData(null,"").size());
	}*/
	@Test
	public void testFindCollateralFilterSearch() {
		List<CollateralResponseDTO> list= Arrays.asList(new CollateralResponseDTO());
		when(searchDAO.callCollateralLookupProc(Matchers.anyList())).thenReturn(list);
		assertEquals(1, userSearchCriteriaServiceImpl.findCollateralFilterSearch(selectionFilterVOList).size());
	}
	@Test(expected=DerivzApplicationException.class)
	public void testFindCollateralFilterSearchExp() {
		when(searchDAO.callCollateralLookupProc(Matchers.anyList())).thenThrow(IllegalArgumentException.class);
		assertEquals(1, userSearchCriteriaServiceImpl.findCollateralFilterSearch(null).size());
	}
	/*@Test
	public void testLoadGSSTData() {
		List<GSSTDataVO> list= Arrays.asList(new GSSTDataVO());
		when(searchDAO.callGSSTDataRetrivalProc(null,"")).thenReturn(list);
		assertEquals(1, userSearchCriteriaServiceImpl.loadGSSTData(null,"").size());
	}
	@Test
	public void testLoadFRTBData() {
		List<FRTBDataVO> list= Arrays.asList(new FRTBDataVO());
		when(searchDAO.callFRTBDataRetrivalProc(null)).thenReturn(list);
		assertEquals(1, userSearchCriteriaServiceImpl.loadFRTBData(null).size());
	}*/
	@Test
	public void testLoadUserDatasetIds() {
		List<UserDatasetVO> userDatasetVOList =Arrays.asList(new UserDatasetVO());
		when( searchDAO.callGetCurrentDatasetIdProc("TEST")).thenReturn(userDatasetVOList);
		User user= new User();
		user.setSoeid("TEST");
		assertEquals(0, userSearchCriteriaServiceImpl.loadUserDatasetIds(user).size());
	}

}
