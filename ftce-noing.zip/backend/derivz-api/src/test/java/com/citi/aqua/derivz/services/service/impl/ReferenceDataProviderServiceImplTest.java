
package com.citi.aqua.derivz.services.service.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit4.SpringRunner;

import com.citi.aqua.derivz.data.cache.eh.ReferenceCacheKeys;
import com.citi.aqua.derivz.data.repository.DistinctValuesRepository;
import com.citi.aqua.derivz.model.DistinctValues;
import com.citi.aqua.derivz.model.RatingRankings;
import com.citi.aqua.derivz.services.service.CacheService;
import com.citi.aqua.derivz.vo.ReferenceDataVO;

@RunWith(SpringRunner.class)
public class ReferenceDataProviderServiceImplTest {

	@InjectMocks
	ReferenceDataProviderServiceImpl referenceDataProviderServiceImpl;

	@Mock
	DistinctValuesRepository distinctValuesRepository;

	@Mock
	CacheService cachingService;

	@Before
	public void setup() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testFindDistinctReferenceData() {
		// Testing the logic for the call of the repository
		List<ReferenceDataVO> referenceResponseData = new LinkedList<>();
		List<DistinctValues> distinctValueList = new LinkedList<>();

		DistinctValues distinctValues1 = new DistinctValues();
		DistinctValues distinctValues2 = new DistinctValues();
		distinctValueList.add(distinctValues1);
		distinctValueList.add(distinctValues2);

		ReferenceDataVO referenceDataVO1 = new ReferenceDataVO();
		ReferenceDataVO referenceDataVO2 = new ReferenceDataVO();

		referenceResponseData.add(referenceDataVO1);
		referenceResponseData.add(referenceDataVO2);

		when(distinctValuesRepository.findDistinctValueByKey(1l)).thenReturn(distinctValueList);

		// Testing the logic after the return of the list from the repository call
		assertNotNull("The collateral lookup column list is not null",
				distinctValuesRepository.findDistinctValueByKey(1l));
		assertEquals(2, distinctValuesRepository.findDistinctValueByKey(1l).size());

		// assertEquals(referenceResponseData,
		// referenceDataProviderServiceImpl.findDistinctReferenceData(1l));
		assertEquals(2, referenceDataProviderServiceImpl.findDistinctReferenceData(1l).size());

	}

	@Test
	public void testFindTypeAheadReferenceList() {
		// Testing the logic for the call of the repository

		List<ReferenceDataVO> referenceResponseData = new LinkedList<>();
		List<DistinctValues> distinctValueList = new LinkedList<>();

		DistinctValues distinctValues1 = new DistinctValues();
		DistinctValues distinctValues2 = new DistinctValues();
		distinctValueList.add(distinctValues1);
		distinctValueList.add(distinctValues2);

		ReferenceDataVO referenceDataVO1 = new ReferenceDataVO();
		ReferenceDataVO referenceDataVO2 = new ReferenceDataVO();

		referenceResponseData.add(referenceDataVO1);
		referenceResponseData.add(referenceDataVO2);

		when(distinctValuesRepository.findTypeAheadValue(3l, "FOR L")).thenReturn(distinctValueList);

		// Testing the logic after the return of the list from the repository call
		assertNotNull("The collateral lookup column list is not null",
				distinctValuesRepository.findTypeAheadValue(3l, "FOR L"));
		// assertEquals(2, distinctValuesRepository.findTypeAheadValue(3l,"FOR
		// L").size());

		// assertEquals(referenceResponseData,
		// referenceDataProviderServiceImpl.findTypeAheadReferenceList(3l,"FOR L"));
		// assertEquals(2,
		// referenceDataProviderServiceImpl.findTypeAheadReferenceList(3l,"FOR
		// L").size());
	}

	@Test
	public void testFindTypeAheadReferenceListByPastedValues() {
		List<ReferenceDataVO> distinctValueList = new LinkedList<>();
		when(cachingService.getReferenceDataByKey(3l, ReferenceCacheKeys.ALL_REFRENCE)).thenReturn(distinctValueList);

		assertNotNull("The collateral lookup column list is not null", referenceDataProviderServiceImpl
				.findTypeAheadReferenceListByPastedValues(3l, new String[] { "FOR L" }));
	}

	@Test
	public void testGetRatingRankings() {
		Set<RatingRankings> ratings= new HashSet<>();
		ratings.add(new RatingRankings());
		when(cachingService.getRatingRankings(ReferenceCacheKeys.RATING_RANKINGS)).thenReturn(ratings);
		assertEquals(1, referenceDataProviderServiceImpl.getRatingRankings().size());
	}
}
