package com.citi.aqua.derivz.services.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.citi.aqua.derivz.commons.constants.DerivzBeanConstants;
import com.citi.aqua.derivz.data.repository.BaseRepository;
import com.citi.aqua.derivz.data.repository.DatasetRepository;
import com.citi.aqua.derivz.model.BaseEntity;
import com.citi.aqua.derivz.model.Dataset;
import com.citi.aqua.derivz.services.service.DatasetService;

@Service(DerivzBeanConstants.DATA_SET_SERVICE_BEAN)
public class DatasetServiceImpl implements DatasetService {

	@Autowired
	DatasetRepository datasetRepository;

	@Autowired
	BaseRepository baseRepository;

	@Override
	public List<? extends BaseEntity> findAll() {
		return (List<Dataset>) datasetRepository.findAll();
	}

	@Override
	public Dataset findByName(String name) {
		return datasetRepository.findByName(name);
	}

	@Override
	public List<? extends BaseEntity> getDataset(String entity, String filterQuery, int maxResults) {
		return baseRepository.getDataset(entity, filterQuery, maxResults);
	}

}
