package com.citi.aqua.derivz.services.service;

import java.util.Comparator;
import java.util.List;
import org.springframework.stereotype.Service;
import com.citi.aqua.derivz.model.SelectionFilters;

@Service
public interface CombinedColumns {

  public List<SelectionFilters> findAll(boolean isLogicalGroupBy);
  public List<SelectionFilters> findByFilterKeyIn(final List<Long> keys);
  public List<SelectionFilters> findByComponentTypeIn(final List<String> componentTypes);
  
  public static Comparator<SelectionFilters> orderByDisplayName() {
    return new Comparator<SelectionFilters>() {

        @Override
        public int compare(SelectionFilters o1, SelectionFilters o2) {
          return o1.getDisplayName().compareTo(o2.getDisplayName());
        }
       
     };
  }
  
  public static Comparator<SelectionFilters> orderByLogicalGroupName() {
    return new Comparator<SelectionFilters>() {

        @Override
        public int compare(SelectionFilters o1, SelectionFilters o2) {
          return o1.getLogicalGroup().compareTo(o2.getLogicalGroup());
        }
       
     };
  }
}
