package com.citi.aqua.derivz.services.service;

import java.util.List;

import com.citi.aqua.derivz.vo.GroupVO;
import com.citi.aqua.derivz.vo.TableNodeVO;

public interface FilterSelectionViewService {

	public List<GroupVO> findTreeViewFilterList();

	public List<TableNodeVO> findFlatViewFilterList();

}
