package com.citi.aqua.derivz.services.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.citi.aqua.derivz.data.jdbc.AgreementDAO;
import com.citi.aqua.derivz.dto.AgreementResponseDTO;
import com.citi.aqua.derivz.dto.CSAResponseDTO;
import com.citi.aqua.derivz.services.service.AgreementService;

@Service
public class AgreementServiceImpl implements AgreementService {

	@Autowired
	AgreementDAO agreementDAO;

	@Override
	public AgreementResponseDTO getAgreementDetails(final Long agreementKey) {
		return agreementDAO.callAgreementDetailsProc(agreementKey);
	}

	@Override
	public CSAResponseDTO getCsaTypeDetails(final Long agreementId, final String csaType) {
		return agreementDAO.callCsaTypeDetailsProc(agreementId, csaType);
	}

}
