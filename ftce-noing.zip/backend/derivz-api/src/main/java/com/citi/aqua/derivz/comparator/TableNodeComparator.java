package com.citi.aqua.derivz.comparator;

import java.util.Comparator;

import com.citi.aqua.derivz.vo.TableNodeVO;

public class TableNodeComparator implements Comparator<TableNodeVO> {

	@Override
	public int compare(TableNodeVO o1, TableNodeVO o2) {
		return o1.getName().compareTo(o2.getName());
	}

}
