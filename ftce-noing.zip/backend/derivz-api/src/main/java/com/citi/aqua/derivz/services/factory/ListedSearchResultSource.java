package com.citi.aqua.derivz.services.factory;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import com.citi.aqua.derivz.services.service.CacheService;
import com.citi.aqua.derivz.vo.ReferenceDataVO;
import com.citi.aqua.derivz.vo.SearchCriteriaResultVO;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.DataFormat;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.citi.aqua.derivz.services.service.UserSearchCriteriaService;
import com.citi.aqua.derivz.vo.SearchFieldVO;

@Component
public class ListedSearchResultSource extends SearchResultSource {

	@Autowired
	UserSearchCriteriaService userSearchCriteriaService;

	@Autowired
	CacheService cacheService;

	@Override
	public List<String> getHeaders() {
		return Arrays.asList("Agreement Id", "Clearing Agreement", "CSA Description", "CSA Margin Type", "CSA Status",
				"Custodian Required", "Customer Name", "Exchange Cleared Agreement", "Governing Law",
				"Incorporated Country", "Mandatory Mark Frequency", "Master Agreement", "Master Agreement Status",
				"Six C Applies", "Six C Applied", "Trigger Event-Security Agreement", "S_M_E");
	}

	@Override
	public int addDataRow(HSSFWorkbook workbook, String sheetName, List<SearchFieldVO> searchCriteria, List<Long> agreementKeyList, int rowNum) {
		Sheet sheet = workbook.getSheet(sheetName);
		DataFormat dataFormat=workbook.createDataFormat();
		int tmpRowNum = rowNum;

		CellStyle cellStyle = workbook.createCellStyle();
		HSSFFont font = workbook.createFont();
		font.setFontName("Calibri");
		font.setFontHeight((short) 220);
		cellStyle.setFont(font);
		sheet.createFreezePane(0, 1);

		Map<Long, List<ReferenceDataVO>> referenceDataElementsList = cacheService.getReferenceData();


		List<SearchCriteriaResultVO> listedData=userSearchCriteriaService
												.findUserFilterSearch(searchCriteria).getSearchCriteriaResultList();


		for(SearchCriteriaResultVO data :listedData){

			int index=-1;
			Row row=sheet.createRow(tmpRowNum++);
			addXLSXCell(row, ++index, Integer.toString(data.getAgreementId()), cellStyle);

			addXLSXCell(row, ++index,data.getClearingAgreement(), cellStyle);
			addXLSXCell(row, ++index,data.getCsaDescription(), cellStyle);
			addXLSXCell(row, ++index,data.getCsaMarginType(), cellStyle);
			addXLSXCell(row, ++index,data.getCsaStatus(), cellStyle);
			addXLSXCell(row, ++index,data.getCustodianRequired(), cellStyle);
			addXLSXCell(row, ++index,data.getCustomerName(), cellStyle);
			addXLSXCell(row, ++index,data.getExchangeclearedAgreement(), cellStyle);
			addXLSXCell(row, ++index,data.getGoverningLaw(), cellStyle);
			addXLSXCell(row, ++index,data.getIncorporatedCountry(), cellStyle);

			addXLSXCell(row, ++index,data.getMandatoryMarkFrequency(), cellStyle);
			addXLSXCell(row, ++index,data.getMasterAgreement(), cellStyle);
			addXLSXCell(row, ++index,data.getMasterAgreementStatus(), cellStyle);
			addXLSXCell(row, ++index,data.getSixCApplies(), cellStyle);
			addXLSXCell(row, ++index,data.getSixcApplied(), cellStyle);

			addXLSXCell(row, ++index,data.getTriggerEvent(), cellStyle);
			addXLSXCell(row, ++index,data.getSME(), cellStyle);





		}


		return tmpRowNum;
	}
}
