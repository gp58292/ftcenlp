package com.citi.aqua.derivz.services.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.citi.aqua.derivz.data.repository.TableMetadataRepository;
import com.citi.aqua.derivz.model.BaseEntity;
import com.citi.aqua.derivz.model.TableMetaData;
import com.citi.aqua.derivz.services.service.MetaDataService;

/**
 * @name MetaDataService
 * @Description Service implementation to get information for the Tables
 *              metadata
 */
@Service("MetaDataService")
public class MetaDataServiceImpl implements MetaDataService {

	@Autowired
	TableMetadataRepository tableMetadataRepository;

	@Override
	public List<? extends BaseEntity> findAll() {

		return (List<TableMetaData>) tableMetadataRepository.findAll();
	}

	@Override
	public List<TableMetaData> findMetadataByTableName(final String tableName) {
		return (List<TableMetaData>) tableMetadataRepository.findByTableName(tableName);
	}

}
