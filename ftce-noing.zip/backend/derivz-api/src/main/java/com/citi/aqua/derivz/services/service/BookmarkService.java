package com.citi.aqua.derivz.services.service;

import java.util.List;

import com.citi.aqua.derivz.model.Bookmark;
import com.citi.aqua.derivz.model.User;
import com.citi.aqua.derivz.model.VoyagerLinkResponse;
import com.citi.aqua.derivz.vo.BookmarkVO;
import com.citi.aqua.derivz.vo.SearchFieldVO;

public interface BookmarkService {

	// Method to update the bookmark
	public Bookmark updateUserBookmark(final Long bookmarkId, final List<BookmarkVO> bookmarkData, String userId,List<SearchFieldVO> searchCriteria,String newBookmarkName);

	// Method to save a new bookmark
	public Bookmark saveUserBookmark(final String userId, final String bookmarkName,
			final List<BookmarkVO> bookmarkData,List<SearchFieldVO> searchCriteria,final Long parentId);

	// Find a book mark with its ID
	public List<SearchFieldVO> getBookmarkForGivenId(final String userId,final Long bookmarkId);

	// Delete existing book mark
	public boolean deleteBookmark(final String userId,final Long bookmarkId);

	// Method to save User's settings column
	public boolean saveUserSettingColumns(final String userId, final String fieldKeysCSV, final String settingsName);

	// Method to update User's settings columns
	public Boolean updateSettingsColumnList(final Long userSettingsListKey, final String fieldKeysCSV);

	// Method to find User's settings columns
	public Bookmark findUserSettingsColumns(final String userId);

	// Method to get the User's settings columns
	public List<Bookmark> getSearchCriteriaList(final String userId, final String listType);

	// Method to save User's Search
	public boolean saveUserSearch(final String userId, final String listType, final List<SearchFieldVO> criteriaList,
			final String searchName);

	// Method to share User's Bookmark
	public boolean shareUserBookmark(final String userId, final String searchName, final Long sharedBookmarkId);

	public VoyagerLinkResponse getDatasetId(final User user, final String datasetTypeName);
	
	
	public Bookmark updateOriginalAndDeleteTmporaryBookmark(final Long bookmarkId, final List<BookmarkVO> bookmarkData, String userId,List<SearchFieldVO> searchCriteria);

	public Boolean deleteAllTempBookmarkByUserId(String userId);

	public List<Bookmark> restoreTempBookmarkByUserId(String userId);
}
