package com.citi.aqua.derivz.services.service;

import java.util.List;

import com.citi.aqua.derivz.model.BaseEntity;


public interface BaseService {
	
	public List<? extends BaseEntity> findAll();
	
	
	
}
