package com.citi.aqua.derivz.services.factory;

import java.io.IOException;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.*;
import org.springframework.stereotype.Component;

import com.citi.aqua.derivz.vo.SearchFieldVO;


@Component
public abstract class SearchResultSource {
	
	public abstract List<String> getHeaders();
	
	public int addHeaderRow(HSSFWorkbook workbook, String sheetName, List<String> headerColumns,  int rowNum) {
		int tmpRowNum = rowNum;
		int columnCount = 0;
		Sheet sheet = workbook.getSheet(sheetName);

		CellStyle headercellStyle = workbook.createCellStyle();
		HSSFFont headerfont = workbook.createFont();
		headerfont.setFontName("Calibri");
		headerfont.setFontHeight((short) 220);
		// headerfont.setBoldweight(Font.BOLDWEIGHT_BOLD);
		headercellStyle.setFont(headerfont);
		sheet.setDefaultColumnWidth(15);

		Row row = sheet.createRow(tmpRowNum++);
		for (String heading : headerColumns) {
			Cell cell1 = row.createCell(columnCount++);
			// cell1.setCellType(Cell.CELL_TYPE_STRING);
			cell1.setCellValue(heading);
			cell1.setCellStyle(headercellStyle);
		}
		return tmpRowNum;
	}
	
	@SuppressWarnings("rawtypes")
	public abstract int addDataRow(HSSFWorkbook workbook, String source, List<SearchFieldVO> searchCriteria, List<Long> agreementKeyList, int rowNum);
	
	public void generateExcel(HttpServletResponse response, HSSFWorkbook workbook, String filePrefix) throws IOException {
		response.setCharacterEncoding("UTF-8");
		response.setContentType("application/vnd.ms-excel");
		String headerKey = "Content-Disposition";
		String headerValue = String.format("attachment; filename=\"%s\"", this.createFileName(filePrefix));
		response.setHeader(headerKey, headerValue);
		response.setHeader("Cache-Control", "must-revalidate");

		OutputStream os = response.getOutputStream();
		workbook.write(os);
		os.flush();
		os.close();
	}
	
	private String createFileName(String filePrefix) {
		return filePrefix + "_" + new SimpleDateFormat("yyyy-MM-dd hh-mm-ss").format(new Date()) + ".xls";
	}
	
	public void addXLSXCell(Row row, int index, String value, CellStyle cellStyle) {
		Cell cell = row.createCell(index);
		cell.setCellStyle(cellStyle);
		// cell.setCellType(Cell.CELL_TYPE_STRING);
		cell.setCellValue(value == "null" ? StringUtils.EMPTY : value);
	}
	
	public void addXLSXCellDate(Row row, int index, Date value, CellStyle cellStyle) {
		Cell cell = row.createCell(index);
		cell.setCellStyle(cellStyle);
		// cell.setCellType(Cell.CELL_TYPE_STRING);
	}

	public void addXLSXCellNumeric(Row row, int index, Long value, CellStyle cellStyle,DataFormat dataFormat) {

		Cell cell = row.createCell(index);
		// cellStyle.setAlignment(ALIGN_RIGHT);
		cellStyle.setDataFormat(dataFormat.getFormat("#,##0_);[Red](#,##0)"));

		cell.setCellStyle(cellStyle);
		// cell.setCellType(Cell.CELL_TYPE_NUMERIC);
		cell.setCellValue(value);

	}
	
	
	public void addXLSXCellDouble(Row row, int index, Double value, CellStyle cellStyle,DataFormat dataFormat) {

		Cell cell = row.createCell(index);
		// cellStyle.setAlignment(ALIGN_RIGHT);
		cellStyle.setDataFormat(dataFormat.getFormat("#,##0_);[Red](#,##0)"));

		cell.setCellStyle(cellStyle);
		// cell.setCellType(Cell.CELL_TYPE_NUMERIC);
		cell.setCellValue(value);

	}
	
	

}
