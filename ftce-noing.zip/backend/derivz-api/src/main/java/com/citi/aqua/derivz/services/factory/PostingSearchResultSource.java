package com.citi.aqua.derivz.services.factory;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.DataFormat;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.citi.aqua.derivz.services.service.UserSearchCriteriaService;
import com.citi.aqua.derivz.vo.PostingDataVO;
import com.citi.aqua.derivz.vo.SearchFieldVO;

@Component
public class PostingSearchResultSource extends SearchResultSource {

	@Autowired
	UserSearchCriteriaService userSearchCriteriaService;

	@Override
	public List<String> getHeaders() {
		return Arrays.asList("Agreement Id", "CSA Description", "MTM USD", "Party Legal Entity", "Posted/Received",
				"Seg/Non-Seg", "IM/VM ", "Collateral Type", "Collateral Currency", "Coll Amt USD Post HC",
				"Coll Source System", "Coll Amt USD Pre HC ", "Coll Amt CCY Post HC", "Coll Amt CCY Pre HC",
				"Liquidity Type", "Type Of Collateral", "S_M_E", "ISIN", "CUSIP", "Right of Reuse");
	}

	@Override
	public int addDataRow(HSSFWorkbook workbook, String sheetName, List<SearchFieldVO> searchCriteria, List<Long> agreementKeyList, int rowNum) {
		Sheet sheet = workbook.getSheet(sheetName);
		DataFormat dataFormat=workbook.createDataFormat();

		int tmpRowNum = rowNum;

		CellStyle cellStyle = workbook.createCellStyle();
		HSSFFont font = workbook.createFont();
		font.setFontName("Calibri");
		font.setFontHeight((short) 220);
		cellStyle.setFont(font);
		sheet.createFreezePane(0, 1);

		List<PostingDataVO> postingDataVOList =  new ArrayList(); 
				// userSearchCriteriaService.loadPostingData(agreementKeyList,false,null);
		for (PostingDataVO data : postingDataVOList) {
			int index = -1;
			Row row = sheet.createRow(tmpRowNum++);
			addXLSXCell(row, ++index, Long.toString(data.getAgreementId()), cellStyle);
			addXLSXCell(row, ++index, data.getCsaDescription(), cellStyle);
			addXLSXCellNumeric(row, ++index, data.getMtmUsd(), cellStyle,dataFormat);
			addXLSXCell(row, ++index, data.getPartyLegalEntity(), cellStyle);
			addXLSXCell(row, ++index, data.getPostedRecieved(), cellStyle);
			addXLSXCell(row, ++index, data.getSegNonSeg(), cellStyle);
			addXLSXCell(row, ++index, data.getImVm(), cellStyle);
			addXLSXCell(row, ++index, data.getCollateralType(), cellStyle);
			addXLSXCell(row, ++index, data.getCollateralCurrency(), cellStyle);
			addXLSXCellDouble(row, ++index, data.getCollateralAmtUsdPostHc(), cellStyle,dataFormat);
			addXLSXCell(row, ++index, data.getCollateralSourceSystem(), cellStyle);
			addXLSXCellDouble(row, ++index,data.getCollateralAmtUsdPreHc(), cellStyle,dataFormat);
			addXLSXCellDouble(row, ++index, data.getCollateralAmtCcyPostHc(), cellStyle,dataFormat);
			addXLSXCellDouble(row, ++index, data.getCollateralAmtCcyPreHc(), cellStyle,dataFormat);
			addXLSXCell(row, ++index, data.getLiquidityType(), cellStyle);
			addXLSXCell(row, ++index, data.getTypeOfCollateral(), cellStyle);
			addXLSXCell(row, ++index, data.getSme(), cellStyle);
			addXLSXCell(row, ++index, data.getCusip(), cellStyle);
			addXLSXCell(row, ++index, data.getIsin(), cellStyle);
			addXLSXCell(row, ++index, data.getRightOfReuse(), cellStyle);
		}
		return tmpRowNum;
	}
}
