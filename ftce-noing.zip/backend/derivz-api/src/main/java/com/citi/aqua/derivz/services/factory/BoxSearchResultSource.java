package com.citi.aqua.derivz.services.factory;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.DataFormat;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.citi.aqua.derivz.services.service.UserSearchCriteriaService;
import com.citi.aqua.derivz.vo.BoxDataVO;
import com.citi.aqua.derivz.vo.SearchFieldVO;

@Component
public class BoxSearchResultSource extends SearchResultSource {

	@Autowired
	UserSearchCriteriaService userSearchCriteriaService;

	@Override
	public List<String> getHeaders() {
		return Arrays.asList("boxData Date", "CUSIP", "CUSIP Desc", "Firm Code", "Firm Code Short Name", "ISIN",
				"Maturity Date", "Issuer Name", "Custodian", "Issue Currency", "Treasury Class", "T-Level 2",
				"LCR Asset Level", "Quantity", "MV+AI(USD)", "Moody's", "S&P", "Market Sector Description", "Country");
	}

	@Override
	public int addDataRow(HSSFWorkbook workbook, String sheetName, List<SearchFieldVO> searchCriteria, List<Long> agreementKeyList, int rowNum) {
		Sheet sheet = workbook.getSheet(sheetName);
		int tmpRowNum = rowNum;
		DataFormat dataFormat=workbook.createDataFormat();

		CellStyle cellStyle = workbook.createCellStyle();
		HSSFFont font = workbook.createFont();
		font.setFontName("Calibri");
		font.setFontHeight((short) 220);
		cellStyle.setFont(font);
		sheet.createFreezePane(0, 1);

		List<BoxDataVO> boxboxDataVOList = new ArrayList();
				//userSearchCriteriaService.loadBoxData(agreementKeyList);

		for (BoxDataVO boxData : boxboxDataVOList) {
			int index = -1;
			Row row = sheet.createRow(tmpRowNum++);
			addXLSXCell(row, ++index, boxData.getCusip(), cellStyle);
			addXLSXCellNumeric(row, ++index, boxData.getQuantity(), cellStyle,dataFormat);
			addXLSXCellDate(row, ++index, boxData.getDataDate(), cellStyle);
			addXLSXCell(row, ++index, boxData.getFirmCode(), cellStyle);
			addXLSXCell(row, ++index, boxData.getFirmCodeShortName(), cellStyle);
			addXLSXCell(row, ++index, boxData.getCusipDescription(), cellStyle);
			addXLSXCell(row, ++index, boxData.getTreasuryClass(), cellStyle);
			addXLSXCell(row, ++index, boxData.getIsin(), cellStyle);
			addXLSXCellDate(row, ++index, boxData.getMatuarityDate(), cellStyle);
			addXLSXCell(row, ++index, boxData.getIssuerName(), cellStyle);
			addXLSXCell(row, ++index, boxData.getCustodian(), cellStyle);
			addXLSXCell(row, ++index, boxData.getIssueCurrency(), cellStyle);
			addXLSXCell(row, ++index, boxData.gettLevel2(), cellStyle);
			addXLSXCell(row, ++index, boxData.getLcrAssetLevel(), cellStyle);
			addXLSXCellNumeric(row, ++index, boxData.getQuantity(), cellStyle,dataFormat);
			addXLSXCellNumeric(row, ++index, boxData.getMvAi(), cellStyle,dataFormat);
			addXLSXCell(row, ++index, boxData.getMoody(), cellStyle);
			addXLSXCell(row, ++index, boxData.getsAndP(), cellStyle);
			addXLSXCell(row, ++index, boxData.getMarketSectorDescription(), cellStyle);
			addXLSXCell(row, ++index, boxData.getCountry(), cellStyle);
		}
		return tmpRowNum;
	}
}
