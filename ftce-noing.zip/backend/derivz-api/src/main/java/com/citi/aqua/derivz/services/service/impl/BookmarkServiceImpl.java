package com.citi.aqua.derivz.services.service.impl;

import java.io.IOException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;
import org.apache.commons.dbutils.DbUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import com.citi.aqua.derivz.commons.constants.DerivzBeanConstants;
import com.citi.aqua.derivz.commons.constants.DerivzCommonConstants;
import com.citi.aqua.derivz.commons.exceptions.CEFTException;
import com.citi.aqua.derivz.commons.exceptions.DerivzApplicationException;
import com.citi.aqua.derivz.commons.exceptions.DerivzDAOLayerException;
import com.citi.aqua.derivz.data.repository.BookmarkRepository;
import com.citi.aqua.derivz.data.repository.SelectionFiltersRepository;
import com.citi.aqua.derivz.enums.ComponentType;
import com.citi.aqua.derivz.model.Bookmark;
import com.citi.aqua.derivz.model.DBConstants;
import com.citi.aqua.derivz.model.DerivzDBConstants;
import com.citi.aqua.derivz.model.SelectionFilters;
import com.citi.aqua.derivz.model.User;
import com.citi.aqua.derivz.model.VoyagerLinkResponse;
import com.citi.aqua.derivz.model.VoyagerNavigationLink;
import com.citi.aqua.derivz.services.service.BookmarkService;
import com.citi.aqua.derivz.services.service.CacheService;
import com.citi.aqua.derivz.services.service.CombinedColumns;
import com.citi.aqua.derivz.services.service.UserSearchCriteriaService;
import com.citi.aqua.derivz.vo.BookmarkVO;
import com.citi.aqua.derivz.vo.RatingFieldVO;
import com.citi.aqua.derivz.vo.SearchFieldVO;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.microsoft.sqlserver.jdbc.SQLServerCallableStatement;
import com.microsoft.sqlserver.jdbc.SQLServerDataTable;
import com.microsoft.sqlserver.jdbc.SQLServerException;

@Service(DerivzBeanConstants.BOOKMARK_SERVICE_BEAN)
public class BookmarkServiceImpl implements BookmarkService {

    private static final Logger LOGGER = LoggerFactory.getLogger(BookmarkServiceImpl.class);
    public static final String QUERY_DELIMETER = "|~";
    public static final String UNDERSCORE_DELIMETER = "_";
    
    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Autowired
    BookmarkRepository bookmarkRepository;

    @Autowired
    SelectionFiltersRepository selectionFiltersRepository;
    
    @Autowired
    CombinedColumns combinedColumns;

    @Autowired
    CacheService cachingService;

    @Autowired
    VoyagerNavigationLink voyagerConfig;
    
    @Autowired
    private UserSearchCriteriaService userSearchCriteriaService;
    
    @SuppressWarnings("rawtypes")
	public Bookmark updateUserBookmark(final Long bookmarkId, final List<BookmarkVO> bookmarkData, String userId, final List<SearchFieldVO> searchCriteria,String newBookmarkName) {
        Bookmark bookmark=null;
        try {
        	int x;
        	if(newBookmarkName==null) {
              x = bookmarkRepository.updateUserSettingsList(bookmarkId, convertObjectToJson(bookmarkData), new Date());
        	} else {
    			x = bookmarkRepository.updateUserSettingsListWithName(bookmarkId, convertObjectToJson(bookmarkData), new Date(),newBookmarkName);
    		}
            if (1 == x) {
            	bookmark=bookmarkRepository.findByUserIdAndKey(userId,bookmarkId);
            }
            this.persistCEFTBookmarkToVoyager(bookmarkId, userId, userSearchCriteriaService.formatCriteriaObjectForRows(searchCriteria),userSearchCriteriaService.formatRatingInRows(searchCriteria),
            		userSearchCriteriaService.formatTenorCriteriaForRows(searchCriteria));
        } catch (Exception e) {
            throw new DerivzApplicationException(e, DerivzDAOLayerException.FAILED_UPDATE_BOOKMARK);
        }
        return bookmark;

    }
    
	@SuppressWarnings("rawtypes")
	public Bookmark updateOriginalAndDeleteTmporaryBookmark(final Long bookmarkId, final List<BookmarkVO> bookmarkData, String userId, final List<SearchFieldVO> searchCriteria) {
        Bookmark bookmark=null;
        try {
        	final Bookmark existingTempBookmark =bookmarkRepository.findByUserIdAndKey(userId,bookmarkId);
        	bookmark=this.updateOrgAndDeleteTmpBookmark(bookmarkId, bookmarkData,userId, existingTempBookmark);
            this.persistCEFTBookmarkToVoyager(existingTempBookmark.getParentId(), userId, userSearchCriteriaService.formatCriteriaObjectForRows(searchCriteria),userSearchCriteriaService.formatRatingInRows(searchCriteria),
            		userSearchCriteriaService.formatTenorCriteriaForRows(searchCriteria));
        } catch (Exception e) {
            throw new DerivzApplicationException(e, DerivzDAOLayerException.FAILED_UPDATE_BOOKMARK);
        }
        return bookmark;

    }
	
	@Transactional(propagation=Propagation.REQUIRES_NEW,rollbackFor=Exception.class)
	public Bookmark updateOrgAndDeleteTmpBookmark(final Long bookmarkId, final List<BookmarkVO> bookmarkData,String userId,Bookmark existingTempBookmark) throws CEFTException {
		Bookmark bookmark=null;
		
        int x = bookmarkRepository.updateUserSettingsList(existingTempBookmark.getParentId(), convertObjectToJson(bookmarkData), new Date());
        bookmarkRepository.delete(existingTempBookmark);
        if (1 == x) {
        	bookmark=bookmarkRepository.findByUserIdAndKey(userId,existingTempBookmark.getParentId());
        }
        
       return bookmark;
	}


    @SuppressWarnings("rawtypes")
	public Bookmark saveUserBookmark(final String userId, final String bookmarkName, final List<BookmarkVO> bookmarkData, final List<SearchFieldVO> searchCriteria,final Long parentId) {
        Bookmark updatedBookmark=null;
        try {
        	
        	updatedBookmark= bookmarkRepository.findTempBookmarkByParentId(userId, parentId);
        		if( updatedBookmark!= null) {
        			
        			bookmarkRepository.updateTempBookmark(convertObjectToJson(bookmarkData),userId, parentId);
        		}
        	 else {
        	
            final Bookmark userSearchList = new Bookmark();
            userSearchList.setName(bookmarkName);
            userSearchList.setType(DerivzCommonConstants.SEARCH_TYPE_LIST);
            userSearchList.setUserId(userId);

            userSearchList.setLastSelected(DerivzCommonConstants.PREVIOUS_SELECTED_FLAG);
            userSearchList.setUpdatedTime(new Date());
            userSearchList.setCriteria(convertObjectToJson(bookmarkData));
            userSearchList.setParentId(parentId);
            // Repository call to persist the data into database for user settings list
            updatedBookmark = bookmarkRepository.save(userSearchList);
        	 }
            // Get bookmarkId and execute stored proc which will persist the changes so Voyager can get the CEFT data set
            if(updatedBookmark!=null) {
	            Long bookmarkId = updatedBookmark.getKey();
	            this.persistCEFTBookmarkToVoyager(bookmarkId, userId, userSearchCriteriaService.formatCriteriaObjectForRows(searchCriteria),userSearchCriteriaService.formatRatingInRows(searchCriteria),
	            		userSearchCriteriaService.formatTenorCriteriaForRows(searchCriteria));
            }
        	
        	} catch (Exception e) {
            throw new DerivzApplicationException(e, DerivzDAOLayerException.FAILED_SETTINGS_SAVE_LIST);
        }
        return updatedBookmark;
    }

    private String convertObjectToJson(final List<BookmarkVO> bookmarkData) throws CEFTException {
        LOGGER.debug("BookmarkServiceImpl::convertObjectToJson(): ");
        String jsonResult = null;
        String result = null;
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            jsonResult = objectMapper.writeValueAsString(bookmarkData);
            result = jsonResult;
        } catch (IOException e) {
            throw new CEFTException(e);
        }
        return result;
    }

    private List<BookmarkVO> convertJsonToObject(final String json) throws CEFTException {
        List<BookmarkVO> bookmarkData = new LinkedList<>();
        try {
            final ObjectMapper objectMapper = new ObjectMapper();
            final TypeReference<List<BookmarkVO>> mapType = new TypeReference<List<BookmarkVO>>() {
            };
            String jsonString = json;
            bookmarkData = objectMapper.readValue(jsonString, mapType);
        } catch (IOException e) {
            throw new CEFTException(e);
        }
        return bookmarkData;
    }

    @SuppressWarnings("rawtypes")
    public List<SearchFieldVO> getBookmarkForGivenId(final String userId,final Long bookmarkId) {
        List<SearchFieldVO> bookmarkDataForSearch = new LinkedList<>();
        try {
            // Repository call to determine the book mark data for the given id
            final Bookmark bookmark = bookmarkRepository.findByUserIdAndKey(userId, bookmarkId);
            if (bookmark!=null && null != bookmark.getCriteria()) {
                final List<BookmarkVO> searchBookmarkData = convertJsonToObject(bookmark.getCriteria());

                bookmarkDataForSearch = createBookmarkData(searchBookmarkData);
            }
        } catch (Exception e) {
            throw new DerivzApplicationException(e, DerivzDAOLayerException.FAILED_SETTINGS_SAVE_LIST);
        }
        return bookmarkDataForSearch;
    }


    @SuppressWarnings("unused")
    private List<BookmarkVO> findIntersectedBookmark(final List<BookmarkVO> searchBookmark, final List<BookmarkVO> settingsBookmark) {
        final Set<BookmarkVO> pageViewBookmark = searchBookmark.stream().filter(Objects::nonNull)
                .map(bookmarkVO -> bookmarkVO).collect(Collectors.toSet());
        final Set<BookmarkVO> pageViewBookmark1 = settingsBookmark.stream().filter(Objects::nonNull)
                .map(bookmarkVO -> bookmarkVO).collect(Collectors.toSet());
        pageViewBookmark.addAll(pageViewBookmark1);
        return pageViewBookmark.stream().collect(Collectors.toList());
    }

    @SuppressWarnings("unused")
    private List<SelectionFilters> findComponentsForKeyList(final List<Long> staticComponentsKeyList) {
        return selectionFiltersRepository.findByFilterKeyIn(staticComponentsKeyList);
    }

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private List<SearchFieldVO> createBookmarkData(final List<BookmarkVO> bookmarkList) throws CEFTException {
		List<SearchFieldVO> bookmarkData = new LinkedList<>();
		try {
			final List<Long> compositeKeyList = bookmarkList.stream().map(BookmarkVO::getKey).collect(Collectors.toList());
			final List<SelectionFilters> filterComponenetList = combinedColumns.findByFilterKeyIn(compositeKeyList);

			bookmarkList.forEach(bookmarkVO -> {
				filterComponenetList.stream()
						.filter(selectionFilters -> selectionFilters.getFilterKey().equals(bookmarkVO.getKey()))
						.forEach(selectionFilters -> {
							final SearchFieldVO attributeVO = new SearchFieldVO();
							attributeVO.setComponentType(ComponentType.valueOfByName(selectionFilters.getComponentType()));
							attributeVO.setDataType(selectionFilters.getAttributeDatatype());
							attributeVO.setName(selectionFilters.getDisplayName());
							attributeVO.setFieldName(selectionFilters.getFieldName());
							attributeVO.setKey(selectionFilters.getFilterKey());
							attributeVO.setLogicalGroupName(selectionFilters.getLogicalGroup());
							attributeVO.setNodeDisplayName(selectionFilters.getNodeDisplayName());
							attributeVO.setNodeName(selectionFilters.getNodeName());
							attributeVO.setSchemaName(selectionFilters.getSchemaName());
							attributeVO.setWhoHasFlag(bookmarkVO.getWhoHasFlag());
							attributeVO.setValue(bookmarkVO.getValue());
							bookmarkData.add(attributeVO);

						});
			});

		} catch (Exception e) {
			throw new CEFTException(e);
		}
		return bookmarkData;
	}

    public boolean deleteBookmark(final String userId,final Long bookmarkId) {
        boolean deleteFlag = false;
        try {
        	Bookmark bookmark=bookmarkRepository.findByUserIdAndKey(userId, bookmarkId);
            
        	deleteFlag = (0 != bookmarkRepository.deleteSoftBookmarkByUserIdAndKey(userId, bookmarkId));
        	if( deleteFlag && bookmark.getParentId()==null  ) {
            	int deleted= bookmarkRepository.deleteTempBookmarksOfOriginal(userId, bookmarkId);
            	LOGGER.debug("Temp Bookmarks of Original Bookmark deleted :{}", deleted);
            }
        } catch (Exception e) {
            throw new DerivzApplicationException(e, DerivzDAOLayerException.FAILED_SEARCH_DELETE_LIST);
        }
        return deleteFlag;
    }

    public boolean saveUserSettingColumns(final String userId, final String fieldKeysCSV, final String settingsName) {
        LOGGER.debug("BookmarkServiceImpl::saveUserSettingColumns() ");
        boolean savedFlag = false;
        try {
            Bookmark userSearchList = new Bookmark();
            userSearchList.setName(settingsName);
            userSearchList.setType(DerivzCommonConstants.SETTINGS_TYPE_LIST);
            userSearchList.setUserId(userId);
            userSearchList.setCriteria(fieldKeysCSV);
            userSearchList.setLastSelected(1);
            userSearchList.setUpdatedTime(new Date());

            // Repository call to persist the data into database for user settings list
            final Bookmark newBookmarkList = bookmarkRepository.save(userSearchList);
            savedFlag = (null != newBookmarkList);
        } catch (Exception e) {
            throw new DerivzApplicationException(e, DerivzDAOLayerException.FAILED_SETTINGS_SAVE_LIST);
        }
        return savedFlag;
    }

    public Boolean updateSettingsColumnList(final Long userSettingsListKey, final String fieldKeysCSV) {
        LOGGER.debug("BookmarkServiceImpl::updateSettingsColumnList() ");
        Boolean updateFlag = false;
        try {
            final Integer x = bookmarkRepository.updateUserSettingsList(userSettingsListKey, fieldKeysCSV, new Date());
            if (DerivzCommonConstants.INTERGER_ONE == x) {
                updateFlag = true;
            }
        } catch (Exception e) {
            throw new DerivzApplicationException(e, DerivzDAOLayerException.FAILED_SETTINGS_GET_DATA);
        }
        return updateFlag;
    }

    public Bookmark findUserSettingsColumns(final String userId) {
        LOGGER.debug("BookmarkServiceImpl::findUserSettingsColumns() ");
        Bookmark settingsColumnList = new Bookmark();
        try {
            settingsColumnList = bookmarkRepository.findByUserIdAndType(userId,
                    DerivzCommonConstants.SETTINGS_TYPE_LIST);
        } catch (Exception e) {
            throw new DerivzApplicationException(e, DerivzDAOLayerException.FAILED_SETTINGS_GET_DATA);
        }
        return settingsColumnList;
    }

    public List<Bookmark> getSearchCriteriaList(final String userId, final String listType) {
        LOGGER.debug("BookmarkServiceImpl::getSearchCriteriaList() ");
        List<Bookmark> searchCriteriaList = new LinkedList<>();
        try {
            searchCriteriaList = bookmarkRepository.findByUserIdAndListCatagoryOrderByupdatedTimeDesc(userId, listType);
            if (null != searchCriteriaList && !searchCriteriaList.isEmpty()) {
                final Bookmark userSearchList = searchCriteriaList.get(0);
                userSearchList.setLastSelected(DerivzCommonConstants.LAST_SELECTED_FLAG);
            }
        } catch (DerivzApplicationException dae) {
            throw new DerivzApplicationException(new Exception(), DerivzDAOLayerException.FAILED_RETRIEVE_BOOKMARKS);
        } catch (Exception e) {
            throw new DerivzApplicationException(e, DerivzDAOLayerException.FAILED_SETTINGS_SAVE_LIST);
        }
        return searchCriteriaList;
    }

    @SuppressWarnings("rawtypes")
	public boolean saveUserSearch(final String userId, final String listType, final List<SearchFieldVO> criteriaList, final String searchName) {
        boolean savedFlag = false;
        try {
            Bookmark userSearchList = new Bookmark();
            userSearchList.setLastSelected(1);
            userSearchList.setName(null != searchName ? searchName : DerivzCommonConstants.DEFAULT_SEARCH_LIST_NAME);
            userSearchList.setType(listType);
            userSearchList.setUserId(userId);
            userSearchList.setCriteria(formatCriteriaObject(criteriaList));
            userSearchList.setUpdatedTime(new Date());
            final Bookmark newList = bookmarkRepository.save(userSearchList);
            savedFlag = (null != newList);
        } catch (Exception e) {
            throw new DerivzApplicationException(e, DerivzDAOLayerException.FAILED_SETTINGS_SAVE_LIST);
        }
        return savedFlag;

    }

    @SuppressWarnings("rawtypes")
    private String formatCriteriaObject(final List<SearchFieldVO> criteriaList) {
        String jsonResp = null;
        try {
            final Map<String, SearchFieldVO> criteriaMap = criteriaList.stream().collect(Collectors
                    .toMap(searchFieldVO -> searchFieldVO.getKey().toString(), searchFieldVO -> searchFieldVO));

            final ObjectMapper mapper = new ObjectMapper();
            jsonResp = mapper.writeValueAsString(criteriaMap);
        } catch (Exception e) {
            throw new DerivzApplicationException(e, DerivzDAOLayerException.FAILED_SETTINGS_SAVE_LIST);
        }
        return jsonResp;
    }

    public boolean deleteSearchList(final String userId, final String listType, final String listName) {
        LOGGER.debug("BookmarkServiceImpl::deleteSearchList() ");
        boolean deleteFlag = false;
        try {
            deleteFlag = bookmarkRepository.deleteByUserIdAndListTypeAndListName(userId, listType, listName);
        } catch (Exception e) {
            throw new DerivzApplicationException(e, DerivzDAOLayerException.FAILED_SEARCH_DELETE_LIST);
        }
        return deleteFlag;
    }

    public boolean shareUserBookmark(final String userId, final String searchName, final Long sharedBookmarkId) {
        Boolean updateFlag = false;
        try {
            final Bookmark sharedBookmark =bookmarkRepository.findByUserIdAndKey(userId,sharedBookmarkId);
            final Bookmark newBookmark = new Bookmark();
            newBookmark.setCriteria(sharedBookmark.getCriteria());
            newBookmark.setUserId(userId);
            newBookmark.setLastSelected(1);
            newBookmark.setName(searchName);
            newBookmark.setType(DerivzCommonConstants.SEARCH_TYPE_LIST);
            newBookmark.setUpdatedTime(new Date());
            final Bookmark newList = bookmarkRepository.save(newBookmark);
            updateFlag = (null != newList);
        } catch (Exception e) {
            throw new DerivzApplicationException(e, DerivzDAOLayerException.FAILED_SHARING_BOOKMARK_DATA);
        }
        return updateFlag;
    }

	@SuppressWarnings("rawtypes")
	private void persistCEFTBookmarkToVoyager(Long bookmarkId, String soeid, List<String[]> rowList, final List<RatingFieldVO> ratingRangeFeilds, List<String[]> tenorRangeList) {
		
        try(Connection conn = jdbcTemplate.getDataSource().getConnection()){
        	StringBuilder sb = new StringBuilder();
        	sb.append(DerivzDBConstants.CALL_PROC).append(DerivzDBConstants.SCHEMA_VOYAGER).append(".").append(DerivzDBConstants.SP_PERSIST_CEFT_BOOKMARK_TO_VOYAGER).append(" (?,?,?,?,?) }");
        	
			
            try (SQLServerCallableStatement cs =(SQLServerCallableStatement) conn.prepareCall(sb.toString())) {
                
                this.prepareInputParameter("INPUT_DATA",cs,rowList);
                cs.setString("SOEID", soeid);
                cs.setLong("BOOKMARKID", bookmarkId);
                this.preapreRangOfField(cs,ratingRangeFeilds);
                this.prepareInputParameter("TENOR",cs,tenorRangeList);
                cs.execute();
            }
        } catch (SQLException e) {
            throw new DerivzApplicationException(e, DerivzDAOLayerException.FAILED_SEARCH_PROCEDURE);
        }
    }
	
	private void prepareInputParameter(String inputName,SQLServerCallableStatement cs, List<String[]> rowList) throws SQLServerException {
		
		SQLServerDataTable sourceDataTable = new SQLServerDataTable();
		sourceDataTable.setTvpName(DerivzDBConstants.SCHEMA_CEFT + "." + DerivzDBConstants.IP_INPUT_PARAMETERS);
		sourceDataTable.addColumnMetadata("field", java.sql.Types.VARCHAR);
		sourceDataTable.addColumnMetadata("node", java.sql.Types.VARCHAR);
		sourceDataTable.addColumnMetadata("filter_value", java.sql.Types.VARCHAR);
		sourceDataTable.addColumnMetadata("conditions", java.sql.Types.VARCHAR);
		sourceDataTable.addColumnMetadata("who_has_flag", java.sql.Types.INTEGER);

        for (String[] indValues : rowList) {
            sourceDataTable.addRow(indValues[0], indValues[1], indValues[2], indValues[3],Integer.parseInt(indValues[4]));
        }
        cs.setStructured(inputName, DerivzDBConstants.SCHEMA_CEFT + "." + DerivzDBConstants.IP_INPUT_PARAMETERS, sourceDataTable);
	}

	@SuppressWarnings("rawtypes")
	private void preapreRangOfField ( SQLServerCallableStatement cs,final List<RatingFieldVO> listOfRangeField) throws SQLServerException {
	      SQLServerDataTable sourceDataTable = new SQLServerDataTable();
	      sourceDataTable.addColumnMetadata("rating_value1", java.sql.Types.INTEGER);
	      sourceDataTable.addColumnMetadata("rating_value2", java.sql.Types.INTEGER);
	      sourceDataTable.addColumnMetadata("issuer_flag", java.sql.Types.VARCHAR);
	      sourceDataTable.addColumnMetadata("and_or_flag", java.sql.Types.VARCHAR);
	      sourceDataTable.addColumnMetadata("seq", java.sql.Types.INTEGER);
	      
	      for (RatingFieldVO indValues : listOfRangeField) {
	          sourceDataTable.addRow(indValues.getRatingStart(), indValues.getRatingEnd(), indValues.getIssuerFlag(), indValues.getAndOr(), indValues.getSeq());
	      }
	      cs.setStructured("Rating_Data",
	    	        DerivzDBConstants.SCHEMA_CEFT + "." + DBConstants.IP_INPUT_RATING_VARIABLE,
	    	        sourceDataTable);
	  }

	public VoyagerLinkResponse getDatasetId(final User user, final String datasetTypeName) {
		ResultSet rs = null;
		StringBuilder sb = new StringBuilder();
    	sb.append(DerivzDBConstants.CALL_PROC).append(DerivzDBConstants.SCHEMA_VOYAGER).append(".").append(DerivzDBConstants.SP_GET_CURRENT_DATASETID).append(" (?,?) }");
		try (Connection conn = jdbcTemplate.getDataSource().getConnection(); CallableStatement cs = conn.prepareCall(sb.toString())) {
			cs.setString("SOEID", user.getSoeid());
			cs.setString("datasetTypeName", datasetTypeName);
			final String token = user.getToken();
			boolean executed = cs.execute();
			Integer datasetId = 0;
			if (executed) {
				rs = cs.getResultSet();
				rs.next();
				datasetId = rs.getInt("dataset_id");
				String navigationURL = voyagerConfig.getHostname() + ":" + voyagerConfig.getPort() + "/?token=" + token + "&datasetId=" + datasetId + "&soeId=" + user.getSoeid();
				return new VoyagerLinkResponse(voyagerConfig.getHostname(), voyagerConfig.getPort(), token,	navigationURL, datasetId);
			}
			return new VoyagerLinkResponse(voyagerConfig.getHostname(), voyagerConfig.getPort(), "", "-1", datasetId);
		} catch (SQLException e) {
			throw new DerivzApplicationException(e, DerivzDAOLayerException.FAILED_SEARCH_PROCEDURE);
		} finally {
			DbUtils.closeQuietly(rs);
		}
	}
	
	@Override
	public Boolean deleteAllTempBookmarkByUserId(String userId) {
		 boolean deleteFlag = false;
	        try {
	            deleteFlag = (0 != bookmarkRepository.deleteSoftTempBookmarkByUserId(userId));
	        } catch (Exception e) {
	            throw new DerivzApplicationException(e, DerivzDAOLayerException.FAILED_SEARCH_DELETE_LIST);
	        }
	        return deleteFlag;
	}

	@Override
	public List<Bookmark> restoreTempBookmarkByUserId(String userId) {
		 LOGGER.debug("BookmarkServiceImpl::restoreTempBookmarkByUserId() ");
	        List<Bookmark> searchCriteriaList = new LinkedList<>();
	        try {
	            searchCriteriaList = bookmarkRepository.getTempBookmarksToRestore(userId);
	            int updatedCount= bookmarkRepository.restoreTempBookmarkByUserId(userId);
	            LOGGER.debug("Restored temp Bookmarks : {}", updatedCount); 
	        } catch (DerivzApplicationException dae) {
	            throw new DerivzApplicationException(new Exception(), DerivzDAOLayerException.FAILED_RETRIEVE_BOOKMARKS);
	        } catch (Exception e) {
	            throw new DerivzApplicationException(e, DerivzDAOLayerException.FAILED_SETTINGS_SAVE_LIST);
	        }
	        return searchCriteriaList;
	}
}