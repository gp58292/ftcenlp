package com.citi.aqua.derivz.data.cache.eh;

public enum StaticCacheKeys {

	STATIC_COMPONENT_DATA,RESULT_COLUMNS
}
