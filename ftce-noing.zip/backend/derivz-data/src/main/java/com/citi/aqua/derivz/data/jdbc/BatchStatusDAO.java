package com.citi.aqua.derivz.data.jdbc;

import java.util.List;

import com.citi.aqua.derivz.dto.BatchStatusResponseDTO;

public interface BatchStatusDAO {
	
	public List<BatchStatusResponseDTO> callDailyBatchStatusReportProc(String cobDate);

}
