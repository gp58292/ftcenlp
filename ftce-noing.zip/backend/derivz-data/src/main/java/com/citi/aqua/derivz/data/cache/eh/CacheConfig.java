package com.citi.aqua.derivz.data.cache.eh;

import static org.springframework.util.Assert.notNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.ehcache.EhCacheCacheManager;
import org.springframework.cache.ehcache.EhCacheManagerFactoryBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableCaching
public class CacheConfig {

//	private static final Logger LOGGER = LoggerFactory.getLogger(CacheConfig.class);
//	private static final String CACHE_FILE_NAME = "ehcache.xml";
//
//	private static EhCacheManagerFactoryBean cmfb;
//
//	public CacheConfig() {
//		cmfb = new EhCacheManagerFactoryBean();
//		notNull(cmfb, "Failed to instanciate EhCache factory!");
//		// cmfb.setConfigLocation(CacheConfig.class.getResource(CACHE_FILE_NAME));
//		//.setConfigLocation(new ClassPathResource(CACHE_ID));
//		cmfb.setShared(true);
//		if (LOGGER.isDebugEnabled())
//			LOGGER.debug("Chache factory created of :" + CACHE_FILE_NAME);
//	}
//
//	@Bean
//	public CacheManager cacheManager() {
//		return new EhCacheCacheManager(cmfb.getObject());
//	}
//
//	@Bean
//	public EhCacheManagerFactoryBean ehCacheCacheManager() {
//		return cmfb;
//	}
//
//	public void setShared(boolean value) {
//		ehCacheCacheManager().setShared(value);
//		if (LOGGER.isDebugEnabled())
//			LOGGER.debug("Chache factory shared status changed to :" + CACHE_FILE_NAME);
//	}
}
