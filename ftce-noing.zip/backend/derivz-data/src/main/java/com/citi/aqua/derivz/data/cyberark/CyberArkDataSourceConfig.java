package com.citi.aqua.derivz.data.cyberark;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import com.microsoft.sqlserver.jdbc.SQLServerDataSource;

import javapasswordsdk.exceptions.PSDKException;

@Component
public class CyberArkDataSourceConfig {

	@Autowired
	private DataSourceProperties dataSourceProperties;
	
	@Autowired
	private CyberArkProperties cyberArkProperties;
	
	
	private static final Logger LOGGER = LoggerFactory.getLogger(CyberArkDataSourceConfig.class);
	
	@Bean
	@Primary
	@Profile({SpringProfiles.PROD,SpringProfiles.UAT})
	public DataSource dataSource() {
		LOGGER.info("Creating data source for UAT or PRODUCTION :: {}",this.dataSourceProperties.getDriverClassName());
		SQLServerDataSource dataSource =new CyberArkDataSource(cyberArkProperties);
		try {
			    dataSource.setURL(this.dataSourceProperties.getUrl());
			    dataSource.setUser(this.dataSourceProperties.getUsername());
			    String password=CyberArkFactory.getPassword(cyberArkProperties.getAppId(), cyberArkProperties.getSafe(), cyberArkProperties.getObject(), cyberArkProperties.getReason());
			    dataSource.setPassword(password);
			    LOGGER.info("Successfully fetched password from CyberArk:: {}",password);
			    //DriverManagerDataSource dataSource = new DriverManagerDataSource(); -- This also work with Input Table as parameter
			    
		} catch (PSDKException | InterruptedException  e) {
			LOGGER.error("*****************************Failed to create data source using *************************",e);
			Thread.currentThread().interrupt();
		} catch (Exception  e) {
			LOGGER.error("*****************************Failed to create data source using Final Exception *************************",e);
		} 
		return dataSource;
	}
	
	@Bean
	@Profile({"!"+SpringProfiles.PROD , "!"+SpringProfiles.UAT})
	public DataSource dataSourceOther() {
		LOGGER.info("Creating data source as Primary Failed to make::{}",this.dataSourceProperties.getDriverClassName());
		SQLServerDataSource dataSource =new SQLServerDataSource();
		try {
		    dataSource.setURL(this.dataSourceProperties.getUrl());
		    dataSource.setUser(this.dataSourceProperties.getUsername());
		    dataSource.setPassword(this.dataSourceProperties.getPassword());
		    return dataSource;
		} catch (Exception e) {
			LOGGER.error("*****************************Finally Failed to create data source*************************",e);
		}
		LOGGER.info("No data source available....");
		return dataSource;
	}
	
}
