package com.citi.aqua.derivz.data.cyberark;


import java.sql.Connection;
import java.sql.SQLException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.microsoft.sqlserver.jdbc.SQLServerDataSource;



public class CyberArkDataSource extends SQLServerDataSource {

	private static final Logger LOGGER = LoggerFactory.getLogger(CyberArkDataSource.class);
	
    
    private transient CyberArkProperties cyberArkProperties;
    
    public CyberArkDataSource(CyberArkProperties cyberArkProperties) {
    		this.cyberArkProperties=cyberArkProperties;
    }
    

	@Override
	public Connection getConnection() {
		Connection conn = null;
		try {
			conn=super.getConnection();
		} catch (Exception e) {
			LOGGER.info("CyberArk -> Retry connect by refreshing password.");
			try {
				conn=createConnectionWithRetry(3);
			} catch (SQLException sqlExc) {
				LOGGER.error("CyberArk -> Retry: Error while connecting to DB with property : ",sqlExc);
			}
		}
		return conn;
		
	}

	private Connection createConnectionWithRetry(int retry) throws SQLException {
		try {
			String password = CyberArkFactory.getPassword(cyberArkProperties.getAppId(), cyberArkProperties.getSafe(), cyberArkProperties.getObject(), "Refresh DataSource Password.");
			this.setPassword(password);
			return super.getConnection();
		} catch (Exception e) {
			LOGGER.warn((new StringBuilder()).append("CyberArk -> Retry:").append(retry)
					.append(". Error while connecting to DB with property : ").toString());
			e.printStackTrace();
			if (--retry < 0)
				throw new SQLException("CyberArk -> Error while connecting to DB with property : ",e.getCause());
			else
				return createConnectionWithRetry(retry);
			

		}
	}

}
