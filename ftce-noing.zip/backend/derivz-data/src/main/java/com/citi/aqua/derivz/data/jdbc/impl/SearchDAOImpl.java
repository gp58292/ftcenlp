package com.citi.aqua.derivz.data.jdbc.impl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.stream.Collectors;
import org.apache.commons.dbutils.DbUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import com.citi.aqua.derivz.commons.exceptions.DerivzApplicationException;
import com.citi.aqua.derivz.commons.exceptions.DerivzDAOLayerException;
import com.citi.aqua.derivz.data.jdbc.SearchDAO;
import com.citi.aqua.derivz.dto.CollateralResponseDTO;
import com.citi.aqua.derivz.dto.ListDataResponseDTO;
import com.citi.aqua.derivz.model.DBConstants;
import com.citi.aqua.derivz.model.DerivzDBConstants;
import com.citi.aqua.derivz.model.DimAgreement;
import com.citi.aqua.derivz.vo.RatingFieldVO;
import com.citi.aqua.derivz.vo.UserDatasetVO;
import com.microsoft.sqlserver.jdbc.SQLServerCallableStatement;
import com.microsoft.sqlserver.jdbc.SQLServerDataTable;
import com.microsoft.sqlserver.jdbc.SQLServerException;

@Repository
public class SearchDAOImpl<T> implements SearchDAO {

	private static final Logger LOGGER = LoggerFactory.getLogger(SearchDAOImpl.class);

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public ListDataResponseDTO callMacDataRetrivalProc(final List<String[]> rowList,List<RatingFieldVO> listOfRangeField) {
		LOGGER.debug("SearchDAOImpl:: callMacDataRetrivalProc");
		final ListDataResponseDTO listDataResponseDTO = new ListDataResponseDTO();
		final List<DimAgreement> dimAgreementList = new LinkedList<>();
		ResultSet rs = null;
		try(Connection conn = jdbcTemplate.getDataSource().getConnection()) {
			
			SQLServerDataTable sourceDataTable = this.setIPSourceDataTable(rowList);
			String sql = DBConstants.CALL_PROC + DBConstants.SCHEMA_CEFT + "." + DBConstants.USP_DERIV_MAC_DATA_RETRIEVAL + " (?,?,?,?) }";
			try (CallableStatement cs = conn.prepareCall(sql)) {
				((SQLServerCallableStatement) cs).setStructured("INPUT_DATA",DBConstants.SCHEMA_CEFT + "." + DBConstants.IP_INPUT_PARAMETERS, sourceDataTable);
				((SQLServerCallableStatement) cs).setStructured("Rating_Data",DBConstants.SCHEMA_CEFT + "." + DBConstants.IP_INPUT_RATING_VARIABLE, setRangOfFieldDataTable(listOfRangeField));
				cs.registerOutParameter("COUNT", Types.BIGINT);
				cs.registerOutParameter("COB_DATE", Types.VARCHAR);
				boolean resultSetReturned = cs.execute();
				if (resultSetReturned) {
					rs = cs.getResultSet();
					while (rs.next()) {
						DimAgreement dimAgreement = new DimAgreement();
						dimAgreement.setAgreementKey(rs.getLong("agreement_key"));
						dimAgreement.setAgreementId(rs.getInt(DerivzDBConstants.AGREEMENT_ID_1));
						dimAgreement.setCsaDescription(rs.getString(DerivzDBConstants.CSA_DESCRIPTION_1));
						dimAgreement.setAddress(rs.getString("address"));
						dimAgreement.setAutoEarlyTerminationFlag(rs.getString("auto_early_termination_flag"));
						dimAgreement.setCalculationAgent(rs.getString("calculation_agent"));
						dimAgreement.setCallFrequency(rs.getString("call_frequency"));
						dimAgreement.setCallMonth(rs.getInt("call_month"));
						dimAgreement.setCallday1Eom(rs.getString("callday1_eom"));
						dimAgreement.setCallday1Ofmonth(rs.getInt("callday1_ofmonth"));
						dimAgreement.setCallday2Eom(rs.getString("callday2_eom"));
						dimAgreement.setCallday2Ofmonth(rs.getInt("callday2_ofmonth"));
						dimAgreement.setCapfloorAddendum(rs.getString("capfloor_addendum"));
						dimAgreement.setCitiThreshold(rs.getString("citi_threshold"));
						dimAgreement.setClearingAgreement(rs.getString("clearing_agreement"));
						dimAgreement.setCloseoutAmountProtocol(rs.getString("closeout_amount_protocol"));
						dimAgreement.setCloseoutNettingEnforcabilityFlag(rs.getString("closeout_netting_enforcability_flag"));
						dimAgreement.setCommonCustodian(rs.getString("common_custodian"));
						dimAgreement.setConsentToSubstitution(rs.getString("consent_to_substitution"));
						dimAgreement.setContact(rs.getString("contact")); //
						dimAgreement.setCounterpartyMultibranch(rs.getString("counterparty_multibranch"));
						dimAgreement.setCounterpartyName(rs.getString("counterparty_name"));
						dimAgreement.setCountryName(rs.getString("country_name"));
						dimAgreement.setCpBorrowingThreshold(rs.getDouble("cp_borrowing_threshold"));
						dimAgreement.setCpMarginType(rs.getString("cp_margin_type"));
						dimAgreement.setCpSpecifiedEntities(rs.getString("cp_specified_entities"));
						dimAgreement.setCpSpecifiedIndebtedness(rs.getString("cp_specified_indebtedness"));
						dimAgreement.setCpSpecifiedTransactions(rs.getString("cp_specified_transactions"));
						dimAgreement.setCpTerminationCurrency(rs.getString("cp_termination_currency"));
						dimAgreement.setCpThreshold(rs.getDouble("cp_threshold"));
						dimAgreement.setCpTransactionThreshold(rs.getDouble("cp_transaction_threshold"));
						dimAgreement.setCpTypeOfBorrowingThreshold(rs.getString("cp_type_of_borrowing_threshold"));
						dimAgreement.setCsaMarginType(rs.getString("csa_margin_type"));
						dimAgreement.setCsaStatus(rs.getString("csa_status"));
						dimAgreement.setCurrency(rs.getString("currency"));
						dimAgreement.setCpCustodianRequired(rs.getString("cp_custodian_required"));
						dimAgreement.setCustodyBankName(rs.getString("custody_bank_name"));
						dimAgreement.setCustomerName(rs.getString("customer_name"));
						dimAgreement.setDerivsProvision(rs.getString("derivs_provision"));
						dimAgreement.setDisputeMechanism(rs.getString("dispute_mechanism"));
						dimAgreement.setEntity(rs.getString("entity"));
						dimAgreement.setEntryDate(rs.getTimestamp("entry_date"));
						dimAgreement.setExchangeclearedAgreement(rs.getString("exchangecleared_agreement"));
						dimAgreement.setExtension(rs.getString("extension"));
						dimAgreement.setFatca(rs.getString("fatca"));
						dimAgreement.setFax(rs.getString("fax"));
						dimAgreement.setFileNumber(rs.getString("file_number"));
						dimAgreement.setFxProvision(rs.getString("fx_provision"));
						dimAgreement.setGoverningLaw(rs.getString("governing_law"));
						dimAgreement.setFxoProvision(rs.getString("fxo_provision"));
						dimAgreement.setIncorporatedCountry(rs.getString("incorporated_country"));
						dimAgreement.setIntercompanyType(rs.getString("intercompany_type"));
						dimAgreement.setLastModified(rs.getTimestamp("last_modified"));
						dimAgreement.setLinkMrnccdOutofscopeTrades(rs.getString("link_mrnccd_outofscope_trades"));
						dimAgreement.setMaDate(rs.getTimestamp("ma_date"));
						dimAgreement.setMandatoryMarkFrequency(rs.getString("mandatory_mark_frequency"));
						dimAgreement.setMarginEffectiveDate(rs.getTimestamp("margin_effective_date"));
						dimAgreement.setMarktomarketAgent(rs.getString("marktomarket_agent"));
						dimAgreement.setMasterAgreement(rs.getString("master_agreement"));
						dimAgreement.setMasterAgreementStatus(rs.getString("master_agreement_status"));
						dimAgreement.setMasterAgreementVersion(rs.getString("master_agreement_version"));
						dimAgreement.setMiniTransferAmt(rs.getDouble("mini_transfer_amt"));
						dimAgreement.setMirrorAgreementid(rs.getInt("mirror_agreementid"));
						dimAgreement.setMrnccdCompliance(rs.getString("mrnccd_compliance"));
						dimAgreement.setMnemonic(rs.getString("mnemonic"));
						dimAgreement.setMtmCurrency(rs.getString("mtm_currency"));
						dimAgreement.setMultiBranchMargining(rs.getString("multi_branch_margining"));
						dimAgreement.setMultiCurrencyMargining(rs.getString("multi_currency_margining"));
						dimAgreement.setNegotiationStartdate(rs.getTimestamp("negotiation_startdate"));
						dimAgreement.setNetting(rs.getString("netting"));
						dimAgreement.setParentChild(rs.getString("parent_child"));
						dimAgreement.setPartyAssociate(rs.getString("party_associate"));
						dimAgreement.setPartyBorrowingThreshold(rs.getDouble("party_borrowing_threshold"));
						dimAgreement.setPartyCustodianRequired(rs.getString("party_custodian_required"));
						dimAgreement.setPartyLegalEntity(rs.getString("party_legal_entity"));
						dimAgreement.setPartyMultibranch(rs.getString("party_multibranch"));
						dimAgreement.setPartyPseMarginReduction(rs.getString("party_pse_margin_reduction"));
						dimAgreement.setPartySpecifiedEntities(rs.getString("party_specified_entities"));
						dimAgreement.setPartySpecifiedIndebtedness(rs.getString("party_specified_indebtedness"));
						dimAgreement.setPartySpecifiedTransactions(rs.getString("party_specified_transactions"));
						dimAgreement.setPartyTerminationCurrency(rs.getString("party_termination_currency"));
						dimAgreement.setPartyTransactionThreshold(rs.getDouble("party_transaction_threshold"));
						dimAgreement.setPartyTypeOfBorrowingThreshold(rs.getString("party_type_of_borrowing_threshold"));
						dimAgreement.setPbgIndicator(rs.getString("pbg_indicator"));
						dimAgreement.setPledgor(rs.getString(DerivzDBConstants.PLEDGOR));
						dimAgreement.setPseMarginReduction(rs.getString("pse_margin_reduction"));
						dimAgreement.setPseMarginLastModified(rs.getTimestamp("pse_margin_last_modified"));
						dimAgreement.setRestrictionsOnCollateral(rs.getString("restrictions_on_collateral"));
						dimAgreement.setSecurityAgreementdate(rs.getDate("security_agreementdate"));
						dimAgreement.setSme(rs.getString("s_m_e"));
						dimAgreement.setSecurityCallDayOfWeek(rs.getString("security_call_day_Of_week"));
						dimAgreement.setSecurityTypeOfAccount(rs.getString("security_type_of_account"));
						dimAgreement.setSftBaselNetting(rs.getString("sft_basel_netting"));
						dimAgreement.setShelf(rs.getString("shelf"));
						dimAgreement.setSixCApplies(rs.getString("six_c_applies"));
						dimAgreement.setSixcApplied(rs.getString("sixc_applied"));
						dimAgreement.setTelephone(rs.getString("telephone"));
						dimAgreement.setTendApplies(rs.getString("tend_applies"));
						dimAgreement.setTerminationDate(rs.getDate("termination_date"));
						dimAgreement.setTerminationTiming(rs.getString("termination_timing"));
						dimAgreement.setTerminationType(rs.getString("termination_type"));
						dimAgreement.setThirdPartyCustFlag(rs.getString("third_party_cust_flag"));
						dimAgreement.setThresholdAmount(rs.getDouble("threshold_amount"));
						dimAgreement.setThresholdBasis(rs.getString("threshold_basis"));
						dimAgreement.setThresholdCurrency(rs.getString("threshold_currency"));
						dimAgreement.setTriggerEvent(rs.getString("trigger_event"));
						dimAgreement.setTriparty(rs.getString("triparty"));
						dimAgreement.setTrueSegregation(rs.getString("true_segregation"));
						dimAgreement.setUseBillingfeeAsCollateral(rs.getString("use_billingfee_as_collateral"));
						dimAgreement.setUseCouponAsCollateral(rs.getString("use_coupon_as_collateral"));
						dimAgreement.setUseExcessVmAsImCollateral(rs.getString("use_excess_vm_as_im_collateral"));
						dimAgreement.setUseFeeAsCollateral(rs.getString("use_fee_as_collateral"));
						dimAgreement.setUsePaiAsCollateral(rs.getString("use_pai_as_collateral"));
						dimAgreement.setVarEligible(rs.getString("var_eligible"));
						dimAgreement.setVmCollateralInCashOnly(rs.getString("vm_collateral_in_cash_only"));

						dimAgreementList.add(dimAgreement);
					}
					Long count = cs.getLong("COUNT");
					String cobDate = cs.getString("COB_DATE");
					
					listDataResponseDTO.setCobDate(cobDate);
					listDataResponseDTO.setCount(count);
					listDataResponseDTO.setDimAgreementList(dimAgreementList);
				}
			}
			return listDataResponseDTO;

		} catch (SQLException e) {
			LOGGER.error("SearchDAOImpl::callMacDataRetrivalProc() ::Error" + e, e);
			throw new DerivzApplicationException(e, DerivzDAOLayerException.FAILED_SEARCH_PROCEDURE);
		} finally {
			DbUtils.closeQuietly(rs);
		}
	}


	@Override
	public List<CollateralResponseDTO> callCollateralLookupProc(final List<String[]> rowList) {
		LOGGER.debug("SearchDAOImpl:: callCollateralLookupProc");
		List<CollateralResponseDTO> collateralLookupList = new LinkedList<>();
		ResultSet rs = null;
		try(Connection conn = jdbcTemplate.getDataSource().getConnection()) {
			SQLServerDataTable sourceDataTable = this.setIPSourceDataTable(rowList);

			try (CallableStatement cs = conn.prepareCall(DerivzDBConstants.CALL_PROC + DerivzDBConstants.SCHEMA_CEFT + "."
					+ DerivzDBConstants.USP_DERIV_COLLATERAL_LOOKUP_RETRIEVAL + " (?) }")) {
				((SQLServerCallableStatement) cs).setStructured(1,
						DerivzDBConstants.SCHEMA_CEFT + "." + DerivzDBConstants.IP_INPUT_PARAMETERS, sourceDataTable);
				boolean resultSetReturned = cs.execute();

				if (resultSetReturned) {
					rs = cs.getResultSet();
					while (rs.next()) {
						CollateralResponseDTO data = new CollateralResponseDTO();
						data.setCollateralTypeName(rs.getString("collateral_type_name"));
						data.setCountryCode(rs.getString("country_code"));
						data.setCurrencyCode(rs.getString("currency_code"));
						data.setGuarantor(rs.getString("guarantor"));
						data.setIncludeExclude(rs.getString("include_exclude"));
						data.setInclusionIndicator(rs.getString("inclusion_indicator"));
						data.setIndexExcluded(rs.getString("index_excluded"));
						data.setIndexName(rs.getString("index_name"));
						data.setIndustryClass(rs.getString("industry_class"));
						data.setIndustryCode(rs.getString("industry_code"));
						data.setIsinCode(rs.getString("isin_code"));
						data.setMarketSectorCode(rs.getString("market_sector_code"));
						data.setSectypeLevel1Code(rs.getString("sectype_level1_code"));
						data.setSectypeLevel2Code(rs.getString("sectype_level2_code"));
						data.setSectypeLevel3Code(rs.getString("sectype_level3_code"));
						data.setSmci(rs.getString("smci"));
						data.setSmcp(rs.getString("smcp"));
						data.setStateCode(rs.getString("state_code"));
						data.setTypeOfCollateral(rs.getString("type_of_collateral"));
						collateralLookupList.add(data);
					}
				}
			}
			collateralLookupList= collateralLookupList.stream().limit(100000L).collect(Collectors.toList());
			
			return collateralLookupList;
		} catch (SQLException e) {
			LOGGER.error("SearchDAOImpl::callCollateralLookupProc() ::Error" + e, e);
			throw new DerivzApplicationException(e, DerivzDAOLayerException.FAILED_SEARCH_PROCEDURE);
		} finally {
			DbUtils.closeQuietly(rs);
		}
	}

		
	@Override
	public List<UserDatasetVO> callGetCurrentDatasetIdProc(final String soeId) {
		LOGGER.debug("SearchDAOImpl:: callGetCurrentDatasetIdProc::{}", soeId);
		final List<UserDatasetVO> userDatasetVOList = new LinkedList<>();
		ResultSet rs = null;
		try(Connection conn = jdbcTemplate.getDataSource().getConnection()) {
			String sql = DerivzDBConstants.CALL_PROC + DerivzDBConstants.SCHEMA_VOYAGER + "."+ DerivzDBConstants.SP_GET_CURRENT_DATASETID + DerivzDBConstants.PROC_ONE_ARG;
			try (SQLServerCallableStatement cs = (SQLServerCallableStatement) conn.prepareCall(sql)) {
				cs.setString(1, soeId);

				boolean resultSetReturned = cs.execute();
				if (resultSetReturned) {
					 rs = cs.getResultSet();
					while (rs.next()) {
						UserDatasetVO data = new UserDatasetVO();
						data.setDatasetId(rs.getInt("dataset_id"));
						data.setDisplayFlag(rs.getInt("display_flag"));
						data.setDisplayName(rs.getString("display_name"));
						data.setShortName(rs.getString("short_name"));
						userDatasetVOList.add(data);
					}
				}
			}
			return userDatasetVOList;
		} catch (SQLException e) {
			LOGGER.error("SearchDAOImpl::callGetCurrentDatasetIdProc() ::Error" + e, e);
			throw new DerivzApplicationException(e, DerivzDAOLayerException.FAILED_SEARCH_PROCEDURE);
		} finally {
			DbUtils.closeQuietly(rs);
		}
	}
	
	private SQLServerDataTable setPostingIPSourceDataTable (final List<Long> agreementKeyList) throws SQLServerException {
		SQLServerDataTable sourceDataTable = new SQLServerDataTable();
		sourceDataTable.addColumnMetadata("agreement_key", java.sql.Types.VARCHAR);
		agreementKeyList.stream().forEach(key -> {
			try {
				sourceDataTable.addRow(key.toString());
			} catch (SQLServerException e) {
				throw new DerivzApplicationException(e, DerivzDAOLayerException.FAILED_SEARCH_PROCEDURE);
			}
		});
		return sourceDataTable;
	}
	
	private SQLServerDataTable setIPSourceDataTable (final List<String[]> rowList) throws SQLServerException {
		SQLServerDataTable sourceDataTable = new SQLServerDataTable();
		sourceDataTable.addColumnMetadata("field", java.sql.Types.VARCHAR);
		sourceDataTable.addColumnMetadata("node", java.sql.Types.VARCHAR);
		sourceDataTable.addColumnMetadata("filter_value", java.sql.Types.VARCHAR);
		sourceDataTable.addColumnMetadata("conditions", java.sql.Types.VARCHAR);
		sourceDataTable.addColumnMetadata("who_has_flag", java.sql.Types.INTEGER);
		
		for (String[] indValues : rowList) {
			LOGGER.debug("SearchDAOImpl:: setIPSourceDataTable:: {}#{}#{}#{}#{}", indValues[0], indValues[1], indValues[2], indValues[3],Integer.parseInt(indValues[4]));
			sourceDataTable.addRow(indValues[0], indValues[1], indValues[2], indValues[3], Integer.parseInt(indValues[4]));
		}
		
		return sourceDataTable;
	}
	
	private SQLServerDataTable setRangOfFieldDataTable (final List<RatingFieldVO> listOfRangeField) throws SQLServerException {
      SQLServerDataTable sourceDataTable = new SQLServerDataTable();
      sourceDataTable.addColumnMetadata("rating_value1", java.sql.Types.INTEGER);
      sourceDataTable.addColumnMetadata("rating_value2", java.sql.Types.INTEGER);
      sourceDataTable.addColumnMetadata("issuer_flag", java.sql.Types.VARCHAR);
      sourceDataTable.addColumnMetadata("and_or_flag", java.sql.Types.VARCHAR);
      sourceDataTable.addColumnMetadata("seq", java.sql.Types.INTEGER);
      
      for (RatingFieldVO indValues : listOfRangeField) {
          sourceDataTable.addRow(indValues.getRatingStart(), indValues.getRatingEnd(), indValues.getIssuerFlag(), indValues.getAndOr(), indValues.getSeq());
      }
      
      return sourceDataTable;
  }
	
	

	@Override
	public List<Map<String, Object>> callDataRetrivalProc(String tabsName, List<Long> agreementIdList,
			Boolean isFilterd, List<String[]> rowList) throws DerivzApplicationException {
		LOGGER.debug("SearchDAOImpl:: callPostingDataRetrivalProc::{}",isFilterd);
		final List<Map<String, Object>> resultListMap=new ArrayList<> ();
		try (Connection conn = jdbcTemplate.getDataSource().getConnection()) { 
			
			SQLServerDataTable sourceDataTable = new SQLServerDataTable();
							   sourceDataTable.addColumnMetadata("agreement_key", java.sql.Types.VARCHAR);
		   agreementIdList.stream().forEach(key -> {
				try {
					sourceDataTable.addRow(key.toString());
				} catch (SQLServerException e) {
					throw new DerivzApplicationException(e, DerivzDAOLayerException.FAILED_SEARCH_PROCEDURE);
				}
			});

			SQLServerDataTable 	criteriaSourceDataTable = new SQLServerDataTable();
								criteriaSourceDataTable.addColumnMetadata("field", java.sql.Types.VARCHAR);
								criteriaSourceDataTable.addColumnMetadata("node", java.sql.Types.VARCHAR);
								criteriaSourceDataTable.addColumnMetadata("filter_value", java.sql.Types.VARCHAR);
								criteriaSourceDataTable.addColumnMetadata("conditions", java.sql.Types.VARCHAR);
								criteriaSourceDataTable.addColumnMetadata("who_has_flag", java.sql.Types.INTEGER);
			if(rowList!=null) {
				for (String[] indValues : rowList) {
					LOGGER.debug("SearchDAOImpl:: callPostingDataRetrivalProc input : {} ", String.join(",", indValues));
					criteriaSourceDataTable.addRow(indValues[0], indValues[1], indValues[2], indValues[3],Integer.parseInt(indValues[4]));
				}
			}
			String sql="{CALL " + DerivzDBConstants.SCHEMA_CEFT + "."+ DerivzDBConstants.SP_GET_FACT_POSTING + " (?,?,?)}";
			try (SQLServerCallableStatement cs =
					(SQLServerCallableStatement) conn.prepareCall(sql)) {
				cs.setStructured(1,DerivzDBConstants.SCHEMA_CEFT + "." + DerivzDBConstants.POSTINGS_INPUT_PARAMETERS, sourceDataTable);
				cs.setInt(2,isFilterd?0:1);
				cs.setStructured(3,DerivzDBConstants.SCHEMA_CEFT + "." + DerivzDBConstants.IP_INPUT_PARAMETERS, criteriaSourceDataTable);

				boolean resultSetReturned = cs.execute();
				if (resultSetReturned) {
					ResultSet rs = cs.getResultSet();
					while (rs.next()) {
						Map<String,Object> resultMap=new TreeMap<String,Object>();
						
						
						resultListMap.add(resultMap);
					}
				}
			}
			return resultListMap;
		} catch (SQLException e) {
			LOGGER.error("SearchDAOImpl::callPostingDataRetrivalProc() ::Error" + e, e);
			throw new DerivzApplicationException(e, DerivzDAOLayerException.FAILED_SEARCH_PROCEDURE);
		} catch (Exception e) {
			LOGGER.error("SearchDAOImpl::callPostingDataRetrivalProc() ::Error" + e, e);
			throw new DerivzApplicationException(e, DerivzDAOLayerException.FAILED_SEARCH_PROCEDURE);
		}
	}

}