package com.citi.aqua.derivz.data.repository;

import java.sql.Timestamp;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.citi.aqua.derivz.model.BatchProcessAudit;
import com.citi.aqua.derivz.model.DerivzDBConstants;

@Repository
@Transactional
public interface BatchProcessAuditRepository extends CrudRepository<BatchProcessAudit, Long> {

	public BatchProcessAudit findByModule(String module);
	
	@Modifying
	@Query(value = "update  " + DerivzDBConstants.SCHEMA_CEFT + "." + DerivzDBConstants.TBL_BATCH_PROCESS_AUDIT + " set  cache_update_time =:cacheUpdatedTime where module= :module ", nativeQuery = true)
	public Integer updateCacheUpdatedTimeForModule(@Param("cacheUpdatedTime") final Timestamp cacheUpdatedTime, @Param("module") final String module);

}
