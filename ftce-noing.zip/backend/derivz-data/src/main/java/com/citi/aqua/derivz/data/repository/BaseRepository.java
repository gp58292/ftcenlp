package com.citi.aqua.derivz.data.repository;

import java.util.List;
import org.springframework.stereotype.Repository;
import com.citi.aqua.derivz.model.BaseEntity;

@Repository
public interface BaseRepository {

	public List<? extends BaseEntity> getDataset(String entity, String filterQuery, int maxResults);

	public List<? extends BaseEntity> findResultSet(final String entity, final String filterQuery);

}
