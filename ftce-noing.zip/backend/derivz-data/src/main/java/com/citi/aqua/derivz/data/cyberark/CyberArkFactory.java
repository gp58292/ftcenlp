package com.citi.aqua.derivz.data.cyberark;



import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javapasswordsdk.PSDKPassword;
import javapasswordsdk.PSDKPasswordRequest;
import javapasswordsdk.exceptions.PSDKException;

public class CyberArkFactory {
	private static final Logger LOGGER = LoggerFactory.getLogger(CyberArkFactory.class);

	public static void main(String[] args){
		if(args.length != 5){
			LOGGER.info("CyberArkFactory -> Invalid parameter count.");
			System.exit(1);
		}
		try {
			String password = getPassword(args[0], args[1], args[2], args[3]);
			if (password == null || password.length() == 0) {
				LOGGER.info("CyberArkFactory -> fetch password failed, please check CyberArk logs.");
				System.exit(1);
			}else {
				LOGGER.info("CyberArkFactory -> fetch password successfully.");
				LOGGER.info("Password For SNU :{}",password);
			}
		} catch (PSDKException | InterruptedException e) {
			LOGGER.info("CyberArkFactory -> fetch password failed, please check CyberArk logs.", e);
			System.exit(1);
			Thread.currentThread().interrupt();
		}
	}
	
	public static String getPassword(String appId, String safe, String object, String reason) throws InterruptedException, PSDKException{
			
			LOGGER.info("CyberArkFactory -> Fetching password with query [appId{}; Safe={}; Object={}]. Fetch reason: [{}]",appId,safe,object,reason);
		
			PSDKPasswordRequest passRequest = new PSDKPasswordRequest(); 
			PSDKPassword password = null; 
			passRequest.setAppID(appId); 
			passRequest.setSafe(safe); 
			passRequest.setObject(object); 
			passRequest.setReason(reason); 
			passRequest.setFailRequestOnPasswordChange(false); 
			boolean passRetrieved = false; 
			int retryIntervalms = 3000; 
			
			while (!passRetrieved) { 
				// Sending the request to get the password 
				password = javapasswordsdk.PasswordSDK.getPassword(passRequest); 
				if (password.getAttribute("PasswordChangeInProcess").equals("true")) 
				{ 
						Thread.sleep(retryIntervalms); 
				} else { 
					passRetrieved = true; 
				} 
			} 
			
			return password.getContent();
	}
}