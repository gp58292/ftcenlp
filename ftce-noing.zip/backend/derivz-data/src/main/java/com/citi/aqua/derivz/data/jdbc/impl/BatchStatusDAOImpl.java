package com.citi.aqua.derivz.data.jdbc.impl;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.dbutils.DbUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.citi.aqua.derivz.commons.exceptions.DerivzApplicationException;
import com.citi.aqua.derivz.commons.exceptions.DerivzDAOLayerException;
import com.citi.aqua.derivz.data.jdbc.BatchStatusDAO;
import com.citi.aqua.derivz.dto.BatchStatusResponseDTO;
import com.citi.aqua.derivz.model.DBConstants;
import com.microsoft.sqlserver.jdbc.SQLServerCallableStatement;

@Repository
public class BatchStatusDAOImpl implements BatchStatusDAO {

	private static final Logger LOGGER = LoggerFactory.getLogger(BatchStatusDAOImpl.class);

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public List<BatchStatusResponseDTO> callDailyBatchStatusReportProc(String cobDate) {
		LOGGER.debug("BatchStatusDAOImpl :: callDailyBatchStatusReportProc");
		List<BatchStatusResponseDTO> feedsList = new ArrayList<>();
		ResultSet rs = null;
		try (Connection conn = jdbcTemplate.getDataSource().getConnection()) {
			String sql = DBConstants.CALL_PROC + DBConstants.SCHEMA_AZ+ "."+ DBConstants.SCHEMA_ETL + "."
					+ DBConstants.SP_DAILY_BATCH_STATUS_AQUA_CEFT + DBConstants.PROC_ONE_ARG;
			try (SQLServerCallableStatement cs = (SQLServerCallableStatement) conn.prepareCall(sql)) {
				cs.setString(1, cobDate);
				boolean resultSetReturned = cs.execute();
				if (resultSetReturned) {
					rs = cs.getResultSet();
					while (rs.next()) {
						BatchStatusResponseDTO dto = new BatchStatusResponseDTO();
						dto.setSourceData(rs.getString(DBConstants.SOURCE_DATA));
						dto.setBau(rs.getString(DBConstants.BAU));
						dto.setSla(rs.getString(DBConstants.SLA));
						dto.setDbBusinessDate(rs.getDate(DBConstants.BUSINESS_DATE_IN_DATABASE));
						dto.setUiBusinessDate(rs.getDate(DBConstants.BUSINESS_DATE_CEFT_UI));
						dto.setDataExist(rs.getInt(DBConstants.DATA_EXIST));
						feedsList.add(dto);
					}
				}
			}
		} catch (SQLException e) {
			LOGGER.error("BatchStatusDAOImpl::callDailyBatchStatusReportProc() ::Error" + e, e);
			throw new DerivzApplicationException(e, DerivzDAOLayerException.FAILED_SEARCH_PROCEDURE);
		} finally {
			DbUtils.closeQuietly(rs);
		}

		return feedsList;
	}

}