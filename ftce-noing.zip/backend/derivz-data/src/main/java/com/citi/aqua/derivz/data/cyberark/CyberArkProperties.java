package com.citi.aqua.derivz.data.cyberark;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Service;

import lombok.Getter;
import lombok.Setter;

@ConfigurationProperties("cyberark")
@Service
public class CyberArkProperties {
	
	@Getter @Setter private String appId;   
    @Getter @Setter private String safe;        
    @Getter @Setter private String object;
    @Getter @Setter private String reason;

}
