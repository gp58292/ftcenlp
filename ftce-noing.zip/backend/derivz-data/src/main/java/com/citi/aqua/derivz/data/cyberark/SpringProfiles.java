package com.citi.aqua.derivz.data.cyberark;

public interface SpringProfiles {
	
	String PROD="prod";
	String UAT="uat";
	String SIT="sit";
	String DEV="dev";
	String WINDEV="windev";
	String TEST="test";
}