#! /bin/bash
# THIS SCRIPT REQUIRES 'BASH' SHELL to run correctly

# Runtime root /opt/aquacore_deploy/runtime/CBA
root=${p:ENV.RUNTIME_HOME}/${p:component/GROUP}

# Current running application link
# /opt/aquacore_deploy/runtime/CBA/ews-web
link=$root/${p:component/NAME}

# Check version
# Case1: 1.1.0     ==> source archive name: ews-web-1.1.0
# Case2: 1.2.0-RC2 ==> source archive name: ews-web-1.2.0-RC2
# Case3: 1.0.0-20161010_2108-2  ==> source archive name: ews-web-1.0.0-SNAPSHOT

arg=${p:version.name}

artifact="${p:component/NAME}-"
case_rc="-RC"
case_r="-"

#version=$arg
# Note: this is quick hack to replace with "" anything that is char or -

version="${arg//[a-z,-]/}"

dlink="${artifact}${version}"
  
  # 1. Check if no RC, then stop
  if [[ $arg =~ $case_rc ]]
  then
      echo "Lable is a Release Candidate version."
      echo "Value: ${version}. Link source name: ${dlink}"
  else
  
  # 2. Check if not a release version, then stop
	  if [[ ! $arg =~ $case_r ]]
	  then
	      echo "Lable is a Release version."
		  echo "Value: ${version}. Link source name: ${dlink}"
	  else

  # 3. All other types - assuming  ver-date_time-#"
	      #version="${arg%%-*}"
          dlink="${artifact}${version}-SNAPSHOT"
		  
	      echo "Lable is a snapshot version. "
		  echo "Value: ${version}. Link source name: ${dlink}"
      fi
  fi

# ${p:ENV.STAGE_HOME}/${p:component/GROUP}/${p:component/NAME}/<>
# E.g.: /opt/aquacore_deploy/runtime/CBA/ews-web/ews-web-1.0.0-SNAPSHOT
source=${p:ENV.STAGE_HOME}/${p:component/GROUP}/${p:component/NAME}/${dlink} 

echo source: $source
echo link: $link

if [ -e $root ]
then
    if  [ -d $root ]
    then
        echo application root verified
    else
        echo runtime root is not a directory - aborting
        exit -10
    fi
else
    mkdir -p $root
	echo WARNING: root directory does not exist - creating
fi

if  [ -d $link ]
then
    sh "rm -d  $link"
fi


if  [ -h $link ]
then
    rm $link
else
    if [ -e $link ]
    then
        echo runtime reference is not a link - aborting
        exit -100
    fi
fi

ln -s $source $link
